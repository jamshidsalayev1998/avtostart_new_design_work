@extends('layouts.admin')

@section('content')

    @php $i = ($data->currentPage() - 1) * $data->perPage() + 1 @endphp

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('lesson.index') }}">Toifalar</a></li>

            <li class="active">Mavzular</li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>

    <div class="container">

        <div class="row" style="margin-right: 12px;margin-left: 12px;">

            @if(session('message'))

                <div class="panel panel-default">

                    <div class="panel-body">

                        <div class="col-md-10">

                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                <div class="alert-icon">

                                    <span class="icon-checkmark-circle"></span>

                                </div>

                                {{ session('message') }}

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                            </div>

                        </div>

                    </div>

                </div>

            @endif

            <div class="block block-condensed">

                <br>

                <div class="block-content">



                    <table class="table table-striped table-bordered datatable-extended">

                        <thead>

                        <tr>

                            <th># </th>

                            <th>Dars nomi</th>

                            <th></th>

                            <th></th>

                        </tr>

                        </thead>

                        <tbody>



                        @foreach($data as $item)

                            <tr>

                                <td>{{ $i }}</td>

                                <td>{{$item->name_uz}}</td>

                                <td>

                                    <a href="{{ route('content.show', ['id' => $item->id]) }}" class="btn btn-default btn-icon">

                                        <i class="fa fa-eye"></i>

                                    </a>

                                </td>

                                <td>

                                    <a href="content/addcontent/{{ $item->id }}" class="btn btn-default btn-icon">

                                        <i class="icon-pencil"></i>

                                    </a>

                                </td>

                            </tr>

                            @php $i++ @endphp

                        @endforeach

                        </tbody>

                        {{ $data->links() }}



                    </table>



                </div>



            </div>



        </div>

    </div>

@endsection



