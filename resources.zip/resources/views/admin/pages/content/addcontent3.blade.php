@extends('layouts.admin')

@section('content')

<style type="text/css">

    .sticky {
      position: fixed;
      top: 0;
      width: 76%;

        z-index: 3 !important;
    }
    .jiji{
        padding: 10px;
        background-color: #EDEFF0;
        z-index: 3 !important;
      width: 100%;
    }
    .sss{
        z-index: 3 !important;

    }
    input{
        z-index: 0 !important;
    }
</style>
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('lesson.index') }}">Fanlar</a></li>
            <li><a href="{{ route('topics.index') }}">Mavzular</a></li>
            <li><a href="{{ route('content.index') }}">Mavzu ma'lumotlari</a></li>
            <li class="active">Yangi ma'lumot qo'shish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="panel-success margin-left-20">
        <ul class="breadcrumb" style="text-transform: uppercase">
            <li><strong>{{ $topic->lesson->name_uz }}</strong></li>
            <li><strong>{{ $topic->name_uz }}</strong></li>
            <li></li>
        </ul>
    </div>
    <div class="container">
        <div class="row">
            <form action="{{ route('content.store') }}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <input type="hidden" name="topic_id" id="topic_id" value="{{ $topic->id }}">
                <div class="container" >
                    <div class="header" id="myHeader">
                        <div class="col-lg-12 jiji"  style="padding-bottom: 20px ; top: 0px; ">
                            <a class="btn btn-primary sss" onclick="creatediv('text')"><i class="fa fa-newspaper-o"></i> Matn</a>
                            <a class="btn btn-primary sss" onclick="creatediv('photo')"><i class="fa fa-photo"></i> Rasm</a>
                            <a class="btn btn-primary sss" onclick="creatediv('move')"><i class="fa fa-film"></i> Video</a>
                            <a class="btn btn-primary sss" onclick="creatediv('audio')"><i class="fa fa-music"></i> Audio</a>
                            <a class="btn btn-primary sss" onclick="creatediv('fayl')"><i class="fa fa-file"></i> Fayl</a>

                            <button class="btn btn-success sss" type="submit"><i class="fa fa-save"></i> Saqlash</button>
                        </div>
                    </div>
                    <div>
                        @php $tartib = 0; @endphp
                        @foreach($data as $item)
                            <div style="border: 1px solid black;margin: 5px" class="panel panel-default">
                                <div class="panel-heading">
                                    @if($item->type_id == 1)
                                        <i class="fa fa-newspaper-o"></i> Matn
                                    @endif
                                    @if($item->type_id == 2)
                                        <i class="fa fa-photo"></i> Rasm <img src="{{$item->content_uz}}" style="height:40px">
                                    @endif
                                    @if($item->type_id == 3)
                                        <i class="fa fa-film"></i> Video
                                    @endif
                                    @if($item->type_id == 4)
                                        <i class="fa fa-music"></i> Audio
                                    @endif
                                    @if($item->type_id == 5)
                                        <i class="fa fa-file"></i> Fayl
                                    @endif
                                    <div class="pull-right">
                                        Tartib: <input type="number" style="height:30px" name="on{{$item->id}}" value="{{$item->order_id}}">
                                        @php $tartib = $item->order_id; @endphp
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="col-lg-4">
                                        O'zbek tilida (lotin)
                                            @if($item->type_id == 1)
                                                <textarea class="form-control editor-full" name="tu{{$item->id}}">{{$item->content_uz}}</textarea>
                                            @endif
                                            @if($item->type_id == 2)
                                                <input type="file" name="pu{{$item->id}}">
                                            @endif
                                            @if($item->type_id == 3)
                                                <input type="file" name="mu{{$item->id}}">
                                            @endif
                                            @if($item->type_id == 4)
                                                <input type="file" name="au{{$item->id}}">
                                            @endif
                                            @if($item->type_id == 5)
                                                <input type="file" name="fu{{$item->id}}">
                                            @endif
                                       
                                    </div>
                                    <div class="col-lg-4">
                                        O'zbek tilida (kiril)
                                        @if($item->type_id == 1)
                                            <textarea class="form-control editor-full" name="tk{{$item->id}}">{{$item->content_kiril}}</textarea>
                                        @endif
                                        @if($item->type_id == 2)
                                            <input type="file" name="pk{{$item->id}}">
                                        @endif
                                        @if($item->type_id == 3)
                                            <input type="file" name="mk{{$item->id}}">
                                        @endif
                                        @if($item->type_id == 4)
                                            <input type="file" name="ak{{$item->id}}">
                                        @endif
                                        @if($item->type_id == 5)
                                            <input type="file" name="fk{{$item->id}}">
                                        @endif
                                        
                                    </div>
                                    <div class="col-lg-4">
                                        Rus tilida
                                        @if($item->type_id == 1)
                                            <textarea class="form-control editor-full" name="tr{{$item->id}}">{{$item->content_ru}}</textarea>
                                        @endif
                                        @if($item->type_id == 2)
                                            <input type="file" name="pr{{$item->id}}">
                                        @endif
                                        @if($item->type_id == 3)
                                            <input type="file" name="mr{{$item->id}}">
                                        @endif
                                        @if($item->type_id == 4)
                                            <input type="file" name="ar{{$item->id}}">
                                        @endif
                                         @if($item->type_id == 5)
                                            <input type="file" name="fr{{$item->id}}">
                                        @endif
                                        
                                    </div>
                                </div>
                            </div>
                        @endforeach
            </div>
            <div  id="content_full">
                    </div>
                </div>
                <div class="block">
                    <button class="btn btn-success btn-block col-md-6">Saqlash</button>
                </div>
            </form>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
               $(window).scrollTop(1000);

        })
    </script>
    <script type="text/javascript">
        window.onscroll = function() {myFunction()};

        var header = document.getElementById("myHeader");
        var sticky = header.offsetTop;

        function myFunction() {
          if (window.pageYOffset >= sticky) {
            header.classList.add("sticky");
          } else {
            header.classList.remove("sticky");
          }
        }
    </script>
    <script !src="">
        window.scrollTo(0,document.body.scrollHeight);
        var i = 0;
        var j = <?php echo $tartib+1; ?>;
        function createDiv(name, input1, input2, input3, i) {
            document.getElementById('content_full').innerHTML +='<div style="border: 1px solid black;margin: 5px" class="panel panel-default">\n' +
                '                        <div class="panel-heading">\n' +
                name +
                '                        <div class="pull-right">Tartib: <input type="number" style="height:30px" name="on'+i+'" value="'+j+'" ></div></div>\n' +
                '                        <div class="panel-body">\n' +
                '                            <div class="col-lg-4">\n' +
                '                                O\'zbek tilida (lotin)\n' +
                input1 +
                '                            </div>\n' +
                '                            <div class="col-lg-4">\n' +
                '                                O\'zbek tilida (kiril)\n' +
                input2 +
                '                            </div>\n' +
                '                            <div class="col-lg-4">\n' +
                '                                Rus tili\n' +
                input3 +
                '                            </div>\n' +
                '                        </div>\n' +
                '                    </div>';
                window.scrollTo(0,document.body.scrollHeight);
        }
        function creatediv(type) {
            if (type == 'text')
                createDiv('<i class="fa fa-newspaper-o"></i> Matn', '<textarea class="form-control editor-full" name="tu'+i+'"></textarea>', '<textarea class="form-control editor-full" name="tk'+i+'"></textarea>', '<textarea class="form-control editor-full" name="tr'+i+'"></textarea>', i);
            else if (type == 'photo')
                createDiv('<i class="fa fa-photo"></i> Rasm', '<input type="file" name="pu'+i+'">', '<input type="file" name="pk'+i+'">', '<input type="file" name="pr'+i+'">', i);
            else if (type == 'move')
                createDiv('<i class="fa fa-film"></i> Video', '<input type="file" name="mu'+i+'">', '<input type="file" name="mk'+i+'">', '<input type="file" name="mr'+i+'">', i);
            else if (type == 'audio')
                createDiv('<i class="fa fa-music"></i> Audio', '<input type="file" name="au'+i+'">', '<input type="file" name="ak'+i+'">', '<input type="file" name="ar'+i+'">', i);
            else if (type == 'fayl')
                createDiv('<i class="fa fa-file"></i> Fayl', '<input type="file" name="fu'+i+'">', '<input type="file" name="fk'+i+'">', '<input type="file" name="fr'+i+'">', i);
            i --;
            j++;
        }
    </script>
    <style>
        textarea { resize: vertical; min-height: 50px;}
    </style>
@section('js')

@endsection
@endsection