@extends('layouts.admin')

@section('content')
<div class="left-content">
                <div class="title-link">
                    <div>
                        <h1>Avtotransport vositalarini xavfsiz boshqarish va harakat xavfsizligi asos...</h1>
                        <p><span>Darsliklar / Toifalar / CE qayta tayyorlash / Yo'l harakati sohasidagi qonunchilik as... /</span>Avtotransport vositalarini xavfsiz boshqarish va ha...</p>                        
                    </div>
                    <div>
                        <a href="#">Ortga</a>
                    </div>
                </div>
                <div class="upate-content-buttons">
                    <div>
                        <h1>Ma’lumot qo’shish</h1>
                    </div>
                    <div>
                        <a id="matn" href="#text-add" >
                            <p>Matn</p>
                            <img height="16px" src="{{ asset('admin/style/images/icons/matin.svg') }}" alt="AAA">
                        </a>
                        <a id="rasm" href="#rasim-add" >
                            <p>Rasim</p>
                            <img height="16px" src="{{ asset('admin/style/images/icons/rasim.svg') }}" alt="AAA">
                        </a>
                        <a id="video" href="#video-add" >
                            <p>Video</p>
                            <img height="16px" src="{{ asset('admin/style/images/icons/video.svg') }}" alt="AAA">
                        </a>
                    </div>
                </div>
                <div class="update-items">
                    <form action="{{ route('content.store') }}" id="form_up" method="post" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        {{ method_field('post') }}
                        <input type="hidden" name="topic_id" id="topic_id" value="{{ $topic->id }}">
                        <!-- 1-qisim -->
                        @foreach($data as $item)
                            <div class="new-elements Text-qoshish" id="text-add">
                                <div class="update-sarlavha">
                                    <div>
                                        
                                         @if($item->type_id == 1)
                                           <img width="18px" src="{{ asset('admin/style/images/icons/UploadTextBlack.svg') }}" alt="AAA"><h1>Matn</h1>
                                        @endif
                                        @if($item->type_id == 2)
                                           <img src="{{ asset('admin/style/images/icons/UploadRasimBlack.svg') }}" width="18px" alt="AAA"><h1>Rasim</h1>
                                            <img  class="belgi-images" width="50px" height="60px" src="{{ asset($item->content_uz) }}" alt="AAA">
                                        @endif
                                        @if($item->type_id == 3)
                                             <img src="{{ asset('admin/style/images/icons/UploadVideoBlack.svg') }}" width="18px" alt="AAA"><h1>Video</h1>
                                        @endif
                                        
                                    </div>
                                    <div>
                                        <button type="button" class="delete-update">
                                            <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                            <p>O'chirish</p>
                                        </button>
                                        <p class="tartib">Tartib:</p><p class="tartib-raqam">1</p>
                                    </div>
                                </div>
                                <div class="update-text">
                                            @if($item->type_id == 1)
                                                <div class="upload-input-text">
                                                    <div class="add-text-p">
                                                        <p>O’zbek tilida (lotin)<span class="toldirish-shrt-span">To'ldirish shart!</span> </p>
                                                    </div>
                                                    <div class="text-box">
                                                        <textarea class="new-text" name="tu{{ $item->id }}" id="template" cols="30" rows="20">{{$item->content_uz}}</textarea>
                                                    </div>
                                                </div>
                                                <div class="upload-input-text">
                                                    <div class="add-text-p">
                                                        <p>O’zbek tilida (kiril)<span class="toldirish-shrt-span">To'ldirish shart!</span> </p>
                                                    </div>
                                                    <div class="text-box">
                                                        <textarea class="new-text" name="tk{{ $item->id }}" id="template" cols="30" rows="20">{{$item->content_kiril}}</textarea>
                                                    </div>
                                                   
                                                </div>
                                                <div class="upload-input-text">
                                                    <div class="add-text-p">
                                                        <p>Rus tilida<span class="toldirish-shrt-span">To'ldirish shart!</span> </p>
                                                    </div>
                                                    <div class="text-box">
                                                        <textarea class="new-text" name="tr{{ $item->id }}" id="template" cols="30" rows="20">{{$item->content_ru}}</textarea>
                                                    </div>
                                                </div>
                                            @endif
                                            @if($item->type_id == 2)
                                                 <div class="input-file-img">
                                                    <div class="upload-file">
                                                        <button type="button" class="f-up-button">
                                                            <input class="f-up-input" type="file">
                                                            <p>Faylni tanlang</p>
                                                        </button>
                                                        <input placeholder="Fayl tanlanmagan" name="pu{{ $item->id }}" class="file-name" type="text">
                                                    </div>
                                                </div>
                                                <div class="input-file-img">
                                                    <div class="upload-file">
                                                        <button type="button" class="f-up-button">
                                                            <input class="f-up-input" type="file">
                                                            <p>Faylni tanlang</p>
                                                        </button>
                                                        <input placeholder="Fayl tanlanmagan" name="pk{{ $item->id }}" class="file-name" type="text">
                                                    </div>
                                                </div>
                                                <div class="input-file-img">
                                                    <div class="upload-file">
                                                        <button type="button" class="f-up-button">
                                                            <input class="f-up-input" type="file">
                                                            <p>Faylni tanlang</p>
                                                        </button>
                                                        <input placeholder="Fayl tanlanmagan" name="pr{{ $item->id }}" class="file-name" type="text">
                                                    </div>
                                                </div>
                                            @endif
                                            @if($item->type_id == 3)
                                                <div class="input-file-img">
                                                    <div class="upload-file">
                                                        <button type="button" class="f-up-button">
                                                            <input class="f-up-input" type="file">
                                                            <p>Faylni tanlang</p>
                                                        </button>
                                                        <input placeholder="Fayl tanlanmagan" name="mu{{ $item->id }}" class="file-name" type="text">
                                                    </div>
                                                </div>
                                                <div class="input-file-img">
                                                    <div class="upload-file">
                                                        <button type="button" class="f-up-button">
                                                            <input class="f-up-input" type="file">
                                                            <p>Faylni tanlang</p>
                                                        </button>
                                                        <input placeholder="Fayl tanlanmagan" name="mk{{ $item->id }}" class="file-name" type="text">
                                                    </div>
                                                </div>
                                                <div class="input-file-img">
                                                    <div class="upload-file">
                                                        <button type="button" class="f-up-button">
                                                            <input class="f-up-input" type="file">
                                                            <p>Faylni tanlang</p>
                                                        </button>
                                                        <input placeholder="Fayl tanlanmagan" name="mr{{ $item->id }}" class="file-name" type="text">
                                                    </div>
                                                </div>
                                            @endif
                                          
                                    
                                </div>
                            </div>
                        @endforeach
                        <!-- Matin add -->
                        <div id="hahaha" >
                            <div class="new-elements Text-qoshish" id="text-add">
                                <div class="update-sarlavha">
                                    <div>
                                        <img width="18px" src="{{ asset('admin/style/images/icons/UploadTextBlack.svg') }}" alt="AAA"><h1>Matn</h1>
                                    </div>
                                    <div>
                                        <button type="button" class="delete-update">
                                            <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                            <p>O'chirish</p>
                                        </button>
                                        <p class="tartib">Tartib:</p><p class="tartib-raqam">1</p>
                                    </div>
                                </div>
                                <div class="upload-file-content">
                                    <div class="upload-input-text">
                                        <div class="add-text-p">
                                            <p>O’zbek tilida (lotin)<span class="toldirish-shrt-span">To'ldirish shart!</span> </p>
                                        </div>
                                        <div class="text-box">
                                            <textarea class="new-text" name="text-1-uz" id="template" cols="30" rows="20"></textarea>
                                        </div>
                                    </div>
                                    <div class="upload-input-text">
                                        <div class="add-text-p">
                                            <p>O’zbek tilida (kiril)<span class="toldirish-shrt-span">To'ldirish shart!</span> </p>
                                        </div>
                                        <div class="text-box">
                                            <textarea class="new-text" name="text-1-kr" id="template" cols="30" rows="20"></textarea>
                                        </div>
                                       
                                    </div>
                                    <div class="upload-input-text">
                                        <div class="add-text-p">
                                            <p>Rus tilida<span class="toldirish-shrt-span">To'ldirish shart!</span> </p>
                                        </div>
                                        <div class="text-box">
                                            <textarea class="new-text" name="text-1-ru" id="template" cols="30" rows="20"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                         
                        
                        <!-- Rasim add -->
                        {{-- <div class="new-elements Text-qoshish" id="rasim-add">
                            <div class="update-sarlavha">
                                <div>
                                    <img src="{{ asset('admin/style/images/icons/UploadRasimBlack.svg') }}" width="18px" alt="AAA"><h1>Rasim</h1>
                                    <img  class="belgi-images" width="50px" height="60px" src="{{ asset('admin/style/images/belgilar/belgi2.svg') }}" alt="AAA">
                                </div>
                                <div>
                                    <button type="button" class="delete-update">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><p class="tartib-raqam">2</p>
                                </div>
                            </div>
                            <div class="upload-file-content">
                                <div class="input-file-img">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input class="f-up-input" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input class="f-up-input" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input class="f-up-input" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                            </div>
                        </div> --}}
                        <!-- Video add -->
                      
                        {{-- <div class="new-elements Video-qoshish" id="video-add">
                            <div class="update-sarlavha">
                                <div>
                                    <img src="{{ asset('admin/style/images/icons/UploadVideoBlack.svg') }}" width="18px" alt="AAA"><h1>Video</h1>
                                </div>
                                <div>
                                    <button type="button" class="delete-update">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><p class="tartib-raqam">6</p>
                                </div>
                            </div>
                            <div class="upload-file-content">
                                <div class="input-file-img">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input class="f-up-input" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input class="f-up-input" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input class="f-up-input" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                            </div>
                        </div> --}}
                        <!-- ****************** -->
                        
                    </form>
                    <div class="submit-uploads">
                            <button type="button" id="but_submit" class="uploads-submit-button">
                                <p>Saqlash</p>
                                <img src="{{ asset('admin/style/images/icons/SaqlashWhite.svg') }}" alt="AAA">
                            </button>
                        </div>

                </div>
                

            </div>

           
            @endsection

            @section('js')

                <script type="text/javascript">
                    $('#matn').click(function(){
                        var html = $('#hahaha').html();
                        console.log(html);
                        $('#form_up').append(html);
                        
                    });
                        
                    $('#rasm').click(function(){
                        
                    });
                    $('#video').click(function(){
                        
                    });
                    $('#but_submit').click(function(){
                        $('#form_up').submit();
                    });
                </script>

                
            @endsection