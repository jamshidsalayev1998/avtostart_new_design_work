@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('lesson.index') }}">Toifalar</a></li>
            <li><a href="{{ route('content.index') }}">Mavzular</a></li>
            <li class="active">Kontentni ko'rish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="text-center">
                        {{$topic->name_uz}}
                        <a href="addcontent/{{$topic->id}}" class="btn btn-default" style="padding: 0px;width: 30px" class="pull-right">
                            <i class="icon-pencil"></i>
                        </a>
                    </div>
                    @if(session('message'))
                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                        <div class="alert-icon">
                            <span class="icon-checkmark-circle"></span>
                        </div>
                        {{ session('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                    </div>
                    @endif
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">O'zbek tilida (lotin)</div>
                <div class="panel-body">
                    <table class="table">
                    @foreach($data as $item)
                        <tr>
                            <td>
                                @if($item->type_id == 1)
                                    {{$item->content_uz}}
                                @endif
                                @if($item->type_id == 2)
                                    <img src="{{$item->content_uz}}" alt="Rasm" style="width: 100%;max-width: 400px;">
                                @endif
                                @if($item->type_id == 3)
                                    <video controls style="width: 100%;max-width: 400px;">
                                        <source src="{{$item->content_uz}}" type="video/mp4" controls/>
                                        Your browser does not support the video tag.
                                    </video>
                                @endif
                                @if($item->type_id == 4)
                                    <audio controls style="width: 100%;max-width: 400px;">
                                        <source src="{{$item->content_uz}}" type="audio/ogg" controls/>
                                        <source src="{{$item->content_uz}}" type="audio/ogg" controls/>

                                        Your browser does not support the video tag.
                                    </audio>
                                @endif
                                @if($item->type_id == 5)
                                    <a href="{{ $item->content_uz }}">{{ substr($item->content_uz, 10 , 1000)  }}</a>
                                @endif
                            </td>
                            <td style="width: 100px; vertical-align: top;">
                                <a href="{{ route('content.edit', ['id' => $item->id]) }}" class="btn btn-default" style="padding: 0px;width: 30px" class="pull-right">
                                    <i class="icon-pencil"></i>
                                </a>
                                <form action="{{ route('content.destroy', ['id' => $item->id]) }}" method="post" style="display: inline" class="pull-right">
                                    {{ csrf_field() }}
                                    {{ method_field('delete') }}
                                    <button class="btn btn-danger" style="width: 30px; text-align: center; padding: 0px"><i class="icon-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                    </table>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">O'zbek tilida (kiril)</div>
                <div class="panel-body">
                    <table class="table">
                        @foreach($data as $item)
                            <tr>
                                <td>
                                    @if($item->type_id == 1)
                                        {{$item->content_kiril}}
                                        @endif
                                    @if($item->type_id == 2)
                                        <img src="{{$item->content_kiril}}" alt="Rasm" style="width: 100%;max-width: 400px;">
                                    @endif
                                    @if($item->type_id == 3)
                                        <video controls style="width: 100%;max-width: 400px;;">
                                            <source src="{{$item->content_kiril}}" type="video/mp4">
                                            Your browser does not support the video tag.
                                        </video>
                                    @endif
                                    @if($item->type_id == 4)
                                    <audio controls style="width: 100%;max-width: 400px;">
                                        <source src="{{$item->content_kiril}}" type="audio/ogg" controls/>
                                        <source src="{{$item->content_kiril}}" type="audio/ogg" controls/>

                                        Your browser does not support the video tag.
                                    </audio>
                                @endif
                                @if($item->type_id == 5)
                                    <a href="{{ $item->content_kiril }}">{{ substr($item->content_kiril, 10 , 1000)  }}</a>
                                @endif
                                </td>
                                <td style="width: 100px; vertical-align: top;">
                                    <a href="{{ route('content.edit', ['id' => $item->id]) }}" class="btn btn-default" style="padding: 0px;width: 30px" class="pull-right">
                                        <i class="icon-pencil"></i>
                                    </a>
                                    <form action="{{ route('content.destroy', ['id' => $item->id]) }}" method="post" style="display: inline" class="pull-right">
                                        {{ csrf_field() }}
                                        {{ method_field('delete') }}
                                        <button class="btn btn-danger" style="width: 30px; text-align: center; padding: 0px"><i class="icon-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">Rus tilida</div>
                <div class="panel-body">
                    <table class="table">
                        @foreach($data as $item)
                            <tr>
                                <td>
                                    @if($item->type_id == 1)
                                        {{$item->content_ru}}
                                        @endif
                                    @if($item->type_id == 2)
                                        <img src="{{$item->content_ru}}" alt="Rasm" style="width: 100%;max-width: 400px;">
                                    @endif
                                    @if($item->type_id == 3)
                                        <video controls style="width: 100%;max-width: 400px;;">
                                            <source src="{{$item->content_ru}}" type="video/mp4">
                                            Your browser does not support the video tag.
                                        </video>
                                    @endif
                                     @if($item->type_id == 4)
                                    <audio controls style="width: 100%;max-width: 400px;">
                                        <source src="{{$item->content_kiril}}" type="audio/ogg" controls/>
                                        <source src="{{$item->content_kiril}}" type="audio/ogg" controls/>

                                        Your browser does not support the video tag.
                                    </audio>
                                @endif
                                @if($item->type_id == 5)
                                    <a href="{{ $item->content_kiril }}">{{ substr($item->content_kiril, 10 , 1000)  }}</a>
                                @endif

                                </td>
                                <td style="width: 100px; vertical-align: top;">
                                    <a href="{{ route('content.edit', ['id' => $item->id]) }}" class="btn btn-default" style="padding: 0px;width: 30px" class="pull-right">
                                        <i class="icon-pencil"></i>
                                    </a>
                                    <form action="{{ route('content.destroy', ['id' => $item->id]) }}" method="post" style="display: inline" class="pull-right">
                                        {{ csrf_field() }}
                                        {{ method_field('delete') }}
                                        <button class="btn btn-danger" style="width: 30px; text-align: center; padding: 0px"><i class="icon-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
