@extends('layouts.admin_alisher')
@section('content')
				<img width="18px" class="text_icon" hidden src="{{ asset('admin/style/images/icons/UploadTextBlack.svg') }}" alt="AAA">
				<img width="18px" class="image_icon" hidden src="{{ asset('admin/style/images/icons/UploadRasimBlack.svg') }}" alt="AAA">
				<img width="18px" class="video_icon" hidden src="{{ asset('admin/style/images/icons/UploadVideoBlack.svg') }}" alt="AAA">
				<img width="18px" class="audio_icon" hidden src="{{ asset('admin/style/images/icons/audioBlack.svg') }}" alt="AAA">
				<img width="18px" class="file_icon" hidden src="{{ asset('admin/style/images/icons/fileBlack.svg') }}" alt="AAA">
				<img width="18px" class="delete_icon" hidden src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                <div class="title-link">
                    <div>
                        <h1>{{ $topic->name_uz }}</h1>
                        <p><span>Darsliklar / Toifalar / {{ $topic->lesson->name_uz }}/ {{ $topic->name_uz }}</p>                        
                    </div>
                    <div>
                        <a href="batafsil.html">Ortga</a>
                    </div>
                </div>
                <div class="upate-content-buttons">
                    <div>
                        <h1>Ma’lumot qo’shish</h1>
                    </div>
                    <div>
                        <a href="#" class="text-qosh-inputs">
                            <p>Matn</p>
                            <img height="16px" src="{{ asset('admin/style/images/icons/matin.svg') }}" alt="AAA">
                        </a>
                        <a href="#" class="fayl-qosh-inputs">
                            <p>Fayl</p>
                            <img height="16px" src="{{ asset('admin/style/images/icons/file.svg') }}" alt="AAA">
                        </a>
                        <a href="#" class="rasim-qosh-inputs">
                            <p>Rasim</p>
                            <img height="16px" src="{{ asset('admin/style/images/icons/rasim.svg') }}" alt="AAA">
                        </a>
                        <a href="#" class="audio-qosh-inputs">
                            <p>Audio</p>
                            <img height="16px" src="{{ asset('admin/style/images/icons/audio.svg') }}" alt="AAA">
                        </a>
                        <a href="#" class="video-qosh-inputs">
                            <p>Video</p>
                            <img height="16px" src="{{ asset('admin/style/images/icons/video.svg') }}" alt="AAA">
                        </a>
                        <button class="submit2"  class="add-video-inputs">
                            <p>Saqlash</p>
                            <img height="16px" src="{{ asset('admin/style/images/icons/SaqlashCure.svg') }}" alt="AAA">
                        </button>
                    </div>
                </div>
                <div class="update-items" id="update-items">
                    <form action="{{ route('content.store') }}" method="post" enctype="multipart/form-data" id="upload-form">
                    	<input type="hidden" name="topic_id" id="topic_id" value="{{ $topic->id }}">
                    	{{ csrf_field() }}
                        <!-- 1-qisim -->
                        @foreach($data as $item)
                        {{-- matn --}}
                        @if($item->type_id == 1)
                        <div class="new-elements Text-qoshish" id="text-add" onclick="new_element_in(this)">
                            <div class="update-sarlavha">
                                <div>
                                    <img width="18px" src="{{ asset('admin/style/images/icons/UploadTextBlack.svg') }}" alt="AAA"><h1>Matn</h1>
                                </div>
                                <div>
                                    <button onclick="delete_div()" type="button" class="delete-update">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><input value="1" class="tartib-raqam" type="number">
                                </div>
                            </div>
                            <div class="update-text">
                                <div class="upload-input-text">
                                    <div class="add-text-p">
                                        <p>O’zbek tilida (lotin)</p>
                                    </div>
                                    <div class="text-box">
                                        <!-- Editor -->
                                        <div class="Alieditor" onclick="get_textEditor(this)">
                                            <div class="a-toolbar">
                                                <div class="a-btn-group">
                                                    <button type="button"  data-command='undo'><i class="fas fa-undo-alt"></i></button>
                                                    <button type="button" data-command='redo'><i class="fas fa-redo-alt"></i></button>
                                                    <button type="button" class="infoButton"><i class="fas fa-info-circle"></i>
                                                    <div class="infoEditor">
                                                        <p><b>Front end:</b>Alisher Paepiyev</p>
                                                        <p><b>Back end:</b>Jamshid Salayev</p>
                                                        <p><b>Companiya:</b> &copyOST</p>
                                                        <p><b>Tel:</b>+998-(99)-878-07-87</p>
                                                    </div>
                                                    </button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" class="fore-wrapper"><b style="color: #2CCA9A;">A</b><div class="fore-palette"></div></button>
                                                    <button type="button" class="back-wrapper"><b style="background:#2CCA9A;">A</b><div class="back-palette"></div></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="bold"><i class="fas fa-bold"></i></button>
                                                    <button type="button" data-command="italic"><i class="fas fa-italic"></i></button>
                                                    <button type="button" data-command="underline"><i class="fas fa-underline"></i></button>
                                                    <button type="button" data-command="strikeThrough"><i class="fas fa-strikethrough"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="justifyLeft"><i class="fas fa-align-left"></i></button>
                                                    <button type="button" data-command="justifyCenter"><i class="fas fa-align-center"></i></button>
                                                    <button type="button" data-command="justifyRight"><i class="fas fa-align-right"></i></button>
                                                    <button type="button" data-command="justifyFull"><i class="fas fa-align-justify"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="indent"><i class="fas fa-indent"></i></button>
                                                    <button type="button" data-command="outdent"><i class="fas fa-outdent"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="insertUnorderedList"><i class="fas fa-list-ul"></i></button>
                                                    <button type="button" data-command="insertOrderedList"><i class="fas fa-list-ol"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="h1"><b>h1</b></button>
                                                    <button type="button" data-command="h2"><b>h2</b></button>
                                                    <button type="button" data-command="p"><b>P</b></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="createlink"><i class="fas fa-link"></i></button>
                                                    <button type="button" data-command="unlink"><i class="fas fa-unlink"></i></button>
                                                    <button type="button" data-command="insertimage"><i class="fas fa-camera"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="subscript"><i class="fas fa-subscript"></i></button>
                                                    <button type="button" data-command="superscript"><i class="fas fa-superscript"></i></button>
                                                </div>
                                            </div>
                                                <div id='editor' class="Aeditor-content" contenteditable onkeyup="get_textVal(this)"><p>{!! $item->content_uz !!}</p></div>
                                                <textarea style="display: none;" class="text-value" style="display: bolck;" value="{{ $item->content_uz }}" name="tu{{ $item->id }}"></textarea>
                                            <div class="Aeditor-counter">
                                                <p><b>&copy OST</b></p>
                                                <p >So'zlar soni: <span class="counterWord">0</span></p>
                                            </div>
                                        </div>
                                        <!-- End Editor -->
                                    </div>
                                </div>
                                <div class="upload-input-text">
                                    <div class="add-text-p">
                                        <p>O’zbek tilida (kiril)</p>
                                    </div>
                                    <div class="text-box">
                                        <!-- Editor -->
                                        <div class="Alieditor" onclick="get_textEditor(this)">
                                            <div class="a-toolbar">
                                                <div class="a-btn-group">
                                                    <button type="button"  data-command='undo'><i class="fas fa-undo-alt"></i></button>
                                                    <button type="button" data-command='redo'><i class="fas fa-redo-alt"></i></button>
                                                    <button type="button" class="infoButton"><i class="fas fa-info-circle"></i>
                                                    <div class="infoEditor">
                                                        <p><b>Front end:</b>Alisher Paepiyev</p>
                                                        <p><b>Back end:</b>Jamshid Salayev</p>
                                                        <p><b>Companiya:</b> &copyOST</p>
                                                        <p><b>Tel:</b>+998-(99)-878-07-87</p>
                                                    </div>
                                                    </button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" class="fore-wrapper"><b style="color: #2CCA9A;">A</b><div class="fore-palette"></div></button>
                                                    <button type="button" class="back-wrapper"><b style="background:#2CCA9A;">A</b><div class="back-palette"></div></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="bold"><i class="fas fa-bold"></i></button>
                                                    <button type="button" data-command="italic"><i class="fas fa-italic"></i></button>
                                                    <button type="button" data-command="underline"><i class="fas fa-underline"></i></button>
                                                    <button type="button" data-command="strikeThrough"><i class="fas fa-strikethrough"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="justifyLeft"><i class="fas fa-align-left"></i></button>
                                                    <button type="button" data-command="justifyCenter"><i class="fas fa-align-center"></i></button>
                                                    <button type="button" data-command="justifyRight"><i class="fas fa-align-right"></i></button>
                                                    <button type="button" data-command="justifyFull"><i class="fas fa-align-justify"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="indent"><i class="fas fa-indent"></i></button>
                                                    <button type="button" data-command="outdent"><i class="fas fa-outdent"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="insertUnorderedList"><i class="fas fa-list-ul"></i></button>
                                                    <button type="button" data-command="insertOrderedList"><i class="fas fa-list-ol"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="h1"><b>h1</b></button>
                                                    <button type="button" data-command="h2"><b>h2</b></button>
                                                    <button type="button" data-command="p"><b>P</b></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="createlink"><i class="fas fa-link"></i></button>
                                                    <button type="button" data-command="unlink"><i class="fas fa-unlink"></i></button>
                                                    <button type="button" data-command="insertimage"><i class="fas fa-camera"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="subscript"><i class="fas fa-subscript"></i></button>
                                                    <button type="button" data-command="superscript"><i class="fas fa-superscript"></i></button>
                                                </div>
                                            </div>
                                                <div id='editor' class="Aeditor-content" contenteditable onkeyup="get_textVal(this)"><p>{!! $item->content_kiril !!}</p></div>
                                                <textarea style="display: none;" class="text-value" style="display: bolck;" value="{{ $item->content_kiril }}" name="tk{{ $item->id }}"></textarea>
                                            <div class="Aeditor-counter">
                                                <p><b>&copy OST</b></p>
                                                <p >So'zlar soni: <span class="counterWord">0</span></p>
                                            </div>
                                        </div>
                                        <!-- End Editor -->
                                    </div>
                                </div>
                                <div class="upload-input-text">
                                    <div class="add-text-p">
                                        <p>Rus tilida</p>
                                    </div>
                                    <div class="text-box">
                                        <!-- Editor -->
                                        <div class="Alieditor" onclick="get_textEditor(this)">
                                            <div class="a-toolbar">
                                                <div class="a-btn-group">
                                                    <button type="button"  data-command='undo'><i class="fas fa-undo-alt"></i></button>
                                                    <button type="button" data-command='redo'><i class="fas fa-redo-alt"></i></button>
                                                    <button type="button" class="infoButton"><i class="fas fa-info-circle"></i>
                                                    <div class="infoEditor">
                                                        <p><b>Front end:</b>Alisher Paepiyev</p>
                                                        <p><b>Back end:</b>Jamshid Salayev</p>
                                                        <p><b>Companiya:</b> &copyOST</p>
                                                        <p><b>Tel:</b>+998-(99)-878-07-87</p>
                                                    </div>
                                                    </button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" class="fore-wrapper"><b style="color: #2CCA9A;">A</b><div class="fore-palette"></div></button>
                                                    <button type="button" class="back-wrapper"><b style="background:#2CCA9A;">A</b><div class="back-palette"></div></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="bold"><i class="fas fa-bold"></i></button>
                                                    <button type="button" data-command="italic"><i class="fas fa-italic"></i></button>
                                                    <button type="button" data-command="underline"><i class="fas fa-underline"></i></button>
                                                    <button type="button" data-command="strikeThrough"><i class="fas fa-strikethrough"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="justifyLeft"><i class="fas fa-align-left"></i></button>
                                                    <button type="button" data-command="justifyCenter"><i class="fas fa-align-center"></i></button>
                                                    <button type="button" data-command="justifyRight"><i class="fas fa-align-right"></i></button>
                                                    <button type="button" data-command="justifyFull"><i class="fas fa-align-justify"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="indent"><i class="fas fa-indent"></i></button>
                                                    <button type="button" data-command="outdent"><i class="fas fa-outdent"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="insertUnorderedList"><i class="fas fa-list-ul"></i></button>
                                                    <button type="button" data-command="insertOrderedList"><i class="fas fa-list-ol"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="h1"><b>h1</b></button>
                                                    <button type="button" data-command="h2"><b>h2</b></button>
                                                    <button type="button" data-command="p"><b>P</b></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="createlink"><i class="fas fa-link"></i></button>
                                                    <button type="button" data-command="unlink"><i class="fas fa-unlink"></i></button>
                                                    <button type="button" data-command="insertimage"><i class="fas fa-camera"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="subscript"><i class="fas fa-subscript"></i></button>
                                                    <button type="button" data-command="superscript"><i class="fas fa-superscript"></i></button>
                                                </div>
                                            </div>
                                                <div id='editor' class="Aeditor-content" contenteditable onkeyup="get_textVal(this)"><p>{!! $item->content_ru !!}</p></div>
                                                <textarea style="display: none;" class="text-value" style="display: bolck;" value="{{ $item->content_ru }}" name="tr{{ $item->id }}"></textarea>
                                            <div class="Aeditor-counter">
                                                <p><b>&copy OST</b></p>
                                                <p >So'zlar soni: <span class="counterWord">0</span></p>
                                            </div>
                                        </div>
                                        <!-- End Editor -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                        {{-- rasm --}}
                        @if($item->type_id == 2)
                        <div class="new-elements Rasim-qoshish" id="rasim-add" onclick="new_element_in(this)">
                            <div class="update-sarlavha">
                                <div>
                                    <img src="{{ asset('admin/style/images/icons/UploadRasimBlack.svg') }}" width="18px" alt="AAA"><h1>Rasim</h1>
                                    <img  class="belgi-images" width="50px" height="60px" src="{{ asset($item->content_ru) }}" alt="AAA">
                                </div>
                                <div>
                                    <button onclick="delete_div()"  type="button" class="delete-update">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><input value="2" class="tartib-raqam" type="number">
                                </div>
                            </div>
                            <div class="upload-file-content">
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="pu{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input  placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img">
                                    <div class="upload-file" onclick="get_elements(this)">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="pk{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="pr{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                        
                        {{-- video --}}
                        @if($item->type_id == 3)
                        <div class="new-elements Video-qoshish" id="video-add" onclick="new_element_in(this)">
                            <div class="update-sarlavha">
                                <div>
                                    <img src="{{ asset('admin/style/images/icons/UploadVideoBlack.svg') }}" width="18px" alt="AAA"><h1>Video</h1>
                                    <button type="button" data-src="{{ asset($item->content_uz) }}" class="joriy-video-button"><img src="{{ asset('admin/style/images/icons/korish.svg') }}" alt="AAA"><p>Joriy videoni ko'rish</p></button>
                                </div>
                                <div>
                                    <button onclick="delete_div()" type="button" class="delete-update">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><input value="3" class="tartib-raqam" type="number">
                                </div>
                            </div>
                            <div class="upload-file-content">
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="mu{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="mk{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="mr{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                        {{-- audio --}}
                        @if($item->type_id == 4)
                        <div class="new-elements Audio-qoshish" id="audio-add" onclick="new_element_in(this)">
                            <div class="update-sarlavha">
                                <div>
                                    <img src="{{ asset('admin/style/images/icons/audioBlack.svg') }}" width="18px" alt="AAA"><h1>Audio</h1>
                                    <audio src="{{ asset($item->content_uz) }}" controls></audio>
                                </div>
                                <div>
                                    <button onclick="delete_div()" type="button" class="delete-update">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><input value="4" class="tartib-raqam" type="number">
                                </div>
                            </div>
                            <div class="upload-file-content">
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="au{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="ak{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="ar{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                        {{-- file --}}
                        @if($item->type_id == 5)
                        <div class="new-elements Fayl-qoshish" id="file-add" onclick="new_element_in(this)">
                            <div class="update-sarlavha">
                                <div>
                                    <img src="{{ asset('admin/style/images/icons/fileBlack.svg') }}" width="18px" alt="AAA"><h1>Fayl</h1>
                                    <a class="joriy-file-show"  href="{{ asset($item->content_uz) }}"><img src="{{ asset('admin/style/images/icons/korish.svg') }}" alt="AAA"><p>Joriy faylni ko'rish</p></a>
                                </div>
                                <div>
                                    <button type="button" class="delete-update" onclick="delete_div()">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><input value="5" class="tartib-raqam" type="number">
                                </div>
                            </div>
                            <div class="upload-file-content">
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="fu{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="fk{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="fr{{ $item->id }}" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                            </div>
                        </div> 
                        @endif
                        @endforeach
                        <!-- Matin add -->
                        {{-- <div class="new-elements Text-qoshish" id="text-add" onclick="new_element_in(this)">
                            <div class="update-sarlavha">
                                <div>
                                    <img width="18px" src="{{ asset('admin/style/images/icons/UploadTextBlack.svg') }}" alt="AAA"><h1>Matn</h1>
                                </div>
                                <div>
                                    <button onclick="delete_div()" type="button" class="delete-update">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><input value="1" class="tartib-raqam" type="number">
                                </div>
                            </div>
                            <div class="update-text">
                                <div class="upload-input-text">
                                    <div class="add-text-p">
                                        <p>O’zbek tilida (lotin)</p>
                                    </div>
                                    <div class="text-box">
                                        <!-- Editor -->
                                        <div class="Alieditor" onclick="get_textEditor(this)">
                                            <div class="a-toolbar">
                                                <div class="a-btn-group">
                                                    <button type="button"  data-command='undo'><i class="fas fa-undo-alt"></i></button>
                                                    <button type="button" data-command='redo'><i class="fas fa-redo-alt"></i></button>
                                                    <button type="button" class="infoButton"><i class="fas fa-info-circle"></i>
                                                    <div class="infoEditor">
                                                        <p><b>Front end:</b>Alisher Paepiyev</p>
                                                        <p><b>Back end:</b>Jamshid Salayev</p>
                                                        <p><b>Companiya:</b> &copyOST</p>
                                                        <p><b>Tel:</b>+998-(99)-878-07-87</p>
                                                    </div>
                                                    </button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" class="fore-wrapper"><b style="color: #2CCA9A;">A</b><div class="fore-palette"></div></button>
                                                    <button type="button" class="back-wrapper"><b style="background:#2CCA9A;">A</b><div class="back-palette"></div></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="bold"><i class="fas fa-bold"></i></button>
                                                    <button type="button" data-command="italic"><i class="fas fa-italic"></i></button>
                                                    <button type="button" data-command="underline"><i class="fas fa-underline"></i></button>
                                                    <button type="button" data-command="strikeThrough"><i class="fas fa-strikethrough"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="justifyLeft"><i class="fas fa-align-left"></i></button>
                                                    <button type="button" data-command="justifyCenter"><i class="fas fa-align-center"></i></button>
                                                    <button type="button" data-command="justifyRight"><i class="fas fa-align-right"></i></button>
                                                    <button type="button" data-command="justifyFull"><i class="fas fa-align-justify"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="indent"><i class="fas fa-indent"></i></button>
                                                    <button type="button" data-command="outdent"><i class="fas fa-outdent"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="insertUnorderedList"><i class="fas fa-list-ul"></i></button>
                                                    <button type="button" data-command="insertOrderedList"><i class="fas fa-list-ol"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="h1"><b>h1</b></button>
                                                    <button type="button" data-command="h2"><b>h2</b></button>
                                                    <button type="button" data-command="p"><b>P</b></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="createlink"><i class="fas fa-link"></i></button>
                                                    <button type="button" data-command="unlink"><i class="fas fa-unlink"></i></button>
                                                    <button type="button" data-command="insertimage"><i class="fas fa-camera"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="subscript"><i class="fas fa-subscript"></i></button>
                                                    <button type="button" data-command="superscript"><i class="fas fa-superscript"></i></button>
                                                </div>
                                            </div>
                                                <div id='editor' class="Aeditor-content" contenteditable onkeyup="get_textVal(this)"><p>...</p></div>
                                                <textarea style="display: none;" class="text-value" style="display: bolck;" value="..." name="tu1"></textarea>
                                            <div class="Aeditor-counter">
                                                <p><b>&copy OST</b></p>
                                                <p >So'zlar soni: <span class="counterWord">0</span></p>
                                            </div>
                                        </div>
                                        <!-- End Editor -->
                                    </div>
                                </div>
                                <div class="upload-input-text">
                                    <div class="add-text-p">
                                        <p>O’zbek tilida (kiril)</p>
                                    </div>
                                    <div class="text-box">
                                        <!-- Editor -->
                                        <div class="Alieditor" onclick="get_textEditor(this)">
                                            <div class="a-toolbar">
                                                <div class="a-btn-group">
                                                    <button type="button"  data-command='undo'><i class="fas fa-undo-alt"></i></button>
                                                    <button type="button" data-command='redo'><i class="fas fa-redo-alt"></i></button>
                                                    <button type="button" class="infoButton"><i class="fas fa-info-circle"></i>
                                                    <div class="infoEditor">
                                                        <p><b>Front end:</b>Alisher Paepiyev</p>
                                                        <p><b>Back end:</b>Jamshid Salayev</p>
                                                        <p><b>Companiya:</b> &copyOST</p>
                                                        <p><b>Tel:</b>+998-(99)-878-07-87</p>
                                                    </div>
                                                    </button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" class="fore-wrapper"><b style="color: #2CCA9A;">A</b><div class="fore-palette"></div></button>
                                                    <button type="button" class="back-wrapper"><b style="background:#2CCA9A;">A</b><div class="back-palette"></div></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="bold"><i class="fas fa-bold"></i></button>
                                                    <button type="button" data-command="italic"><i class="fas fa-italic"></i></button>
                                                    <button type="button" data-command="underline"><i class="fas fa-underline"></i></button>
                                                    <button type="button" data-command="strikeThrough"><i class="fas fa-strikethrough"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="justifyLeft"><i class="fas fa-align-left"></i></button>
                                                    <button type="button" data-command="justifyCenter"><i class="fas fa-align-center"></i></button>
                                                    <button type="button" data-command="justifyRight"><i class="fas fa-align-right"></i></button>
                                                    <button type="button" data-command="justifyFull"><i class="fas fa-align-justify"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="indent"><i class="fas fa-indent"></i></button>
                                                    <button type="button" data-command="outdent"><i class="fas fa-outdent"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="insertUnorderedList"><i class="fas fa-list-ul"></i></button>
                                                    <button type="button" data-command="insertOrderedList"><i class="fas fa-list-ol"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="h1"><b>h1</b></button>
                                                    <button type="button" data-command="h2"><b>h2</b></button>
                                                    <button type="button" data-command="p"><b>P</b></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="createlink"><i class="fas fa-link"></i></button>
                                                    <button type="button" data-command="unlink"><i class="fas fa-unlink"></i></button>
                                                    <button type="button" data-command="insertimage"><i class="fas fa-camera"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="subscript"><i class="fas fa-subscript"></i></button>
                                                    <button type="button" data-command="superscript"><i class="fas fa-superscript"></i></button>
                                                </div>
                                            </div>
                                                <div id='editor' class="Aeditor-content" contenteditable onkeyup="get_textVal(this)"><p>...</p></div>
                                                <textarea style="display: none;" class="text-value" style="display: bolck;" value="..." name="tk1"></textarea>
                                            <div class="Aeditor-counter">
                                                <p><b>&copy OST</b></p>
                                                <p >So'zlar soni: <span class="counterWord">0</span></p>
                                            </div>
                                        </div>
                                        <!-- End Editor -->
                                    </div>
                                </div>
                                <div class="upload-input-text">
                                    <div class="add-text-p">
                                        <p>Rus tilida</p>
                                    </div>
                                    <div class="text-box">
                                        <!-- Editor -->
                                        <div class="Alieditor" onclick="get_textEditor(this)">
                                            <div class="a-toolbar">
                                                <div class="a-btn-group">
                                                    <button type="button"  data-command='undo'><i class="fas fa-undo-alt"></i></button>
                                                    <button type="button" data-command='redo'><i class="fas fa-redo-alt"></i></button>
                                                    <button type="button" class="infoButton"><i class="fas fa-info-circle"></i>
                                                    <div class="infoEditor">
                                                        <p><b>Front end:</b>Alisher Paepiyev</p>
                                                        <p><b>Back end:</b>Jamshid Salayev</p>
                                                        <p><b>Companiya:</b> &copyOST</p>
                                                        <p><b>Tel:</b>+998-(99)-878-07-87</p>
                                                    </div>
                                                    </button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" class="fore-wrapper"><b style="color: #2CCA9A;">A</b><div class="fore-palette"></div></button>
                                                    <button type="button" class="back-wrapper"><b style="background:#2CCA9A;">A</b><div class="back-palette"></div></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="bold"><i class="fas fa-bold"></i></button>
                                                    <button type="button" data-command="italic"><i class="fas fa-italic"></i></button>
                                                    <button type="button" data-command="underline"><i class="fas fa-underline"></i></button>
                                                    <button type="button" data-command="strikeThrough"><i class="fas fa-strikethrough"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="justifyLeft"><i class="fas fa-align-left"></i></button>
                                                    <button type="button" data-command="justifyCenter"><i class="fas fa-align-center"></i></button>
                                                    <button type="button" data-command="justifyRight"><i class="fas fa-align-right"></i></button>
                                                    <button type="button" data-command="justifyFull"><i class="fas fa-align-justify"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="indent"><i class="fas fa-indent"></i></button>
                                                    <button type="button" data-command="outdent"><i class="fas fa-outdent"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="insertUnorderedList"><i class="fas fa-list-ul"></i></button>
                                                    <button type="button" data-command="insertOrderedList"><i class="fas fa-list-ol"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="h1"><b>h1</b></button>
                                                    <button type="button" data-command="h2"><b>h2</b></button>
                                                    <button type="button" data-command="p"><b>P</b></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="createlink"><i class="fas fa-link"></i></button>
                                                    <button type="button" data-command="unlink"><i class="fas fa-unlink"></i></button>
                                                    <button type="button" data-command="insertimage"><i class="fas fa-camera"></i></button>
                                                </div>
                                                <div class="a-btn-group">
                                                    <button type="button" data-command="subscript"><i class="fas fa-subscript"></i></button>
                                                    <button type="button" data-command="superscript"><i class="fas fa-superscript"></i></button>
                                                </div>
                                            </div>
                                                <div id='editor' class="Aeditor-content" contenteditable onkeyup="get_textVal(this)"><p>...</p></div>
                                                <textarea style="display: none;" class="text-value" style="display: bolck;" value="..." name="tr1"></textarea>
                                            <div class="Aeditor-counter">
                                                <p><b>&copy OST</b></p>
                                                <p >So'zlar soni: <span class="counterWord">0</span></p>
                                            </div>
                                        </div>
                                        <!-- End Editor -->
                                    </div>
                                </div>
                            </div>
                        </div> --}}
                        <!-- image add -->
                       {{--  <div class="new-elements Rasim-qoshish" id="rasim-add" onclick="new_element_in(this)">
                            <div class="update-sarlavha">
                                <div>
                                    <img src="{{ asset('admin/style/images/icons/UploadRasimBlack.svg') }}" width="18px" alt="AAA"><h1>Rasim</h1>
                                    <img  class="belgi-images" width="50px" height="60px" src="{{ asset('admin/style/images/belgilar/belgi2.svg') }}" alt="AAA">
                                </div>
                                <div>
                                    <button onclick="delete_div()"  type="button" class="delete-update">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><input value="2" class="tartib-raqam" type="number">
                                </div>
                            </div>
                            <div class="upload-file-content">
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="pu1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input  placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img">
                                    <div class="upload-file" onclick="get_elements(this)">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="pk1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="pr1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                            </div>
                        </div> --}}
                        <!-- Video add -->
                        {{-- <div class="new-elements Video-qoshish" id="video-add" onclick="new_element_in(this)">
                            <div class="update-sarlavha">
                                <div>
                                    <img src="{{ asset('admin/style/images/icons/UploadVideoBlack.svg') }}" width="18px" alt="AAA"><h1>Video</h1>
                                    <button type="button" class="joriy-video-button"><img src="{{ asset('admin/style/images/icons/korish.svg') }}" alt="AAA"><p>Joriy videoni ko'rish</p></button>
                                </div>
                                <div>
                                    <button onclick="delete_div()" type="button" class="delete-update">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><input value="3" class="tartib-raqam" type="number">
                                </div>
                            </div>
                            <div class="upload-file-content">
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="mu1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="mk1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input onchange="Names(this)" class="f-up-input" name="mr1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                            </div>
                        </div> --}}
                        <!-- ********** --> 
                        <!-- Music add  -->
                        {{-- <div class="new-elements Audio-qoshish" id="audio-add" onclick="new_element_in(this)">
                            <div class="update-sarlavha">
                                <div>
                                    <img src="{{ asset('admin/style/images/icons/audioBlack.svg') }}" width="18px" alt="AAA"><h1>Audio</h1>
                                    <audio src="{{ asset('admin/style/audios/ummon-guruhi_-_yo-q.mp3') }}" controls></audio>
                                </div>
                                <div>
                                    <button onclick="delete_div()" type="button" class="delete-update">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><input value="4" class="tartib-raqam" type="number">
                                </div>
                            </div>
                            <div class="upload-file-content">
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="au1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="ak1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="ar1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                            </div>
                        </div>  --}}
                        <!-- end music add                     -->
                        <!-- File add  -->
                        {{-- <div class="new-elements Fayl-qoshish" id="file-add" onclick="new_element_in(this)">
                            <div class="update-sarlavha">
                                <div>
                                    <img src="{{ asset('admin/style/images/icons/fileBlack.svg') }}" width="18px" alt="AAA"><h1>Fayl</h1>
                                    <a class="joriy-file-show"  href="#"><img src="{{ asset('admin/style/images/icons/korish.svg') }}" alt="AAA"><p>Joriy faylni ko'rish</p></a>
                                </div>
                                <div>
                                    <button type="button" class="delete-update" onclick="delete_div()">
                                        <img src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                        <p>O'chirish</p>
                                    </button>
                                    <p class="tartib">Tartib:</p><input value="5" class="tartib-raqam" type="number">
                                </div>
                            </div>
                            <div class="upload-file-content">
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="fu1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="fk1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                                <div class="input-file-img" onclick="get_elements(this)">
                                    <div class="upload-file">
                                        <button type="button" class="f-up-button">
                                            <input  onchange="Names(this)" class="f-up-input" name="fr1" type="file">
                                            <p>Faylni tanlang</p>
                                        </button>
                                        <input placeholder="Fayl tanlanmagan" class="file-name" type="text">
                                    </div>
                                </div>
                            </div>
                        </div> --}} 
                        <!--  end music add   -->
                        <!-- End olsd -->
                        <div id="new-uploads"></div>
                        <div class="submit-uploads">
                            <button type="submit" class="uploads-submit-button">
                                <p>Saqlash</p>
                                <img src="{{ asset('admin/style/images/icons/SaqlashWhite.svg') }}" alt="AAA">
                            </button>
                        </div>
                    </form>

                </div>


                <div class="joriy-video">
				    <div class="video-content-joriy">
				        <button class="joriy-video-close"><img width="14px" src="{{ asset('admin/style/images/icons/closex.svg') }}" alt="AAA"></button>
				        <video id="joriy-video-item"  controls ></video>
				    </div>
				    <div class="close-joriy-video"></div>
				</div>
@endsection