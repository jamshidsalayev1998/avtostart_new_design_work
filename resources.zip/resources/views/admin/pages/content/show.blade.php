@extends('layouts.admin_alisher')
@section('content')
                <div class="title-link">
                    <div>
                        <h1>{{ $topic->name_uz }}</h1>
                        <p><span>Darsliklar / Toifalar / {{ $topic->lesson->name_uz }} /</span> {{ $topic->name_uz }} </p>                        
                    </div>
                    <div>
                        <a href="{{ url()->previous() }}">Ortga</a>
                    </div>
                </div>
                <div class="table-toifa-batafsil">
                    <div class="boshlash-batafsil">
                        <div class="korinish-lang-buttons">
                            <button id="but_uz" class="korinish-lang-active">O'z</button>
                            <button id="but_kr">Ўз</button>
                            <button id="but_ru">Ру</button>
                        </div>
                        
                        <div class="mavzular-batafsil-button">
                            <a href="{{ route('addcontent',['id'=>$topic->id]) }}" class="batafsil-mav-qosh">
                                <p>Ma’lumot qo’shish</p>
                                <img width="16px" src="{{ asset('admin/style/images/icons/addMavzuWhite.svg') }}" alt="AAA">
                             </a>
                           
                        </div>
                    </div>
                    <div id="korinish_uz" class="korinish-textes">
                        <div class="korinish-h1-p">
                            <div>
                                <h1>{{$topic->name_uz}}</h1>
                            </div>
                            <div class="batafsil-p-i korinish-p-i">
                                <img width="14px" src="{{ asset('admin/style/images/icons/soat.svg') }}" alt="">
                                <p>{{ $topic->updated_at }}</p>
                            </div>
                        </div>
                        @foreach($data as $item)
                        @if($item->type_id == 1)
                        <div class="content-korinish-text">
                           {!! $item->content_uz !!}
                        </div>
                        @endif
                        @if($item->type_id == 2)
                        <div class="korinish-img">
                            <img width="200px" src="{{ asset($item->content_uz) }}" alt="AAA">
                        </div>
                        @endif
                        @if($item->type_id == 3)
                         <div class="korinish-video">
                            <video  controls src="{{ asset($item->content_uz) }}"></video>
                        </div>
                        @endif
                        @if($item->type_id == 4)
                        <div>
                                    <img src="{{ asset('admin/style/images/icons/audioBlack.svg') }}" width="18px" alt="AAA"><h1>Audio</h1>
                                    <audio src="{{ asset($item->content_uz) }}" controls></audio>
                                </div>
                        @endif
                        @if($item->type_id == 5)
                        <a href="{{ asset($item->content_uz) }}">{{ $item->content_uz }}</a>
                        @endif
                        @endforeach
                        
                    </div>
                    <div id="korinish_kr" class="korinish-textes">
                        <div class="korinish-h1-p">
                            <div>
                                <h1>{{$topic->name_uz}}</h1>
                            </div>
                            <div class="batafsil-p-i korinish-p-i">
                                <img width="14px" src="style/images/icons/soat.svg" alt="">
                                <p>{{ $topic->updated_at }}</p>
                            </div>
                        </div>
                        @foreach($data as $item)
                        @if($item->type_id == 1)
                        <div class="content-korinish-text">
                           {!! $item->content_kiril !!}
                        </div>
                        @endif
                        @if($item->type_id == 2)
                        <div class="korinish-img">
                            <img width="200px" src="{{ asset($item->content_kiril) }}" alt="AAA">
                        </div>
                        @endif
                        @if($item->type_id == 3)
                         <div class="korinish-video">
                            <video  controls src="{{ asset($item->content_kiril) }}"></video>
                        </div>
                        @endif
                        @if($item->type_id == 4)
                        <div>
                                    <img src="{{ asset('admin/style/images/icons/audioBlack.svg') }}" width="18px" alt="AAA"><h1>Audio</h1>
                                    <audio src="{{ asset($item->content_kiril) }}" controls></audio>
                                </div>
                        @endif
                        @if($item->type_id == 5)
                        <a href="{{ asset($item->content_kiril) }}">{{ $item->content_kiril }}</a>
                        @endif
                        @endforeach
                    </div>
                    <div id="korinish_ru" class="korinish-textes">
                        <div class="korinish-h1-p">
                            <div>
                                <h1>{{$topic->name_ru}}</h1>
                            </div>
                            <div class="batafsil-p-i korinish-p-i">
                                <img width="14px" src="style/images/icons/soat.svg" alt="">
                                <p>{{ $topic->updated_at }}</p>
                            </div>
                        </div>
                        @foreach($data as $item)
                        @if($item->type_id == 1)
                        <div class="content-korinish-text">
                           {!! $item->content_ru !!}
                        </div>
                        @endif
                        @if($item->type_id == 2)
                        <div class="korinish-img">
                            <img width="200px" src="{{ asset($item->content_ru) }}" alt="AAA">
                        </div>
                        @endif
                        @if($item->type_id == 3)
                         <div class="korinish-video">
                            <video  controls src="{{ asset($item->content_ru) }}"></video>
                        </div>
                        @endif
                        @if($item->type_id == 4)
                        <div>
                                    <img src="{{ asset('admin/style/images/icons/audioBlack.svg') }}" width="18px" alt="AAA"><h1>Audio</h1>
                                    <audio src="{{ asset($item->content_ru) }}" controls></audio>
                                </div>
                        @endif
                        @if($item->type_id == 5)
                        <a href="{{ asset($item->content_ru) }}">{{ $item->content_ru }}</a>
                        @endif
                        @endforeach
                    </div>
                </div>

@endsection

@section('js')
    <script type="text/javascript">
        function active_but(id_but){
            if (id_but == 'but_uz') {
                $('#but_kr').removeClass('korinish-lang-active');
                $('#but_ru').removeClass('korinish-lang-active');
                $('#but_uz').addClass('korinish-lang-active');
            }
            if (id_but == 'but_kr') {
                $('#but_uz').removeClass('korinish-lang-active');
                $('#but_ru').removeClass('korinish-lang-active');
                $('#but_kr').addClass('korinish-lang-active');
            }
            if (id_but == 'but_ru') {
                $('#but_kr').removeClass('korinish-lang-active');
                $('#but_uz').removeClass('korinish-lang-active');
                $('#but_ru').addClass('korinish-lang-active');
            }
        }
        function display_none(elem){
            if (elem == 'uz') {
                $('#korinish_kr').css({
                    'display': 'none',
                });
                $('#korinish_ru').css({
                    'display': 'none',
                });
                $('#korinish_uz').css({
                    'display': 'block',
                });
            }
            if (elem == 'kr') {
                $('#korinish_uz').css({
                    'display': 'none',
                });
                $('#korinish_ru').css({
                    'display': 'none',
                });
                $('#korinish_kr').css({
                    'display': 'block',
                });
            }
            if (elem == 'ru') {
                $('#korinish_kr').css({
                    'display': 'none',
                });
                $('#korinish_uz').css({
                    'display': 'none',
                });
                $('#korinish_ru').css({
                    'display': 'block',
                });
            }
        }
        $(document).ready(function(){
            active_but('but_uz');
            display_none('uz');
        });
        $('#but_uz').click(function(){
            display_none('uz');
            active_but('but_uz');
        });
        $('#but_kr').click(function(){
            display_none('kr');
            active_but('but_kr');
        });
        $('#but_ru').click(function(){
            display_none('ru');
            active_but('but_ru');
        });
    </script>
@endsection