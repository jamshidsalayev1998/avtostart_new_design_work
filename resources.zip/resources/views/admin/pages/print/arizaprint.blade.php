﻿<!DOCTYPE html>
<html lang="en">

<head>

    <!-- META SECTION -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style media="all">
        body {
            font-family: DejaVu Sans;
            font-size: 15px !important;
            line-height: 1;
            margin-left: 55px;
        }

        .box {
            display: inline-block;
            width: 53%;
        }

        .box2 {
            display: inline-block;
            width: 40%;
        }

        table {
            width: 100%;
        }

        .table-list {
            border-collapse: collapse;
        }

        .table-list {
            border: 0.1px solid black;
        }

        .more {
            page-break-after: always;
        }

        .flex {
            display: flex;
            justify-content: flex-end;
        }
    </style>
    <style media="print">
        @page {
            size: auto;
            margin: 20px;
        }

        .more {
            page-break-after: always;
            font-size: 14px;
        }

        button {
            display: none;
        }
    </style>
    <!-- EOF CSS INCLUDE -->
</head>

<body>

    <button style="float:right;height:25px;position: absolute;" onclick="myFunction()">Hammasini chop etish.</button>
    <br>
    <div id="content">
        <?php $i=1;?>
        @foreach($data as $group)
        <!-- APP WRAPPER -->
        <div class="app">
            <!-- START APP CONTAINER -->
            <div class="app-container">
                <!-- START APP CONTENT -->
                <div class="app-content">
                    <!-- START PAGE CONTAINER -->
                    <div class="container" style="text-align: justify;">

                        <div class="flex">
                            <span style=" margin: 5px 0px 0 0;"> <b> Ўзбекистон Мудофаасига </b> </span><br>
                        </div>
                        <div class="flex">
                            <span style=" margin: 5px 0px 0 0;"> <b> Кўмаклашувчи “Ватанпарвар”</b> </span><br>
                        </div>
                        <div class="flex">
                            <span style=" margin: 5px 0px 0 0;"> @foreach($branch as $bra)<b> {{$bra->name_uz}}</b> @endforeach </span><br>
                        </div>
                        <div class="flex">
                            <span style=" margin: 5px 0px 0 0;"> <b> бошлиғи         @foreach($branch_admin as $bra1)<b> {{$bra1->full_name}}</b> @endforeach</b> </span><br>
                        </div>
                        <div class="flex">
                            <span style=" margin: 5px 0px 0 0;"> <b> Фуқаро <b style="border-bottom: 0.1px solid black;">{{$group->last_name}} {{$group->first_name}} {{$group->middle_name}} </b>дан </b> </span><br>
                        </div>
                        <p style="text-align:center;    margin: 5px 0px 0 0;"> <b> АРИЗА </b></p>
                        Ушбу ариза орқали Сиздан, мени Ўзбекистон Мудофаасига Кўмаклашувчи “Ватанпарвар” ташкилотининг  @foreach($branch as $bra)<b> {{$bra->name_uz}}</b> @endforeach қошида ташкил этилган    <b>
                                @if($group->edu_type ==1)
                                «B» тайёрлаш
                                @endif
                                @if($group->edu_type ==2)
                                «A» тайёрлаш
                                @endif
                                @if($group->edu_type ==3)
                                «C» тайёрлаш
                                @endif
                                @if($group->edu_type ==4)
                                «BC» тайёрлаш
                                @endif
                                @if($group->edu_type ==5)
                                «D» қайта тайёрлаш
                                @endif
                                @if($group->edu_type ==6)
                                «CE» қайта тайёрлаш
                                @endif
                                @if($group->edu_type ==7)
                                «BE» қайта тайёрлаш
                                @endif
                                @if($group->edu_type ==8)
                                «C» қайта тайёрлаш
                                @endif
                                @if($group->edu_type ==9)
                                «DE» қайта тайёрлаш
                                @endif
                            </b> тоифали автотранспорт воситалари хайдовчиларини тайёрлаш курсида тахсил олишга қабул қилишингизни сўрайман.
                        Ўзбекистон Мудофаасига Кўмаклашувчи “Ватанпарвар” ташкилоти Низоми хамда ўқув шартномаси талаб ва мажбуриятлари билан танишдим, уларга тўлиқ риоя этилишини таъминлайман.
                        <br>    Ўзим хақимда қуйидаги маълумотларни маълум қиламан:
                        <br> 1. Ф.И.Ш <b style="border-bottom: 0.1px solid black;margin-bottom:5px;">{{$group->last_name}} {{$group->first_name}} {{$group->middle_name}} </b>
                        <br> 2. Туғилган сана<b style="border-bottom: 0.0.1px solid black;"> {{$group->birth_date}}  </b>
                        <br> 3. Турар жойим<b style="border-bottom: 0.1px solid black;"> {{$group->home_address}}  </b>
                        <br> 4. Паспорт маълумотларим:  Паспорт сер: <b style="text-align: center;border-bottom:0.5px solid black;">{{$group->passport_serial}} </b> № <b style="text-align: center;border-bottom:0.5px solid black;">{{$group->passport_number}} </b>
                        <br> « <b style="text-align: center;border-bottom:0.5px solid black;"><?php echo mb_substr($group->passport_issued_date,0,2)?> </b>» <b style="text-align: center;border-bottom:0.5px solid black;"><?php echo mb_substr($group->passport_issued_date,3,2)?>  </b>&nbsp;   20<b style="text-align: center;border-bottom:0.5px solid black;"><?php echo mb_substr($group->passport_issued_date,8,2)?>  </b> йилда <b style="text-align: center;border-bottom:0.5px solid black;">{{$group->passport_issued_by}} </b> томонидан берилган
                        <br>   5. Рўйхатдан ўтган манзилим <b style="border-bottom: 0.1px solid black;"> {{$group->home_address}}  </b>
                        <br>  6. Маълумотим <b style="border-bottom: 0.1px solid black;"> {{$group->info}}  </b>
                        <br>    7. Иш жойим___________________________________________________________
                        <br>  8. Лавозимим___________________________________________________________
                        <br>   9. Телефон рақамларим: мобил  <b style="border-bottom: 0.1px solid black;"> {{$group->phone1}}  </b>  уй  <b style="border-bottom: 0.1px solid black;"> {{$group->phone2}}  </b>
                        <br>    Машғулотларга қатнашиш имкониятим мавжуд, ўқиш пулининг 30% олдиндан тўлай оламан.
                        <br>   Ўқиш дастурида белгиланган ўқув машғулотларининг 20% ортиғини сабабсиз қолдирсам, ўқув гурухидан четлаштиришим, шунингдек тўлаган пулларим қайтарилмаслиги тўғрисида огохлантирилдим ва ушбу шартларга розиман.
                        <br>      <span style=" margin: 5px 0px 0 0;"> <b> Фуқаро <b style="border-bottom: 0.1px solid black;">{{$group->last_name}} {{$group->first_name}} {{$group->middle_name}} </b>дан </b> </span>  _____________   Имзо
                       
                        <br>    «______»____________2020 йил
                    </div>
                </div>
            </div>
            <p>------------------------------------------------------------------------------------------------------------------------------------</p>
        </div>
        <?php if($i%2==0):?>
        <div class="more"></div>
        <?php endif?>
        <?php $i++;?>

        @endforeach

        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
        <script>
            function myFunction() {
                window.print();
            }
        </script>
    </div>