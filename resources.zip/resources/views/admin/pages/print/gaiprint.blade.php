<html>
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style type="text/css">
        body{
            font-size: 14px;
        }
        .top {
            float: right;
        }
        .container {
            font-family: normal;
            padding-bottom: 200px;
        }
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        .col1{
            float: right;
            line-height: .4;
        }
        .container{
            margin-left: 5%;
            text-align: center;
            width: 90%;
            text-align: justify;
        }
        .col2{
            float: left;
            padding-left: 200px;
            line-height: 31px;
        }
        .col3{
            padding-left: 480px;
            line-height: 31px;
            padding-top: 0.1px;
        }
        .row1{
            margin-left: 5%;
            width: 100%;
            text-align: justify;
        }
        .col4{
            float: left;
        }
        .col5{
            padding-top: 1px;
            padding-left: 400px;
        }
        .col6{
            float: left;
        }
        .col7{
            float: left;
            padding-left: 120px;
        }
        .col8{
            padding-left: 700px;
            padding-top: 1px;
        }
    </style>
    <style media="print" >
        .top {
            float: right;
        }
        .container {
            font-family: normal;
            padding-bottom: 200px;
        }
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        .col1{
            float: right;
            line-height: 10px;
        }
        .container{
            margin-left: 5%;
            text-align: center;
            width: 90%;
            text-align: justify;
        }
        .col2{
            line-height: 90px;
            float: left;
            padding-left: 100px;
            line-height: 31px;
        }
        .col3{
            padding-left: 350px;
            line-height: 31px;
            padding-top: 0.1px;
        }
        .row0{
            line-height: 31px;
        }
        .span1{
            line-height: 20px;
        }
        .p3{
            margin-top: 26px;
        }
        .col4{
            float: left;
        }
        .col5{
            padding-top: 1px;
            padding-left: 280px;
        }
        .col6{
            float: left;
            font-size: 13px;
        }
        .col7{
            font-size: 13px;
            padding-left: 20px;
            float: left;
        }
        .col8{
            font-size: 13px;
            padding-left: 500px;
            /*padding-top: 1px;*/
        }
    </style>
    <style media="print">
 @page {
  size: auto;
  margin: 20px;
       }
       button{
       display: none;
       }
   
            .more {
                page-break-after: always;
                font-size: 14px;
            }
        }
</style>
</head>
<body>
    <button style="float:right;height:25px;" onclick="myFunction()">Hammasini chop etish.</button>
        <div class="block block-condensed">
            <div class="block-content">

                <div class="container" style="">
                    <div class="row">
                        <div class="col1" style="">
                            <p class="">________________________________ </p>
                            <p class=""> YHXB boshligʼi __________________</p></b>
                            <p class=""><b>______________________________ga</b></p>
                        </div>
                    </div>
                    <br><br><br><br><br>

                    <div class="row0">
                        <div class="col-xs-1"></div>
                        <div class="col-xs-11">
                               <p class="p1">
                                @foreach($branch as $bra)
                                <b>{{$bra->name_uz}}</b>
                                @endforeach
                                № _____-sonli
                                @foreach($group as $g)
                                @if($g->edu_type ==1)
                                «B» tayyorlash
                                @endif
                                @if($g->edu_type ==2)
                                «A» tayyorlash
                                @endif
                                @if($g->edu_type ==3)
                                «C» tayyorlash
                                @endif
                                @if($g->edu_type ==4)
                                «BC» tayyorlash
                                @endif
                                @if($g->edu_type ==5)
                                «D» кайта tayyorlash
                                @endif
                                @if($g->edu_type ==6)
                                «CE» кайта tayyorlash
                                @endif
                                @if($g->edu_type ==7)
                                «BE» кайта tayyorlash
                                @endif
                                @if($g->edu_type ==8)
                                «C» кайта tayyorlash
                                @endif
                                @if($g->edu_type ==9)
                                «DE» кайта tayyorlash
                                @endif
                                avtotransport vositasi xaydovchilarini tayyorlash uchun

                                <b>{{$g->name_uz}}</b>
                                @endforeach
                                guruhni ro`yxatga olishingizni soʼraydi.
                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-2"></div>
                        <div class="col-xs-10">
                            <div class="row1">
                                <div class="col2">
                                    <p class="p2"><b>Manzilgoh:</b></p>
                                    <p class="p2"><b>Mashg'ulotlar o'tish vaqti:</b></p>
                                    <p class="p2"><b>Mashg'ulot boshlanishi:</b></p>
                                    <p class="p2"><b>Mashg'ulot tugashi:</b></p>
                                </div>
                                <div class="col3">
                                    <p class="p2"><b>
                                            @foreach($branch as $bra)
                                            <b>{{$bra->address}}</b>
                                            @endforeach
                                        </b>
                                    </p>
                                    <p class="p2"><b>
                                            Soat

                                            <b>{{$start_time}}</b>

                                            dan
                                            <b>{{$end_time}}</b>
                                            gacha


                                        </b></p>
                                    <p class="p2"><b>
                                            @foreach($group as $g)

                                            &lt;&lt; <b>{{mb_substr($g->edu_starting_date,8,2)}}</b> &gt;&gt; &nbsp;
                                            &lt;&lt; {{mb_substr($g->edu_starting_date,5,2)}} &gt;&gt; &nbsp;

                                            {{mb_substr($g->edu_starting_date,0,4)}} </b></p>
                                    <p class="p2"><b>


                                            &lt;&lt; <b>{{mb_substr($g->edu_ending_date,8,2)}}</b> &gt;&gt; &nbsp;
                                            &lt;&lt; {{mb_substr($g->edu_ending_date,5,2)}} &gt;&gt; &nbsp;

                                            {{mb_substr($g->edu_ending_date,0,4)}} </b>
                                        </p>
                                </div>
                            </div>
                             @endforeach
                        </div>
                    </div>
                    <div class="row">
                              <p class="p3">1.
                            <span class="span1">
                                Аvtotransport vositalarining tuzilishi va ishlatishni oʼqitish uchun
                                @foreach($teacher as $t)
                                <b>{{$t->full_name}}</b>

                                tayinlandi. Maʼlumoti&nbsp;<b>{{$t->info}}</b>. <b>{{$t->finish_university}}</b> tamomlagan.
                            </span>
                        </p>
                         <p class="p3">2.
                            <span class="span1">
                                Yo`l harakati qoidalari, avtomobillarni boshqarish asoslari va harakat xavfsizligini
                                oʼqitish boʼyicha
                                <b>{{$t->full_name}}</b>
                                tayinlandi. <b>{{$t->info}}</b>. <b>{{$t->finish_university}}</b> tamomlagan.
                                Xaydovchilik guvohnomasi
                                seriyasi <b class="b1">{{mb_substr($t->driving_number,0,2)}}</b></b> raqami
                                <b>{{mb_substr($t->driving_number,2,7)}} </b>
                                <b>&nbsp; &lt;&lt;{{($t->driving_category)}}&gt;&gt;&nbsp; </b>
                                toifalardan iborat. <b>{{($t->driving_date)}} </b> sanada <b> {{($t->driving_who)}}</b>
                                tomonidan berilgan.
                            </span>
                        </p>
                        @endforeach
                            @foreach($med_teacher as $mt)
                        <p class="p3">3.
                            <span class="span1">
                                Tibbiy yordam koʼrsatish boʼyich <b>{{$mt->full_name}} </b>tayinlandi.
                                Maʼlumoti <b>{{$mt->info}} </b>.
                                <b>{{$mt->finish_university}} </b> tamomlagan.
                            </span>
                        </p>
                        @endforeach
                            <b class="p2">Аvtomobilni amaliy boshqarish ustalari:</b>
                            @foreach($master as $mas)
                                @if($g->master1_id==$mas->id)
                        <p class="p3">1.
                            <span class="span1">
                                <b>{{$mas->full_name}} </b>.Maʼlumoti <b>{{$mas->info}} </b>.
                                Oʼqitish huquqi berilgan guvoxnoma seriyasi <b>{{mb_substr($mas->write,0,2)}} </b>
                                raqami <b>{{mb_substr($mas->write,2,7)}} </b>.
                                Haydovchilik guvohnomasi <b class="b1">&lt;&lt;{{($mas->driving_category)}}&gt;&gt;</b>
                                toifalardan iborat.
                                Seriyasi <b>{{mb_substr($mas->driving_number,0,2)}} </b>
                                raqami <b>{{mb_substr($mas->driving_number,2,7)}} {{($mas->driving_date)}}</b> da
                                <b> {{($mas->driving_who)}}</b> tomonidan berilgan.
                                Аvtomobil rusumi <b class="b1">________</b>
                                davlat raqami <b class="b1">______________</b> boʼlgan
                                oʼquv avtomobilida mashgʼulot oʼtkazish uchun tayinlandi.
                            </span>
                        </p>
                        @endif

                         @if($g->master2_id==$mas->id)
                        
                        <p class="p3 ">2.
                            <span class="span1">
                                <b>{{$mas->full_name}} </b>.Maʼlumoti <b>{{$mas->info}} </b>.
                                Oʼqitish huquqi berilgan guvoxnoma seriyasi <b>{{mb_substr($mas->write,0,2)}} </b>
                                raqami <b>{{mb_substr($mas->write,2,7)}} </b>.
                                Haydovchilik guvohnomasi <b class="b1">&lt;&lt;{{($mas->driving_category)}}&gt;&gt;</b>
                                toifalardan iborat.
                                Seriyasi <b>{{mb_substr($mas->driving_number,0,2)}} </b>
                                raqami <b>{{mb_substr($mas->driving_number,2,7)}} {{($mas->driving_date)}}</b> da
                                <b> {{($mas->driving_who)}}</b> tomonidan berilgan.
                                Аvtomobil rusumi <b class="b1">________</b>
                                davlat raqami <b class="b1">______________</b> boʼlgan
                                oʼquv avtomobilida mashgʼulot oʼtkazish uchun tayinlandi.
                            </span>
                        </p>
                        @endif
                        @endforeach
                         <div class="more">
                             
                         </div>
                    </div>
              
                  
                   
                    <table width="103%" style="font-size:12.5px;">
                        <tbody>
                            <tr>
                                <th style="width:4%;">№</th>
                                <th class="text-center">F.I.SH</th>
                                <th class="text-center" style="width: 12%;">Tug'ilgan sana</th>
                                <th class="text-center" style="width: 10%;">Ma'lumoti</th>
                                <th class="text-center">Tug'ilgan joyi</th>
                                <th class="text-center">Yashash manzili</th>
                            </tr>

                           <?php $i=1?>
                            @foreach($data as $student)
                            <tr>
                                <td style="    text-align: center;"><b> {{$i++}}</b></td>
                                <td>{{$student->last_name}} {{$student->first_name}} {{$student->middle_name}}</td>
                                <td style="    text-align: center;">{{$student->birth_date}}</td>
                                <td class="text-center">{{$student->info}}</td>
                                <td style="    text-align: center;">{{$student->tuman}}</td>
                                <td style="    text-align: center;">{{$student->home_address}}</td>
                            </tr>
                            @endforeach
                           
                        </tbody>
                    </table>
       <br>
                        <table style="width: 100%;">
                            <tr>
                            <td>Ro'yxatga olindi:</td>
                            <td>Mashgʼulot boshlanishi:</td>
                            <td>Mashgʼulot tugashi:</td>
                             </tr>
                                  <tr>
                            <td>  Soat

                                <b>{{$start_time}}</b>

                                dan
                                <b>{{$end_time}}</b>
                                гача
                            </td>
                            <td>{{($g->edu_starting_date)}}</td>
                            <td>{{($g->edu_ending_date)}}</td>
                             </tr>
                           
                        </table>

                   
              
                    <div class="row">
                        <div class="col6">
                            <p class="p5"><b>@foreach($region as $reg)
                                    <b>{{$reg->name_uz}}</b>
                                    @endforeach IIB YHXB RIB</b></p>
                            <p class="p5"><b> @foreach($branch as $bra)
                                    <b>{{$bra->name_uz}}</b>
                                    @endforeach </b></p>
                        </div>
                        <div class="col7">
                             <p class="p5"><b> boshligʼi:______________ </p>
                            <p class="p5"><b> boshligʼi:______________ </p>
                                </b>
                            </b>
                        </div>
                        <div class="col8">
                           <p class="p5"><b>_________________________</b></p>
                            <p class="p5"><b>@foreach($branch_admin as $bran)
                                    <b>{{$bran->full_name}}</b>
                                    @endforeach </b></p>
                         </div>
                    </div>
                </div>
            </div>
        </div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
    <script>
function myFunction() {
  window.print();
}
</script>

</body></html>