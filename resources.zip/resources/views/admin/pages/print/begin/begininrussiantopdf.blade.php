<!DOCTYPE html>
<html lang="en">
<head>
    <title>Boooya - Payment - Invoice</title>

    <!-- META SECTION -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style media="all">
        body {
            font-family: DejaVu Sans;
            line-height: 1;
        }
        .invoice-company
        {
            margin-left: 35.5%;
        }
        .invoice-address
        {
            margin-top: 0px;
        }
        .invoice-header
        {
            padding: 15px;
        }
        .text-right{
            text-align: right;
            font-family: "Consolas", "Bitstream Vera Sans Mono", "Courier New", Courier, monospace;
        }
        .text-italic
        {
            font-style: italic;
        }
        .table {
            width: 100%;
            max-width: 100%;
            margin-bottom: 0;
            padding: 0;
        }
        .table th,
        .table td {
            padding: 0.75rem;
            vertical-align: top;
            border-top: 1px solid #eceeef;
        }
        .table thead th {
            vertical-align: bottom;
            border-bottom: 2px solid #eceeef;
        }
        .table tbody + tbody {
            border-top: 2px solid #eceeef;
        }
        .table .table {
            background-color: #fff;
        }
        .table-sm th,
        .table-sm td {
            padding: 0.3rem;
        }
        .table-bordered {
            border: 1px solid #eceeef;
        }
        .table-bordered th,
        .table-bordered td {
            border: 1px solid #eceeef;
        }
        .table-bordered thead th,
        .table-bordered thead td {
            border-bottom-width: 2px;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.05);
        }
        .table-hover tbody tr:hover {
            background-color: rgba(0, 0, 0, 0.075);
        }
        .table-active,
        .table-active > th,
        .table-active > td {
            background-color: rgba(0, 0, 0, 0.075);
        }
        .table-hover .table-active:hover {
            background-color: rgba(0, 0, 0, 0.075);
        }
        .table-hover .table-active:hover > td,
        .table-hover .table-active:hover > th {
            background-color: rgba(0, 0, 0, 0.075);
        }
        .table-success,
        .table-success > th,
        .table-success > td {
            background-color: #dff0d8;
        }
        .table-hover .table-success:hover {
            background-color: #d0e9c6;
        }
        .table-hover .table-success:hover > td,
        .table-hover .table-success:hover > th {
            background-color: #d0e9c6;
        }
        .table-info,
        .table-info > th,
        .table-info > td {
            background-color: #d9edf7;
        }
        .table-hover .table-info:hover {
            background-color: #c4e3f3;
        }
        .table-hover .table-info:hover > td,
        .table-hover .table-info:hover > th {
            background-color: #c4e3f3;
        }
        .table-warning,
        .table-warning > th,
        .table-warning > td {
            background-color: #fcf8e3;
        }
        .table-hover .table-warning:hover {
            background-color: #faf2cc;
        }
        .table-hover .table-warning:hover > td,
        .table-hover .table-warning:hover > th {
            background-color: #faf2cc;
        }
        .table-danger,
        .table-danger > th,
        .table-danger > td {
            background-color: #f2dede;
        }
        .table-hover .table-danger:hover {
            background-color: #ebcccc;
        }
        .table-hover .table-danger:hover > td,
        .table-hover .table-danger:hover > th {
            background-color: #ebcccc;
        }
        .thead-inverse th {
            color: #fff;
            background-color: #292b2c;
        }
        .thead-default th {
            color: #464a4c;
            background-color: #eceeef;
        }
        .table-inverse {
            color: #fff;
            background-color: #292b2c;
        }
        .table-inverse th,
        .table-inverse td,
        .table-inverse thead th {
            border-color: #fff;
        }
        .table-inverse.table-bordered {
            border: 0;
        }
        .table-responsive {
            display: block;
            width: 100%;
            overflow-x: auto;
            -ms-overflow-style: -ms-autohiding-scrollbar;
        }
        .table-responsive.table-bordered {
            border: 0;
        }
    </style>
    <!-- EOF CSS INCLUDE -->
</head>
<body>

<!-- APP WRAPPER -->
<div class="app">

    <!-- START APP CONTAINER -->
    <div class="app-container">
        <!-- START APP CONTENT -->
        <div class="app-content">
            <!-- START PAGE CONTAINER -->
            <div class="container">

                <div class="invoice">
                    <div class="invoice-header">
                        <div class="row">
                            <div class="col-lg-8 col-lg-offset-2">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="invoice-address">
                                            <table>
                                                <tbody>
                                                <tr>
                                                    <td style="padding-left: -60px; padding-right: 60px;">
                                                        <div class="invoice-company">
                                                            <img src="{{ asset('extra/logo.png') }}"  style="margin-left: 50px;margin-bottom: 20px;">
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <h3 style="text-transform: uppercase;text-align: center;font-size: 18px;margin-bottom: 0;font-weight: 500">
                                                        </h3>
                                                        <hr style="border: 0.5px solid black;margin: 0;padding: 0">
                                                        <h3 style="padding: 0;margin: 0;font-size: 18px;text-align: center;font-weight: 600">BUYRUQ</h3>
                                                        <hr style="border: 0.5px solid black;margin: 0;padding: 0">
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                            <table>
                                                <tr style="border:1px solid red">
                                                    <td>
                                                        <p>
                                                            {{ date('Y',time()) }} yil  "___"  ____________
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p style="text-align: center">
                                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;№ _____________
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="text-right">
                                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $data->branch->region->name_uz }}
                                                        </p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="invoice-container">
                        <div class="row">
                            <div class="col-md-12 col-md-offset-1">
                                <div class="row margin-left-30">
                                    <p><span id="group_name" style="font-weight: bold">{{ $data->name_uz }}</span> «<span id="group_type" style="font-weight: bold">{{ $data->getCourse()->name }}</span>» ўқув гурухи ташкил қилиниши ва тоифаси  тўғрисида»
                                    </p>
                                    <p>
                                        2018 й. ўқув йилида автотранспорт воситалари ҳайдовчиларини тайёрлаш бўйича тасдиқланган режага ва ўқитувчи  <span id="teacher" style="font-weight: bold">{{ $data->teacher->full_name }}</span> ўқув гуруҳида <span id="number" style="font-weight: bold">{{ count($students) }}</span> одам йиғилганлиги тўғрисидаги хабарномасига асосан,
                                    </p>
                                </div>
                            </div>
                            <h2 style="padding: 0;margin: 0;text-align: center;font-weight: bold;font-size: 18px;">Б У Ю Р А М А Н :</h2>
                            <div class="col-lg-8 col-lg-offset-2">
                                <p>
                                    1.	Автотранспорт воситалари ҳайдовчиларини <span style="font-weight: bold">{{ $data->getCourse()->name }}</span> тоифага тайёрлаш бўйича <br><strong>№ <span id="group_name2" style="font-weight: bold">{{ $data->name_uz }}</span></strong> рақамли гуруҳ қуйидаги таркибда йиғилган деб хисоблансин:
                                </p>
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th style="text-align: center;width:10%">#</th>
                                        <th style="width:60%">FIO</th>
                                        <th style="text-align: center;width: 30%;">Tug'ilgan yili</th>
                                    </tr>
                                    </thead>
                                    <tbody class="text-thin" id="students">
                                    @php $i=1; @endphp
                                    @foreach($students as $student)
                                        <tr style="text-align: center">
                                            <td style="padding: 0;margin: 0">{{ $i }}</td>
                                            <td style="padding: 0;margin: 0;text-align: left">&nbsp;&nbsp;{{ $student->student->getFullName() }}</td>
                                            <td style="padding: 0;margin: 0">{{ $student->student->birth_date }}</td>
                                        </tr>
                                        @php $i++; @endphp
                                    @endforeach
                                    </tbody>
                                </table>
                                <p style="font-weight: 400">

                                    1. Таълимнинг бошланиши   : <span id="start_date" style="font-weight: bold">{{ $data->edu_starting_date }}</span> йил<br>
                                    2. Таълимнинг тугалланиши:  <span id="end_date" style="font-weight: bold">{{ $data->edu_ending_date }}</span> йил<br>
                                    3. Машғулотларни ўтказиш жойи: <span id="room" style="font-weight: bold">{{ $data->room->name }}</span><br>
                                    4. Масъул ўқитувчи:  <span id="teacher" style="font-weight: bold">{{  $data->teacher->full_name }}</span><br>
                                    5.Инструкторлар:{{ $info }}
                                </p>
                                <div class="invoice-thanks">
                                    <div class="row">
                                        <div style="width:68%;float: left;">
                                            <p class="text-italic" style="padding: 0;margin: 0;font-weight: 600">«Ватанпарвар» ташкилоти<br>
                                                {{ $data->branch->name_uz }} бошлиги</p>
                                        </div>
                                        <div style="width:28%;float: left;">
                                            <br>
                                            <strong class="text-italic">{{ $bigman }}</strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- END PAGE CONTAINER -->

        </div>
        <!-- END APP CONTENT -->

    </div>
    <!-- END APP CONTAINER -->
    <!-- APP OVERLAY -->
    <div class="app-overlay"></div>
    <!-- END APP OVERLAY -->
</div>
<!-- END APP WRAPPER -->
</body>
</html>