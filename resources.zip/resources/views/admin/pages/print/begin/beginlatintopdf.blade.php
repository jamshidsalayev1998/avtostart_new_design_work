<!DOCTYPE html>
<html lang="en">
<head>
    <title>Buyruq</title>

    <!-- META SECTION -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style media="all">
        body {
            font-family: DejaVu Sans;
            font-size: 12px !important;
            line-height: 1;
        }
        table{
            width: 100%;
        }
        .table-list {
            border-collapse: collapse;
        }
        .table-list {
            border: 1px solid black;
        }
    </style>
    <!-- EOF CSS INCLUDE -->
</head>
<body>

<!-- APP WRAPPER -->
<div class="app">

    <!-- START APP CONTAINER -->
    <div class="app-container">
        <!-- START APP CONTENT -->
        <div class="app-content">
            <!-- START PAGE CONTAINER -->
            <div class="container">
                <table>
                    <tr>
                        <td style="width: 60px">
                            <img src="{{ asset('extra/logo.png') }}"  style="width: 100%;">
                        </td>
                        <td style="text-align: center">
                            <b style="text-transform: uppercase;text-align: center;">
                            </b>
                            <hr style="border: 0.5px solid black;margin: 0;padding: 0">
                            <div style="padding: 0;margin: 0;text-align: center;font-weight: 600">BUYRUQ</div>
                            <hr style="border: 0.5px solid black;margin: 0;padding: 0">
                        </td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <td>
                            <p>
                                {{ date('Y',time()) }} yil  "___"  ____________
                            </p>
                        </td>
                        <td style="width: 30%">
                            <p style="text-align: center">
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;№ _____________
                            </p>
                        </td>
                        <td style="text-align: right">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{ $data->branch->region->name_uz }}
                        </td>
                    </tr>
                </table>
                <p style="text-align: justify">
                    &emsp;&emsp;&emsp;<span id="group_name" style="font-weight: bold">{{ $data->name_uz }}</span> "<span id="group_type" style="font-weight: bold">{{ $data->getCourse()->name }}</span>" oʻquv guruxi tashkil qilinishi va toifasi  toʻgʻrisida"
                </p>
                <p style="text-align: justify">
                    &emsp;&emsp;&emsp;2018-y. oʻquv yilida avtotransport vositalari haydovchilarini tayyorlash boʻyicha tasdiqlangan rejaga va oʻqituvchi  <span id="teacher" style="font-weight: bold">{{ $data->teacher->full_name }}</span> ўқув гуруҳида <span id="number" style="font-weight: bold">{{ count($students) }}</span> odam yigʻilganligi toʻgʻrisidagi xabarnomasiga asosan,
                </p>
                <p style="text-align: center;">
                    <b>B U Y U R A M A N :</b>
                </p>
                <p style="text-align: justify">
                    1.  Avtotransport vositalari haydovchilarini <span style="font-weight: bold">{{ $data->getCourse()->name }}</span> toifaga tayyorlash boʻyicha <strong>№ <span id="group_name2" style="font-weight: bold">{{ $data->name_uz }}</span></strong> raqamli guruh quyidagi tarkibda yigʻilgan deb xisoblansin:
                </p>
                <table class="table-list">
                    <thead class="table-list">
                    <tr>
                        <th class="table-list" style="text-align: center;width: 30px">#</th>
                        <th class="table-list" style="text-align: center">F.I.O.</th>
                        <th class="table-list" style="text-align: center;width: 100px;">Tug'ilgan yili</th>
                    </tr>
                    </thead>
                    <tbody class="text-thin" id="students">
                    @php $i=1; @endphp
                    @foreach($students as $student)
                        <tr style="text-align: center" class="table-list">
                            <td style="padding: 0;margin: 0" class="table-list">
                                {{ $i++ }}
                            </td>
                            <td style="padding: 0;margin: 0;text-align: left" class="table-list">&nbsp;&nbsp;
                                {{ $student['name'] }}
                            </td>
                            <td style="padding: 0;margin: 0" class="table-list">
                                {{ $student['b_date'] }}
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
                <p style="font-weight: 400; text-align: justify">

                    1.  Taʼlimning boshlanishi: <span id="start_date" style="font-weight: bold">{{ $data->edu_starting_date }}</span> yil<br>
                    2.  Taʼlimning tugallanishi:  <span id="end_date" style="font-weight: bold">{{ $data->edu_ending_date }}</span> yil<br>
                    3.  Mashgʻulotlarni oʻtkazish joyi: <span id="room" style="font-weight: bold">{{ $data->room->name }}</span><br>
                    4.  Masʼul oʻqituvchi:  <span id="teacher" style="font-weight: bold">{{  $data->teacher->full_name }}</span><br>
                    5.  Instruktorlar: {{ $info }}
                </p>
                <div style="width:68%;float: left;">
                    <p>
                        <b>
                            “Vatanparvar” tashkiloti<br>
                            {{ $data->branch->name_uz }} boshligi
                        </b>
                    </p>
                </div>
                <div style="width:30%;float: left;">
                    <br>
                    <strong class="text-italic">{{ $bigman }}</strong>
                </div>
            </div>
        </div>
    </div>
</div>