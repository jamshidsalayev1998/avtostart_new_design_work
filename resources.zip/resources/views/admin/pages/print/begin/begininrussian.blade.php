@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('group.index') }}">Pechat qilish</a></li>
            <li class="active">Buyruq boshlanishi</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="app-heading app-heading-bordered app-heading-page">
        <div class="icon icon-lg">
            <span class="icon-clipboard-text"></span>
        </div>
        <div class="heading-elements col-md-12">
            <div class="col-md-3">
                <select class="bs-select group-select"  id="group_id" data-live-search="true" data-dependent="student_id" name="student_id">
                    <option style="display: none">Guruhni tanlang</option>
                    @foreach($groups as $group)
                        <option value="{{ $group->id }}"
                                data-type="{{ $group->getCourse()->name }}"
                                data-room = "{{ $group->room }}"
                                data-start_date = "{{ $group->edu_starting_date }}"
                                data-end_date = "{{ $group->edu_ending_date }}"
                                data-teacher = "{{ $group->teacher->full_name }}"
                                @if($group->assistant_id != null || $group->assistant_id != '') data-assistant = "{{ $group->assistant->full_name }}"@endif
                                data-count_st = "{{ count($group->students) }}">
                            {{ $group->name_uz }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-7">
                <div class="col-md-3">
                    <div class="app-radio">
                        <label><input type="radio" name="app-radio-1" id="app-uzbek" value="0" class="clickable-row" data-href="{{ route('begin') }}"> O'zbek tildia<span></span></label>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="app-radio">
                        <label><input type="radio" name="app-radio-1" id="app-russian" value="1" checked class="clickable-row" data-href="{{ route('begininrussian') }}"> Rus tilida<span></span></label>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="app-radio success">
                        <label><input type="radio" name="app-radio-2" id="app-radio-2" disabled value="0" checked data-href="{{ route('begin') }}" class="clickable-row"> Кириллча<span></span></label>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="app-radio success">
                        <label><input type="radio" name="app-radio-2" id="app-radio-3" value="1" disabled data-href="{{ route('beginwithlatin') }}" class="clickable-row"> Lotincha<span></span></label>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <button onclick="$('#pdf-form').submit()"  class="rendering btn btn-default"><span class="fa fa-download text-danger">&nbsp;</span>Pdfda saqlash</button>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="invoice">
            <div class="invoice-container">
                <div class="row">
                    <div class="col-lg-12 col-lg-offset-5">
                        <div class="row">
                            <div class="center-block">
                                <div class="invoice-company">
                                    <img src="{{ asset('extra/logo.png') }}"  style="margin-left: 50px;">
                                    <br>
                                    <br>
                                    <br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="invoice-container invoice-container-highlight">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="invoice-address">
                                    <h3 style="text-transform: uppercase;text-align: center;font-size: 21px;margin-bottom: 0">
                                    </h3>
                                    <hr style="border: 0.5px solid black;margin: 0;padding: 0">
                                    <h2 style="padding: 0;margin: 0;text-align: center;font-weight: bold">BUYRUQ</h2>
                                    <hr style="border: 0.5px solid black;margin: 0;padding: 0">
                                    <div class="col-md-4">
                                        <p>
                                            {{ date('Y',time()) }} yil  "___"  ____________
                                        </p>
                                    </div>
                                    <div class="col-md-4">
                                        <p style="text-align: center">
                                            № _____________
                                        </p>
                                    </div>
                                    <div class="col-md-4">
                                        <p style="text-align: right">
                                            {{ $region }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="invoice-container">
                <div class="row">
                    <div class="col-md-12 col-md-offset-1">
                        <div class="row margin-left-30">
                            <p><span id="group_name">___</span> «<span id="group_type">___</span>» ўқув гурухи ташкил<br>
                                қилиниши ва тоифаси  тўғрисида»
                            </p>
                            <p>
                                2018 й. ўқув йилида автотранспорт воситалари ҳайдовчиларини тайёрлаш бўйича тасдиқланган режага ва <br>ўқитувчи  <span id="teacher">__________________</span> ўқув гуруҳида <span id="number">___</span> одам йиғилганлиги тўғрисидаги хабарномасига асосан,
                            </p>
                        </div>
                    </div>
                    <h2 style="padding: 0;margin: 0;text-align: center;font-weight: bold">Б У Ю Р А М А Н :</h2>
                    <div class="col-lg-8 col-lg-offset-2">
                        <p>
                            1.	Автотранспорт воситалари ҳайдовчиларини <span id="group_type2">В</span> тоифага тайёрлаш бўйича № <span id="group_name2">___</span> рақамли гуруҳ<br> қуйидаги таркибда йиғилган деб хисоблансин:
                        </p>
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>FIO</th>
                                <th>Tug'ilgan yili</th>
                            </tr>
                            </thead>
                            <tbody class="text-thin" id="students">
                            <p>Guruhni tanlang</p>
                            </tbody>
                        </table>
                        <form method="post" action="{{ route('begininrussiantopdf') }}" id="pdf-form">
                            {{ csrf_field() }}
                            <input type="hidden" name="guruh_id" id="guruh_id">
                            <p>
                                1. Таълимнинг бошланиши   : <span id="start_date">_________</span> йил<br>
                                2. Таълимнинг тугалланиши:  <span id="end_date">_________</span> йил<br>
                                3. Машғулотларни ўтказиш жойи: <span id="room">____</span><br>
                                4. Масъул ўқитувчи:  <span id="teacher2">___________________</span><br>
                                5.Инструкторлар:<textarea class="form-control" rows="6" name="defination" required></textarea>
                            </p>
                            <div class="invoice-thanks">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div>
                                            <strong>«Ватанпарвар» ташкилоти<br>
                                                {{ $branch }} бошлиги</strong>
                                        </div>
                                    </div>
                                    <div class="col-md-6 text-right">
                                        <div class="title"></div>
                                        <strong class="text-italic"><input type="text" name="bigman" required class="pull-right form-control text-right"  value="{{ $bigman }}"></strong>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection