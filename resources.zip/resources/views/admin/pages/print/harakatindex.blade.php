@extends('layouts.admin')

@section('content')

@php $i =1 @endphp

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('group.index') }}">Hujjatlar</a></li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>



    <div class="block block-condensed">

                <br>

                <div class="block-content">
         

            <table class="table table-striped table-bordered datatable-extended">

                        <thead>

                        <tr>

                                <th># </th>

                             <!--    <th>Yaratilgan yili</th> -->

                                <th>Guruh nomi</th>

                    

                                <th>Guruh toifasi</th>

                                <th  width="5%">Baholar Ro`yxati</th>
                                <th  width="5%">Shaxsiy varaqa</th>
                                <th  width="5%">Shartnoma sinov</th>
                                <th  width="5%">Ariza sinov</th>
                                <th  width="5%">Gaiga varaqa</th>
                                <th  width="5%">Yo`llanma</th>

                                <th  width="5%"></th>
                            </tr>

                            </thead>

                            <tbody>



                            @foreach($data as $group)

                               <tr>

                                    

                                    <td>{{$i}}</td>

                                  <!--   <td>{{mb_substr(($group->edu_starting_date), 0,4)}}</td> -->

                                    <td>{{$group->name_uz}}</td>

                                    <td>{{$group->getCourseName() }}</td>
                
                           
                                   <td>
                                             @if($group->status == 1 || $group->status == 2)
                                        <a href="{{'../decisions'}}" target="blank" class="btn btn-default btn-icon">
                                            <i class="fa fa-bitcoin" style="background-color: #7F8FA4;color: white; padding: 8px; border-radius: 8px;"></i>
                                        </a>
                                            @endif
                                    </td>


                                     <td>
                                             @if($group->status == 1 || $group->status == 2)
                                        <a href="{{'../print/harakatprint'}}/{{$group->id}}" target="blank" class="btn btn-default btn-icon">
                                            <i class="icon-printer"  style="background-color: #7F8FA4;color: white; padding: 8px; border-radius: 8px;"></i>
                                        </a>
                                            @endif
                                    </td>
                                     <td>
                                             @if($group->status == 1 || $group->status == 2)
                                        <a href="{{'../print/shartnomaprint'}}/{{$group->id}}" target="blank" class="btn btn-default btn-icon">
                                     <i class="fa fa-book" style="background-color: #7F8FA4;color: white; padding: 8px; border-radius: 8px;"></i>
                                        </a>
                                            @endif
                                    </td>
                                      <td>
                                             @if($group->status == 1 || $group->status == 2)
                                        <a href="{{'../print/arizaprint'}}/{{$group->id}}" target="blank" class="btn btn-default btn-icon">
                                     <i class="fa fa-adn" style="background-color: #7F8FA4;color: white; padding: 8px; border-radius: 8px;"></i>
                                        </a>
                                            @endif
                                    </td>

                                                 <td>
                                             @if($group->status == 1 || $group->status == 2)
                                        <a href="{{'../print/gaiindex'}}/{{$group->id}}" target="blank" class="btn btn-default btn-icon">
                                            <i class="fa fa-file"  style="background-color: #7F8FA4;color: white; padding: 8px; border-radius: 8px;"></i>
                                        </a>
                                            @endif
                                    </td>

                                         <td>
                                                 @if($group->status == 1 || $group->status == 2)
                                        <a href="{{'../print/yullanma'}}/{{$group->id}}" target="blank" class="btn btn-default btn-icon">
                                            <i class="fa fa-file-pdf-o"  style="background-color: #7F8FA4;color: white; padding: 8px; border-radius: 8px;"></i>
                                        </a>
                                         @endif
                                    </td>

                                    <td>

                                        <a href="{{ route('group.show', ['id' => $group->id]) }}"  class="btn btn-default btn-icon">

                                            <i class="icon-eye"  style="background-color: #7F8FA4;color: white; padding: 8px; border-radius: 8px;"></i>

                                        </a>

                                    </td>


                                </tr>

                                

                                @php $i++ @endphp

                            @endforeach

                            </tbody>

                                                        



                        </table>

                      

                    </div>



                </div>



     

        </div>

@endsection