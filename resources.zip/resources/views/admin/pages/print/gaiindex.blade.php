@extends('layouts.admin')

@section('content')

<style type="text/css">
body {
    text-align: justify;
    line-height: 30px;
}

.top {
    float: right;
}

.container {
    font-family: normal;
    padding-bottom: 200px;
}

.p1 {
    font-size: 17px;
    line-height: 30px;
}

.p2 {
    font-size: 17px;
}

.p3 {
    line-height: 30px;
    font-size: 17px;
}

.p4 {
    font-size: 15px;
}

.span1 {
    margin-left: 4px;

}

table,
th,
td {
    border: 1px solid black;
    border-collapse: collapse;
}

.p5 {
    color: black;
    font-size: 16px;
}

.b1 {
    font-size: 15px;
}
</style>



<div class="app-heading-container app-heading-bordered bottom">

    <ul class="breadcrumb">

        <li><a href="/backoffice">Dashboard</a></li>

        <li><a href="{{ route('payment.index') }}">Ariza</a></li>

    </ul>

    <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

</div>

<div class="container">

    <div class="row" style="margin-right: 12px;margin-left: 12px;">

        <div class="panel panel-default">

            <div class="panel-body">

                <div class="col-md-12">

                       <div class="col-md-6"> @foreach($group as $g)
                        <a style="margin:5px;" href="{{ route('gaiprint',['id'=>$g->id]) }}"
                            class="btn btn-success pull-left"><span class="fa fa-plus text-sm">&nbsp;</span>Chop qilish (Pdfga
                            export)</a>
                        @endforeach
                       </a> 

                    </div>
<p style="color: red; text-transform: uppercase;"> Ma`lumotlar xato bo`lsa <b>Foydalanuvchilar</b> bo`limining <b>o`qituvchilar</b> qismidan o`qituvchilarni ma`lumotini va <b>Amaliy ustalar</b> bo`limidan <b>amaliy ustaning</b> ma`lumotini o`zgartirishingiz mumkin!</p>  
                </div>



                @if(session('message'))

                <div class="col-md-10">

                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                        <div class="alert-icon">

                            <span class="icon-checkmark-circle"></span>

                        </div>

                        {{ session('message') }}

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                class="fa fa-times"></span></button>

                    </div>

                </div>

                @endif

            </div>

        </div>
        <?php $x=0;?>
        @foreach($master as $mas)
        <?php $x++;?>
        @endforeach
        @foreach($teacher as $t)
        <?php $a=$t->info;
                                   $b=$t->finish_university;
                                   $c=$t->driving_date;
                                   $d=$t->driving_who;
                                   $e=$t->driving_number;
                                   $f=$t->driving_category;
                                ?>
        @endforeach
        @if(($x!=0)&&($a!=NULL&&$b!=NULL&&$c!=NULL&&$d!=NULL&&$e!=NULL&&$f!=NULL))
        <div class="block block-condensed">
            <div class="block-content">

                <div class="container ">
                    <div class="row">
                        <div class="col-md-8"></div>
                        <div class="col-md-4" style="line-height: .4">
                            <p class="top p3">________________________________</p>
                            <p class="top p3 "> YHXB boshligʼi __________________</p>
                            <p class="top p3"><b>_______________________________ga</b></p>
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-xs-1"></div>
                        <div class="col-xs-11">
                            <p class="p1">
                                @foreach($branch as $bra)
                                <b>{{$bra->name_uz}}</b>
                                @endforeach
                                № _____-sonli
                                @foreach($group as $g)
                                @if($g->edu_type ==1)
                                «B» tayyorlash
                                @endif
                                @if($g->edu_type ==2)
                                «A» tayyorlash
                                @endif
                                @if($g->edu_type ==3)
                                «C» tayyorlash
                                @endif
                                @if($g->edu_type ==4)
                                «BC» tayyorlash
                                @endif
                                @if($g->edu_type ==5)
                                «D» кайта tayyorlash
                                @endif
                                @if($g->edu_type ==6)
                                «CE» кайта tayyorlash
                                @endif
                                @if($g->edu_type ==7)
                                «BE» кайта tayyorlash
                                @endif
                                @if($g->edu_type ==8)
                                «C» кайта tayyorlash
                                @endif
                                @if($g->edu_type ==9)
                                «DE» кайта tayyorlash
                                @endif
                                avtotransport vositasi haydovchilarini tayyorlash uchun

                                <b>{{$g->name_uz}}</b>
                                @endforeach
                                guruhni ro`yxatga olishingizni soʼraydi.
                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-2"></div>
                        <div class="col-xs-10">
                            <div class="row">
                                <div class="col-xs-5">
                                    <p class="p2"><b>Manzilgoh:</b></p>
                                    <p class="p2"><b>Mashg`ulotlar o`tish vaqti:</b></p>
                                    <p class="p2"><b>Mashg`ulot boshlanishi:</b></p>
                                    <p class="p2"><b>Mashg`ulot tugashi:</b></p>
                                </div>
                                <div class="col-xs-7">
                                    <p class="p2"><b>
                                            @foreach($branch as $bra)
                                            <b>{{$bra->address}}</b>
                                            @endforeach
                                        </b>
                                    </p>
                                    <p class="p2"><b>
                                            Soat

                                            <b>{{$start_time}}</b>

                                            dan
                                            <b>{{$end_time}}</b>
                                            gacha


                                        </b></p>
                                    <p class="p2"><b>
                                            @foreach($group as $g)

                                            &lt;&lt; <b>{{mb_substr($g->edu_starting_date,8,2)}}</b> &gt;&gt; &nbsp;
                                            &lt;&lt; {{mb_substr($g->edu_starting_date,5,2)}} &gt;&gt; &nbsp;

                                            {{mb_substr($g->edu_starting_date,0,4)}} </b></p>
                                    <p class="p2"><b>


                                            &lt;&lt; <b>{{mb_substr($g->edu_ending_date,8,2)}}</b> &gt;&gt; &nbsp;
                                            &lt;&lt; {{mb_substr($g->edu_ending_date,5,2)}} &gt;&gt; &nbsp;

                                            {{mb_substr($g->edu_ending_date,0,4)}} </b>
                                        </p>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                    <div class="row">
                        <p class="p3">1.
                            <span class="span1">
                                Аvtotransport vositalarining tuzilishi va ishlatishni oʼqitish uchun
                                @foreach($teacher as $t)
                                <b>{{$t->full_name}}</b>

                                tayinlandi. Maʼlumoti<b>{{$t->info}}</b>. <b>{{$t->finish_university}}</b> tamomlagan.
                            </span>
                        </p>
                        <p class="p3">2.
                            <span class="span1">
                                Yo`l harakati qoidalari, avtomobillarni boshqarish asoslari va harakat xavfsizligini
                                oʼqitish
                                boʼyicha
                                <b>{{$t->full_name}}</b>
                                tayinlandi. <b>{{$t->info}}</b>. <b>{{$t->finish_university}}</b> tamomlagan.
                                Xaydovchilik guvohnomasi
                                seriyasi <b class="b1">{{mb_substr($t->driving_number,0,2)}}</b></b> raqami
                                <b>{{mb_substr($t->driving_number,2,7)}} </b>
                                <b>&nbsp; &lt;&lt;{{($t->driving_category)}}&gt;&gt;&nbsp; </b>
                                toifalarrdan iborat. <b>{{($t->driving_date)}} </b> sanada <b> {{($t->driving_who)}}</b>
                                tomonidan berilgan.
                            </span>
                        </p>
                        @endforeach
                        @foreach($med_teacher as $mt)
                        <p class="p3">3.
                            <span class="span1">
                                Tibbiy yordam koʼrsatish boʼyich <b>{{$mt->full_name}} </b>tayinlandi.
                                Maʼlumoti <b>{{$mt->info}} </b>.
                                <b>{{$mt->finish_university}} </b>.
                            </span>
                        </p>
                        @endforeach
                        <b class="p2">Аvtomobilni amaliy boshqarish ustalari:</b>
                      @foreach($master as $mas)
                                @if($g->master1_id==$mas->id)
                        <p class="p3">1.
                            <span class="span1">
                                <b>{{$mas->full_name}} </b>.Maʼlumoti <b>{{$mas->info}} </b>.
                                Oʼqitish huquqi berilgan guvoxnoma seriyasi <b>{{mb_substr($mas->write,0,2)}} </b>
                                raqami <b>{{mb_substr($mas->write,2,7)}} </b>.
                                Haydovchilik guvohnomasi <b class="b1">&lt;&lt;{{($mas->driving_category)}}&gt;&gt;</b>
                                toifalardan iborat.
                                Seriyasi <b>{{mb_substr($mas->driving_number,0,2)}} </b>
                                raqami <b>{{mb_substr($mas->driving_number,2,7)}} {{($mas->driving_date)}}</b> da
                                <b> {{($mas->driving_who)}}</b> tomonidan berilgan.
                                Аvtomobil rusumi <b class="b1">________</b>
                                davlat raqami <b class="b1">______________</b> boʼlgan
                                oʼquv avtomobilida mashgʼulot oʼtkazish uchun tayinlandi.
                            </span>
                        </p>
                        @endif
                         @if($g->master2_id==$mas->id)
                        <p class="p3">2.
                            <span class="span1">
                                <b>{{$mas->full_name}} </b>.Maʼlumoti <b>{{$mas->info}} </b>.
                                Oʼqitish huquqi berilgan guvoxnoma seriyasi <b>{{mb_substr($mas->write,0,2)}} </b>
                                raqami <b>{{mb_substr($mas->write,2,7)}} </b>.
                                Haydovchilik guvohnomasi <b class="b1">&lt;&lt;{{($mas->driving_category)}}&gt;&gt;</b>
                                toifalardan iborat.
                                Seriyasi <b>{{mb_substr($mas->driving_number,0,2)}} </b>
                                raqami <b>{{mb_substr($mas->driving_number,2,7)}} {{($mas->driving_date)}}</b> da
                                <b> {{($mas->driving_who)}}</b> tomonidan berilgan.
                                Аvtomobil rusumi <b class="b1">________</b>
                                davlat raqami <b class="b1">______________</b> boʼlgan
                                oʼquv avtomobilida mashgʼulot oʼtkazish uchun tayinlandi.
                            </span>
                        </p>
                        @endif
                        @endforeach
                    </div>
                    <table width="100%" style="font-size:14px;">
                        <tbody>
                            <tr>
                                <th style="width:4%;">№</th>
                                <th class="text-center">F.I.SH</th>
                                <th class="text-center" style="width: 12%;">Tug`ilgan sana</th>
                                <th class="text-center" style="width: 10%;">Ma`lumoti</th>
                                <th class="text-center">Tug`ilgan joyi</th>
                                <th class="text-center">Yashash manzili</th>
                            </tr>
                            <?php $i=1?>
                            @foreach($data as $student)
                            <tr>
                                <td style="    text-align: center;"><b> {{$i++}}</b></td>
                                <td>{{$student->last_name}} {{$student->first_name}} {{$student->middle_name}}</td>
                                <td style="    text-align: center;">{{$student->birth_date}}</td>
                                <td class="text-center">{{$student->info}}</td>
                                <td style="    text-align: center;">{{$student->tuman}}</td>
                                <td style="    text-align: center;">{{$student->home_address}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <br><br>

                    <div class="row">
                        <div class="col-xs-4">
                            <p class="p4"><b>Ro`yxatga olindi:</b></p>
                            <p class="p4"><b>Mashgʼulot boshlanishi:</b></p>
                            <p class="p4"><b>Mashgʼulot tugashi:</b></p>
                        </div>
                        <div class="col-xs-8">
                            <p class="p2"> Soat

                                <b>{{$start_time}}</b>

                                dan
                                <b>{{$end_time}}</b>
                                гача


                                </b></p>
                            <p class="p4"><b>
                                    @foreach($group as $g)

                                    &lt;&lt; <b>{{mb_substr($g->edu_starting_date,8,2)}}</b> &gt;&gt; &nbsp;
                                    &lt;&lt; {{mb_substr($g->edu_starting_date,5,2)}} &gt;&gt; &nbsp;

                                    {{mb_substr($g->edu_starting_date,0,4)}}</b></p>
                            <p class="p4"><b>

                                    &lt;&lt; <b>{{mb_substr($g->edu_ending_date,8,2)}}</b> &gt;&gt; &nbsp;
                                    &lt;&lt; {{mb_substr($g->edu_ending_date,5,2)}} &gt;&gt; &nbsp;

                                    {{mb_substr($g->edu_ending_date,0,4)}} </b></p>
                        </div>
                    </div>
                    @endforeach
                    <br>
                    <div class="row">
                        <div class="col-xs-4">
                            <p class="p5"><b>@foreach($region as $reg)
                                    <b>{{$reg->name_uz}}</b>
                                    @endforeach IIB YHXB RIB</b></p>
                            <p class="p5"><b> @foreach($branch as $bra)
                                    <b>{{$bra->name_uz}}</b>
                                    @endforeach </b></p>
                        </div>
                        <div class="col-xs-4">
                            <p class="p5"><b> boshligʼi:________________________ </p>
                            <p class="p5"><b> boshligʼi:________________________ </p>
                        </div>
                        <div class="col-xs-4">
                            <p class="p5"><b>______________________________</b></p>
                            <p class="p5"><b>@foreach($branch_admin as $bran)
                                    <b>{{$bran->full_name}}</b>
                                    @endforeach </b></p>
                        </div>
                    </div>


                </div>

            </div>

        </div>
        @endif


    </div>

</div>

</div>
    <script>
function myFunction() {
  window.print();
}
</script>
@endsection