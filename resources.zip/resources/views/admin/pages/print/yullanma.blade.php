<html>
<head>
    <style>
    	body{
    		font-size: 12px;
    	}
	    table, th, td {
	        border: 1px solid black;
	        border-collapse: collapse;
	    }
	    .col1{
	    	float: right;
	    	line-height: 10px;
	    }
	    .container{
	    	margin-left: 10%;
	    	text-align: center;
	    	width: 80%;
			text-align: justify;
	    }
        .yullanma{
            text-align: center;
            font-size: 20px;
            white-space: pre;
            padding-top: 70px;
            
        }
        p{
            font-family: inherit;
        }
        span{
            font-family: inherit;
        }
        .table{
            text-align: center;
            margin-left: 295px;
            line-height: 0;
        }
        .ilova{
            text-align: center;
            font-weight: bold;
            font-size: 15px;
        }
        .table1{
            font-size: 25px;
        }
        .coment{
            margin-left: -418px;
        }
        .input1{
            outline: none;
            width: 400px;
            font-size: 20px;
            margin-left: 61px;
        }
        .input2{
            outline: none;
            width: 400px;
            font-size: 20px;
            margin-left: 96px;
        }
        .input3{
            outline: none;
            width: 400px;
            font-size: 20px;
            margin-left: 22px;
        }
        .input4{
            outline: none;
            width: 200px;
            font-size: 20px;
            margin-left: 23px;
        }
        .spna{
          font-size: 17px;  
        }
        .seriya{
            outline: none;
            width: 60px;
            font-size: 20px;
        }
        .number{
            width:120px;
            outline: none;
            font-size: 20px;
        }
        .hr{
            margin-top: 40px;
            line-height: .9;
        }
        .coment1{
            text-align: center;
            margin-top: -3px;
        }
        .from1{
            outline: none;
            margin-top: 23px;
            width: 290px;
        }
        .imzo{
            margin-left: 120px;
        }
        .td{
            height: 30px;
            text-align: center;
        }
    </style>
       <style media="print">
       	.table{
            text-align: center;
            margin-left: 95px;
            line-height: 0;
        }
        .coment{
        	text-align: center;
        	margin-left: -60px;
        }
 @page {
  size: auto;
  margin: 20px;
       }
       button{
           display:none;
       }
</style>
</head>
<body>
	<button style="height:25px;" onclick="myFunction()">Hammasini chop etish.</button>
    <div class="block block-condensed">
        <div class="block-content">
        	    @foreach($data as $student)
            <div class="container">
            	

                <div class="row">
                    <div class="col1">
                        <p>Yo'riqnoma</p>
                        <p>№ 1 ilova</p></b>
                    </div>
                </div>
                <p class="yullanma">Y O' L L A N M A </p>
                <p class="ilova">Toifasi bo'yicha yo'li harakati qoidalari va avtotransport vositalarini amaliy boshqarish bo`yicha ko`nikmalarni tekshirish</p>
                <div  class="table">
                       <table class="table-list" style="font-size: 16px;">
                    <thead class="table-list">
                    <tr>
                    <th class="table-list" style="text-align: center;width:40px">A</th>
                        <th class="table-list" style="text-align: center;width: 40px">B</th>
                        <th class="table-list" style="text-align: center;width: 40px;">C(Т)</th>
                          <th class="table-list" style="text-align: center;width: 40px;">BC</th>
                          <th class="table-list" style="text-align: center;width: 40px;">D</th>
                          <th class="table-list" style="text-align: center;width: 40px;">C(ҚТ)</th>
                          <th class="table-list" style="text-align: center;width: 40px;">BE</th>
                      <th class="table-list" style="text-align: center;width: 40px;">CE</th>
                        <th class="table-list" style="text-align: center;width: 40px;">DE</th>

                      
                    </tr>
                    </thead>
                    <tbody class="text-thin" id="students">

                 <tr style="text-align: center" class="table-list">
            <td style="padding: 0;margin: 0; font-size:20px; text-align:center;"  class="table-list">
                        @foreach($groups as $group)
                            @if($group->edu_type ==2)
                          <p>  XXX</p>
                            @endif
                          
            </td>
   <td style="padding: 0;margin: 0; font-size:20px; text-align:center;"  class="table-list">
            @if($group->edu_type ==1)
                                XXX
                            @endif
                            
            </td>
         <td style="padding: 0;margin: 0; font-size:20px; text-align:center;"  class="table-list">
            @if($group->edu_type ==3)
                               XXX
                            @endif
                            
            </td>
            <td style="padding: 0;margin: 0; font-size:20px; text-align:center;"  class="table-list">
       
                            @if($group->edu_type ==4)
                         XXX
                            @endif
                           
            </td>
           <td style="padding: 0;margin: 0; font-size:20px; text-align:center;"  class="table-list">
            @if($group->edu_type ==5)
                           XXX
                            @endif
                           
            </td>
          <td style="padding: 0;margin: 0; font-size:20px; text-align:center;"  class="table-list">
            
                            @if($group->edu_type ==8)
                            XXX
                            @endif
                          
            </td>
          <td style="padding: 0;margin: 0; font-size:20px; text-align:center;"  class="table-list">
           
                            @if($group->edu_type ==7)
                            XXX
                            @endif
                           
            </td>
       <td style="padding: 0;margin: 0; font-size:20px; text-align:center;"  class="table-list">
            @if($group->edu_type ==6)
                              XXX
                            @endif 
                           
            </td>
       <td style="padding: 0;margin: 0; font-size:20px; text-align:center;"  class="table-list">
            @if($group->edu_type ==9)
                           XXX
                            @endif
            </td>
                    
            </tr>
                     @endforeach
                    </tbody>
                </table>
                    <p style="text-align: center;" class="coment">(IZOX: Tegishli toifaga «XXX» belgisi qoʼyiladi)</p>  
                </div><br><br><br>
                <form>
                    <span class="spna">Familiya:</span> <input type="text" name="" value="{{$student->last_name}}" class="input1"><br><br>
                    <span class="spna">Ism:</span> <input type="text" name="" value="{{$student->first_name}}" class="input2"><br><br>
                    <span class="spna">Otasining ismi:</span> <input type="text" value="{{$student->middle_name}}" name="" class="input3"><br><br>
                    <span class="spna">Tug'ilgan sana:</span> <input type="text" value="{{$student->birth_date}}" name="" class="input4">
                </form><br>
                <span class="spna">Guvohnoma berilgan: seriya</span>
                <input type="text" name="" class="seriya">
                <span>№</span>
                <span><input type="text" name="" class="number"></span>
                <div class="hr" style="margin-bottom: 10px;    margin-top: 30px;">
                   <p style="text-align: center;">   @foreach($branch as $bra)
                        {{$bra->name_uz}}
                        @endforeach boshlig`i @foreach($branch_admin as $bran)
                                    <b>{{$bran->full_name}}</b>
                                    @endforeach  </p> 
                    <hr>
                    <p class="coment1">(guvohnoma bergan tashkilot, shaxsning lavozimi, familiyasi, ismi, otasining ismi)</p> 
                    <hr>
                </div>

                <form>
                    <input class="from1" type="" name=""> <span class="imzo">Imzo__________________</span>
                </form><br><br>

                <table width="100%" style="font-size:14px;">
                    <tbody>
                        <tr>
                            <th style="width:4%;"  rowspan ="2">№</th>
                            <th rowspan ="2">Bayonnoma raqami</th>
                            <th rowspan ="2">Tekshirilgan vaqt</th>
                            <th style="width: 12%;" colspan="2"> Yo'lharakati qoidalari va avtoransport vositalarini amaliy boshqarish bo`yicha ko`nikmlarni tekshirish natijalari</th>
                            <th rowspan ="2">TRIB xodimi imzosi</th>
                        </tr>
                        <tr>
                            <th class="text-center" style="width: 12%;">Nazariy</th>
                            <th class="text-center" style="width: 10%;">Amaliy</th>
                        </tr>
                        <tr>
                            <td class="td">1</td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                        </tr>
                        <tr>
                            <td class="td">2</td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                        </tr>
                        <tr>
                            <td class="td">3</td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                        </tr>
                        <tr>
                            <td class="td">4</td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                        </tr>
                        <tr>
                            <td class="td">5</td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                        </tr>
                        <tr>
                            <td class="td">6</td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                            <td class="td"></td>
                        </tr>
                    </tbody>
                </table>
                <br>
           
                
            </div>
        </div>
              @endforeach
    </div>
</body>
 <script>
function myFunction() {
  window.print();
}
</script>
</html>