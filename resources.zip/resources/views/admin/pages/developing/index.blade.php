@extends('layouts.admin')

@section('content')
<div class="app-heading-container app-heading-bordered bottom">
    <ul class="breadcrumb">
        <li><a href="/backoffice">Dashboard</a></li>
        <li><a href="{{ route('developing.index') }}">Developing mode</a></li>
    </ul>
    <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
</div>
<div class="container">
    <div class="row">

        <div class="col-md-12">

            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="col-md-6">
                        Welcome to developing mode! Add your IP and activate developing mode
                    </div>
                    <div class="col-md-3 margin-top-10">
                        <label class="pull-right" style="font-size: 15px;margin-top: -10px;">Current status: <strong>Inactive</strong></label>
                    </div>
                    <div class="col-md-3">
                            <form id="developing" method="post" action="{{ route('developing_status') }}">
                                {{ csrf_field() }}
                                <div class="form-group">
                                    <select class="form-control" name="status">
                                        <option value="on">Activate</option>
                                        <option value="off">Deactivate</option>
                                    </select>
                                    <button type="submit" class="btn btn-default">Go</button>
                                </div>
                            </form>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="col-md-2">
                        <button data-toggle="modal" data-target="#modal-default" class="btn btn-default"><i class="icon-plus-circle">&nbsp;</i>Add IP</button>
                    </div>

                    @if(session('message'))
                    <div class="col-md-10">
                        <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                            <div class="alert-icon">
                                <span class="icon-checkmark-circle"></span>
                            </div>
                            {{ session('message') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                        </div>
                    </div>
                    @endif
                    @if(session('error'))
                    <div class="col-md-10">
                        <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">
                            <div class="alert-icon">
                                <span class="icon-checkmark-circle"></span>
                            </div>
                            {{ session('error') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                        </div>
                    </div>
                    @endif
                </div>
            </div>

            <div class="block">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <th style="width: 2%">#</th>
                        <th>Your IP</th>
                        <th>Created at</th>
                        <th colspan="1" style="width: 8%"></th>
                    </tr>
                    </thead>
                    <tbody>
                    @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp
                    @foreach($data as $item)
                    <tr>
                        <td>{{ ++$count }}</td>
                        <td>{{ $item->ip }}</td>
                        <td>{{ date('Y.m.d, H:i',$item->created_at) }}</td>
                        <td>
                            <form action="{{ route('developing.destroy', ['id' => $item->id]) }}" method="post">
                                {{ csrf_field() }}
                                {{ method_field('delete') }}
                                <button class="btn btn-default btn-icon deleteData"><i class="icon-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                    </tbody>
                </table>

                {!! $data->links() !!}

            </div>

        </div>


    </div>
</div>

<div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="modal-default-header">
    <div class="modal-dialog" role="document">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="modal-default-header">Add your IP</h4>
            </div>
            <form action="{{ route('developing.store') }}" method="post">
                {{ csrf_field() }}
                <div class="modal-body">
                    <div class="form-group">
                        <label>Your IP
                            @if($errors->has('ip'))
                            <span class="text-danger"> | {{ $errors->first('ip') }}</span>
                            @endif
                        </label>
                        <input type="text" name="ip" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-link" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-default">Add to list</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection