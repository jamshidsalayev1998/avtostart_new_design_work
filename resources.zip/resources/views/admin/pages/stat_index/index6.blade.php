@extends('layouts.admin')
@section('content')

	<div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
        </ul>
    </div>

    <div class="container">
    	<div class="row">
    		<div class="panel panel-default">
                <div class="panel-body">
                    <div class="col-md-12">
                        <div class="col-md-6">
                            <h3 style="float: left"> Viloyat bo`yicha umuiy statistika</h3>
                        </div>

                    </div>


                </div>
            </div>
             <div class="block block-condensed">
             	 <div class="block-content">
             	 	<br>
             	 	<table class="table table-bordered datatable-extended">
             	 		<thead>
             	 			<tr>
             	 				<th>#</th>
             	 				<th>Filiallar</th>
             	 				<th>Guruhlar </th>
             	 				<th>Tugagan guruhlar</th>
             	 				<th>Aktiv guruhlar</th>
             	 				<th>O`quvchilar</th>
             	 				<th>Tugatgan oquvchilar</th>
             	 			</tr>
             	 		</thead>
             	 		<tbody>
             	 			<?php $i = 1;?>
             	 			@foreach($data as $item)
             	 			<tr>
								<td>{{$i}}<?php $i++;?></td>
             	 				<td>{{$item->name_uz}}</td>
             	 				<td>{{$item->groups}}</td>
             	 				<td>{{$item->ended_groups}}</td>
             	 				<td>{{$item->active_groups}}</td>
             	 				<td>{{$item->students}}</td>
             	 				<td>{{$item->ended_students}}</td>

             	 			</tr>
             	 			@endforeach
             	 		</tbody>
             	 	</table>
             	 </div>
             </div>
    	</div>
    </div>


@endsection