@extends('layouts.admin')
@section('content')

	<div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
        </ul>
    </div>

    <div class="container">
    	<div class="row">
    		<div class="panel panel-default">
                <div class="panel-body">
                    <div class="col-md-12">

                        <div class="app-content-tabs">
                                <ul>
                                    <li><a href="#t1" class="active"><span class="fa fa-group"></span>Guruhlar kesimida statistika</a></li>
                                    <li><a href="#t2"><span class="fa fa-globe"></span>Umumiy statistika </a></li>
                                </ul>
                            </div>

                    </div>


                </div>
            </div>
             <div class="block block-condensed">
             	 <div class="block-content">
             	 	<br>
             	 	<div class="app-content-tab active " id="t1">
	             	 	<table class="table table-bordered datatable-extended">
	             	 		<thead>
	             	 			<tr>
	             	 				<th>#</th>
	             	 				<th>Guruhllar</th>
	             	 				<th>O`quvchilar soni</th>
	             	 				<th>Chetlashtirilganlar</th>
	             	 				<th>Ta`lim holati</th>
	             	 				<th>Ais uchun to`lov holati</th>
	             	 			</tr>
	             	 		</thead>
	             	 		<tbody>
	             	 			<?php $i = 1;?>
	             	 			@foreach($data as $item)
	             	 			<tr>
									<td>{{$i}}<?php $i++;?></td>
	             	 				<td>{{$item->name_uz}}</td>
	             	 				<td>{{$item->students}}</td>
	             	 				<td>{{$item->returns}}</td>
	             	 				@if($item->status == 0)
	             	 				<td style="color: red">Passiv</td>
	             	 				@endif
	             	 				@if($item->status == 1)
	             	 				<td style="color: green">Aktiv</td>
	             	 				@endif
	             	 				@if($item->status == 2)
	             	 				<td >Tugagan</td>
	             	 				@endif
	             	 				@if($item->paygroups == 100)
	             	 				<td style="color: green;">To`langan</td>
	             	 				@endif
	             	 				@if($item->paygroups == 30 || $item->paygroups == 70)
	             	 				<td style="color: yellow;">Qisman</td>
	             	 				@endif
	             	 				@if($item->paygroups == 0)
	             	 				<td style="color: red;">To`lanmagan</td>
	             	 				@endif




	             	 			</tr>
	             	 			@endforeach
	             	 		</tbody>
	             	 	</table>
             	 	</div>
             	 	<div class="app-content-tab  " id="t2">
             	 		<table class="table table-bordered">
             	 			<thead>
             	 				<tr>
             	 					<th>Malumot</th>
             	 					<th>Qiymati</th>
             	 				</tr>
             	 			</thead>
             	 			<tbody>
             	 				<tr>
             	 					<td>Guruhlar soni</td>
             	 					<td>{{$data2->groupsc}}</td>
             	 				</tr>
             	 				<tr>
             	 					<td>Ta`lim tugagan guruhlar</td>
             	 					<td>{{$data2->ended_groups}}</td>
             	 				</tr>
             	 				<tr>
             	 					<td>O`quvchilar</td>
             	 					<td>{{$data2->students}}</td>
             	 				</tr>
             	 				<tr>
             	 					<td>Tugatgan o`quvchilar</td>
             	 					<td>{{$data2->ended_students}}</td>
             	 				</tr>
             	 				<tr>
             	 					<td>Ais uchun tolov qilinganlar</td>
             	 					<td>{{$payed_groups}}</td>
             	 				</tr>
             	 				<tr>
             	 					<td>Chetlashtirilganlar</td>
             	 					<td>{{$data2->returneds}}</td>
             	 				</tr>
             	 				<tr>
             	 					<td>O`qituvchilar</td>
             	 					<td>{{$data2->teachers}}</td>
             	 				</tr>
             	 				<tr>
             	 					<td>Hisobchilar</td>
             	 					<td>{{$data2->accountants}}</td>
             	 				</tr>
             	 			</tbody>
             	 		</table>
             	 	</div>
             	 </div>
             </div>
    	</div>
    </div>


@endsection