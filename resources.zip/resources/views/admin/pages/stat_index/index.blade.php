@extends('layouts.admin')
@section('content')

<style>
  .card_div_1{
    width: 100%;

    border: none;
    color: white;
    padding: 12px;
    border-radius: 5px;
  }
  .card_div_2{
    font-size: 25px;
    margin: 5px;
  }
  .card_div_3{
    font-size: 16px;
    margin: 5px;
  }
  .card_div_4{
    margin: 5px;
    font-weight: 9;
    text-align: center;
    cursor: pointer;
  }
  .card_div_4:hover{
    font-size: 14px;
    }
  .bg_yellow{
     background-color: #FEC007;
  }
  .bg_green{
    background-color: #28A745;
  }
  .bg_dark{
    background-color: #6B6B6B;

  }
  .bg_light{
    background-color: #D8D8D8;

  }
  .bg_red{
    background-color: #DC3545;
  }
  .card_self{
    height: 170px;
  }
</style>


	<div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
        </ul>
    </div>

    <div class="container">
    	<div class="row">
    		<div class="block block-condensed">
             	 <div class="block-content" >
             	 	<br>

                  <div class="col-md-3 " >
                    <div class="card_self card_div_1 bg_yellow" >
                      <div class="col-md-8 card_div_2">{{$data2->groupsc}}</div>
                      <div class="col-md-3 " ><span style="font-size: 45px;" class="fa fa-group"></span></div>
                      <div  class="card_div_3">Guruhlar soni <br> (oxirgi kvartal)</div>
                      <hr>
                      <div  class="border-top card_div_4">
                        Ro`yxat
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 " >
                    <div class="card_self card_div_1 bg_green" >
                      <div class="col-md-8 card_div_2">{{$data2->students}}</div>
                      <div class="col-md-3 " ><span style="font-size: 45px;" class="fa fa-user"></span></div>
                      <div  class="card_div_3">O`quvchilar soni <br> (oxirgi kvartal)</div>
                      <hr>
                      <div  class="border-top card_div_4">
                        Ro`yxat
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 " >
                    <div class=" card_self card_div_1 bg_dark" >
                      <?php
function formatMoney($number, $fractional = false) {
	if ($fractional) {
		$number = sprintf('%.2f', $number);
	}
	while (true) {
		$replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
		if ($replaced != $number) {
			$number = $replaced;
		} else {
			break;
		}
	}
	return $number;
}
?>
                      <div class="col-md-8 card_div_2"> {{formatMoney( $payment)}}</div>
                      <div class="col-md-3 " ><span style="font-size: 45px;" class="fa fa-money"></span></div>
                      <div  class="card_div_3">To`langan summa <br> (oxirgi kvartal)</div>
                      <hr>
                      <div  class="border-top card_div_4">
                        Ro`yxat
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 " >
                    <div class=" card_self card_div_1 bg_red" >
                      <div class="col-md-8 card_div_2">{{formatMoney($paygroup)}}</div>
                      <div class="col-md-3 " ><span style="font-size: 45px;" class="fa fa-usd"></span></div>
                      <div  class="card_div_3"> Ais to`lov <br> (oxirgi kvartal)</div>
                      <hr>
                      <div  class="border-top card_div_4">
                        Ro`yxat
                      </div>
                    </div>
                  </div>


             	 </div>
            </div>
    	</div>
    </div>




@endsection