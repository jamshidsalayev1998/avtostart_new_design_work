@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="block">

                    <form action="{{ route('area.update', ['id' => $data->id]) }}" method="post">

                        {{ csrf_field() }}
                        {{ method_field('put') }}

                        <div class="col-md-6">
                            <label for="name_ru">Tuman nomi</label>
                            <input type="text" name="name" id="name" class="form-control" value="{{ $data->name}}" required>
                        </div>

                        <div class="col-md-6">
                            <label for="name_uz">Viloyati</label>
                            <select name = "region_id" class="form-control">
                                @foreach($regions as $region)
                                    <option @if($data->region_id == $region->id) selected @endif value="{{$region->id}}">{{$region->name_uz}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-6 margin-top-20" style="clear: both">
                            <button class="btn btn-success btn-block">O'zgarishlarni Saqlash</button>
                        </div>
                        <div class="col-md-6 margin-top-20">
                            <a href="{{ url()->previous() }}" class="btn btn-warning btn-block">Bekor qilish</a>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
@endsection