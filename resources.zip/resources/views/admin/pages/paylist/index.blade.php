@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">
                    <div class="panel-heading">

                    </div>
                    <div class="panel-body">
                        @if(session('message'))
                            <div class="col-12">
                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        @endif
                        <table class="table">
                            <tbody>
                                <tr>
                                    <th>Tashkilot nomi</th>
                                    <td>{{ $data->name }}</td>
                                </tr>
                                <tr>
                                    <th>Manzil</th>
                                    <td>{{ $data->address }}</td>
                                </tr>
                                <tr>
                                    <th>Telfon raqami</th>
                                    <td>{{ $data->phone }}</td>
                                </tr>
                                <tr>
                                    <th>Bank</th>
                                    <td>{{ $data->bank }}</td>
                                </tr>
                                <tr>
                                    <th>Hisob raqam</th>
                                    <td>{{ $data->bill }}</td>
                                </tr>
                                <tr>
                                    <th>INN</th>
                                    <td>{{ $data->inn }}</td>
                                </tr>
                                <tr>
                                    <th>MFO</th>
                                    <td>{{ $data->mfo }}</td>
                                </tr>
                                <tr>
                                    <th>Bitta o'quvchi uchun narx</th>
                                    <td>{{ $data->price }} so'm</td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="col-12 text-right">
                            <a href="{{ route('paylist.create') }}" class="btn btn-success">Tahrirlash</a>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
@endsection