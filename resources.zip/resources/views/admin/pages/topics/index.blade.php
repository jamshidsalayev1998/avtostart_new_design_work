@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('lesson.index') }}">Fanlar</a></li>
            <li class="active">Mavzular</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="block block-condensed">
            <div class="app-heading app-heading-small">
                <div class="title">
                    <h2>Fanlar va mavzular</h2>
                    <p></p>
                </div>
            </div>
            @if(session('message'))
                <p>
                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                    <div class="alert-icon">
                        <span class="icon-checkmark-circle"></span>
                    </div>
                    {{ session('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                </div>
                </p>
            @endif
            <div class="block-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="dd" id="nestable">
                            <ol class="dd-list">
                                @foreach($lessons as $lesson)
                                    <li class="dd-item dd-nodrag" data-id="2" >
                                        <div class="dd-handle">{{ $lesson->name_uz }}
                                            <a  href="{{ route('addtopic',['id'=>$lesson->id]) }}" title="Mavzu qo'shish" data-id="{{ $lesson->id }}" class="btn btn-default pull-right btn-sm" style="margin-top:0px;">
                                                <span class="icon-plus-circle"></span>
                                            </a>
                                        </div>
                                        <ol class="dd-list">
                                           @foreach($lesson->topics as $topic)
                                           <li class="dd-item dd-collapsed" data-id="5">
                                                <div class="dd-handle">{{ $topic->name_uz }}
                                                   <div class="dropdown pull-right margin-right-10">
                                                        <button type="button" class="btn btn-default pull-right btn-sm margin-left-5" style="margin-top:0px;" data-toggle="dropdown"><span class="fa fa-ellipsis-v "></span></button>
                                                        <ul class="dropdown-menu dropdown-left">
                                                            <li><a href="{{ route('addcontent',['id'=>$topic->id]) }}"><span class="icon-plus-circle"></span>Mavzuga ma'lumot qo'shish</a></li>
                                                            <li><a href="{{ route('topics.show',['id'=>$topic->id]) }}"><span class="fa fa-eye"></span> Mavzu haqida</a></li>
                                                            <li><a href="{{ route('topics.edit',['id'=>$topic->id]) }}"><span class="fa fa-edit"></span>Mavzuni o'zgartirish</a></li>
                                                            <li><a href="{{ route('goup',['id'=>$topic->id]) }}"><span class="icon-arrow-up-circle"></span>Tepaga ko'tarish</a></li>
                                                            <li><a href="{{ route('godown',['id'=>$topic->id]) }}"><span class="icon-arrow-down-circle"></span>Pastga tushirish</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <ol class="dd-list">
                                                    <li class="dd-item" data-id="6"><div class="dd-handle">Basic element #6</div></li>
                                                    <li class="dd-item" data-id="7"><div class="dd-handle">Basic element #7</div></li>
                                                    <li class="dd-item" data-id="8"><div class="dd-handle">Basic element #8</div></li>
                                                </ol>
                                            </li>
                                            @endforeach
                                        </ol>
                                    </li>
                                @endforeach
                            </ol>
                        </div>
                    </div>
                    <div class="col-md-2">

                    </div>
                </div>

            </div>
        </div>
        <!-- END NESTABLE LIST -->
    </div>
@endsection