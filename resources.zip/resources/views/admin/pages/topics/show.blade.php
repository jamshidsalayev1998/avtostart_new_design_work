               @extends('layouts.admin_alisher')
                @section('content')
                <div class="title-link">
                    <div>
                        <h1>Yo'l harakati sohasidagi qonunchilik asoslari</h1>
                        <p><span>Darsliklar / Toifalar / CE qayta tayyorlash /</span> Yo'l harakati sohasidagi qonunchilik as...</p>                        
                    </div>
                    <div>
                        <a href="{{ url()->previous() }}">Ortga</a>
                    </div>
                </div>
                <div class="table-toifa-batafsil">
                    <div class="boshlash-batafsil">
                        <div class="korinish-lang-buttons">
                            <button class="korinish-lang-active">O'z</button>
                            <button>Ўз</button>
                            <button>Ру</button>
                        </div>
                        
                        <div class="mavzular-batafsil-button">
                            <a href="{{ route('addcontent',['id'=>$data->id]) }}" class="batafsil-mav-qosh">
                                <p>Ma’lumot qo’shish</p>
                                <img width="16px" src="{{ asset('admin/style/images/icons/addMavzuWhite.svg') }}" alt="AAA">
                            </a>
                            <form action="{{ route('topics.destroy' , ['id' => $data->id]) }}" method="post">
                                {{ csrf_field() }}
                                {{ method_field('delete') }}
                                <button class="batafsil-mav-uchir">
                                    <img width="16px" src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
                                    <p>O'chirish</p>
                                </button>
                            </form>
                            
                        </div>
                    </div>
                    <div class="korinish-textes">
                        <div class="korinish-h1-p">
                            <div>
                                <h1>{{ $data->name_uz }}</h1>
                            </div>
                            <div class="batafsil-p-i korinish-p-i">
                                <img width="14px" src="{{ asset('admin/style/images/icons/soat.svg') }}" alt="">
                                <p>{{ date('d.m.Y H:i',strtotime($data->updated_at)) }}</p>
                            </div>
                        </div>
                        @foreach($data->contents as $content)
                        @if($content->type_id == 1)
                        <div class="content-korinish-text">
                            {!! $content->content_uz !!}
                        </div>
                        @endif
                        @if($content->type_id == 2)
                        <div class="korinish-img">
                            <img width="200px" src="{{ asset($content->content_uz) }}" alt="AAA">
                            
                        </div>
                        @endif
                        @if($content->type_id == 3)
                       <div class="korinish-video">
                            <video  controls src="{{ asset($content->content_uz) }}"></video>
                        </div>
                        @endif
                        @if($content->type_id == 4)
                        <div class="content-korinish-text">
                            
                        </div>
                        @endif
                        @endforeach
                        
                        
                        
                       
                    </div>
                </div>
                @endsection

