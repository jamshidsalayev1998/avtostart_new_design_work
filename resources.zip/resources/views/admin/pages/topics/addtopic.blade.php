@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('topics.index') }}">Fanlar & Mavzular</a></li>
            <li><a href="{{ route('lesson.show',['id'=>$lesson->id]) }}">{{ $lesson->name_uz }}</a></li>
            <li class="active">Yangi mavzu qo'shish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="row">
            <form action="{{ route('topics.store') }}" method="post">
                {{ csrf_field() }}

                <div class="col-md-6">
                    <div class="block">
                        <button class="btn btn-success btn-block" type="submit">Saqlash</button>


                        <div class="form-group margin-top-20" disabled>
                            <label>Fan nomi
                                @if($errors->has('lesson_id'))
                                    <span class="text-danger"> | {{ $errors->first('lesson_id') }}</span>
                                @endif
                            </label>
                            <select class="bs-select"  disabled>
                                <option value="{{ $lesson->id }}" selected class="text-success"><i class="fa fa-check text-success"></i>{{ $lesson->name_uz }}</option>
                            </select>
                        </div>
                        <input type="hidden" name="lesson_id" value="{{ $lesson->id }}">
                        <div class="form-group">
                            <label class="control-label">Tartibi
                                @if($errors->has('tp_order'))
                                    <span class="text-danger"> | {{ $errors->first('tp_order') }}</span>
                                @endif
                            </label>
                            <div class="spinner-wrapper"><input type="text" class="form-control spinner" name="tp_order" value="1" data-spinner-min="0"><button class="spinner-button-down"><span class="fa fa-angle-down"></span></button><button class="spinner-button-up"><span class="fa fa-angle-up"></span></button></div>
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select class="form-control" name="status" id="status">
                                <option value="1" >Aktiv</option>
                                <option value="0" >Passiv</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="app-content-tabs" style="margin-top: 1px;">
                        <ul>
                            <li><a href="#uz" class="active"><span class="fa fa-globe"></span>O'zbek tili</a></li>
                            <li><a href="#ru"><span class="fa fa-globe"></span> Rus tili</a></li>
                        </ul>
                    </div>

                    <div class="container app-content-tab active" id="uz">
                        <div class="block">
                            <label for="name_uz">Mavzuning nomlanishi
                                @if($errors->has('name_uz'))
                                    <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_uz" id="name_uz" value="{{ old('name_uz') }}" class="form-control" >
                        </div>
                    </div>

                    <div class="container app-content-tab" id="ru">
                        <div class="block">
                            <label for="name_ru">Названия Тема
                                @if($errors->has('name_ru'))
                                    <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_ru" id="name_ru" value="{{ old('name_ru') }}" class="form-control" >
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection