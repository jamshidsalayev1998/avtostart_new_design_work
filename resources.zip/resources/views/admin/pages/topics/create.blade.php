@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('lesson.index') }}">Fanlar & Mavzular</a></li>
            <li class="active">Yangi darslik qo'shish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="row">
            <form action="{{ route('lesson.store') }}" method="post">
                {{ csrf_field() }}

                <div class="col-md-6">
                    <div class="block">
                        <button class="btn btn-success btn-block" type="submit">Saqlash</button>


                        <div class="form-group margin-top-20">
                            <label>Ta'lim yo'nalishi
                                @if($errors->has('edu_type'))
                                    <span class="text-danger"> | {{ $errors->first('edu_type') }}</span>
                                @endif
                            </label>
                            <select class="bs-select dynamic"  id="edu_type" data-live-search="true" data-dependent="edu_type" name="edu_type">
                                <option value="B" @if(old('edu_type')=='B') selected @endif>B toifali</option>
                                <option value="BC" @if(old('edu_type')=='BC') selected @endif>BC toifali</option>
                                <option value="C" @if(old('edu_type')=='C') selected @endif>C toifali</option>
                                <option value="D" @if(old('edu_type')=='D') selected @endif>D toifali</option>
                                <option value="E" @if(old('edu_type')=='E') selected @endif>E toifali</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Soatlar soni
                                @if($errors->has('hours'))
                                    <span class="text-danger"> | {{ $errors->first('hours') }}</span>
                                @endif
                            </label>
                            <input class="form-control" placeholder="Soatlar soni"  name="hours" value="{{old('hours')}}" id="hours">
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select class="form-control" name="status" id="status">
                                <option value="1" >Aktiv</option>
                                <option value="0" >Passiv</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="app-content-tabs" style="margin-top: 1px;">
                        <ul>
                            <li><a href="#uz" class="active"><span class="fa fa-globe"></span>O'zbek tili</a></li>
                            <li><a href="#ru"><span class="fa fa-globe"></span> Rus tili</a></li>
                        </ul>
                    </div>

                    <div class="container app-content-tab active" id="uz">
                        <div class="block">
                            <label for="name_uz">Darslikning nomlanishi
                                @if($errors->has('name_uz'))
                                    <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_uz" id="name_uz" value="{{ old('name_uz') }}" class="form-control" >
                        </div>
                    </div>

                    <div class="container app-content-tab" id="ru">
                        <div class="block">
                            <label for="name_ru">Названия Учебника
                                @if($errors->has('name_ru'))
                                    <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_ru" id="name_ru" value="{{ old('name_ru') }}" class="form-control" >
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection