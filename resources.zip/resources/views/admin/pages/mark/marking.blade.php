@extends('layouts.admin')



@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('mark.index') }}">{{ $group->name_uz }} - Guruh</a></li>

            <li class="active">Baholash</li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>

    <div class="app-heading app-heading-bordered app-heading-page">

        <div class="icon icon-lg">

            <span class="icon-clipboard-text"></span>

        </div>

        <div class="heading-elements col-md-12">

            <div class="col-md-5">

                <select class="bs-select group-decision"  id="group_id" data-live-search="true" data-dependent="student_id" name="student_id">

                    <option style="display: none">Guruhni tanlang</option>

                    @foreach($groups as $item)

                        <option value="{{ $item->id }}" data-href="{{ route('mark.show',['id'=>$item->id]) }}"

                                @if($item->id == $group->id) selected @endif

                        >{{ $item->name_uz }}</option>

                    @endforeach

                </select>

            </div>

            <div class="col-md-2"></div>

            <div class="col-md-4">

                <button onclick="$('#marks-form').submit()"  class="rendering btn btn-success form-control"><span class="fa fa-save">&nbsp;</span>Saqlash</button>

            </div>

            <div class="col-md-1">

                <div class="dropdown pull-right">

                    <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>

                    <ul class="dropdown-menu dropdown-left">

                        <li><a href="{{ route('timetables.index') }}" ><span class="fa fa-print">&nbsp;&nbsp;</span> Guvohnoma chiqarish</a></li>

                        <li><a href="{{ route('timetables.index') }}" ><span class="fa fa-file-pdf-o text-danger">&nbsp;&nbsp;</span> PDF Export</a></li>

                        <li><a href="{{ route('export.markstoexcel',['id'=>$group->id]) }}" ><span class="fa fa-file-excel-o text-success">&nbsp;&nbsp;</span> Excel Export</a></li>

                    </ul>

                </div>

            </div>

        </div>

    </div>

    <div class="container">

        <div class="row">



            <div class="col-md-12">

                @if(session('message'))

                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                        <div class="alert-icon">

                            <span class="icon-checkmark-circle"></span>

                        </div>

                        {{ session('message') }}

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                    </div>

                @endif

                <div class="col-md-4" style="background: white;padding:0;margin: 0;border-right:none">

                    <table class="table table-bordered table-hover" style="margin: 0">

                        <thead>

                        <tr>

                            <th style="width: 2%">#</th>

                            <th style="min-width: 200px;padding: 16px;">FIO</th>

                        </tr>

                        </thead>

                        <tbody>

                        @php $i = 1;@endphp

                        @foreach($array2 as $student)

                            @php $student = $student->student; @endphp

                            <tr>

                                <td>{{ $i }}</td>

                                <td>{{ $student->last_name."  ".$student->first_name }}</td>

                                @php $i++; @endphp

                            </tr>

                        @endforeach

                        </tbody>

                    </table>

                </div>

                <div class="col-md-8" style="padding: 0;margin: 0">

                    <div class="block" style="overflow-x: scroll;padding: 0">

                        <form method="post" name="marks-form" id="marks-form" action="{{ route('mark.store') }}">

                            {{ csrf_field() }}

                            <input type="hidden" name="group_id" value="{{ $group->id }}">

                            <table class="table table-bordered table-hover">

                                <thead>

                                <tr>

                                    @foreach($group->classDate as $lesson)

                                        <th class="clickable-row" title="Ushbu sana bo'yicha" style="cursor: pointer;text-align: center;font-size:10px;padding: 0" data-href="{{ route('schedule.show',['id'=>$lesson->id]) }}">

                                            <div style="background: blueviolet;color:white;border-radius: 50%;margin:5px;padding: 0">

                                                {{ date("d",strtotime($lesson->start_time)) }}

                                            </div>

                                            {{ date("m/Y",strtotime($lesson->start_time)) }}

                                        </th>

                                    @endforeach

                                </tr>

                                </thead>

                                <tbody>

                                @php $i = 1;@endphp

                                @foreach($array2 as $student)

                                    @php $student = $student->student; @endphp

                                    <tr>

                                        @foreach($group->classDate as $lesson)

                                            <td style="height:40px;width:40px;text-align:center;@if(date('d.m.Y',strtotime($lesson->start_time)) == date('d.m.Y',time()) || $group->checkPermission($lesson->start_time)) ;background: lightgreen; @endif" @if((time() - strtotime($lesson->start_time))>-86400 ) @if(date('Y.m.d',time()) == date('Y.m.d',strtotime($lesson->start_time)) || $group->checkPermission($lesson->start_time)) data-student_id = "{{ $student->id }}" data-class_id="{{ $lesson->id }}" class="marking-ball" @endif @endif>

                                        {{ \Test\Model\Mark::getMark($student->id, $lesson->id) }}

                                        </td>

                                        @endforeach

                                        @php $i++; @endphp

                                    </tr>

                                @endforeach

                                </tbody>

                            </table>

                        </form>



                    </div>

                </div>

            </div>

        </div>

    </div>

@endsection