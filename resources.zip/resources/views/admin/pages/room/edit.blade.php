@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('room.index') }}">Auditoriyalar</a></li>
            <li class="active">{{ $data->name }}</li>
            <li class="active">O'zgartirish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="block">

                    <form action="{{ route('room.update', ['id' => $data->id]) }}" method="post">

                        {{ csrf_field() }}
                        {{ method_field('put') }}

                        <div class="col-md-4">
                            <label for="name">Nomlanishi</label>
                            <input type="text" name="name" id="name" class="form-control" value="{{ $data->name }}" required>
                        </div>
                        <div class="col-md-4">
                            <label for="status">Status</label>
                            <select name="status" class="form-control">
                                <option value="1" <?php if($data->status==1) echo 'selected'?>>Xona bo'sh</option>
                                <option value="0" <?php if($data->status==0) echo 'selected'?>>Xona band</option>
                            </select>
                        </div>

                        <div class="col-md-4" style="margin-top: 25px;">
                            <button class="btn btn-success btn-block">Saqlash</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
@endsection