@extends('layouts.admin')



@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('exceptions.index') }}">Bayram kunlari</a></li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>

    <div class="container">

        <div class="row">



            <div class="col-md-12">



                <div class="panel panel-default">

                    <div class="panel-heading">Sana bo'yicha guruhga ruxsat berish</div>

                    <div class="panel-body">

                        <div class="col-md-2">

                            <button data-toggle="modal" data-target="#modal-default" class="btn btn-default adds-permission"><i class="icon-plus-circle">&nbsp;</i>Yangi qo'shish</button>

                        </div>



                        @if(session('message'))

                            <div class="col-md-10">

                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('message') }}

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                        @if(session('error'))

                            <div class="col-md-10">

                                <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('error') }}

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                    </div>

                </div>



                <div class="block">

                    <table class="table table-bordered table-hover">

                        <thead>

                        <tr>

                            <th style="width: 2%">#</th>

                            <th>Guruh</th>

                            <th>Filial</th>

                            <th>Sanadan</th>

                            <th>Sanagacha</th>

                            <th style="text-align: center;width: 5%">Baholash</th>

                            <th style="text-align: center;width: 5%">Monitoring</th>

                            <th style="text-align: center;width: 5%">To'lov kiritish</th>

                            <th colspan="2" style="width: 8%"></th>

                        </tr>

                        </thead>

                        <tbody>

                        @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp

                        @foreach($data as $item)

                            <tr>

                                <td>{{ ++$count }}</td>

                                <td>{{ $item->group->name_uz }}</td>

                                <td>{{ $item->group->branch->name_uz }}</td>

                                <td>{{ $item->from_date }}</td>

                                <td>{{ $item->to_date }}</td>

                                <td style="text-align: center"><span class="@if($item->marking) fa fa-check text-success @endif @if(!$item->marking) fa fa-times text-danger @endif"></span></td>

                                <td style="text-align: center"><span class="@if($item->monitoring) fa fa-check text-success @endif @if(!$item->monitoring) fa fa-times text-danger @endif"></span></td>

                                <td style="text-align: center"><span class="@if($item->payment) fa fa-check text-success @endif @if(!$item->payment) fa fa-times text-danger @endif"></span></td>

                                <td>

                                    <form action="{{ route('permissions.destroy', ['id' => $item->id]) }}" method="post">

                                        {{ csrf_field() }}

                                        {{ method_field('delete') }}

                                        <button class="btn btn-default btn-icon deleteData"><i class="icon-trash"></i></button>

                                    </form>

                                </td>

                            </tr>

                        @endforeach

                        </tbody>

                    </table>



                    {!! $data->links() !!}



                </div>



            </div>





        </div>

    </div>



    <div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="modal-large-header">

        <div class="modal-dialog modal-lg" role="document">

            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>



            <div class="modal-content">

                <div class="modal-header">

                    <h4 class="modal-title" id="modal-default-header">Guruhga ruxsat berish</h4>

                </div>

                <form method="post" action="{{ route('permissions.store') }}" id="group-permission-form">

                    {{ csrf_field() }}

                    <div class="modal-body">

                            {{ csrf_field() }}

                            <div class="col-md-6" style="padding-left: 0">

                            <div class="form-group">

                                <label>Viloyatni tanlang

                                    @if($errors->has('region_id'))

                                        <span class="text-danger"> | {{ $errors->first('region_id') }}</span>

                                    @endif

                                </label>

                                <select class="form-control"  id="regions" data-live-search="true" data-dependent="area" name="region_id">

                                           

                                </select>

                            </div>

                        </div>

                        <div class="col-md-6" style="padding-left: 0">

                            <div class="form-group">

                                <label>Filialni tanlang

                                    @if($errors->has('region_id'))

                                        <span class="text-danger"> | {{ $errors->first('branch_id') }}</span>

                                    @endif

                                </label>

                                <select class="form-control"  id="branches" data-live-search="true" data-dependent="area" name="branch_id">

                                           

                                </select>

                            </div>

                        </div>

                        <div style="clear:both;height:15px;margin-top: 15px;border-bottom:1px solid darkgrey"></div>

                        <div class="col-md-4" style="padding-right: 0">

                            <div class="form-group">

                                <label>Guruhni tanlang

                                    @if($errors->has('group_id'))

                                        <span class="text-danger"> | {{ $errors->first('group_id') }}</span>

                                    @endif

                                </label>

                                <select class="form-control"  id="groups" data-live-search="true" data-dependent="area" name="group_id">



                                </select>

                            </div>

                        </div>

                            <div class="col-md-4">

                                <div class="form-group">

                                    <label>Ushbu sanadan

                                        @if($errors->has('from_date'))

                                            <span class="text-danger"> | {{ $errors->first('from_date') }}</span>

                                        @endif

                                    </label>

                                    <div class="input-group bs-datepicker">

                                        <input type="text" class="form-control"  name="from_date" id="from_date" value="{{ old('from_date') }}">

                                        <span class="input-group-addon">

                                      <span class="icon-calendar-full"></span>

                                </span>

                                    </div>

                                </div>

                            </div>

                            <div class="col-md-4">

                                <div class="form-group">

                                    <label>Ushbu sanagacha

                                        @if($errors->has('to_date'))

                                            <span class="text-danger"> | {{ $errors->first('to_date') }}</span>

                                        @endif

                                    </label>

                                    <div class="input-group bs-datepicker">

                                        <input type="text" class="form-control"  name="to_date" id="to_date" value="{{ old('to_date') }}">

                                        <span class="input-group-addon">

                                      <span class="icon-calendar-full"></span>

                                </span>

                                    </div>

                                </div>

                            </div>

                            <div class="col-md-4">

                                <div class="form-group">

                                    <label>Monitoring</label>

                                    <br>

                                    <label class="switch switch-md">

                                        <input type="checkbox" name="monitoring" checked id="status">

                                    </label>

                                </div>

                            </div>

                            <div class="col-md-4">

                                <div class="form-group">

                                    <label>Baholash</label>

                                    <br>

                                    <label class="switch switch-md">

                                        <input type="checkbox" name="marking" checked id="status">

                                    </label>

                                </div>

                            </div>

                            <div class="col-md-4">

                                <div class="form-group">

                                    <label>To'lov kiritish</label>

                                    <br>

                                    <label class="switch switch-md">

                                        <input type="checkbox" name="payment" checked id="status">

                                    </label>

                                </div>

                            </div>

                        </form>

                    </div>

                </form>

                <div class="modal-footer">

                    <button type="reset" class="btn btn-link" data-dismiss="modal">Bekor qilish</button>

                    <button onclick="$('#group-permission-form').submit()" class="btn btn-default">Qo'shish</button>

                </div>

            </div>

        </div>

    </div>

@endsection