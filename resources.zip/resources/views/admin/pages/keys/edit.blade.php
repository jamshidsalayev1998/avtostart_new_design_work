@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="block">

                    <form action="{{ route('keys.update', ['id' => $data->id]) }}" method="post">

                        {{ csrf_field() }}
                        {{ method_field('put') }}

                        <div class="col-md-10">
                            <label for="key">Kalit</label>
                            <input type="text" name="key" id="key" class="form-control" value="{{ $data->key }}" required>
                        </div>

                        <div class="col-md-5 margin-top-20">
                            <button class="btn btn-success btn-block">Saqlash</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
@endsection