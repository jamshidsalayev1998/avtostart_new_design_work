@extends('layouts.admin_alisher')

@section('content')
                
                <div class="title-link">
                        <div>
                            <h1>O`qituvchilar</h1>
                            <p><span class="head-link-href">Bosh sahifa</span> / O`qituvchilar</p>
                        </div>
                        
                    </div>
                    <div class="table-toifa-CE">
                        <div class="h1-button">
                            <h1>O`qituvchilar ro’yxati</h1>
                            <button id="href_button" data-href="{{ route('teacher.create') }}" class="add-fan">
                                <p> Qo'shish</p>
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M7 1.16667V12.8333" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M1.16602 7H12.8327" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                            </button>
                        </div>
                        <div class="table-content">

                    <table id="DataTables_Table_0" class="">

                        <thead>

                        <tr>

                            <th><p>FIO </p></th>

                            @if(\Auth::user()->role==7) <th><p>Viloyati </p></th> @endif

                            @if(\Auth::user()->role==7 || \Auth::user()->role==6) <th><p>Tuman </p></th> @endif

                            <th><p>Login </p></th>

                    
                            <th><p>Kirgan vaqti(AIS) </p></th>
                            <th><p>Kirgan vaqti(STUDY) </p></th>
                            <th><p>Filial Nomi</th>

                            <th  width="5%"><p> </p></th>

                            <th  width="5%"><p> </p></th>

                            <th  width="5%"><p> </p></th>

                        </tr>

                        </thead>

                        <tbody>

                        @foreach($data as $item)

                            <tr 
                            <?php $user=Test\User::find($item->user_id);?>
                            @if(!empty($user))
                            <?php if($user->status==0):?>
                            style="background-color: #ffb2b2;"
                           <?php endif?>
                           @endif
                            >

                                <td><p>{{$item->full_name}} </p></td>

                                @if(\Auth::user()->role==7) <td><p>{{ $item->getRegion() }} </p></td> @endif

                                @if(\Auth::user()->role==7 || \Auth::user()->role==6) <td><p>{{ $item->getArea() }} </p></td> @endif

                                <td><p>
                                    @if(empty($item->user->username))
                                           
                                    @endif
                                       @if(!empty($item->user->username))
                                            {{$item->user->username}}
                                    @endif </p>

                                </td>

                              
                                <td><p>{{$item->last_seen}} </p></td>
                                <td><p>{{$item->last_seen_shablon}} </p></td>
                                <?php  $branch = Test\Model\Branch::where('id', $item->branch_id)->first()?>
                                <td><p>{{$branch->name_uz}} </p></td>

                                <td><p>

                                    <a href="{{ route('teacher.show', ['id' => $item->id]) }}" class="btn btn-default btn-icon">

                                        <i class="fa fa-eye"></i>

                                    </a> </p>

                                </td>

                                <td><p>

                                    <a href="{{ route('teacher.edit', ['id' => $item->id]) }}" class="btn btn-default btn-icon">

                                        <i class="fa fa-edit"></i>

                                    </a> </p>

                                </td>

                                <td><p>

                                    <form action="{{ route('teacher.destroy', ['id' => $item->id]) }}" method="post">

                                        {{ csrf_field() }}

                                        {{ method_field('delete') }}

                                        <button data-confirm="Agar siz o`chirish tugmasini bossangiz o`qituvchini holati passiv bo`ladi va u ais,study tizimlariga kirish huquqidan mahrum bo`ladi hamda guruh yaratish oynasida ushbu o`qituvchi ko`rinmaydi." class="btn btn-default btn-icon deleteData1"><i class="fa fa-trash"></i></button>

                                    </form> </p>

                                </td>

                            </tr>

                        @endforeach

                        </tbody>

                    </table>



                </div>



            </div>

       

@endsection