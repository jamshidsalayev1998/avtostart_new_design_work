
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
<link rel="stylesheet" href="{{ asset('admin/dist/css/bootstrap.css') }}">   
<link rel="stylesheet" href="{{ asset('admin/dist/css/main.css') }}">
<link rel="stylesheet" href="{{ asset('admin/dist/dist/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('admin/dist/css/bootstrap-theme.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/dist/css/bootstrap-theme.min.css') }}">
    <style media="print">

        @page  {
            size: auto;
          margin-top: 5.795276px;
            margin-left: 22.677165px;
            margin-left: 22.677165px;
            margin-bottom: 22.677165px;
        }
        .dis{
            text-decoration: none;
        }
        .opacity{
            opacity: 0;
        }

        .h41{
            margin-top: 9%;
        }
        .h42{
            margin-top: -6px;
            font-weight: bold;
            letter-spacing: 2px;
            margin-left: 10px;
        }
        .hr{
            margin-left: -3%;
            margin-top: -5.2%;
        }
        .hr1{
            margin-left: -3%;
            margin-top: -0.5%;
        }

        .p1{
            margin-left: -5%;
            font-size: 10px;
            margin-top: -4%;
        }
        .span{

            color: #d43f3a;
            font-size: 22px;
            font-family: normal;

        }
        .guvohnoma{
            margin-top: -1%;
            margin-left: -4%;
            font-weight: bold;
            letter-spacing: 12px;
            font-family: normal;
        }
        .p2{
            margin-left: -3%;
            margin-top: 11px;
            font-family: normal;
            font-weight: bold;
        }
        .p3{
            font-size: 10px;
            margin-top: -4%;
        }
        .p4{
            font-weight: bold;
            margin-top: -3.7%;
            margin-left: -3%;
        }
        .p5{
            font-weight: bold;
            margin-left: -5%;
            margin-top: -1px;
        }
        .p6{
            margin-top: -1px;
            margin-left: -3%;
        }
        .p7{
            margin-top: -1px;
            margin-left: -3%;
        }
        .p8{
            margin-top: -2px;
            margin-left: -4%;
        }
        .p9{
            margin-left: -5%;
            line-height: 1.2;
            margin-top: -2%;
            font-weight: bold;
            margin-bottom: 2%;
        }
        .row1{
            margin-left: -4%;
            margin-top: -1.5%;
        }
        .row11{
            margin-left: -3%;
            margin-top: -4%;
        }
        .row12{
            margin-left: -4%;
            margin-top: -5%;
        }
        .row2{
            margin-left: -3%;
            margin-top: -1.5%;
        }
        .row22{
            margin-left: -3%;
            margin-top: -4%;
        }
        .row23{
            margin-left: -3%;
            margin-top: -5%;
        }
        .oqiv{
            font-size: 10px;
            margin-left: 20%;
            margin-top: -5%;
        }
        .oqiv1{
            font-size: 10px;
            margin-left: 20%;
            margin-top: -6%;
        }
        .baho{
            font-size: 10px;
            margin-left: 48%;
            margin-top: -13%;
        }
        .baho1{
            font-size: 10px;
            margin-left: 48%;
            margin-top: -11.5%;
        }






        .a1{
            font-weight: bold;
            margin-top: 9%;
        }
        .ro1{
            /*margin-left: 1%;*/
            margin-top: -8.5px;
        }
        .ro2{
            /*margin-left: 1%;*/
            margin-top: -8.5px;
        }
        .oqi{
            font-size: 10px;
            margin-left: 25%;
            margin-top: -6%;
        }
        .bah{
            font-size: 10px;
            margin-left: 48%;
            margin-top: -13%;
        }


        .a2{
            font-weight: bold;
            /*padding-top: 1px;*/
        }
        .ro11{
            margin-top: -3.5%;
        }
        .oqi2{
            margin-left: -3%;
        }

        .ro22{
            margin-top: -3.5%;
        }
        .a3{
            font-weight: bold;
            float:right;
            margin-right: 6%;
            margin-top: 1%;
        }
        .a4{
            margin-top: 13%;
            font-weight: bold;
        }
        .a5{
            text-align: center;
            font-size: 10px;
            margin-top: -3%;
        }
        .a6{
            font-weight: bold;
            /*margin-top: -4%;*/
        }

        .ro12{
            margin-top: 1%;
        }
        .ro23{
            margin-top: 1%;
        }
        .a7{
            font-weight: bold;
            margin-top: 1%;
        }
        .a8{
            float: right;
            margin-right: 6%;
            margin-top: -1%;
        }
        .a9{
            text-align: center;
            font-weight: bold;
            margin-top: 7.5%;
        }
        .h43{
            margin-top: 4.5%;
            font-weight: bold;
            letter-spacing: 2px;
            margin-left: 10px;
        }
        .p12{
            margin-left: 3%;
        }
        .p13{
            margin-left: 10px;
        }
    </style>
</head>
<body>

<div class="container" style=" width: 20cm;height: 14.5cm;background-size: cover;    background-color: #ffb2b2;">
<div class="col-xs-12">
    <div class="row">
        <div class="col-xs-6">
            <h4 class="text-center h41 opacity">O'BEKISTON RESPUBLIKASI</h4>
            <p class="hr">
                <ins class="dis">{{$branch_name}}</ins>
            </p>
            <p class="hr1">
                <ins class="dis">.</ins>
            </p>
            <p class="p1 text-center opacity">(ta'lim muassasasi (tashkiloti)ning nomi)</p>
            <h4 class="text-center h42 opacity">10AA 
                <span class="span">0445250</span>
            </h4>
            <h3 class="guvohnoma text-center opacity">GUVOHNOMA</h3>
            <p class="p2">
                <span class=" opacity"> Berildi ushbu</span>
                <ins class="dis"> {{$student->last_name}} {{$student->first_name}} </ins>
            </p>
            <p class="text-center p3  opacity"> (familiyasi, ismi, otasining ismi)</p>
            <p class="p4">
            <ins class="dis"> {{$student->middle_name}} </ins>
                <span class=" opacity">ga shu haqdakim</span> 
            </p>
            <p class="p5">
                <span class=" opacity">u 20</span>
                <ins class="dis"> {{$start_year}}</ins> 
                <span class=" opacity">yilning<<</span> 
                <ins class="dis p13">  {{$start_day }} </ins> 
                <span class=" opacity">>></span>
                <ins class="dis p13"> {{$start_month }}  </ins>
                <span class=" opacity"> dan</span>
            </p>
            <p class="p5">
                <span class=" opacity">u 20</span> 
                <ins class="dis">  {{$end_year}} </ins> 
                <span class=" opacity">yilning<<</span>
                <ins class="dis p13">  {{$end_day}} </ins>
                <span class=" opacity">>></span>
                <ins class="dis p13"> {{$end_month}} </ins>
                <span class=" opacity"> gacha</span>
            </p>
            <p class="p6"> 
                <ins class="dis"> 
                @if($edu_type ==1)
                            «B» тайёрлаш 
                            @endif
                            @if($edu_type ==2)
                            «A» тайёрлаш
                            @endif
                            @if($edu_type ==3)
                            «C» тайёрлаш
                            @endif
                            @if($edu_type ==4)
                            «BC» тайёрлаш
                            @endif
                            @if($edu_type ==5)
                            «D» кайта тайёрлаш
                            @endif
                            @if($edu_type ==6)
                            «CE» кайта тайёрлаш
                            @endif
                            @if($edu_type ==7)
                            «BE» кайта тайёрлаш
                            @endif
                            @if($edu_type ==8)
                            «C» кайта тайёрлаш
                            @endif
                            @if($edu_type ==9)
                            «DE» кайта тайёрлаш
                            @endif
                 </ins>
            </p>
            <p class="p7"> 
                <ins class="dis ">    </ins>
                <span class="opacity">dasturi bo'yicha</span>
            </p>
            <p class="p8">
                <span class="opacity">o'qidi va 20</span>
                <ins class="dis ">  </ins> 
                <span class="opacity">yil <<</span>
                <ins class="dis p13 "> </ins>
                <span class="opacity">>></span>
                <ins class="dis p13 ">  </ins>
                <span class="opacity">dagi</span>
            </p>
            <p class="p9">
                <span class="opacity"><<</span>
                <ins class="dis"> </ins> 
                <span class="opacity">>> raqamli majlis qaroriga binoan bitirish imtihonlarida
                            quyidagi baholarni (qoniqarli, yaxshi, a'lo) oldi.</span>
            </p>
            <div class="row">
                <div class="col-xs-8 row1">
                    <p class="p10"><ins class="dis"> ATVTXK </ins></p>
                    <p class="oqiv opacity" >(o'quv fanining nomi)</p>
                </div>
                <div class="col-xs-4 row2">
                    <p class="p11"><ins class="dis"> {{$mark1}} </ins></p>
                    <p class="baho opacity">(baho)</p>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-8 row11">
                    <p class="p10"><ins class="dis"> YXQVXXA </ins></p>
                    <p class="oqiv1 opacity">(o'quv fanining nomi)</p>
                </div>
                <div class="col-xs-4 row22">
                    <p class="p11"><ins class="dis"> {{$mark2}} </ins></p>
                    <p class="baho1 opacity">(baho)</p>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-8 row12">
                    <p class="p10"><ins class="dis"> Avtomobilni boshqarish </ins></p>
                    <p class="oqiv opacity">(o'quv fanining nomi)</p>
                </div>
                <div class="col-xs-4 row23">
                    <p class="p11"><ins class="dis"> {{$is_submitted}} </ins></p>
                    <p class="baho opacity">(baho)</p>
                </div>
            </div>
        </div>
        <div class="col-xs-6">
            <p class="a1  opacity">Imtihonlar komissiyasi raisi:</p>
            <div class="row">
                <div class="col-xs-8 ro1">
                    <p><ins class="dis" style="font-size: 12px;"> {{$komis_rais}}</ins></p>
                    <p class="oqi opacity">(o'quv fanining nomi)</p>
                </div>
                <div class="col-xs-4 ro2">
                    <p><ins class="dis opacity"> ______</ins></p>
                    <p class="bah opacity">(imzo)</p>
                </div>
            </div>
            <p class="a2  opacity">Talim muassasasi (tashkiloti) rahbari</p>
            <div class="row">
                <div class="col-xs-8 ro11">
                    <p><ins class="dis" style="font-size: 12px;"> {{$tash_rahbar}} </ins></p>
                    <p class="oqi opacity">(o'quv fanining nomi)</p>
                </div>
                <div class="col-xs-4 ro22">
                    <p><ins class="dis opacity"> ______ </ins></p>
                    <p class="bah opacity">(imzo)</p>
                </div>
            </div>
            <p class="a3  opacity">M.O'.</p>
            <p CLASS="a4">
                <ins class="dis" style="font-size: 12px;"> {{$hudud_nomi}} </ins>
                <span class="opacity">YHXB RIB (TRIB)</span>
            </p>
            <p class="a5 opacity">(hududiy  IIV.IIBB.IIB nomi)</p>
            <p class="a6">
                <span class="opacity">tomonidan</span>
                <ins class="dis opacity"> ___________ </ins> 
                <span class="opacity">seriyadagi</span>
                <ins class="dis opacity "> ___________ </ins>
                <span class="opacity">raqamli haydovchilik guvohnomasi berildi RIB (TRIB) boshligi:</span>
            </p>
            <div class="row">
                <div class="col-xs-8 ro12">
                    <p>
                        <ins class="dis"> {{$rib_rais}} </ins>
                    </p>
                    <p class="oqi opacity">(o'quv fanining nomi)</p>
                </div>
                <div class="col-xs-4 ro23">
                    <p><ins class="dis opacity"> ______ </ins></p>
                    <p class="bah opacity">(imzo)</p>
                </div>
            </div>
            <p class="a7">
                <span class="opacity">20</span>
                <ins class="dis p12 opacity"> __ </ins> 
                <span class="opacity">yil <<</span>
                <ins class="dis p12 opacity"> __ </ins> 
                <span class="opacity">>></span>
                <ins class="dis p12 opacity"> _________ </ins> 
               
            </p>
            <p class="a9 opacity">Ushbu hujjat avtomototransport vositalari va shahar
            elektr traansporti vositalarini boshqarish huquqini bermaydi.
            </p>
            <h4 class="text-center h43 opacity">10AA <span class="span">0445250</span></h4>
        </div>
    </div>
</div>
</div>

</body>
</html>