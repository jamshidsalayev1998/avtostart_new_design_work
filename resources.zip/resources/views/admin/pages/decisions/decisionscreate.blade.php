@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="#">Qo'shimcha</a></li>
            <li class="active">Rekvisiztlarni kiritish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="row">
            <form action="../decision/decisionsstore" method="post">
                {{ csrf_field() }}
                <input type="hidden" value="{{ $branch_id }}" name="branch_id">
                <div class="col-md-12">
                    <div class="block">
                        <button class="btn btn-success btn-block" type="submit">Saqlash</button>

                        <div class="form-group margin-top-20">
                            <label>Imtihonlar komissiyasi raisi(familiyasi, ismi, otasining ismi):
                                @if($errors->has('inn'))
                                    <span class="text-danger"> | {{ $errors->first('inn') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input type="text" class="form-control"  name="inn" id="inn" value="{{ old('inn') }}">
                            </div>
                        </div>
                        <div class="form-group" style="margin-bottom: 5px;">
                            <label>Talim muassasasi (tashkiloti) rahbari(familiyasi, ismi, otasining ismi):
                                @if($errors->has('bank_info'))
                                    <span class="text-danger"> | {{ $errors->first('bank_info') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input type="text" class="form-control"  name="bank_info" id="bank_info" value="{{ old('bank_info') }}">
                            </div>
                        </div>
                        <div class="form-group" style="margin-bottom: 5px;">
                            <label>YHXB BIR (TRIB)(hududiy IIV.IIBB.IIB nomi)
                                @if($errors->has('okonh'))
                                    <span class="text-danger"> | {{ $errors->first('okonh') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input type="text" class="form-control"  name="okonh" id="okonh" value="{{ old('okonh') }}">
                            </div>
                        </div>
                        <div class="form-group" style="margin-bottom: 5px;">
                            <label> RIB (TRIB) boshligi(familiyasi, ismi, otasining ismi):    
                                @if($errors->has('bmm'))
                                    <span class="text-danger"> | {{ $errors->first('bmm') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input type="text" class="form-control"  name="bmm" id="bmm" value="{{ old('bmm') }}">
                            </div>
                        </div>
                    </div>
                </div>
               
            </form>
        </div>
    </div>
@endsection