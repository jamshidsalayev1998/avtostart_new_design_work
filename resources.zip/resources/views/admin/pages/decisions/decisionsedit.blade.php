@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="#">Qo'shimcha</a></li>
            <li class="active">Rekvisiztlarni kiritish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="row">

        <form action="../../buyruq/buyruqupdate" method="get">
                {{ csrf_field() }}
                {{ method_field('put') }}
                <div class="col-md-12">
                    <div class="block">
                        <button class="btn btn-success btn-block" type="submit">Saqlash</button>
                        <input type="hidden" class="form-control"  name="id" id="inn" value="{{ $data->id     }}">
                        <div class="form-group margin-top-20">
                            <label>Imtihonlar komissiyasi raisi(familiyasi, ismi, otasining ismi):
                                @if($errors->has('inn'))
                                    <span class="text-danger"> | {{ $errors->first('inn') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input type="text" class="form-control"  name="inn" id="inn" value="{{ $data->komis_rais }}">
                            </div>
                        </div>
                        <div class="form-group" style="margin-bottom: 5px;">
                            <label>Talim muassasasi (tashkiloti) rahbari(familiyasi, ismi, otasining ismi):
                                @if($errors->has('bank_info'))
                                    <span class="text-danger"> | {{ $errors->first('bank_info') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input type="text" class="form-control"  name="bank_info" id="bank_info" value="{{ $data->tash_rahbar  }}">
                            </div>
                        </div>
                        <div class="form-group" style="margin-bottom: 5px;">
                            <label>YHXB BIR (TRIB)(hududiy IIV.IIBB.IIB nomi)
                                @if($errors->has('okonh'))
                                    <span class="text-danger"> | {{ $errors->first('okonh') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input type="text" class="form-control"  name="okonh" id="okonh" value="{{ $data->hudud_nomi  }}">
                            </div>
                        </div>
                        <div class="form-group" style="margin-bottom: 5px;">
                            <label> RIB (TRIB) boshligi(familiyasi, ismi, otasining ismi):    
                                @if($errors->has('bmm'))
                                    <span class="text-danger"> | {{ $errors->first('bmm') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input type="text" class="form-control"  name="bmm" id="bmm" value="{{ $data->rib_rais  }}">
                            </div>
                        </div>
                    </div>
                </div>
               
            </form>
        </div>
    </div>
@endsection