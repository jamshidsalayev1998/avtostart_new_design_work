@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('group.index') }}">Guvohnoma chiqarish</a></li>
            <li class="active">{{ $data->name_uz }}</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="app-heading app-heading-bordered app-heading-page">
        <div class="icon icon-lg">
            <span class="icon-clipboard-text"></span>
        </div>
        <div class="heading-elements col-md-12">
            <div class="col-md-5">
                <select class="bs-select group-decision"  id="group_id" data-live-search="true" data-dependent="student_id" name="student_id">
                    <option style="display: none">Guruhni tanlang</option>
                    @foreach($groups as $group)
                        <option value="{{ $group->id }}" data-href="{{ route('decisions.show',['id'=>$group->id]) }}"
                            @if($group->id == $data->id) selected @endif
                        >{{ $group->name_uz }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-4">
                <button onclick="$('#decisions-form').submit()"  class="rendering btn btn-success form-control"><span class="fa fa-save">&nbsp;</span>Saqlash</button>
            </div>
            <div class="col-md-1">
                <div class="dropdown pull-right">
                    <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>
                    <ul class="dropdown-menu dropdown-left">
                        <li><a href="{{ route('timetables.index') }}" ><span class="fa fa-print">&nbsp;&nbsp;</span> Guvohnoma chiqarish</a></li>
                        <li><a href="{{ route('timetables.index') }}" ><span class="fa fa-file-pdf-o text-danger">&nbsp;&nbsp;</span> PDF Export</a></li>
                        <li><a href="{{ route('timetables.index') }}" ><span class="fa fa-file-excel-o text-success">&nbsp;&nbsp;</span> Excel Export</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="invoice">
            <div class="invoice-container">
                <div class="row">
                    <div class="col-lg-10 col-lg-offset-1">
                        @if(session('message'))
                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-checkmark-circle"></span>
                                </div>
                                {{ session('message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        @endif
                        <form method="post" action="{{ route('decisions.store') }}" id="decisions-form">
                            {{ csrf_field() }}
                            <input type="hidden" value="{{ $data->id }}" name="group_id">
                            <table class="table table-bordered" id="decisions-form">
                                <thead>
                                <tr>
                                    <th style="width: 2%">#</th>
                                    <th style="width: 38%;text-align: center">FIO</th>
                                    <th style="width: 10%;text-align: center">Fan1</th>
                                    <th style="width: 10%;text-align: center">Fan2</th>
                                    <th style="width: 10%;text-align: center">Amaliy</th>
                                    <th style="width: 30%">Guvohnoma nomeri</th>
                                    <th style="width: 30%;text-align: center" >Guvohnoma chiqarish</th>
                                </tr>
                                </thead>
                                <tbody class="text-thin" id="students">
                                @php $i=1; @endphp
                                @foreach($data->students as $student)
                                @php $student = $student->student @endphp
                                <tr>
                                    <td>{{ $i }}</td>
                                    <td>{{ $student->fio() }}</td>
                                    <td>
                                        <input type="text" name="{{ $student->id }}mark1" style="text-align: center" class="form-control student-mark" @if(isset($student->decision)) value="{{ $student->decision->mark1 }} @endif">
                                    </td>
                                    <td>
                                        <input type="text" name="{{ $student->id }}mark2" style="text-align: center" class="form-control student-mark" @if(isset($student->decision)) value="{{ $student->decision->mark2 }}" @endif>
                                    </td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-default btn-icon submitting" data-student_id="{{ $student->id }}">
                                            @if(isset($student->decision)) @if($student->decision->is_submitted == 1)<span class="fa fa-check-circle text-success"></span>@endif @endif
                                            @if(isset($student->decision)) @if($student->decision->is_submitted == 0)<span class="fa fa-times text-danger"></span>@endif @endif
                                            @if(!isset($student->decision)) <span class="fa fa-check-circle text-success"></span>@endif
                                        </button>
                                        <input type="hidden" value="@if(isset($student->decision))  {{ $student->decision->is_submitted }} @endif @if(!isset($student->decision)){{ 1 }}@endif" name="{{ $student->id }}is_submitted" id="is_submitted{{ $student->id }}" >
                                    </td>
                                    
                                    <td>
                                 
                                    <input type="text" name="{{ $student->id }}licence_number"
                                    @if((isset($student->decision->licence_number)))
                                     value=" {{ $student->decision->licence_number}} "   
                                     @endif  
                                      class="form-control">
                              
                                    </td>
                                    <td class="text-center">
                                       @if((isset($student->decision->licence_number))&&(isset($student->decision->mark1))&&(isset($student->decision->mark2)))
                                    <a style="text-align:center" href="../decision/decisionsprint/{{ $student->id}}" target="blank" class="btn btn-default btn-icon">
                                            <i class="icon-printer"></i>
                                        </a>
                                                @endif  
                                        </td>

                                    
                                    @php $i++; @endphp
                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection