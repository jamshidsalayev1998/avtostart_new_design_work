@extends('layouts.admin')
@section('content')
<style media="print">

@page  {
    size: auto;
  margin-top: 5.795276px;
    margin-left: 22.677165px;
    margin-left: 22.677165px;
    margin-bottom: 22.677165px;
}
.dis{
    text-decoration: none;
}
.opacity{
    opacity: 0;
}

.h41{
    margin-top: 9%;
}
.h42{
    margin-top: -6px;
    font-weight: bold;
    letter-spacing: 2px;
    margin-left: 10px;
}
.hr{
    margin-left: -3%;
    margin-top: -5.2%;
}
.hr1{
    margin-left: -3%;
    margin-top: -0.5%;
}

.p1{
    margin-left: -5%;
    font-size: 10px;
    margin-top: -4%;
}
.span{

    color: #d43f3a;
    font-size: 22px;
    font-family: normal;

}
.guvohnoma{
    margin-top: -1%;
    margin-left: -4%;
    font-weight: bold;
    letter-spacing: 12px;
    font-family: normal;
}
.p2{
    margin-left: -3%;
    margin-top: 11px;
    font-family: normal;
    font-weight: bold;
}
.p3{
    font-size: 10px;
    margin-top: -4%;
}
.p4{
    font-weight: bold;
    margin-top: -3.7%;
    margin-left: -3%;
}
.p5{
    font-weight: bold;
    margin-left: -5%;
    margin-top: -1px;
}
.p6{
    margin-top: -1px;
    margin-left: -3%;
}
.p7{
    margin-top: -1px;
    margin-left: -3%;
}
.p8{
    margin-top: -2px;
    margin-left: -4%;
}
.p9{
    margin-left: -5%;
    line-height: 1.2;
    margin-top: -2%;
    font-weight: bold;
    margin-bottom: 2%;
}
.row1{
    margin-left: -4%;
    margin-top: -1.5%;
}
.row11{
    margin-left: -3%;
    margin-top: -4%;
}
.row12{
    margin-left: -4%;
    margin-top: -5%;
}
.row2{
    margin-left: -3%;
    margin-top: -1.5%;
}
.row22{
    margin-left: -3%;
    margin-top: -4%;
}
.row23{
    margin-left: -3%;
    margin-top: -5%;
}
.oqiv{
    font-size: 10px;
    margin-left: 20%;
    margin-top: -5%;
}
.oqiv1{
    font-size: 10px;
    margin-left: 20%;
    margin-top: -6%;
}
.baho{
    font-size: 10px;
    margin-left: 48%;
    margin-top: -13%;
}
.baho1{
    font-size: 10px;
    margin-left: 48%;
    margin-top: -11.5%;
}






.a1{
    font-weight: bold;
    margin-top: 9%;
}
.ro1{
    /*margin-left: 1%;*/
    margin-top: -8.5px;
}
.ro2{
    /*margin-left: 1%;*/
    margin-top: -8.5px;
}
.oqi{
    font-size: 10px;
    margin-left: 25%;
    margin-top: -6%;
}
.bah{
    font-size: 10px;
    margin-left: 48%;
    margin-top: -13%;
}


.a2{
    font-weight: bold;
    /*padding-top: 1px;*/
}
.ro11{
    margin-top: -3.5%;
}
.oqi2{
    margin-left: -3%;
}

.ro22{
    margin-top: -3.5%;
}
.a3{
    font-weight: bold;
    float:right;
    margin-right: 6%;
    margin-top: 1%;
}
.a4{
    margin-top: 13%;
    font-weight: bold;
}
.a5{
    text-align: center;
    font-size: 10px;
    margin-top: -3%;
}
.a6{
    font-weight: bold;
    /*margin-top: -4%;*/
}

.ro12{
    margin-top: 1%;
}
.ro23{
    margin-top: 1%;
}
.a7{
    font-weight: bold;
    margin-top: 1%;
}
.a8{
    float: right;
    margin-right: 6%;
    margin-top: -1%;
}
.a9{
    text-align: center;
    font-weight: bold;
    margin-top: 7.5%;
}
.h43{
    margin-top: 4.5%;
    font-weight: bold;
    letter-spacing: 2px;
    margin-left: 10px;
}
.p12{
    margin-left: 3%;
}
.p13{
    margin-left: 10px;
}
</style>

    <!-- START PAGE HEADING -->
    <div class="app-heading app-heading-bordered app-heading-page">
   
        <!--<div class="heading-elements">
            <a href="#" class="btn btn-danger" id="page-like"><span class="app-spinner loading"></span> loading...</a>
            <a href="https://themeforest.net/item/boooya-revolution-admin-template/17227946?ref=aqvatarius&license=regular&open_purchase_for_item_id=17227946" class="btn btn-success btn-icon-fixed"><span class="icon-text">$24</span> Purchase</a>
        </div>-->
    </div>
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Sozlamalar</a></li>
            <li class="active">Guvohnoma chiqarish</li>
        </ul>
        @if($data != null)
        <strong style=" float: right;margin: 4px;" class="text-danger"> &nbsp;<a class="btn btn-success" href=" ../decision/decisionsedit/{{$data->id}} "><span style="    line-height: 19px;" class="icon-plus-circle"></span>Ma`lumotlarni o`zgartirish</a></strong>
        @endif
        @if($data === null && \Auth::user()->role == 5)
            <strong style=" float: right;margin: 4px;" class="text-danger">Ma`lumotlar hali kiritilmagan. &nbsp;<a class="btn btn-success" href="../decision/decisionscreate"><span style="    line-height: 19px;" class="icon-plus-circle"></span>Ma`lumotlarni kiritish</a></strong>
        @endif
    </div>
    @if($data != null)
    <div class="container" style=" width: 24cm;height: 14.5cm;background-size: cover; background-color: white;

    background-size: white;
    margin: 25px 0 45px 80px;">
<div class="col-xs-12">
    <div class="row">
        <div class="col-xs-6">
            <h4 class="text-center h41 opacity">O'BEKISTON RESPUBLIKASI</h4>
            <p class="hr">
                <ins class="dis">____________________________________________________</ins>
            </p>
            <p class="hr1">
                <ins class="dis">____________________________________________________</ins>
            </p>
            <p class="p1 text-center opacity" style="    margin-top: -3%;">(ta'lim muassasasi (tashkiloti)ning nomi)</p>
            <h4 class="text-center h42 opacity">10AA 
                <span class="span">0445250</span>
            </h4>
            <h3 class="guvohnoma text-center opacity">GUVOHNOMA</h3>
            <p class="p2">
                <span class=" opacity"> Berildi ushbu</span>
                <ins class="dis">   _____________________________________________</ins>
            </p>
            <p class="text-center p3  opacity" style="    margin-top: -3%;" > (familiyasi, ismi, otasining ismi)</p>
            <p class="p4">
               
                <span class=" opacity">_____________________________________ga shu haqdakim</span> 
            </p>
            <p class="p5">
                <span class=" opacity">u 20 </span>
                <ins class="dis"> __  	&nbsp;</ins> 
                <span class=" opacity">  yilning &lt;&lt; </span> 
                <ins class="dis p13"> ___ </ins> 
                <span class=" opacity"> &gt;&gt;</span>
                <ins class="dis p13"> __________________________ </ins>
                <span class=" opacity"> dan</span>
            </p>
            <p class="p5">
                <span class=" opacity"> 20</span> 
                <ins class="dis"> ___ 	&nbsp;</ins> 
                <span class=" opacity">yilning &lt;&lt;</span>
                <ins class="dis p13"> ___ </ins>
                <span class=" opacity"> &gt;&gt;</span>
                <ins class="dis p13"> ________________________  </ins>
                <span class=" opacity"> gacha</span>
            </p>
            <p class="p6"> 
                <ins class="dis"> ____________________________________________________ </ins>
            </p>
            <p class="p7"> 
                <ins class="dis"> ______________________________________ </ins>
                <span class="opacity">dasturi bo'yicha</span>
            </p>
            <p class="p8">
                <span class="opacity">o'qidi va 20</span>
                <ins class="dis"> ___ </ins> 
                <span class="opacity">yil &lt;&lt;</span>
                <ins class="dis p13"> ___</ins>
                <span class="opacity">&gt;&gt;</span>
                <ins class="dis p13"> _______________________ </ins>
                <span class="opacity">dagi</span>
            </p>
            <p class="p9">
                <span class="opacity">&lt;&lt;</span>
                <ins class="dis">______________</ins> 
                <span class="opacity">&gt;&gt; raqamli majlis qaroriga binoan bitirish imtihonlarida
                            quyidagi baholarni (qoniqarli, yaxshi, a'lo) oldi.</span>
            </p>
            <div class="row">
                <div class="col-xs-8 row1">
                    <p class="p10"><ins class="dis"> _____________________________ </ins></p>
                    <p class="oqiv opacity" >(o'quv fanining nomi)</p>
                </div>
                <div class="col-xs-4 row2">
                    <p class="p11"><ins class="dis"> ______________ </ins></p>
                    <p class="baho opacity">(baho)</p>
                </div>
            </div>
            <div class="row" style="margin-bottom: 4px;">
                <div class="col-xs-8 row11">
                    <p class="p10"><ins class="dis"> _____________________________ </ins></p>
                    <p class="oqiv1 opacity" style="margin-top: -13px;">(o'quv fanining nomi)</p>
                </div>
                <div class="col-xs-4 row22">
                    <p class="p11"><ins class="dis"> ______________ </ins></p>
                    <p class="baho1 opacity">(baho)</p>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-8 row12">
                    <p class="p10"><ins class="dis"> _____________________________ </ins></p>
                    <p class="oqiv opacity">(o'quv fanining nomi)</p>
                </div>
                <div class="col-xs-4 row23">
                    <p class="p11"><ins class="dis"> ______________ </ins></p>
                    <p class="baho opacity">(baho)</p>
                </div>
            </div>
        </div>
        <div class="col-xs-6">
            <p class="a1  opacity">Imtihonlar komissiyasi raisi:</p>
            <div class="row">
                <div class="col-xs-8 ro1">
                    <p><ins class="dis"><b> ____________________________________</b>
                    
                     </ins></p>
                      <span style="    font-size: 11px;position: absolute;left: 17px;">
                    <b style="color:red"> {{ $data->komis_rais }}</b>
                     </span>
                    <p class="oqi opacity" style="    margin-top: -11px;">(familiyasi,ismi-sharifi)</p>
                </div>
                <div class="col-xs-4 ro2">
                    <p><ins class="dis"> _______________ </ins></p>
                    <p class="bah opacity"  style="    margin-left: 40%; margin-top: -11px;">(imzo)</p>
                </div>
            </div>
            <p class="a2  opacity">Talim muassasasi (tashkiloti) rahbari</p>
            <div class="row">
                <div class="col-xs-8 ro11">
                    <p><ins class="dis" > ____________________________________ </ins></p>
                    <span style="    font-size: 11px;position: absolute;left: 17px;">
                    <b style="color:red">  {{ $data->tash_rahbar }}</b>
                     </span>
                    <p class="oqi opacity" style="    margin-top: -11px;">(familiyasi,ismi-sharifi)</p>
                </div>
                <div class="col-xs-4 ro22">
                    <p><ins class="dis"> _______________ </ins></p>
                    <p class="bah opacity"  style="margin-left: 40%;margin-top: -11px;"     >(imzo)</p>
                </div>
            </div>
            <p class="a3  opacity" style="    margin-right: -82%;">M.O'.</p>
            <p class="a4" style="    margin-top: 10%;">
                <ins class="dis"> ____________________________________ </ins>
                <span style="    font-size: 11px;position: absolute;left: 17px;">
                    <b style="color:red"> {{ $data->hudud_nomi }}</b>
                     </span>
                <span class="opacity" >YHXB BIR (TRIB)</span>
            </p>
            <p class="a5 opacity" style="    margin-left: -16%;margin-top: -11px;" >(hududiy  IIV.IIBB.IIB nomi)</p>
            <p class="a6">
                <span class="opacity">tomonidan</span>
                <ins class="dis"> _____________ </ins> 
                <span class="opacity">seriyadagi</span>
                <ins class="dis"> ____________</ins>
                <span class="opacity">raqamli haydovchilik guvohnomasi berildi.&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp &nbsp&nbsp&nbsp &nbsp&nbsp&nbsp &nbsp&nbsp&nbsp &nbsp&nbsp&nbsp &nbsp&nbsp&nbsp  &nbsp&nbsp&nbsp     RIB (TRIB) boshligi:</span>
            </p>
            <div class="row">
                <div class="col-xs-8 ro12">
                    <p>
                        <ins class="dis"> _________________________________     </ins>
                    </p>
                    <p class="oqi opacity" style="    margin-top: -11px;">(familiyasi,ismi-sharifi)</p>
                    <span style="    font-size: 11px;position: absolute;left: 17px;">
                    <b style="color:red"> {{ $data->rib_rais }}</b>
                     </span>
                </div>
                <div class="col-xs-4 ro23">
                    <p><ins class="dis" > ______________ </ins></p>
                    <p class="bah opacity"  style="    margin-top: -11px;">(baho)</p>
                </div>
            </div>
         
            <p class="a7">
                <span class="opacity">20</span>
                <ins class="dis p12"> ____ </ins> 
                <span class="opacity">yil &lt;&lt;</span>
                <ins class="dis p12"> ____ </ins> 
                <span class="opacity">&gt;&gt;</span>
                <ins class="dis p12"> _________________________ </ins> 
                <span class="a8 opacity">M.O'.</span>
            </p>
            <br>
            <p class="a9 opacity">Ushbu hujjat avtomototransport vositalari va shahar
            elektr traansporti vositalarini boshqarish huquqini bermaydi.
            </p>
            <h4 class="text-center h43 opacity">10AA <span class="span">0445250</span></h4>
        </div>
    </div>
</div>
</div>

@endif

    </div>
    <!-- END PAGE CONTAINER -->
@endsection