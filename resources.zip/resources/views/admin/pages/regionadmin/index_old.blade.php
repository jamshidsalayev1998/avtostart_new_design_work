@extends('layouts.admin')



@section('content')

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">

                    <div class="panel-heading">

                        <div class="col-md-11">

                            <h3 class="panel-title">Hududiy Administratorlar</h3>

                            <a href="{{route('regionadmin.create')}}" class="btn btn-success pull-right"><i class="icon-plus-circle">&nbsp;</i>Yangi qo'shish</a>

                        </div>

                        <div class="col-md-1">

                            <div class="dropdown pull-right">

                                <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>

                                <ul class="dropdown-menu dropdown-left">

                                    <li><a href="{{ route('timetables.index') }}" ><span class="fa fa-file-pdf-o text-danger">&nbsp;&nbsp;</span> PDF Export</a></li>

                                    <li><a href="{{ route('export.adminstoexcel') }}" ><span class="fa fa-file-excel-o text-success">&nbsp;&nbsp;</span> Excel Export</a></li>

                                </ul>

                            </div>

                        </div>

                    </div>

                    <div class="panel-body">

                        @if(session('message'))

                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                <div class="alert-icon">

                                    <span class="icon-checkmark-circle"></span>

                                </div>

                                {{ session('message') }}

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                            </div>

                        @endif

                        <table class="table table-bordered table-hover">

                            <thead>

                            <tr>

                                <th style="width: 2%">#</th>

                                <th>FIO</th>

                                <th>Viloyat</th>

                                <th>Yaratilgan sana</th>
                                 <th>Kirgan sana</th>

                                <th colspan="3" width="5%"></th>

                            </tr>

                            </thead>

                            <tbody>



                            @php $count = $data->perPage() * ($data->currentPage() - 1) @endphp

                            @foreach($data as $person)

                                <tr>

                                    <td>{{ ++$count }}</td>

                                    <td>{{ $person->full_name }}</td>

                                    <td>{{ $person->region->name_uz }}</td>

                                    <td>{{ $person->created_at }}</td>

                                    <td>{{ $person->last_seen }}</td>



                                    <td>

                                        <a href="{{ route('regionadmin.show', ['id' => $person->id]) }}" class="btn btn-default btn-icon">

                                            <i class="fa fa-eye"></i>

                                        </a>

                                    </td>

                                    <td>

                                        <a href="{{ route('regionadmin.edit', ['id' => $person->id]) }}" class="btn btn-default btn-icon">

                                            <i class="icon-pencil"></i>

                                        </a>

                                    </td>

                                    <td>

                                        <form action="{{ route('regionadmin.destroy', ['id' => $person->id]) }}" method="post">

                                            {{ csrf_field() }}

                                            {{ method_field('delete') }}

                                            <button class="btn btn-default btn-icon deleteData"><i class="icon-trash"></i></button>

                                        </form>

                                    </td>

                                </tr>

                            @endforeach

                            </tbody>

                        </table>



                        {!! $data->links() !!}



                    </div>

                </div>



            </div>

        </div>

    </div>

@endsection