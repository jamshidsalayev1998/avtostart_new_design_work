@extends('layouts.admin')
@section('content')
    <div class="container">

        <form action="regionadmin/managerstore" method="post" class="has-validation-callback">
            {{ csrf_field() }}

            <div class="block block-condensed">
                <div class="block-content">

                    <div class="wizard show-submit">
                        <ul>
                            <li>
                                <a href="#step-8">
                                    <span class="stepNumber">1</span>
                                    <span class="stepDesc">Admin Content<br /><small>Shaxsiy ma'lumotlarni kiritish</small></span>
                                </a>
                            </li>
                           
                        </ul>

                        

                        <div id="step-8">

                            <div class="form-group">
                                    <div class="form-group">
                                            <label>Admin Content FIO
                                                @if($errors->has('full_name'))
                                                    <span class="text-danger"> | {{ $errors->first('full_name') }}</span>
                                                @endif
                                            </label>
                                            <input class="form-control"  placeholder="FIO" value="{{ old('full_name') }}" id="full_name" name="full_name">
                                        </div>
                                <div class="row">
                                    <label class="col-md-12 control-label">Login
                                        @if($errors->has('login'))
                                            <span class="text-danger"> | {{ $errors->first('login') }}</span>
                                        @endif
                                    </label>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="login" id="login" placeholder="login" value="{{old('login')}}">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <label class="col-md-12 control-label">Parol
                                        @if($errors->has('password'))
                                            <span class="text-danger"> | {{ $errors->first('password') }}</span>
                                        @endif
                                    </label>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="password" id="password" value="{{old('password')}}"  placeholder="Parolni kiriting yoki generatsiya qiling">
                                    </div>
                                    <div class="col-md-3">
                                        <button type="button" class="btn btn-default" onclick="password_generator(10)"><span class="fa fa-key">&nbsp;</span>Parol generator</button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
@endsection