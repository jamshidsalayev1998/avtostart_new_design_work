@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="col-md-11">
                            <h3 class="panel-title">Hududiy Administratorlar</h3>
                            <a href="{{action('Admin\RegionAdminController@managercreate',[])}}" class="btn btn-success pull-right"><i class="icon-plus-circle">&nbsp;</i>Yangi qo'shish</a>
                        </div>
                     
                    </div>
                    <div class="panel-body">
                        @if(session('message'))
                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-checkmark-circle"></span>
                                </div>
                                {{ session('message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        @endif
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="width: 2%">#</th>
                                <th>FIO</th>
                                <th>Ko`rish</th>
                                <th>O`chirish</th>
                            
                            </tr>
                            </thead>
                            <tbody>

                            @php $count = $data->perPage() * ($data->currentPage() - 1) @endphp
                            @foreach($data as $person)
                                <tr>
                                    <td>{{ ++$count }}</td>
                                    <td>{{ $person->name }}</td>
                                   
                                    

                                    <td>
                                        <a href="regionadmin/managershow/<?=$person->id?>" class="btn btn-default btn-icon">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    </td>
                                   
                                    <td>
                                            <a href="regionadmin/managerdestroy/<?=$person->id?>" class="btn btn-default btn-icon">
                                                    <i class="icon-trash"></i>
                                                </a>
                                   
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {!! $data->links() !!}

                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection