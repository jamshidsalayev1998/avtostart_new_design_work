@extends('layouts.admin_alisher')



@section('content')

                    <div class="title-link">
                        <div>
                            <h1>Hududiy Administratorlar</h1>
                            <p><span class="head-link-href" data-href="/backoffice">Bosh sahifa</span>/Hududiy Administratorlar</p>
                        </div>
                        
                    </div>
                    <div class="table-toifa-CE">
                    <div class="h1-button">
                        <h1>Hududiy Administratorlar</h1>
                        <button id="href_button" data-href = {{ route('regionadmin.create') }} class="add-fan">
                            <p> Qo'shish</p>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7 1.16667V12.8333" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M1.16602 7H12.8327" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>    
                        </button>
                    </div>
                    <div class="table-content">

                        <table class="table-hover ">

                            <thead>

                            <tr>

                                <th style="width: 2%"><p># </p></th>

                                <th><p>FIO </p></th>

                                <th><p>Viloyat </p></th>

                                <th><p>Yaratilgan sana </p></th>
                                 <th><p>Kirgan sana </p></th>

                                <th colspan="3" width="5%"><p> </p></th>

                            </tr>

                            </thead>

                            <tbody>



                            @php $count = $data->perPage() * ($data->currentPage() - 1) @endphp

                            @foreach($data as $person)

                                <tr>

                                    <td><p>{{ ++$count }} </p></td>

                                    <td><p>{{ $person->full_name }} </p></td>

                                    <td><p>{{ $person->region->name_uz }} </p></td>

                                    <td><p>{{ $person->created_at }} </p></td>

                                    <td><p>{{ $person->last_seen }} </p></td>



                                    <td><p>

                                        <a href="{{ route('regionadmin.show', ['id' => $person->id]) }}" class="btn btn-default btn-icon">

                                            <i class="fa fa-eye"></i>

                                        </a> </p>

                                    </td>

                                    <td><p>

                                        <a href="{{ route('regionadmin.edit', ['id' => $person->id]) }}" class="btn btn-default btn-icon">

                                            <i class="fa fa-edit"></i>

                                        </a> </p>

                                    </td>

                                    <td><p>

                                        <form action="{{ route('regionadmin.destroy', ['id' => $person->id]) }}" method="post">

                                            {{ csrf_field() }}

                                            {{ method_field('delete') }}

                                            <button class="btn btn-default btn-icon deleteData"><i class="fa fa-trash"></i></button>

                                        </form> </p>

                                    </td>

                                </tr>

                            @endforeach

                            </tbody>

                        </table>



                        {!! $data->links() !!}



                    </div>

                </div>




@endsection