@extends('layouts.admin')
@section('content')
    <div class="container">

        <!-- SEARCH FORM -->
        <div class="block padding-top-20">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <div class="input-group">
                            <a class="btn btn-default btn-icon">
                                <i class="fa fa-search"></i>
                            </a>&nbsp;&nbsp;&nbsp;<span style="font-size: 18px;">{{$data->full_name}}</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 text-right">
                    <div class="col-md-4">
                        <a href="{{route('regionadmin.edit',['id'=>$data->id])}}" class="btn btn-default btn-icon-fixed"><span class="icon-pencil"></span> O'zgartirish</a>
                    </div>
                    <div class="col-md-4">
                        <a href="{{route('regionadmin.index')}}" class="btn btn-default btn-icon-fixed "><span class="icon-list"></span> Ro'yxat</a>
                    </div>
                    <div class="col-md-4">
                        <form action="{{ route('regionadmin.destroy', ['id' => $data->id]) }}" method="post">
                            {{ csrf_field() }}
                            {{ method_field('delete') }}
                            <button class="btn btn-danger btn-icon-fixed deleteData"><span class="icon-trash"></span> O'chirish</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- END SEARCH FORM -->


        <div class="block block-arrow-top padding-top-20">
            <div class="row">
                <div class="col-md-9">

                    <div class="listing listing-separated margin-bottom-0">
                        <div class="listing-item margin-bottom-10">
                            <a href="#" class="text-lg">Ko'rish</a>
                        </div>
                        <div class="col-md-12">

                            <div class="panel panel-default" id="panel-toggle">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th style="border-right: 1px solid black;text-align: right">Ustun nomi</th>
                                        <th >Qiymati</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th>1</th>
                                        <td style="border-right: 1px solid black;text-align: right">FIO Admin</td>
                                        <td style="font-weight: 800;border-right:">{{$data->full_name}}</td>
                                    </tr>
                                    <tr>
                                        <th>2</th>
                                        <td style="border-right: 1px solid black;text-align: right">Tug'ilgan sana</td>
                                        <td style="font-weight: 800">{{$data->birthdate}}</td>
                                    </tr>
                                    <tr>
                                        <th>3</th>
                                            <td style="border-right: 1px solid black;text-align: right">Viloyat nomi</td>
                                        <td style="font-weight: 800">{{$data->region->name_uz}}</td>
                                    </tr>
                                    <tr>
                                        <th>4</th>
                                        <td style="border-right: 1px solid black;text-align: right">Pasport ma'lumoti</td>
                                        <td style="font-weight: 800">{{$data->passport_info}}</td>
                                    </tr>
                                    <tr>
                                        <th>5</th>
                                        <td style="border-right: 1px solid black;text-align: right">Jinsi</td>
                                        <td style="font-weight: 800">{{$data->getGender()}}</td>
                                    </tr>
                                    <tr>
                                        <th>6</th>
                                        <td style="border-right: 1px solid black;text-align: right">Telefon raqam</td>
                                        <td style="font-weight: 800">{{$data->phone}}</td>
                                    </tr>
                                    <tr>
                                        <th>7</th>
                                        <td style="border-right: 1px solid black;text-align: right">Manzil</td>
                                        <td style="font-weight: 800">{{$data->address}}</td>
                                    </tr>
                                    <tr>
                                        <th>8</th>
                                        <td style="border-right: 1px solid black;text-align: right">Yaratuvchi</td>
                                        <td style="font-weight: 800">{{$data->getCreator()}}</td>
                                    </tr>
                                    <tr>
                                        <th>9</th>
                                        <td style="border-right: 1px solid black;text-align: right">So'ngi o'zgartiruvchi</td>
                                        <td style="font-weight: 800">{{$data->getUpdater()}}</td>
                                    </tr>
                                    <tr>
                                        <th>10</th>
                                        <td style="border-right: 1px solid black;text-align: right">Yaratilgan sana</td>
                                        <td style="font-weight: 800">{{$data->created_at}}</td>
                                    </tr>
                                    <tr>
                                        <th>11</th>
                                        <td style="border-right: 1px solid black;text-align: right">O'zgartirilgan sana</td>
                                        <td style="font-weight: 800">{{$data->updated_at}}</td>
                                    </tr>
                                    <tr>
                                        <th>12</th>
                                        <td style="border-right: 1px solid black;text-align: right">Login</td>
                                        <td style="font-weight: 800">{{$data->user->username}}</td>
                                    </tr>
                                    <tr>
                                        <th>13</th>
                                        <td style="border-right: 1px solid black;text-align: right">Parol</td>
                                        <td style="font-weight: 800"><span id="item_v"></span><button class="btn btn-default" id="passwordshower" data-url = "regionadmin" data-idec="{{$data->user->id}}">&nbsp;<i class="fa fa-eye">Parolni ko'rish</i></button></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection