@extends('layouts.admin_alisher')

@section('content')
                <div class="title-link">
                    <div>
                        <h1>Mening guruhlarim</h1>
                        <p><span>Darsliklar</span>/Mening guruhlarim</p>
                    </div>
                    
                </div>
                <div class="table-toifa">
                    <h1>Mening guruhlarim</h1>
                    <div class="table-content">
                    <table class="table table-bordered table-hover">
                        <tr>
                            <th style="width: 2%"><p># </p></th>
                            <th><p>Raqami </p></th>
                            <th><p>Sizning rolingiz </p></th>
                            <th style="text-align: center"><p>Ta'limning davomiyligi </p></th>
                            <th><p>Holati </p></th>
                            <th colspan="2" style="width: 8%"><p> </p></th>
                        </tr>
                        @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp
                        @foreach($data as $item)
                            <tr style="@if($item->status == 1) background: lightgreen @endif @if($item->status == 2) ;background: lightpink @endif ">
                                <td><p>{{ ++$count }} </p></td>
                                <td><p>{{ $item->name_uz }} </p></td>
                                <td><p>@if($item->teacher_id == $responsible->id) Asosiy o'qituvchi @endif @if($item->assistant_id == $responsible->id) Yordamchi o'qituvchi @endif </p></td>
                                <td align="center"><p>{{ $item->edu_starting_date }} <span class="fa fa-long-arrow-right"></span> {{ $item->edu_ending_date }} </p></td>
                                <td><p>{{ $item->getStatus() }} </p></td>
                                <td><p>
                                    <a href="{{ route('group.show', ['id' => $item->id]) }}" class="btn btn-sm btn-default btn-icon">
                                        <span class="fa fa-eye"></span>
                                    </a> </p>
                                </td>
                            </tr>
                        @endforeach
                    </table>

                    {!! $data->links() !!}

                </div>

            </div>


@endsection