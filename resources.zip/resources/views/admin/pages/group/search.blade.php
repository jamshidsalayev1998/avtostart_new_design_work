@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('group.index') }}">Guruhlar</a></li>
        </ul>
    </div>
    <div class="block" style="background: whitesmoke">
        <div class="c">
            <form method="post" action="/backoffice/group/search" name="group-search-form">
                {{ csrf_field() }}
                <div class="col-md-8 col-lg-8" style="padding: 0px;">
                    <div class="col-md-4" style="padding: 2px;margin: 0px;">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <span class="fa fa-calendar"></span>
                            </div>
                            <input type="text" name="daterange" class="form-control daterange">
                        </div>
                    </div>
                    <div class="col-lg-4" style="padding: 2px;margin: 0px;">
                        <select class="bs-select student_id"  id="teacher_id" data-live-search="true" data-dependent="teacher_id" name="teacher_id">
                            <option selected style="display: none;opacity: 0.7" value="">#Asosiy o'qituvchi</option>
                            @foreach($teachers as $teacher)
                                <option value="{{ $teacher->id }}" @if(old('teacher_id')==$teacher->id) selected @endif>{{ $teacher->full_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-lg-4" style="padding: 2px;margin: 0px;">
                        <select class="bs-select assistant_id"  id="assistant_id" data-live-search="true" data-dependent="assistant_id" name="assistant_id">
                            <option selected style="opacity: 0.7;display: none;" value="">@Yordamchi o'qituvchi</option>
                            @foreach($teachers as $teacher)
                                <option value="{{ $teacher->id }}" @if(old('assistant_id')==$teacher->id) selected @endif>{{ $teacher->full_name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-4" style="padding-right: 0px;">
                    <div class="form-group" style="padding: 2px;margin: 0px;">
                        <div class="input-group">
                            <input type="text" class="form-control text-bold" name="keyword" placeholder="Qidirish..." value="@if(isset($keyword)){{ $keyword }}@endif">
                            <div class="input-group-btn">
                                <button class="btn btn-default btn-icon dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="icon-cog"></span></button>
                                <ul class="dropdown-menu dropdown-left" >
                                    <li>
                                        <a href="#">
                                            <div class="app-checkbox"><label><input type="checkbox" name="ac-1" checked> Guruh nomi bo'yicha (UZ)<span></span></label></div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <div class="app-checkbox"><label><input type="checkbox" name="ac-2" checked=""> Guruh nomi bo'yicha (Ru)<span></span></label></div>
                                        </a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a href="#">
                                            <div class="app-checkbox"><label><input type="checkbox" name="ac-4"> Arxivdan qidirish<span></span></label></div>
                                        </a>
                                    </li>
                                </ul>
                                <button type="submit" class="btn btn-default">Qidirish</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <p class="help-block margin-left-20">Search result for <span class="text-bold">Boooya Revolution Admin Template</span> (1,321 results)</p>
        </div>
    </div>
    <div class="container">
        <div class="row grid" style="position: relative; height: 3726px;">
            @foreach($data as $group)
                <div class="col-md-3 col-ms-4 grid-element " style="position: absolute; left: 0%; top: 0px;">
                    <a href="{{ route('group.show',['id'=>$group->id]) }}">
                        <div class="tile-basic">
                        <span style="color: blue" class="tile-image tile-image-padding tile-image-hover-grayscale preview" data-preview-image="assets/images/large/img-1.jpg" data-preview-size="modal-lg">
                            <h1 style="text-align: center">{{ $group->name_uz }}</h1>
                        </span>
                            <div class="tile-content tile-content-condensed-bottom text-center">
                                <span class="tile-subtitle" style="color:black;opacity: 0.7">#{{ \Test\Model\Group::getTeacher($group->teacher_id) }}</span>
                                <span class="tile-subtitle" style="color:black;opacity: 0.7">{{ '@'.\Test\Model\Group::getTeacher($group->assistant_id) }}</span>
                                <h3 class="tile-title" style="color:blue;">{{ $group->edu_type }}</h3>
                            </div>
                        </div>
                    </a>
                </div>
            @endforeach
        </div>

    </div>
@endsection