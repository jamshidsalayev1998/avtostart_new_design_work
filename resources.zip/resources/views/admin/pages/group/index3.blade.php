@extends('layouts.admin_alisher')

@section('content')
                <div class="title-link">
                    <div>
                        <h1>Barcha guruhlar</h1>
                        <p><span>Darsliklar</span>/Barcha guruhlar</p>
                    </div>
                    
                </div>
                <div class="table-toifa">
                    <h1>Barcha guruhlar</h1>
                    <div class="table-content">
                    <table class="table-hover">
                        <tr>
                            <th style="width: 2%"><p># </p></th>
                            <th><p>Raqami </p></th>
                            <th><p>Filial nomi </p></th>
                            <th style="text-align: center"><p>Ta'limning davomiyligi </p></th>
                            <th><p>O'quvchilar soni </p></th>
                            <th><p>Holati </p></th>
                            <th colspan="2" style="width: 8%"><p> </p></th>
                        </tr>
                        @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp
                        @foreach($data as $item)
                            <tr style="@if($item->status == 1 ) background: cyan @endif @if($item->status == 2) ;background: lightgreen @endif ">
                         
                         
                                <td><p>{{ ++$count }} </p></td>
                                <td><p>{{ $item->name_uz }} </p></td>
                                <td><p>{{ $item->branch->name_uz }} </p></td>
                                <td align="center"><p>{{ $item->edu_starting_date }} <span class="fa fa-long-arrow-right"></span> {{ $item->edu_ending_date }} </p></td>
                                <td><p>{{ count($item->students) }} </p></td>
                                <td><p>{{ $item->getStatus() }} </p></td>
                                <td><p>
                                    <a href="{{ route('group.show', ['id' => $item->id]) }}" class="btn btn-sm btn-default btn-icon">
                                        <span class="fa fa-eye"></span>
                                    </a> </p>
                                </td>
                                
                            </tr>
                        @endforeach
                    </table>

                    {!! $data->links() !!}

                </div>

            </div>


@endsection