@extends('layouts.admin')

@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('group.index') }}">Guruhlar</a></li>

            <li class="active">Guruhni shakllanitirish</li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>

    <div class="container">



        <!-- NEW DEPOSITS -->

        <div class="row">

            <div class="col-md-1">

            </div>

            <div class="col-md-10">

                <div class="tile-basic tile-basic-icon-top">

                    <div class="tile-icon">

                        @if($data->status == 0) <span class="icon-cog"></span> @endif

                        @if($data->status == 1) <span class="icon-checkmark-circle text-success"></span> @endif

                        @if($data->status == 2) <span class="icon-power-switch text-danger"></span>@endif

                    </div>

                    <div class="tile-content text-center">

                        <h3 class="tile-title" style="color: blue">{{ $data->name_uz." (".$data->getCourseName().")" }}</h3>

                        @if($data->assistant_id != null)

                            <h5>#{{ $data->teacher->full_name }} / {{ "@".$data->assistant->full_name }}</h5>
                            <h5>
                                <?php  $master1 = Test\Model\Master::where('id', '=', $data->master1_id )->first();?>
                                <?php  $master2 = Test\Model\Master::where('id', '=', $data->master2_id )->first();?>
                               
                                @if(!empty($master1))
                                   {{ " Asosiy usta:".$master1->full_name }}
                                     
                                @endif
                            
                                 

                                  @if(!empty($master2))
                                   {{ "----Yordamchi usta:".$master2->full_name }}
                                     
                                @endif
                            
                         </h5>

                        @endif

                        {{ $data->edu_starting_date }} <span class="fa fa-long-arrow-right"></span> {{ $data->edu_ending_date }} / {{ count($grouped_students) }} ta o'quvchi<br><br>

                        <div class="col-md-10">

                            <p class="text-left margin-0">Guruhning hozirgi holati:
                                @if($data->status == 0)
                             <strong>Shakllantirilayotgan guruh</strong>
                                @endif
                                 @if($data->status == 1&&$data->has_timetable ==1)
                             <strong>Aktiv </strong>
                                @endif
                                @if($data->status == 1&&$data->has_timetable ==0)
                             <strong>Aktiv lekin dars jadvali yaratilmagan </strong>
                                @endif
                                 @if($data->status == 2)
                             <strong>Ta`lim tugagan </strong>
                                @endif
                         </p>

                            @if($data->status == 0)<p class="text-left margin-0"><span class="fa fa-info" style="color: blue;text-align: justify">&nbsp;</span>Eslatma: <span style="opacity: 0.8">Guruhni 12-25 ta o'quvchilar bilan to'ldirsangiz guruh avtomatik ravishda <strong>Aktiv</strong> holatga o'tadi!</span></p>@endif

                            @if($data->status == 1 || $data->status == 2)
                                <p  class="text-left margin-top-0 margin-bottom-5"> Guruh uchun to`lov holati :
                                    @if(!isset($tolov_holati[0]))
                                        <strong style="color: #ff0000">
                                            Umuman to`lanmagan!
                                        </strong>

                                    @endif
                                    @if(isset($tolov_holati[0]))
                                        @if($tolov_holati->sum('percent') == 100)
                                            <strong style="color: #21ff13">
                                                To`langan!
                                            </strong>

                                        @endif
                                        @if($tolov_holati->sum('percent') < 100)
                                            <strong style="color: #ffa50f">
                                                {{$tolov_holati[0]->percent}}% to`langan!
                                            </strong>

                                        @endif
                                    @endif
                                </p>
                            @endif
                        </div>

                        <div class="col-md-2">

                            <div class="dropdown pull-right">

                                <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>

                                <ul class="dropdown-menu dropdown-left">

                                    <li><a href="{{ route('timetables.index') }}" ><span class="note-icon-table">&nbsp;&nbsp;</span> Dars jadvali</a></li>

                                    <li><a href="{{ route('group.edit',['id'=>$data->id]) }}" ><span class="fa fa-edit"></span> Guruhni o'zgartirish</a></li>

                                    <li><a href="#" data-toggle="modal" data-target="#modal-password"><span class="fa fa-archive"></span>Guruhni Arxivga olish</a></li>

                                    @if($data->status < 2)

                                    <li>

                                        <form action="{{ route('group.destroy', ['id' => $data->id]) }}" method="post">

                                            {{ csrf_field() }}

                                            {{ method_field('delete') }}

                                            <button class="btn btn-danger btn-icon-fixed deleteData form-control" style="text-align: left;border: none;">&nbsp;<span class="icon-trash" style="margin-left: 15px;"></span>Guruhni O'chirish</button>

                                        </form>

                                    </li>

                                    @endif

                                </ul>

                            </div>

                        </div>
                        <br>
                              <div class="col-md-12">
    <a type="button" href="{{ route('monitoring.show',['id'=>$data->id]) }}" class="btn btn-info  btn-lg " value="Excelga export qilish  " style="">Monitoring</a>
    <a type="button" href="{{ route('mark.show',['id'=>$data->id]) }}" class="btn btn-danger  btn-lg " value="Excelga export qilish  " style="">Baholash</a>

    <a type="button" href="{{ route('timetables.result',['id'=>$data->id]) }}" class="btn btn-warning  	 btn-lg " value="Excelga export qilish  " style="">Dars jadvali</a>
        <a type="button" href="../test/reg/{{ $data->id }}" class="btn btn-success 	 btn-lg " value="Excelga export qilish  " style="">Testga ruxsat</a>

									</div>


                    </div>

                </div>

            </div>

            <div class="col-md-2">

            </div>

        </div>

        <!-- END NEW DEPOSITS -->

        <input type="hidden" id="members" value="{{ count($grouped_students) }}">

        <!-- DEPOSITS -->

        <div class="block block-condensed">

            <div class="app-heading app-heading-small">

                <div class="title">

                    <h2>Guruh o'quvchilari</h2>

                    <p>O'quvchini qo'shish yoki o'chirish o'ng tomonda amalga oshiriladi</p>

                </div>

                <div class="heading-elements">

                    <button class="btn btn-default btn-icon notify" data-toggle="modal"

                            @if(count($grouped_students)==25)  disabled @endif

                            data-target="#modal-add" data-notify-type="alert"

                            data-notify-layout="top" data-notify="<strong id='countstudents' style='font-size:16px;'>0</strong> o'quvchi tanlandi!"

                            data-clicked="0" id="add-button">

                        <span class="icon-plus-circle"></span>

                    </button>
                    <input type="button" onclick="tableToExcel('testTable', 'W3C Example Table')" class="btn btn-default btn-lg pull-right" value="Excelga export qilish  " style="    padding: 5px 7px;
    font-size: 13px;
    text-transform: uppercase;
    margin-left: 15px;">
     <a type="button" href="{{ route('printstudents',['id'=>$data->id]) }}" class="btn btn-default btn-lg pull-right" value="Excelga export qilish  " style="   
      padding: 5px 7px;
    font-size: 13px;
    background-color: #5c945c;
    color: white;
    text-transform: uppercase;
    margin-left: 15px;">Parollar</a>


                   <button class="btn btn-default btn-icon" data-toggle="modal" data-target="#modal-remove"><span class="icon-trash text-danger"></span></button>

                   <!--  <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown" style="margin-left: 3px;"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>

                    <ul class="dropdown-menu dropdown-left">

                        <li><a href="{{ route('printstudents',['id'=>$data->id]) }}" ><span class="fa fa-file-pdf-o text-danger"></span> Parollarni pdfda yuklash</a></li>

                    </ul> -->

                </div>

            </div>



            <div class="block-content">

                <table class="table table-bordered table-striped margin-bottom-10"  id="testTable">

                    <thead>

                    <tr>

                        <th style="width: 3%">#</th>

                        <th style="width: 33%;">FIO</th>
                        <th style="width: 33%;">Tug`ilgan yili</th>
                        <th style="width: 33%;">Yashash manzili</th>
                        <th style="width: 33%;">Toifasi</th>

                        <th style="width: 20%;text-align: center">Pasport</th>

                        <th style="width: 20%;text-align: center">Telefon</th>

                        <th style="width: 3%;text-align: center">Qo`shimcha</th>

                    </tr>

                    </thead>

                    <tbody>@php $i=1; @endphp

                    @foreach($grouped_students as $student)

                        <tr>

                            <td>{{ $i }}</td>

                            <td>{{ $student->student->fio() }}</td>

                            <td  style="text-align: center">{{ $student->student->birth_date }} </td>
                            <td  style="text-align: center">{{ $student->student->home_address   }} </td>
                            <td  style="text-align: center">

                            @if($student->student->edu_type ==1)
                            «B» тайёрлаш 
                            @endif
                            @if($student->student->edu_type ==2)
                            «A» тайёрлаш
                            @endif
                            @if($student->student->edu_type ==3)
                            «C» тайёрлаш
                            @endif
                            @if($student->student->edu_type ==4)
                            «BC» тайёрлаш
                            @endif
                            @if($student->student->edu_type ==5)
                            «D» қайта тайёрлаш
                            @endif
                            @if($student->student->edu_type ==6)
                            «CE» қайта тайёрлаш
                            @endif
                            @if($student->student->edu_type ==7)
                            «BE» қайта тайёрлаш
                            @endif
                            @if($student->student->edu_type ==8)
                            «C» қайта тайёрлаш
                            @endif
                            @if($student->student->edu_type ==9)
                            «DE» қайта тайёрлаш
                            @endif


                             </td>
                          
                            <td  style="text-align: center">{{ $student->student->passport_serial }} {{ $student->student->passport_number }}</td>

                            <td  style="text-align: center">+{{ $student->student->phone1 }}@php $i++; @endphp</td>

                            <td  style="text-align: center">

                                <div class="dropdown pull-right margin-right-10">

                                    <button type="button" class="btn btn-default btn-icon pull-right btn-sm" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>

                                    <ul class="dropdown-menu dropdown-left">

                                        <li><a href="{{ route('student.show',['id'=>$student->student->id]) }}" ><span class="fa fa-user"></span> O'quvchi haqida</a></li>

                                        <li><a href="{{ route('payment.show',['id'=>$student->student->id]) }}" ><span class="fa fa-calculator"></span> O'quvchining to'lovlari</a></li>

                                        <li><a href="{{ route('payment.show',['id'=>$student->student->id]) }}" ><span class="fa fa-times"></span> O'quvchining davomati</a></li>

                                        <li><a href="{{ route('payment.show',['id'=>$student->student->id]) }}" ><span class="fa fa-check"></span> O'quvchining baholari</a></li>

                                    </ul>

                                </div>

                            </td>

                        </tr>

                    @endforeach

                    </tbody>

                </table>

            </div>

        </div>

        <!-- MODAL LARGE -->

        <div class="modal fade" id="modal-add" tabindex="-1" role="dialog" aria-labelledby="modal-large-header">

            <div class="modal-dialog modal-lg" role="document">

                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>



                <div class="modal-content">

                    <div class="modal-header">

                        <h4 class="modal-title" id="modal-large-header">Guruhga o'quvchini qo'shish</h4>

                        <p>O'quvchilarni belgilng va <i>Qo'shish</i> tugmasini bosing.</p>

                    </div>

                    <div class="modal-body">

                        <div class="block-content">

                            <form method="post" name="add-member-form" id="add-member-form" action="/backoffice/group/addmember/{{ $data->id }}">

                                {{ csrf_field() }}

                                <table class="table table-bordered table-striped margin-bottom-10">

                                    <thead>

                                    <tr>

                                        <th>№</th>

                                        <th>#</th>

                                        <th style="width: 33%;">FIO</th>

                                        <th style="width: 20%;text-align: center">Student ID</th>

                                        <th style="width:20%;text-align: center">Passport info</th>

                                        <th style="width: 20%;text-align: center">Telefon</th>

                                    </tr>

                                    </thead>

                                    <tbody>@php $i=1; @endphp

                                    @foreach($ungrouped_students as $student)

                                        <tr>

                                            <td>{{ $i }}</td>

                                            <td>

                                                <div class="app-checkbox inline">

                                                    <label><input type="checkbox" class="add-member" name="{{ $student->id }}" id="{{ $student->id }}"> &nbsp;<span></span></label>

                                                </div>

                                            </td>

                                            <td>{{ $student->fio() }}</td>

                                            <td style="text-align: center">{{ $student->student_number }}</td>

                                            <td style="text-align: center">{{ $student->passport_serial." ".$student->passport_number }}</td>

                                            <td style="text-align: center">{{ $student->phone1 }}@php $i++; @endphp</td>

                                        </tr>

                                    @endforeach

                                    </tbody>

                                </table>

                            </form>

                        </div>

                    </div>

                    <div class="modal-footer">

                        <button type="button" class="btn btn-link" data-dismiss="modal">Yopish</button>

                        <button type="button" onclick="$('#add-member-form').submit()" class="btn btn-default"><span class="icon-plus-circle"></span>Qo'shish</button>

                    </div>

                </div>

            </div>

        </div>

        <!-- END MODAL LARGE -->

        <!-- END DEPOSITS -->

        <!-- MODAL LARGE -->

        <div class="modal fade" id="modal-remove" tabindex="-1" role="dialog" aria-labelledby="modal-large-header" >

            <div class="modal-dialog modal-lg" role="document">

                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>



                <div class="modal-content">

                    <div class="modal-header">

                        <h4 class="modal-title" id="modal-large-header">Guruhdan o'quvchini o'chirish</h4>

                        <p>O'quvchilarni belgilang va <i>O'chirish</i> tugmasini bosing.</p>

                    </div>

                    <div class="modal-body">

                        <div class="block-content">

                            <form method="post" name="remove-member-form" id="remove-member-form" action="/backoffice/group/removemember/{{ $data->id }}">

                                {{ csrf_field() }}

                                <table class="table table-bordered table-striped margin-bottom-10">

                                    <thead>

                                    <tr>

                                        <th>#</th>

                                        <th style="width: 33%;">FIO</th>

                                        <th style="width: 20%;">Student ID</th>

                                        <th style="width:20%">Passport info</th>

                                        <th style="width: 20%;">Telefon</th>

                                    </tr>

                                    </thead>

                                    <tbody>@php $i=1; @endphp

                                    @foreach($grouped_students as $student)

                                        <tr>

                                            <td>

                                                <div class="app-checkbox inline">

                                                    <label><input type="checkbox" class="remove-member" name="{{ $student->student->id }}"> &nbsp;<span></span></label>

                                                </div>

                                            </td>

                                            <td>{{ $student->student->fio() }}</td>

                                            <td>{{ $student->student->student_number }}</td>

                                            <td>{{ $student->student->passport_serial." ".$student->student->passport_number }}</td>

                                            <td>{{ $student->student->phone1 }}</td>

                                        </tr>

                                    @endforeach

                                    </tbody>

                                </table>

                            </form>

                        </div>

                    </div>

                    <div class="modal-footer">

                        <button type="button" class="btn btn-link" data-dismiss="modal">Yopish</button>

                        <button type="button" onclick="$('#remove-member-form').submit()" @if(count($grouped_students)==0)  disabled @endif class="btn btn-danger"><span class="icon-trash"></span>O'chirish</button>

                    </div>

                    <input type="hidden" name="counter-add" id="counter-add" value="{{ count($grouped_students) }}">

                    <input type="hidden" name="counter-remove" id="counter-remove" value="{{ count($grouped_students) }}">

                </div>

            </div>

        </div>



    </div>

@endsection