@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('region.show',['id'=>$data->branch->region->id]) }}">{{ $data->branch->region->name_uz }}</a></li>
            <li><a href="{{ route('branch.show',['id'=>$data->branch->id]) }}">{{ $data->branch->name_uz }}</a></li>
            <li class="active">{{ $data->name_uz }} - Guruh</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">

        <!-- NEW DEPOSITS -->
        <div class="row">
            <div class="col-md-2">
            </div>
            <div class="col-md-8">
                <div class="tile-basic tile-basic-icon-top">
                    <div class="tile-icon">
                        <span @if($data->status == 0) class="icon-cog" @endif @if($data->status == 1) class="icon-checkmark-circle text-success" @endif></span>
                    </div>
                    <div class="tile-content text-center">
                        <h3 class="tile-title" style="color: blue">{{ $data->name_uz." (".$data->getCourse()->name.")" }}</h3>
                        @if($data->assistant_id != null)
                            <h5>#{{ $data->teacher->full_name }} / {{ "@".$data->assistant->full_name }}</h5>
                        @endif
                        {{ $data->edu_starting_date }} <span class="fa fa-long-arrow-right"></span> {{ $data->edu_ending_date }} / {{ count($data->students) }} ta o'quvchi<br><br>
                        <div class="col-md-10">
                            <p class="text-left margin-0">Guruhning hozirgi holati:
                                @if($data->status == 0)
                             <strong>Aktiv emas</strong>
                                @endif
                                 @if($data->status == 1&&$data->has_timetable ==1)
                             <strong>Aktiv </strong>
                                @endif
                                @if($data->status == 1&&$data->has_timetable ==0)
                             <strong>Aktiv lekin dars jadvali yaratilmagan </strong>
                                @endif
                                  @if($data->status == 2)
                             <strong>Ta`lim tugagan </strong>
                                @endif
                         </p>
                            <p class="text-left margin-0"><span class="fa fa-info" style="color: blue;text-align: justify">&nbsp;</span>Eslatma: <span style="opacity: 0.8">Guruhni 12-25 ta o'quvchilar bilan to'ldirsangiz guruh avtomatik ravishda <strong>Aktiv</strong> holatga o'tadi!</span></p>
                            @if($data->status == 1 || $data->status == 2)
                                <p  class="text-left margin-top-0 margin-bottom-5"> Guruh uchun to`lov holati :
                                    @if(!isset($tolov_holati[0]))
                                        <strong style="color: #ff0000">
                                            Umuman to`lanmagan!
                                        </strong>
                                        @if(\Illuminate\Support\Facades\Auth::user()->role == 2)
                                            <a data-toggle="modal" data-target="#pay_group" class="btn btn-info">To`lov qilish</a>
                                        @endif
                                    @endif
                                    @if(isset($tolov_holati[0]))
                                        @if($tolov_holati->sum('percent') == 100)
                                            <strong style="color: #21ff13">
                                                To`langan!
                                            </strong>

                                        @endif
                                        @if($tolov_holati->sum('percent') < 100)
                                            <strong style="color: #ffa50f">
                                                {{$tolov_holati[0]->percent}}% to`langan!
                                            </strong>
                                            @if(\Illuminate\Support\Facades\Auth::user()->role == 2)
                                                <a data-toggle="modal" data-target="#pay_group"  class="btn btn-info">To`lov qilish</a>
                                            @endif
                                        @endif
                                    @endif
                                </p>
                                <div class="modal fade" id="pay_group" role="dialog">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">To`lov yaratish</h4>
                                            </div>
                                            <form action="/backoffice/pay/create" class="row" method="post">
                                                {{ csrf_field() }}
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <table class="table table-striped table-bordered">
                                                                <thead>
                                                                <tr>
                                                                    <td>
                                                                        Tanlash
                                                                    </td>
                                                                    <td>
                                                                        Guruh nomi
                                                                    </td>
                                                                    <td>
                                                                        O`quvchilar soni
                                                                    </td>
                                                                    <td>
                                                                        Guruh uchun to`lov
                                                                    </td>
                                                                    <td>
                                                                        To`lanadigan foiz
                                                                    </td>

                                                                </tr>
                                                                </thead>
                                                                <tbody class="bodyy">

                                                                        <?php $ee = 0;
$ftu = 1;?>
                                                                        @foreach($groups as $group)
                                                                            @if(!isset($group->paygroups[0]))
                                                                                 <tr id="tr{{$ftu}}">
                                                                                    <td>
                                                                                        <input type="checkbox" name="input[check][{{$group->id}}]" value="{{$group->id}}" class="form-control leftt">
                                                                                    </td>
                                                                                    <td>
                                                                                        {{$group->name_uz}}
                                                                                    </td>
                                                                                    <td>
                                                                                        {{count($group->students)}}
                                                                                    </td>
                                                                                    <td class="centerr">
                                                                                        {{count($group->students)*$price_gr->price}}
                                                                                    </td>
                                                                                    <td>
                                                                                        <select  name="input[percent][{{$group->id}}]" class="form-control rightt" >
                                                                                            <option value="100">100%</option>
                                                                                            <option value="70">70%</option>
                                                                                            <option value="30">30%</option>
                                                                                        </select>
                                                                                    </td>

                                                                                </tr>
                                                                                <?php $ee++;
$ftu++;?>
                                                                            @endif
                                                                            @if(isset($group->paygroups[0]) && count($group->paygroups) == 1 && $group->paygroups[0]->percent != 100)
                                                                                <tr id="tr{{$ftu}}">
                                                                                    <td>
                                                                                        <input type="checkbox" name="input[check][{{$group->id}}]" value="{{$group->id}}" class="form-control leftt">
                                                                                    </td>
                                                                                    <td>
                                                                                        {{$group->name_uz}}
                                                                                    </td>
                                                                                    <td>
                                                                                        {{count($group->students)}}
                                                                                    </td>
                                                                                    <td class="centerr">
                                                                                        {{count($group->students)*$price_gr->price}}
                                                                                    </td>
                                                                                    <td>
                                                                                        <select name="input[percent][{{$group->id}}]" class="form-control rightt" >
                                                                                            @if($group->paygroups[0]->percent == 30)
                                                                                                <option value="70">70%</option>
                                                                                            @else
                                                                                                <option value="30">30%</option>
                                                                                            @endif
                                                                                        </select>
                                                                                    </td>

                                                                                </tr>
                                                                                <?php $ee++;
$ftu++;?>
                                                                            @endif
                                                                        @endforeach
                                                                </tbody>
                                                            </table>

                                                                <div class="col-sm-4">
                                                                    <label for="">Tolangan vaqti</label> <input required type="date" class="form-control" name="paydate">
                                                                </div>
                                                                <div class="col-sm-8">
                                                                        <strong >Umumiy summa:</strong> <b style="color:green" class="summa"></b>
                                                                </div>


                                                        </div>
                                                    </div>
                                                </div>

                                            <div class="modal-footer">

                                                    <button type="submit" class="btn btn-default" >Yaratish</button>

                                            </div>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                                @endif
                        </div>
                        <div class="col-md-2">
                            <div class="dropdown pull-right">
                                <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>
                                <ul class="dropdown-menu dropdown-left">
                                    <li><a href="#" data-toggle="modal" data-target="#modal-password"><span class="fa fa-th"></span>Dars jadvali</a></li>
                                    @if(\Auth::user()->role >3)<li><a href="{{ route('group.edit',['id'=>$data->id]) }}" ><span class="fa fa-edit"></span> Guruhni o'zgartirish</a></li>@endif
                                    @if(\Auth::user()->role >3) <li><a href="{{ route('printstudents',['id'=>$data->id]) }}" ><span class="fa fa-file-pdf-o"></span> Parollarni pdfda yuklash</a></li>@endif
                                    <li><a href="{{ route('mark.show',['id'=>$data->id]) }}" target="_blank"><span class="fa fa-pencil"></span>O'quvchilarning baholari</a></li>
                                    <li><a href="{{ route('monitoring.show',['id'=>$data->id]) }}" target="_blank"><span class="fa fa-times"></span>Monitoring</a></li>
                                    @if(\Auth::user()->role >3)<li><a href="#" data-toggle="modal" data-target="#modal-password"><span class="fa fa-archive"></span>Guruhni Arxivga olish</a></li>@endif
                                    @if(\Auth::user()->role == 7 )
                                      <li>
                                      <a href="#" data-toggle="modal" data-target="#group-permission"><span class="fa fa-cog"></span> Guruhga Ruxsat berish</a></li>@endif
                                        @if($data->status == 0 && (\Auth::user()->role == 5 || \Auth::user()->role == 4))
                                        <li>
                                            <form action="{{ route('group.destroy', ['id' => $data->id]) }}" method="post">
                                                {{ csrf_field() }}
                                                {{ method_field('delete') }}
                                                <button class="btn btn-danger btn-icon-fixed deleteData form-control" style="text-align: left;border: none;">&nbsp;<span class="icon-trash" style="margin-left: 15px;"></span>Guruhni O'chirish</button>
                                            </form>
                                        </li>
                                    @endif
                                    @if(\Auth::user()->role == 7)
                                        <li>
                                            <form action="{{ route('group.destroy', ['id' => $data->id]) }}" method="post">
                                                {{ csrf_field() }}
                                                {{ method_field('delete') }}
                                                <button class="btn btn-danger btn-icon-fixed deleteData form-control" style="text-align: left;border: none;">&nbsp;<span class="icon-trash" style="margin-left: 15px;"></span>Guruhni O'chirish</button>
                                            </form>
                                        </li>
                                    @endif
                                </ul>
                            </div>

                        </div>
                        <div class="col-md-12">
    <a type="button" href="{{ route('monitoring.show',['id'=>$data->id]) }}" class="btn btn-info  btn-lg " value="Excelga export qilish  " style="">Monitoring</a>
    <a type="button" href="{{ route('mark.show',['id'=>$data->id]) }}" class="btn btn-danger  btn-lg " value="Excelga export qilish  " style="">Baholash</a>

    <a type="button" href="{{ route('timetables.result',['id'=>$data->id]) }}" class="btn btn-warning    btn-lg " value="Excelga export qilish  " style="">Dars jadvali</a>
        <a type="button" href="../test/reg/{{ $data->id }}" class="btn btn-success   btn-lg " value="Excelga export qilish  " style="">Testga ruxsat</a>

                                    </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
            </div>
        </div>
        <!-- END NEW DEPOSITS -->
        <!-- DEPOSITS -->
        <div class="block block-condensed">
            <div class="app-heading app-heading-small">
                <div class="title">
                    <h2>Guruh o'quvchilari</h2>
                    <p>O'quvchini qo'shish yoki o'chirish o'ng tomonda amalga oshiriladi</p>
                </div>
                <div class="heading-elements">
                </div>
            </div>

            <div class="block-content">
                <table class="table table-bordered table-striped margin-bottom-10">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th >FIO</th>
                         <th >Tug`ilgan yili</th>
                        <th >Yashash manzili</th>
                        <th >Pasport seriya va raqami</th>
                        <th >Telefon</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>@php $i=1; @endphp
                    @foreach($data->students as $student)
                        <tr>
                            <td>{{ $i }}</td>
                            <td>{{ $student->student->fio() }}</td>

                            <td  style="text-align: center">{{ $student->student->birth_date }} </td>
                            <td  style="text-align: center">{{ $student->student->home_address   }} </td>
                           <td  style="">{{ $student->student->passport_serial }} {{ $student->student->passport_number }}</td>
                            <td>{{ $student->student->phone1 }}@php $i++; @endphp</td>
                            <td>
                                <a href="{{ route('payment.show', ['id' => $student->student->id]) }}" class="btn btn-default btn-icon">
                                    <i class="fa fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>

    </div>
    <div class="modal fade" id="group-permission" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <div class="modal-body">

                    <div class="app-heading app-heading-small app-heading-condensed margin-bottom-10">
                        <div class="title">
                            <h5 style="text-align: center;">Guruhga ruxsat berish</h5>
                        </div>
                    </div>
                    <form method="post" action="{{ route('permissions.store') }}" id="group-permission-form">
                        {{ csrf_field() }}
                        <input type="hidden" value="{{ $data->id }}" name="group_id">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Ushbu sanadan
                                    @if($errors->has('from_date'))
                                        <span class="text-danger"> | {{ $errors->first('from_date') }}</span>
                                    @endif
                                </label>
                                <div class="input-group bs-datepicker">
                                    <input type="text" class="form-control"  name="from_date" id="from_date" value="{{ old('from_date') }}">
                                    <span class="input-group-addon">
                                      <span class="icon-calendar-full"></span>
                                </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Ushbu sanagacha
                                    @if($errors->has('to_date'))
                                        <span class="text-danger"> | {{ $errors->first('to_date') }}</span>
                                    @endif
                                </label>
                                <div class="input-group bs-datepicker">
                                    <input type="text" class="form-control"  name="to_date" id="to_date" value="{{ old('to_date') }}">
                                    <span class="input-group-addon">
                                      <span class="icon-calendar-full"></span>
                                </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Monitoring</label>
                                <br>
                                <label class="switch switch-md">
                                    <input type="checkbox" name="monitoring" checked id="status">
                                </label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Baholash</label>
                                <br>
                                <label class="switch switch-md">
                                    <input type="checkbox" name="marking" checked id="status">
                                </label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>To'lov kiritish</label>
                                <br>
                                <label class="switch switch-md">
                                    <input type="checkbox" name="payment" checked id="status">
                                </label>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-link" data-dismiss="modal">Yopish</button>
                    <button type="button" onclick="$('#group-permission-form').submit()" class="btn btn-default"><span class="icon-checkmark-circle"></span>Saqlash</button>
                </div>
            </div>
        </div>
    </div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script >

        function bustan(){

            var s = 0;
            var t = 0;
        var tt = $("tbody.bodyy tr");
            for(var i = 1; i <= tt.length; i++){
                var tr = $("#tr"+i).find(".centerr");
                if($("#tr"+i).find(".leftt").is(':checked')){
                    var tr = $("#tr"+i).find(".centerr");
                    var f = $("#tr"+i).find(".rightt");
                    var foiz = parseInt(f.val());
                    var price = parseInt(tr.text());
                    var summa = price*foiz/100;
                    s=s+summa;
                }
            }
            var sum = $(".summa");
            sum.html(s);
        }



        $(document).ready(function() {
            $(".leftt").change(function(){
                bustan();
            });
        $(".rightt").change(function(){
            bustan();
        });
            var s = 0;
            var t = 0;
        var tt = $("tbody.bodyy tr");
            for(var i = 1; i <= tt.length; i++){
                var tr = $("#tr"+i).find(".centerr");
                if($("#tr"+i).find(".leftt").is(':checked')){
                    var tr = $("#tr"+i).find(".centerr");
                    var f = $("#tr"+i).find(".rightt");
                    var foiz = parseInt(f.val());
                    var price = parseInt(tr.text());
                    var summa = price*foiz/100;
                    s=s+summa;
                }
            }
            var sum = $(".summa");
            sum.html(s);


        });
</script>

@endsection
