@extends('layouts.admin')

@section('content')
    <<h1>dsadsadss</h1>
@endsection