@extends('layouts.admin')

@section('content')

@php $i =1 @endphp

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('group.index') }}">Guruhlar</a></li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>

    <div class="block" style="background: whitesmoke">

        <div class="c">

            <form method="post" action="/backoffice/group/search" name="group-search-form">

                {{ csrf_field() }}

                <div class="col-md-8 col-lg-8" style="padding: 0px;">

                    <div class="col-md-4" style="padding: 2px;margin: 0px;">

                        <div class="input-group">

                            <div class="input-group-addon">

                                <span class="fa fa-calendar"></span>

                            </div>

                            <input type="text" name="daterange" class="form-control daterange">

                        </div>

                    </div>

                    <div class="col-lg-4" style="padding: 2px;margin: 0px;">

                            <select class="bs-select student_id"  id="teacher_id" data-live-search="true" data-dependent="teacher_id" name="teacher_id">

                                <option selected style="display: none;opacity: 0.7" value="">#Asosiy o'qituvchi</option>

                                @foreach($teachers as $teacher)

                                    <option value="{{ $teacher->id }}" @if(old('teacher_id')==$teacher->id) selected @endif>{{ $teacher->full_name }}</option>

                                @endforeach

                            </select>

                    </div>

                    <div class="col-lg-4" style="padding: 2px;margin: 0px;">

                            <select class="bs-select assistant_id"  id="assistant_id" data-live-search="true" data-dependent="assistant_id" name="assistant_id">

                                <option selected style="opacity: 0.7;display: none;" value="">@Yordamchi o'qituvchi</option>

                                @foreach($teachers as $teacher)

                                    <option value="{{ $teacher->id }}" @if(old('assistant_id')==$teacher->id) selected @endif>{{ $teacher->full_name }}</option>

                                @endforeach

                            </select>

                    </div>

                </div>

                <div class="col-md-4" style="padding-right: 0px;">

                    <div class="form-group" style="padding: 2px;margin: 0px;">

                        <div class="input-group">

                            <input type="text" class="form-control text-bold" name="keyword" placeholder="Qidirish...">

                            <div class="input-group-btn">

                                <button class="btn btn-default btn-icon dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="icon-cog"></span></button>

                                <ul class="dropdown-menu dropdown-left" >
                                   <li>
                                        <a href="#">

                                            <div class="app-checkbox"><label><input type="checkbox" name="ac-1" checked> Guruh nomi bo'yicha (UZ)<span></span></label></div>

                                        </a>

                                    </li>

                                    <li>

                                        <a href="#">

                                            <div class="app-checkbox"><label><input type="checkbox" name="ac-2" checked=""> Guruh nomi bo'yicha (Ru)<span></span></label></div>

                                        </a>

                                    </li>

                                    <li class="divider"></li>

                                    <li>

                                        <a href="#">

                                            <div class="app-checkbox"><label><input type="checkbox" name="ac-4"> Arxivdan qidirish<span></span></label></div>

                                        </a>

                                    </li>

                                </ul>

                                <button type="submit" class="btn btn-default">Qidirish</button>

                            </div>

                        </div>

                    </div>

            </div>

            </form>

            <p class="help-block margin-left-20">

                @if(session('message'))

                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                        <div class="alert-icon">

                            <span class="icon-checkmark-circle"></span>

                        </div>

                        {{ session('message') }}

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                    </div>

                @endif

                <a href="{{ route('group.create') }}" class="pull-right btn btn-success margin-right-15" style="margin: 0;"><span class="icon-plus-circle"></span>Guruh yaratish</a>

            </p>

        </div>

    </div>

   <!--  <div class="container">

        <div class="row grid" style="position: relative;">

       

            @foreach($data as $group)

            <div class="col-md-3 col-ms-4 grid-element " >

                <a href="{{ route('group.show',['id'=>$group->id]) }}">

                    <div class="tile-basic">

                        <span style="color: blue" class="tile-image tile-image-padding tile-image-hover-grayscale preview" data-preview-image="assets/images/large/img-1.jpg" data-preview-size="modal-lg">

                            <h1 style="text-align: center">{{ $group->name_uz }}</h1>

                        </span>

                        <div class="tile-content tile-content-condensed-bottom text-center">

                            <span class="tile-subtitle" style="color:black;opacity: 0.7">#

                                {{ $group->teacher->full_name }}</span>

                            @if($group->assistant_id != null)

                            <span class="tile-subtitle" style="color:black;opacity: 0.7">

                                {{ '@'.$group->assistant->full_name }}</span>

                            @endif

                            <h3 class="tile-title" style="color:blue;">{{ $group->getCourseName() }}</h3>

                        </div>

                    </div>

                </a>

            </div>

            

            @endforeach

        </div>



    </div> -->

    <div class="block block-condensed">

                <br>

                <div class="block-content">
         

            <table class="table table-striped table-bordered datatable-extended">

                        <thead>

                        <tr>

                                <th># </th>

                             <!--    <th>Yaratilgan yili</th> -->

                                <th>Guruh nomi</th>

                    

                                <th>Guruh toifasi</th>

                                <th>Asosiy o`qituvchi</th>

                        <!--         <th>Yordamchi o`qituvchi</th> -->

                                <th>Ta`lim boshlanish vaqti</th>

                                <th>Ta`lim tugash vaqti</th>

                                <th>Holati</th>

                                <th  width="5%">Ko`rish</th>
                                <th  width="5%">Shaxsiy varaqa</th>
                                <th  width="5%">Gaiga Ariza</th>
                            </tr>

                            </thead>

                            <tbody>

                            @foreach($data as $group)

                               <tr>

                              

                                    <td>{{$i}}</td>

                                  <!--   <td>{{mb_substr(($group->edu_starting_date), 0,4)}}</td> -->

                                    <td>{{$group->name_uz}}</td>

                                    <td>{{$group->getCourseName() }}</td>

                                    <td>{{$group->teacher->full_name }}</td>



                                   <!--  <td> @if($group->assistant_id != null)

                            <span class="tile-subtitle" style="color:black;opacity: 0.7">

                                {{ $group->assistant->full_name }}</span>

                            @endif</td> -->

                            <td>{{$group->edu_starting_date}}</td>

                            <td>{{$group->edu_ending_date}}</td>

                            <td> @if($group->status == 1)

                            <span class="tile-subtitle" style="color:black;opacity: 0.7">

                                Aktiv</span>

                            @endif

                                @if($group->status != 1)

                            <span class="tile-subtitle" style="color:black;opacity: 0.7">

                                Aktiv emas</span>

                            @endif

                        </td>

                                    <td>

                                        <a href="{{ route('group.show', ['id' => $group->id]) }}"  class="btn btn-default btn-icon">

                                            <i class="icon-eye  "></i>

                                        </a>

                                    </td>

                                     <td>
                                     	 	 @if($group->status == 1 || $group->status == 2)
                                        <a href="{{'print/harakatprint'}}/{{$group->id}}" target="blank" class="btn btn-default btn-icon">
                                            <i class="icon-printer"></i>
                                        </a>
                                            @endif
                                    </td>

                                         <td>
                                          	 	 @if($group->status == 1 || $group->status == 2)
                                        <a href="{{'print/gaiindex'}}/{{$group->id}}" target="blank" class="btn btn-default btn-icon">
                                            <i class="fa fa-file-pdf-o"></i>
                                        </a>
                                         @endif
                                    </td>

                                </tr>

                                

                                @php $i++ @endphp

                            @endforeach

                            </tbody>

                                                        



                        </table>

                      

                    </div>



                </div>



     

        </div>

@endsection