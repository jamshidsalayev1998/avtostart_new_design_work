@extends('layouts.admin')



@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="/backoffice/group/">Barcha guruhlar</a></li>

            <li class="active">Guruh ma'lumotlarini o'zgartirish</li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>

    <div class="container">



        <div class="row">

            <div class="col-md-12">

                <div class="app-heading-container app-heading-bordered bottom" style="border-radius: 5px;">

                    @if(session('error'))

                        <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">

                            <div class="alert-icon">

                                <span class="icon-warning"></span>

                            </div>

                            {{ session('error') }}

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                        </div>

                    @endif

                </div>

            </div>

            <form action="{{ route('group.update',['id'=>$data->id]) }}" method="post">

                {{ csrf_field() }}

                {{ method_field('put') }}

                <div class="col-md-6">

                    <div class="block">

                        <button class="btn btn-success btn-block" type="submit">Saqlash</button>



                        <div class="form-group margin-top-20">

                            <label>Asosiy o'qituvchi

                                @if($errors->has('teacher_id'))

                                    <span class="text-danger"> | {{ $errors->first('teacher_id') }}</span>

                                @endif

                            </label>

                            <select class="bs-select student_id"  id="teacher_id" data-live-search="true" data-dependent="student_id" name="teacher_id">

                                <option></option>

                                @foreach($teachers as $teacher)

                                    <option value="{{ $teacher->id }}"  @if($teacher->id == $data->teacher_id) selected @endif @if(old('teacher_id')==$teacher->id) selected @endif>{{ $teacher->full_name }}</option>

                                @endforeach

                            </select>

                        </div>

                           <div class="form-group" style="width: 49%; margin-right: 1%;">
                   
                            <label>Yordamchi o'qituvchi

                                @if($errors->has('assistant_id'))

                                    <span class="text-danger"> | {{ $errors->first('assistant_id') }}</span>

                                @endif

                            </label>

                            <select class="bs-select assistant_id"  id="assistant_id" data-live-search="true" data-dependent="assistant_id" name="assistant_id">

                                <option></option>

                                @foreach($teachers as $teacher)

                                    <option value="{{ $teacher->id }}" @if($teacher->id == $data->assistant_id) selected @endif @if(old('assistant_id')==$teacher->id) selected @endif>{{ $teacher->full_name }}</option>

                                @endforeach

                            </select>

                        </div>
                           <div class="form-group" style="width: 50%;">
                      

                            <label>Tibbiyot o'qituvchi

                                @if($errors->has('med_teacher_id'))

                                    <span class="text-danger"> | {{ $errors->first('med_teacher_id') }}</span>

                                @endif

                            </label>

                            <select class="bs-select assistant_id"  id="med_teacher_id" data-live-search="true" data-dependent="assistant_id" name="med_teacher_id">

                                <option></option>

                                @foreach($teachers as $teacher)

                                    <option value="{{ $teacher->id }}" @if($teacher->id == $data->med_teacher_id) selected @endif @if(old('med_teacher_id')==$teacher->id) selected @endif>{{ $teacher->full_name }}</option>

                                @endforeach

                            </select>

                        </div>

                           <div class="form-group" style="width: 49%; margin-right: 1%;">

                        <label>Asosiy amaliy usta

                            @if($errors->has('master1_id'))

                            <span class="text-danger"> | {{ $errors->first('master1_id') }}</span>

                            @endif

                        </label>

                        <select class="bs-select assistant_id" id="master1_id" data-live-search="true" data-dependent="master1_id" name="master1_id">

                            <option></option>

                            @foreach($masters as $master)

                            <option value="{{ $master->id }}" @if($master->id == $data->master1_id) selected @endif>{{ $master->full_name }}</option>

                            @endforeach

                        </select>

                    </div>

                    <div class="form-group" style="width: 50%;">

                        <label>Yordamchi amaliy usta

                            @if($errors->has('master2_id'))

                            <span class="text-danger"> | {{ $errors->first('master2_id') }}</span>

                            @endif

                        </label>

                        <select class="bs-select med_teacher_id" id="master2_id" data-live-search="true" data-dependent="master2_id" name="master2_id">

                            <option></option>

                           @foreach($masters as $master)

                            <option value="{{ $master->id }}"  @if($master->id == $data->master2_id) selected @endif>{{ $master->full_name }}</option>

                            @endforeach

                        </select>

                    </div>

                        <div class="form-group" style="margin-top: 5px;">

                            <div class="col-md-6 padding-left-0">

                                <label>Ta'limning boshlanish sanasi

                                    @if($errors->has('edu_starting_date'))

                                        <span class="text-danger"> | {{ $errors->first('edu_starting_date') }}</span>

                                    @endif

                                </label>

                                <div class="input-group bs-datepicker">

                                    <input type="text" class="form-control"  name="edu_starting_date" id="edu_starting_date" value="<?php if(old('edu_starting_date')=="") echo date("d/m/Y",strtotime($data->edu_starting_date));  else echo old('edu_starting_date')?>">

                                    <span class="input-group-addon">

                                      <span class="icon-calendar-full"></span>

                                </span>

                                </div>

                            </div>

                            <div class="col-md-6 padding-right-0">

                                <label>Ta'limning yakunlanish sanasi

                                    @if($errors->has('edu_ending_date'))

                                        <span class="text-danger"> | {{ $errors->first('edu_ending_date') }}</span>

                                    @endif

                                </label>

                                <div class="input-group bs-datepicker">

                                    <input type="text" class="form-control"  name="edu_ending_date" id="edu_ending_date" value="<?php if(old('edu_ending_date')=="") echo date("d/m/Y",strtotime($data->edu_ending_date)); else echo old('edu_ending_date')?>">

                                    <span class="input-group-addon">

                                      <span class="icon-calendar-full"></span>

                                </span>

                                </div>

                            </div>

                        </div>

                   

                    </div>

                </div>

                <div class="col-md-6">

               

                    <div class="app-content-tabs" style="margin-top: 10px;">

                        <br>
                        <div class="form-group">

                            <label>Ta'lim yo'nalishi

                                @if($errors->has('edu_type'))

                                    <span class="text-danger"> | {{ $errors->first('edu_type') }}</span>

                                @endif

                            </label>

                            <select class="bs-select dynamic"  id="edu_type" data-live-search="true" data-dependent="edu_type" name="edu_type">

                                @foreach($courses as $course)

                                    <option value="{{ $course->id }}" @if($data->edu_type== $course->id) selected @endif>{{ $course->name }} toifali</option>

                                @endforeach

                            </select>

                        </div>
                         <div class="block1">

                            <label for="name_uz">Guruh nomlanishi

                                @if($errors->has('name_uz'))

                                    <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>

                                @endif

                            </label>

                            <input type="text" name="name_uz" id="name_uz" value="<?php if(old('name_uz')=="") echo $data->name_uz; else echo old('name_uz')?>" class="form-control" required>

                        </div>
                             <div class="form-group" style="margin-top: 10px;">

                            <label for="name_ru">Ta`lim narxi

                                @if($errors->has('tuition_fee'))

                                    <span class="text-danger"> | {{ $errors->first('tuition_fee') }}</span>

                                @endif

                            </label>

                            <input type="text" name="tuition_fee" id="tuition_fee" value="<?php if(old('tuition_fee')=="") echo $data->tuition_fee; else echo old('tuition_fee')?>" class="form-control" required>

                        </div>

                        <div class="form-group" style="margin-bottom: 30px;">

                            <label>Auditoriya

                                @if($errors->has('edu_type'))

                                    <span class="text-danger"> | {{ $errors->first('edu_type') }}</span>

                                @endif

                            </label>

                            <select class="bs-select dynamic"  id="edu_type" data-live-search="true" name="room_id">

                                <option style="display: none;" value="">Xonani tanlang</option>

                                @foreach($rooms as $room)

                                    <option value="{{ $room->id }}" @if($data->room_id == $room->id) selected @endif>{{ $room->name }}</option>

                                @endforeach

                            </select>

                        </div>

                    </div>

                </div>

            </form>

        </div>

    </div>

@endsection