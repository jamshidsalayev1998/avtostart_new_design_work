@extends('layouts.admin')



@section('content')

<div class="app-heading-container app-heading-bordered bottom">

    <ul class="breadcrumb">

        <li><a href="/backoffice">Dashboard</a></li>

        <li><a href="/backoffice/group">Barcha guruhlar</a></li>

        <li class="active">Yangi guruh yaratish</li>

    </ul>

    <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

</div>

<div class="container">

    <div class="row">

        <div class="col-md-12">

            <div class="app-heading-container app-heading-bordered bottom" style="border-radius: 5px;">

                <p><span class="fa fa-info"></span>&nbsp;Dastlab guruh yaratilgach unga toifa bo'yicha o'quvchilarni qo'shasiz!</p>


                @if(session('error'))

                <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">

                    <div class="alert-icon">

                        <span class="icon-warning"></span>

                    </div>

                    {{ session('error') }}

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                </div>

                @endif

            </div>

        </div>

        <form action="{{ route('group.store') }}" method="post">

            {{ csrf_field() }}



            <div class="col-md-6">

                <div class="block">

                    <button class="btn btn-success btn-block" type="submit">Saqlash</button>



                    <div class="form-group margin-top-20">

                        <label>Asosiy o'qituvchi

                            @if($errors->has('teacher_id'))

                            <span class="text-danger"> | {{ $errors->first('teacher_id') }}</span>

                            @endif

                        </label>

                        <select class="bs-select student_id" id="teacher_id" data-live-search="true" data-dependent="student_id" name="teacher_id">

                            <option></option>

                            @foreach($teachers as $teacher)
                            <?php $user=Test\User::find($teacher->user_id);?>
                            @if(!empty($user))
                            <?php if($user->status!=0):?>
                       
                            <option value="{{ $teacher->id }}" @if(old('teacher_id')==$teacher->id) selected @endif>{{ $teacher->full_name }}</option>
                            <?php endif?>
                           @endif
                            @endforeach

                        </select>

                    </div>

                    <div class="form-group" style="width: 49%; margin-right: 1%;">

                        <label>Yordamchi o'qituvchi

                            @if($errors->has('assistant_id'))

                            <span class="text-danger"> | {{ $errors->first('assistant_id') }}</span>

                            @endif

                        </label>

                        <select class="bs-select assistant_id" id="assistant_id" data-live-search="true" data-dependent="assistant_id" name="assistant_id">

                            <option></option>
                            @foreach($teachers as $teacher)
                            <?php $user=Test\User::find($teacher->user_id);?>
                            @if(!empty($user))
                            <?php if($user->status!=0):?>
                           
                            <option value="{{ $teacher->id }}" @if(old('assistant_id')==$teacher->id) selected @endif>{{ $teacher->full_name }}</option>
                            <?php endif?>
                           @endif
                            @endforeach

                        </select>

                    </div>

                    <div class="form-group" style="width: 50%;">

                        <label>Tibbiyot o'qituvchi

                            @if($errors->has('med_teacher_id'))

                            <span class="text-danger"> | {{ $errors->first('med_teacher_id') }}</span>

                            @endif

                        </label>

                        <select class="bs-select med_teacher_id" id="med_teacher_id" data-live-search="true" data-dependent="med_teacher_id" name="med_teacher_id">

                            <option></option>

                            @foreach($teachers as $teacher)

                            <option value="{{ $teacher->id }}" @if(old('med_teacher_id')==$teacher->id) selected @endif>{{ $teacher->full_name }}</option>

                            @endforeach

                        </select>

                    </div>
                    
                     <div class="form-group" style="width: 49%; margin-right: 1%;">

                        <label>Asosiy amaliy usta

                            @if($errors->has('master1_id'))

                            <span class="text-danger"> | {{ $errors->first('master1_id') }}</span>

                            @endif

                        </label>

                        <select class="bs-select assistant_id" id="master1_id" data-live-search="true" data-dependent="master1_id" name="master1_id">

                            <option></option>

                            @foreach($masters as $master)

                            <option value="{{ $master->id }}" @if(old('master1_id')==$master->id) selected @endif>{{ $master->full_name }}</option>

                            @endforeach

                        </select>

                    </div>

                    <div class="form-group" style="width: 50%;">

                        <label>Yordamchi amaliy usta

                            @if($errors->has('master2_id'))

                            <span class="text-danger"> | {{ $errors->first('master2_id') }}</span>

                            @endif

                        </label>

                        <select class="bs-select med_teacher_id" id="master2_id" data-live-search="true" data-dependent="master2_id" name="master2_id">

                            <option></option>

                           @foreach($masters as $master)

                            <option value="{{ $master->id }}" @if(old('master2_id')==$master->id) selected @endif>{{ $master->full_name }}</option>

                            @endforeach

                        </select>

                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">

                            <label>Ta'limning boshlanish sanasi

                                @if($errors->has('edu_starting_date'))

                                <span class="text-danger"> | {{ $errors->first('edu_starting_date') }}</span>

                                @endif

                            </label>

                            <div class="input-group bs-datepicker">

                                <input type="text" class="form-control" name="edu_starting_date" id="edu_starting_date" value="{{ old('edu_starting_date') }}">

                                <span class="input-group-addon">

                                    <span class="icon-calendar-full"></span>

                                </span>

                            </div>

                        </div>
                    </div>
                    <div class="col-md-6">

                        <div class="form-group" style="margin-bottom: 5px;">

                            <label>Ta'limning yakunlanish sanasi

                                @if($errors->has('edu_ending_date'))

                                <span class="text-danger"> | {{ $errors->first('edu_ending_date') }}</span>

                                @endif

                            </label>

                            <div class="input-group bs-datepicker">

                                <input type="text" class="form-control" name="edu_ending_date" id="edu_ending_date" value="{{ old('edu_ending_date') }}">

                                <span class="input-group-addon">

                                    <span class="icon-calendar-full"></span>

                                </span>

                            </div>

                        </div>
                    </div>

                </div>

            </div>
            <br>
            <br>
            <br>

            <div class="col-md-6">





                <div class="app-content-tabs">

                    <div class="form-group" style="margin-bottom: 20px;">

                        <label>Ta'lim yo'nalishi

                            @if($errors->has('edu_type'))

                            <span class="text-danger"> | {{ $errors->first('edu_type') }}</span>

                            @endif

                        </label>

                        <select class="bs-select " data-branch_id="{{$branch_id}}" id="edu_type" data-live-search="true" data-dependent="edu_type" name="edu_type">

                            @foreach($courses as $course)

                            <option value="{{ $course->id }}" @if(old('edu_type')==$course->id) selected @endif>{{ $course->name }} toifali</option>

                            @endforeach

                        </select>



                        <br>
                        <br>




                        <div class=" app-content-tab active" id="uz">



                            <label for="name_uz">Guruh nomlanishi

                                @if($errors->has('name_uz'))

                                <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>

                                @endif

                            </label>

                            <input type="text" name="name_uz" id="name_uz" value="{{ $group_name }}" class="form-control" required>



                        </div>



                        <label style="    margin-top: 9px;" for="name_uz">Guruh ta`lim narxi

                            @if($errors->has('tuition_fee'))

                            <span class="text-danger"> | {{ $errors->first('tuition_fee') }}</span>

                            @endif

                        </label>

                        <input type="text" style="color: red;" value="" id="branch_price" name="tuition_fee" value="" class="form-control" required>

                    </div>




                    <div class="form-group margin-bottom-30">

                        <label>Auditoriya

                            @if($errors->has('room_id'))

                            <span class="text-danger"> | {{ $errors->first('room_id') }}</span>

                            @endif

                        </label>

                        <select class="bs-select " id="room_id" data-live-search="true" data-dependent="room_id" name="room_id" required>

                            <option></option>

                            @foreach($rooms as $room)

                            <option value="{{ $room->id }}">{{ $room->name }}</option>

                            @endforeach

                        </select>

                    </div>


                </div>

            </div>

        </form>

    </div>

</div>

@endsection