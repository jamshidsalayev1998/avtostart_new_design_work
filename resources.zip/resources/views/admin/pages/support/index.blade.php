@extends('layouts.admin')
@section('content')
    <!-- START PAGE HEADING -->
    <div class="app-heading app-heading-bordered app-heading-page">
        <div class="title">
            <h1>Chat</h1>
        </div>
        <!--<div class="heading-elements">
            <a href="#" class="btn btn-danger" id="page-like"><span class="app-spinner loading"></span> loading...</a>
            <a href="https://themeforest.net/item/boooya-revolution-admin-template/17227946?ref=aqvatarius&license=regular&open_purchase_for_item_id=17227946" class="btn btn-success btn-icon-fixed"><span class="icon-text">$24</span> Purchase</a>
        </div>-->
    </div>
    <!-- START PAGE SEPARATED CONTAINER -->
    <div class="app-content-separate app-content-separated-left">

        <div style="overflow-y: auto;max-height: 465px;margin-top: 16px;border-radius:3px;" class="app-content-separate-left scroll mCustomScrollbar _mCS_2 mCS-autoHide mCS_no_scrollbar" data-separate-control-height="true"><div id="mCSB_2" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" style="max-height: none;" tabindex="0"><div id="mCSB_2_container" class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" style="position:relative; top:0; left:0;" dir="ltr">
                    <div class="app-content-separate-panel visible-mobile">
                        <div class="pull-left">
                            <h4 class="text-sm text-uppercase text-bolder margin-bottom-0">Yozishmalar</h4>
                            <p class="subheader">Kontaktlar ro'yxati</p>
                        </div>
                        <button class="btn btn-default btn-icon pull-right" data-separate-toggle-panel=".app-content-separate-left"><span class="icon-users2"></span></button>
                    </div>
                    <div class="app-content-separate-content" id="active-contacts">
                        <div class="list-group list-group-adapt" id="contacts">
                            @foreach($contacts as $contact)
                                <div id="contact{{ $contact['id'] }}">
                                    <form method="post" action="{{ route('support.index') }}" id="form{{ $contact['id'] }}">
                                        {{ csrf_field() }}
                                        <input type="hidden" name="receiver_id" value="{{ $contact['id'] }}">
                                        <a onclick="$('#form{{ $contact['id'] }}').submit()" class="list-group-item @if($receiver_id == $contact['id']) active @endif">
                                            <div class="contact contact-rounded contact-bordered contact-lg status-online margin-bottom-0">
                                                <img src="{{ $contact['image'] }}" alt="" class="mCS_img_loaded">
                                                <div class="contact-container"> <strong>{{ $contact['name'] }}</strong>
                                                    <p>Hey. I am busy righ now, can you help me with...<span class="label label-danger pull-right">+24</span></p>

                                                </div>
                                            </div>
                                        </a>
                                    </form>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
        <div id="mCSB_2_scrollbar_vertical" class="mCSB_scrollTools mCSB_2_scrollbar mCS-light mCSB_scrollTools_vertical" style="display: none;">
            <div class="mCSB_draggerContainer"><div id="mCSB_2_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 30px; height: 0px; top: 0px;" oncontextmenu="return false;"><div class="mCSB_dragger_bar" style="line-height: 30px;"></div></div><div class="mCSB_draggerRail"></div></div></div></div>
        </div>
        <div class="app-content-separate-content">
            <!-- CONTENT CONTAINER -->
            <div class="container">

                <div class="block block-condensed">
                    <div class="app-heading app-heading-small margin-bottom-0">
                        <div class="title">
                            <div class="contact contact-rounded contact-bordered contact-lg margin-bottom-0">
                                <img @if($receiver->image  === null) src="/admin/img/user/no-image.png" @endif @if($receiver->image != null) src="{{ $receiver->image }}" @endif>
                                <div class="contact-container">
                                    <a href="#">{{ $receiver->name }}</a>
                                    <span></span>
                                </div>
                            </div>
                        </div>
                        <div class="heading-elements">
                            <div class="dropdown pull-right">
                                <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>
                                <ul class="dropdown-menu dropdown-left">
                                    <li><a href="#"><span class="icon-trash text-danger"></span>Yozishmalarni o'chirish</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="block-divider"></div>
                    <div class="block-content" style="overflow-y: auto;height: 240px;" id="messages-content">
                        <div class="messages" id="messages">

                        </div>
                    </div>
                </div>
                <div class="block block-condensed block-arrow-top">
                    <div class="block-content padding-top-15">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-btn">
                                    <button class="btn btn-default btn-icon"><span class="icon-picture"></span></button>
                                    <button class="btn btn-default btn-icon"><span class="icon-cloud-upload"></span></button>
                                </div>
                                <input type="text" class="form-control" name="message" data-receiver = {{ $receiver_id }} id="message" placeholder="Xabar...">
                                <div class="input-group-btn">
                                    <button class="btn btn-default send-message">Yuborish</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- CONTENT CONTAINER -->
        </div>

    </div>
    <!-- END PAGE SEPARATED CONTAINER -->
@endsection