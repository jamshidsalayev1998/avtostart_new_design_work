@extends('layouts.admin')

@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('teacher.index') }}">O'qituvchilar</a></li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>



    <div class="container">

        <div class="row" style="margin-right: 12px;margin-left: 12px;">

            <div class="panel panel-default">

                <div class="panel-heading">

                    <div class="col-md-11">

                        <h3 class="panel-title">Barcha o'qituvchilar ro'yxati</h3>

                        <a href="{{route('teacher.create')}}" class="btn btn-success pull-right"><i class="icon-plus-circle">&nbsp;</i>Yangi qo'shish</a>

                    </div>

                    <div class="col-md-1">

                        <div class="dropdown pull-right">

                            <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>

                            <ul class="dropdown-menu dropdown-left">

                                <li><a href="{{ route('timetables.index') }}" ><span class="fa fa-file-pdf-o text-danger">&nbsp;&nbsp;</span> PDF Export</a></li>

                                <li><a href="{{ route('export.teacherstoexcel') }}" ><span class="fa fa-file-excel-o text-success">&nbsp;&nbsp;</span> Excel Export</a></li>

                            </ul>

                        </div>

                    </div>

                    @if(session('message'))

                        <div class="col-md-12">

                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                <div class="alert-icon">

                                    <span class="icon-checkmark-circle"></span>

                                </div>

                                {{ session('message') }}

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                            </div>

                        </div>

                    @endif

                </div>

            </div>

            <div class="block block-condensed">

                <br>

                <div class="block-content">



                    <table class="table table-striped table-bordered datatable-extended">

                        <thead>

                        <tr>

                            <th>FIO</th>

                            @if(\Auth::user()->role==7) <th>Viloyati</th> @endif

                            @if(\Auth::user()->role==7 || \Auth::user()->role==6) <th>Tuman</th> @endif

                            <th>Login</th>

                          
                            <th>Kirgan vaqti(AIS)</th>
                            <th>Kirgan vaqti(STUDY)</th>

                            <th  width="5%"></th>

                            <th  width="5%"></th>

                            <th  width="5%"></th>

                        </tr>

                        </thead>

                        <tbody>

                        @foreach($data as $item)

                            <tr 
                            <?php $user=Test\User::find($item->user_id);?>
                            @if(!empty($user))
                            <?php if($user->status==0):?>
                            style="background-color: #ffb2b2;"
                           <?php endif?>
                           @endif
                            >

                                <td>{{$item->full_name}}</td>

                                @if(\Auth::user()->role==7) <td>{{ $item->getRegion() }}</td> @endif

                                @if(\Auth::user()->role==7 || \Auth::user()->role==6) <td>{{ $item->getArea() }}</td> @endif

                                <td>
                                    @if(empty($item->user->username))
                                           
                                    @endif
                                       @if(!empty($item->user->username))
                                            {{$item->user->username}}
                                    @endif

                                </td>

                              
                                <td>{{$item->last_seen}}</td>
                                <td>{{$item->last_seen_shablon}}</td>

                                <td>

                                    <a href="{{ route('teacher.show', ['id' => $item->id]) }}" class="btn btn-default btn-icon">

                                        <i class="fa fa-eye"></i>

                                    </a>

                                </td>

                                <td>

                                    <a href="{{ route('teacher.edit', ['id' => $item->id]) }}" class="btn btn-default btn-icon">

                                        <i class="icon-pencil"></i>

                                    </a>

                                </td>

                                <td>

                                    <form action="{{ route('teacher.destroy', ['id' => $item->id]) }}" method="post">

                                        {{ csrf_field() }}

                                        {{ method_field('delete') }}

                                        <button data-confirm="Agar siz o`chirish tugmasini bossangiz o`qituvchini holati passiv bo`ladi va u ais,study tizimlariga kirish huquqidan mahrum bo`ladi hamda guruh yaratish oynasida ushbu o`qituvchi ko`rinmaydi." class="btn btn-default btn-icon deleteData1"><i class="icon-trash"></i></button>

                                    </form>

                                </td>

                            </tr>

                        @endforeach

                        </tbody>

                    </table>



                </div>



            </div>

        </div>

    </div>

@endsection