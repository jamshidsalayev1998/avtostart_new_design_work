@extends('layouts.admin')

@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="#">Inspeksiyaga hisobot</a></li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>
        <div class="container">

            <div class="row" style="margin-right: 12px;margin-left: 12px;">

                <div class="panel panel-default">

                    <div class="panel-heading">
                        <div class="row">

                            <h5 class="col-md-6">
                                {{$branch->name_uz}} filiali hisobotlar tarixi.
                            </h5>

                            <h5 class="col-md-6">
                                @if(isset($branch->branchadmin->full_name))


                                 Filial raxbari {{$branch->branchadmin->full_name}}
                                 @endif
                            </h5>
                        </div>

                        @if(session('message'))

                            <div class="col-md-12">

                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('message') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                         @if(session('error'))

                            <div class="col-md-12">

                                <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-danger-circle"></span>

                                    </div>

                                    {{ session('error') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                    </div>

                </div>

                <div class="app-content-tabs col-md-10">
                                <ul>
                                    <li><a href="#t1" class="active"><span class="fa fa-ssticky-note"></span>Hisobotlar</a></li>
                                    <li><a href="#t2"><span class="fa fa-user"></span> O`quvchilar</a></li>
                                    <li><a href="#t3"><span class="fa fa-calculator"></span> O`qituvchilar</a></li>
                                    <li><a href="#t4"><span ></span> Kategoriyalar bo`yicha o`quvchilar</a></li>


                                </ul>

                            </div>

                <div class="app-content-tab active " id="t1">
                @foreach($data as $hisobot)

                    <div class="block block-condensed">

                        <br>



                        <div style="padding: 0px 5px 20px;">



                                <strong>
                                    {{$hisobot->hisobot_year}}-yil {{$hisobot->kvartal}}-chorak
                                </strong>

                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>
                                             Guruhlar soni
                                        </th>
                                        <th>
                                             Tugatgan guruhlar soni
                                        </th>
                                         <th>
                                            O`quvchilar
                                        </th>

                                        <th>
                                             Tugatgan o`quvchilar
                                        </th>
                                        <th>
                                            Chetlashtirilgan o`quvchilar
                                        </th>
                                    </tr>
                                </thead>

                                <tbody>

                                    <tr>

                                            <td>
                                                {{$hisobot->all_group_count}}
                                            </td>
                                            <td>
                                                {{$hisobot->ended_groups}}
                                            </td>
                                            <td>
                                                {{$hisobot->all_students_count}}
                                            </td>
                                            <td>
                                                {{$hisobot->all_ended_students}}
                                            </td>
                                            <td>
                                                {{$hisobot->returned_students_count}}
                                            </td>

                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                @endforeach
            </div>

            <div  class="app-content-tab  " id="t2">
                 <div class="block block-condensed">

                        <br>
                    <div style="padding: 0px 5px 20px;">
                        <div class="row">
                            <div class="col-md-3">
                                <select name="" class="form-control" id="yearr">
                                    <?php $datey = date('Y');
for ($i = 2019; $i <= $datey; $i++) {
	if ($i == $datey) {
		echo ' <option selected value="' . $i . '" selected>' . $i . '</option>';
	} else {
		echo ' <option value="' . $i . '" selected>' . $i . '</option>';
	}

}
?>


                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="" class="form-control" id="kvartall">
                                    <option selected value="4">4</option>
                                    <option value="3">3</option>

                                    <option value="2">2</option>

                                    <option value="1">1</option>
                                </select>

                            </div>
                            <div class="col-md-12 " style="margin-top: 15px;">
                                <table class="table  table-bordered">
                                    <thead>
                                        <tr>
                                            <th style="width: 5%;">#</th>
                                            <th>F.I</th>
                                            <th>Talim turi</th>
                                            <th>Ko`rish</th>

                                        </tr>
                                    </thead>
                                    <tbody id="tbtable"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

              <div  class="app-content-tab  " id="t3">
                 <div class="block block-condensed">

                        <br>
                    <div style="padding: 0px 5px 20px;">
                        <div class="row">
                            <div class="col-md-3">
                                <select name="" class="form-control" id="year_teacher">
                                    <?php $datey = date('Y');
for ($i = 2019; $i <= $datey; $i++) {
	if ($i == $datey) {
		echo ' <option selected value="' . $i . '" selected>' . $i . '</option>';
	} else {
		echo ' <option value="' . $i . '" selected>' . $i . '</option>';
	}

}
?>


                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="" class="form-control" id="kvartal_teacher">
                                    <option selected value="4">4</option>
                                    <option value="3">3</option>

                                    <option value="2">2</option>

                                    <option value="1">1</option>
                                </select>

                            </div>
                            <div class="col-md-12 " style="margin-top: 15px;">
                                <table class="table  table-bordered">
                                    <thead>
                                        <tr>
                                            <th style="width: 5%;">#</th>
                                            <th>F.I</th>
                                            <th>ta`lim   Turi</th>
                                            <th>Ko`rish</th>

                                        </tr>
                                    </thead>
                                    <tbody id="tbtable_teacher"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div  class="app-content-tab  " id="t4">
                 <div class="block block-condensed">

                        <br>
                    <div style="padding: 0px 5px 20px;">
                        <div class="row">
                            <div class="col-md-3">
                                <select name="" class="form-control" id="year_category">
                                    <?php $datey = date('Y');
for ($i = 2019; $i <= $datey; $i++) {
	if ($i == $datey) {
		echo ' <option selected value="' . $i . '" selected>' . $i . '</option>';
	} else {
		echo ' <option value="' . $i . '" selected>' . $i . '</option>';
	}

}
?>


                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="" class="form-control" id="kvartal_category">
                                    <option selected value="4">4</option>
                                    <option value="3">3</option>

                                    <option value="2">2</option>

                                    <option value="1">1</option>
                                </select>

                            </div>
                            <div class="col-md-12 " style="margin-top: 15px;">
                                <div id="list_category">
                                    <table class="table  table-bordered" >
                                        <thead>
                                            <tr>
                                                <th style="width: 5%;">#</th>
                                                <th>Talim turi</th>
                                                <th>O`quvchilar soni</th>
                                                <th>Ro`yhat</th>

                                            </tr>
                                        </thead>
                                        <tbody id="tbtable_category"></tbody>
                                    </table>
                                </div>
                                <div id="list_student" style="display: none;">
                                    <button onclick="show_category()" class="btn btn-default">Kategoriyalar</button>
                                    <table class="table table-bordered" style="margin-top: 15px;" >
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>F.I</th>
                                                <th>Ko`rish</th>
                                            </tr>
                                        </thead>
                                        <tbody id="body_list_student">

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>







            </div>

        </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script >
        function show_category(){
             $('#list_category').css({
                'display':'block'
            });
            $('#list_student').css({
                'display':'none'
            });
        }
        function list_student_category(type_id){
            $('#list_category').css({
                'display':'none'
            });
            $('#list_student').css({
                'display':'block'
            });
            if ($('#year_category').val() != '' && $('#kvartal_category').val() != '') {
                var _token = $('input[name="_token"]').val();
                var year = $('#year_category').val();
                var kvartal = $('#kvartal_category').val();
                var id = <?php echo ($branch->id); ?>;
                var url = '/backoffice/get_student_kvartal/' + year + '/' + kvartal + '/' + id;
                $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        _token: _token,
                    },
                    success: function(result) {
                        var students = JSON.parse(result);
                        var tr = '';
                        var  ii =1;
                        $.each(students, function(key, value) {
                            if (value['id_type'] == type_id) {
                                tr = tr + '<tr><td>'+ii+'</td><td>'+value['first_name']+value['last_name']+'</td><td><a href="/backoffice/student/'+value['id']+'" class="btn btn-default btn-icon"><span class="fa fa-eye"></span><a/></td></tr>';
                                ii++;
                            }

                        });
                        $('#body_list_student').html(tr);
                    }
                });
            }
        }
        function get_student_kvartal(){
              if ($('#yearr').val() != '' && $('#kvartall').val() != '') {
                var _token = $('input[name="_token"]').val();
                var year = $('#yearr').val();
                var kvartal = $('#kvartall').val();
                var id = <?php echo ($branch->id); ?>;
                var url = '/backoffice/get_student_kvartal/' + year + '/' + kvartal + '/' + id;
                $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        _token: _token,
                    },
                    success: function(result) {
                          var students = JSON.parse(result);
                        if (students == '') {
                             tr = '<tr><td >1</td><td >Bu kvartal uchun filial hisobot topshirmagan</td><td style="display: none"></td> <td style="display: none"></td></tr>';
                            $('#tbtable').html(tr);
                        }
                        else{


                            var tr = '';
                            var  ii =1;
                            $.each(students, function(key, value) {
                                tr = tr + '<tr><td>'+ii+'</td><td>'+value['first_name']+value['last_name']+'</td><td>'+value['name']+'</td><td><a href="/backoffice/student/'+value['id']+'" class="btn btn-default btn-icon"><span class="fa fa-eye"></span><a/></td></tr>';
                               ii++;
                            });
                            $('#tbtable').html(tr);
                        }

                    }
                });
            }
        }
        function get_student_category(){
             if ($('#kvartal_category').val() != '' && $('#year_category').val() != '') {
                var _token = $('input[name="_token"]').val();
                var year = $('#year_category').val();
                var kvartal = $('#kvartal_category').val();
                var id = <?php echo ($branch->id); ?>;
                var url = '/backoffice/get_student_category/' + year + '/' + kvartal + '/' + id;
                $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        _token: _token,
                    },
                    success: function(result) {
                        var students = JSON.parse(result);
                        var tr = '';
                        var  ii =1;
                        console.log(students);
                        $.each(students, function(key, value) {
                            tr = tr + '<tr><td>'+ii+'</td><td>'+value['name']+'</td><td>'+value['student']+'</td><td><button onclick="list_student_category('+value['id']+')" class="btn btn-default btn-icon"> <span class="fa fa-list"></span> </button></td></tr>';
                            ii++;
                        });
                        $('#tbtable_category').html(tr);

                    }
                });
            }
        }
        function get_teacher_kvartal(){
            if ($('#year_teacher').val() != '' && $('#kvartal_teacher').val() != '') {
                var _token = $('input[name="_token"]').val();
                var year = $('#year_teacher').val();
                var kvartal = $('#kvartal_teacher').val();
                var id = <?php echo ($branch->id); ?>;
                var url = '/backoffice/get_teacher_kvartal/' + year + '/' + kvartal + '/' + id;
                $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        _token: _token,
                    },
                    success: function(result) {
                        var students = JSON.parse(result);
                        var tr = '';
                        var  ii =1;
                        $.each(students, function(key, value) {
                            tr = tr + '<tr><td>'+ii+'</td><td>'+value['full_name']+'</td><td>'+value['driving_category']+'</td><td><a href="/backoffice/teacher/'+value['id']+'" class="btn btn-default btn-icon"><span class="fa fa-eye"></span></a></td></tr>';
                           ii++;
                        });
                        $('#tbtable_teacher').html(tr);
                    }
                });
            }
        }

        $(document).ready(function(){
            get_student_kvartal();
            get_teacher_kvartal();
            get_student_category();
        });
         $('#kvartall').change(function() {
           get_student_kvartal();
        });
          $('#kvartal_teacher').change(function() {
           get_teacher_kvartal();
        });
          $('#kvartal_category').change(function() {
           get_student_category();
        });
          $('#yearr').change(function() {
           get_student_kvartal();
        });
        $('#year_teacher').change(function() {
           get_teacher_kvartal();
        });
        $('#year_category').change(function() {
           get_student_category();
        });
    </script>




@endsection