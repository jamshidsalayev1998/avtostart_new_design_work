@extends('layouts.admin')

@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="#">Inspeksiyaga hisobot</a></li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>
        <div class="container">

            <div class="row" style="margin-right: 12px;margin-left: 12px;">

                <div class="panel panel-default">

                    <div class="panel-heading">

                        <div class="col-md-12">

                            <h3 class="panel-title">{{$kvartal}}-chorak uchun hisobot

                            </h3>

                        </div>
                        @if(session('message'))

                            <div class="col-md-12">

                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('message') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                         @if(session('error'))

                            <div class="col-md-12">

                                <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-danger-circle"></span>

                                    </div>

                                    {{ session('error') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                    </div>

                </div>


                <div class="block block-condensed">

                    <br>
                <form action="{{route('hisobot.store')}}" method="post">
                    {{csrf_field()}}
                    {{method_field('post')}}

                    <div class="block-content">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-6" style="padding: 0px 20px;">
                                @if(Auth::user()->role == 5 && $ruxsat == 1)
                                    <button type="submit" class="btn btn-success">Hisobotni saqlash</button>
                                    @else
                                    <strong>
                                        Hisobotni saqlash imkoniyati har bir chorak boshidan 10 kun mobaynida beriladi!
                                    </strong>
                                @endif


                            </div>
                        </div>

                        <div style="padding: 0px 5px;">
                            <table class="table table-bordered ">
                                <thead>
                                    <tr>
                                        <th>
                                            Guruhlar soni
                                        </th>
                                        <th>
                                            Tugatgan guruhlar soni
                                        </th>
                                        <th>
                                            O`quvchilar
                                        </th>

                                        <th>
                                            Tugatgan o`quvchilar
                                        </th>
                                        <th>
                                            Chetlashtirilgan o`quvchilar
                                        </th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>

                                            <input type="number" disabled="" name="groups" class="form-control " style="border:none;" value="{{$data->groups}}">
                                        </td>
                                        <td>

                                            <input type="number" disabled="" name="ended_groups" class="form-control" style="border:none;" value="{{$data->ended_groups}}">
                                        </td>

                                        <td>
                                            <input type="number" disabled="" name="students" class="form-control" style="border:none;" value="{{$data->students}}">
                                        </td>
                                        <td>
                                            <input type="number" disabled="" name="ended_students" class="form-control" style="border:none;" value="{{$data->ended_students}}">
                                        </td>
                                        <td>
                                            <input type="number" disabled="" name="returned_students" class="form-control" style="border:none;" value="{{$data->returned_students}}">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>



                    </div>
                </form>

                </div>



                @foreach($olddata as $data)


                    <div class="block block-condensed">
                        <br>



                        <div class="block-content">
                            <div class="row">
                                <div class="col-md-12">
                                    {{$data->hisobot_year}}-yil {{$data->kvartal}}-chorak uchun hisobot
                                </div>
                            </div>
                            <br>

                            <div class="row">
                                <table class="table table-bordered ">
                                    <thead>
                                        <tr>
                                            <th>
                                                Guruhlar soni
                                            </th>
                                            <th>
                                                Tugatgan guruhlar soni
                                            </th>

                                            <th>
                                                O`quvchilar soni
                                            </th>
                                            <th>
                                                Tugatgan o`quvchilar
                                            </th>
                                            <th>
                                                Chetlashtirilgan o`quvchilar
                                            </th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>

                                                {{$data->all_group_count}}
                                            </td>
                                            <td>

                                                {{$data->ended_groups}}
                                            </td>

                                            <td>
                                               {{$data->all_students_count}}
                                            </td>
                                            <td>
                                                {{$data->all_ended_students}}
                                            </td>
                                            <td>
                                                {{$data->returned_students_count}}
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>



                        </div>

                    </div>
                @endforeach




            </div>

        </div>


@endsection