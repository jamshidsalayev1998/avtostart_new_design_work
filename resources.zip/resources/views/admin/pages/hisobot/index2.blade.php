@extends('layouts.admin')

@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="#">Inspeksiyaga hisobot</a></li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>
    <form action="{{route('hisobot.store')}}" method="post">
        {{csrf_field()}}
        {{method_field('post')}}
        <div class="container">

            <div class="row" style="margin-right: 12px;margin-left: 12px;">

                <div class="panel panel-default">

                    <div class="panel-heading">

                        <div class="col-md-12">

                            <h3 class="panel-title">{{date('Y')}}-yil {{$kvartal}}-chorak uchun hisobot

                            </h3>

                        </div>
                        @if(session('message'))

                            <div class="col-md-12">

                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('message') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>



                                </div>

                            </div>

                        @endif

                    </div>

                </div>


                <div class="block block-condensed">

                    <br>

                    <div class="block-content">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-6">
                                 @if($ruxsat == 0)
                                    <button type="submit" class="btn btn-success">Hisobotni saqlash</button>
                                 @else
                                        <p>
                                            Har bir chorak oxirida 10 kun muddat mobaynida hisobotni saqlash tugmasi hosil bo`ladi
                                        </p>
                                @endif
                            </div>
                        </div>

                        <table class="table table-bordered mt-4">
                            <thead>
                                <tr>
                                    <th>
                                        #
                                    </th>
                                    <th>
                                        Guruhlar
                                    </th>
                                    <th>
                                        O`quvchilar
                                    </th>
                                    <th>
                                        Tugatganlar
                                    </th>
                                    <th>
                                        Chetlashtirilganlar
                                    </th>
                                    <th>
                                        To`langan pul
                                    </th>
                                    <th>
                                        Qaytarilgan pul
                                    </th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $r = 0;?>

                                @foreach($data as $item)
                                    <tr>
                                        <td>
                                            {{$r+1}}
                                        </td>
                                        <td>
                                            {{$item->name_uz}}
                                            <input type="number" name="input[{{$r}}][group]" value="{{$item->id}}" hidden>
                                        </td>
                                        <td>
                                            <input class=" umumiy form-control" style="border: none;" name="input[{{$r}}][student]"  type="number" value="{{$item->ts_count}}">

                                        </td>
                                        <td>
                                            <input class="tugatgan form-control" style="border: none;"  name="input[{{$r}}][end]" type="number" value="{{$item->tugatgan}}">

                                        </td>
                                        <td>
                                             <input class="chetlashgan form-control" style="border: none;" name="input[{{$r}}][return]"  type="number" value="{{$item->tr_count}}">

                                        </td>
                                        <td>
                                             <input class=" foyda form-control" style="border: none;" name="input[{{$r}}][amount]"  type="number" value="{{$item->amount}}">
                                        </td>
                                        <td>
                                            <input class="zdachi form-control" style="border: none;" name="input[{{$r}}][returned]"  type="number" value="{{$item->returned}}">
                                        </td>
                                    </tr>
                                    <?php $r++;?>
                                @endforeach
                                <tr>
                                    <td>
                                        Umumiy
                                    </td>
                                    <td >
                                        {{$r--}}
                                    </td>
                                    <td class="studentsf">

                                    </td>
                                    <td class="endedf">

                                    </td>
                                    <td class="returnedf">

                                    </td>
                                    <td class="amountf">

                                    </td>
                                    <td class="returned_amountf">

                                    </td>
                                </tr>


                            </tbody>
                        </table>

                    </div>



                </div>

                <div class="panel panel-default">

                    <div class="panel-heading">
                        Oldin saqlangan hisobotlar
                    </div>
                </div>
                <div class="block block-condensed">

                    <br>
                    @foreach($dataold as $data2)
                    <div class="block-content">
                        <p>{{date('Y' , strtotime($data2[0]->year))}}-yil  {{$data2[0]->kvartal}}-chorak hisoboti</p>
                        <br>
                        <table class="table table-bordered mt-4">
                            <thead>
                                <tr>
                                    <th>
                                        #
                                    </th>
                                    <th>
                                        Guruhlar
                                    </th>
                                    <th>
                                        O`quvchilar
                                    </th>
                                    <th>
                                        Tugatganlar
                                    </th>
                                    <th>
                                        Chetlashtirilganlar
                                    </th>
                                    <th>
                                        To`langan pul
                                    </th>
                                    <th>
                                        Qaytarilgan pul
                                    </th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $r = 0;?>

                                @foreach($data2 as $value)
                                    <tr>
                                        <td>
                                            {{$r+1}}
                                        </td>
                                        <td>
                                            {{$value->group->name_uz}}
                                        </td>
                                        <td>
                                            {{$value->students}}
                                        </td>
                                        <td>
                                            {{$value->ended_students}}
                                        </td>
                                        <td>
                                            {{$value->returned_students}}
                                        </td>
                                        <td>
                                            {{$value->amount_sum}}
                                        </td>
                                        <td>
                                            {{$value->returned_sum}}
                                        </td>
                                    </tr>
                                    <?php $r++;?>
                                @endforeach


                            </tbody>
                        </table>
                    </div>
                    @endforeach
                </div>

            </div>

        </div>
    </form>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script>
        $(window).click(function(e) {

                var sum1 = 0;
                $('.umumiy').each(function() {
                    sum1 += Number($(this).val());
                });
                var sum2 = 0;
                $('.tugatgan').each(function() {
                    sum2 += Number($(this).val());
                });
                var sum3 = 0;
                $('.chetlashgan').each(function() {
                    sum3 += Number($(this).val());
                });
                var sum4 = 0;
                $('.foyda').each(function() {
                    sum4 += Number($(this).val());
                });
                var sum5 = 0;
                $('.zdachi').each(function() {
                    sum5 += Number($(this).val());
                });

                var umumiy = $(".studentsf");
                umumiy.html(sum1);
                var tugatgan = $(".endedf");
                tugatgan.html(sum2);
                var chetlashgan = $(".returnedf");
                chetlashgan.html(sum3);
                var foyda = $(".amountf");
                foyda.html(sum4);
                var zdachi = $(".returned_amountf");
                zdachi.html(sum5);





        });

       $(document).ready(function() {

                var sum1 = 0;
                $('.umumiy').each(function() {
                    sum1 += Number($(this).val());
                });
                var sum2 = 0;
                $('.tugatgan').each(function() {
                    sum2 += Number($(this).val());
                });
                var sum3 = 0;
                $('.chetlashgan').each(function() {
                    sum3 += Number($(this).val());
                });
                var sum4 = 0;
                $('.foyda').each(function() {
                    sum4 += Number($(this).val());
                });
                var sum5 = 0;
                $('.zdachi').each(function() {
                    sum5 += Number($(this).val());
                });

                var umumiy = $(".studentsf");
                umumiy.html(sum1);
                var tugatgan = $(".endedf");
                tugatgan.html(sum2);
                var chetlashgan = $(".returnedf");
                chetlashgan.html(sum3);
                var foyda = $(".amountf");
                foyda.html(sum4);
                var zdachi = $(".returned_amountf");
                zdachi.html(sum5);

       });
    </script>

@endsection