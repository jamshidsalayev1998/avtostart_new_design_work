@extends('layouts.admin')

@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="#">Inspeksiyaga hisobot</a></li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>
        <div class="container">

            <div class="row" style="margin-right: 12px;margin-left: 12px;">

                <div class="panel panel-default">

                    <div class="panel-heading">


                        <form action="{{route('hisobot.sort')}}" method="post">
                            {{csrf_field()}}
                            {{method_field('post')}}
                            <div class="row">

                                <div class="col-md-3">
                                    <select class="form-control year" name="year">
                                        <?php for ($i = 2019; $i <= date('Y'); $i++) {
	if ($yil == $i) {
		echo "<option selected value='" . $i . "'>" . $i . "</option>";
	} else {
		echo "<option value='" . $i . "'>" . $i . "</option>";
	}
}?>

                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-control kvartal" name="kvartal">
                                        <option value="1" @if($kvartal == 1) selected @else @endif>1</option>
                                        <option value="2" @if($kvartal == 2) selected @else @endif>2</option>
                                        <option value="3" @if($kvartal == 3) selected @else @endif>3</option>
                                        <option value="4" @if($kvartal == 4) selected @else @endif>4</option>
                                    </select>
                                </div>

                                <button class="btn btn-success">OK</button>

                            </div>
                        </form>

                        @if(session('message'))

                            <div class="col-md-12">

                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('message') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                         @if(session('error'))

                            <div class="col-md-12">

                                <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-danger-circle"></span>

                                    </div>

                                    {{ session('error') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                    </div>

                </div>


                <div class="block block-condensed">

                    <br>
                    <div style="padding: 0px 5px 20px;">
                        <table class="table table-bordered datatable-extended">
                            <thead>
                                <tr>
                                    <th>
                                        #
                                    </th>
                                    <th>
                                        Viloyat
                                    </th>
                                    <th>
                                        Filiallar
                                    </th>
                                    <th>
                                        Hisobot topshirgan
                                    </th>
                                    <th>
                                        Hisobot topshirmagan
                                    </th>


                                </tr>
                            </thead>

                            <tbody id="thisobot">
                                 <?php $r = 1;?>

                                @foreach($data as $item)
                                <tr>

                                        <td>
                                            {{$r}}
                                        </td>
                                        <td>
                                            <a href="{{route('sort_branch' , ['year' => $yil , 'kvartal' => $kvartal , 'id' => $item->id , ])}}">
                                                {{$item->name_uz}}
                                            </a>
                                        </td>
                                        <td>
                                            {{$item->filials}}
                                        </td>
                                        <td>
                                            {{$item->hisobot_qilgan}}
                                        </td>
                                        <td>
                                            {{$item->hisobot_qilmagan}}
                                        </td>

                                </tr>
                                <?php $r++;?>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

        </div>




@endsection