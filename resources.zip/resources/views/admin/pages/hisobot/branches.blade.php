@extends('layouts.admin')

@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="#">Inspeksiyaga hisobot</a></li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>
        <div class="container">

            <div class="row" style="margin-right: 12px;margin-left: 12px;">

                <div class="panel panel-default">

                    <div class="panel-heading">


                        @if(session('message'))

                            <div class="col-md-12">

                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('message') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                         @if(session('error'))

                            <div class="col-md-12">

                                <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-danger-circle"></span>

                                    </div>

                                    {{ session('error') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                    </div>

                </div>


                <div class="block block-condensed">

                    <br>
                    <div style="padding: 0px 5px 20px;">
                        <table class="table table-bordered datatable-extended">
                            <thead>
                                <tr>
                                    <th>
                                        #
                                    </th>
                                    <th>
                                        Filiallar
                                    </th>
                                    <th>
                                         Guruhlar soni
                                    </th>
                                    <th>
                                         Tugatgan guruhlar soni
                                    </th>
                                     <th>
                                        O`quvchilar
                                    </th>

                                    <th>
                                         Tugatgan o`quvchilar
                                    </th>
                                    <th>
                                        Chetlashtirilgan o`quvchilar
                                    </th>

                                </tr>
                            </thead>

                            <tbody >
                                <?php $r = 1;?>
                                @foreach($data as $item)
                                <tr>

                                        <td class="no-sort">
                                            {{$r}}
                                        </td>
                                        <td>
                                            <a href="{{route('hisobot.newshow' , ['cc' => 'hisobot' , 'id' => $item->id])}}">
                                                {{$item->name_uz}}
                                            </a>
                                        </td>
                                        <?php $hisobot = 'Test\Model\Hisobot'::where('branch_id', $item->id)->where('hisobot_year', $yil)->first();?>

                                        @if(isset($hisobot))
                                            <td class="no-sort">
                                                {{$hisobot->all_group_count}}
                                            </td>
                                            <td class="no-sort">
                                                {{$hisobot->ended_groups}}
                                            </td>
                                            <td  class="no-sort">
                                                 {{$hisobot->all_students_count}}
                                            </td >
                                            <td class="no-sort">
                                                {{$hisobot->all_ended_students}}
                                            </td>
                                            <td class="no-sort">
                                                {{$hisobot->returned_students_count}}
                                            </td>
                                            @else

                                            <td colspan="5" class="text-center no-sort">
                                                <p style="color: red;">
                                                    Bu filial {{$yil}}-yil {{$kvartal}}-chorak uchun hisobot qilmagan
                                                </p>
                                            </td>
                                            <td style="display: none;"></td>
                                            <td style="display: none;"></td>
                                            <td style="display: none;"></td>
                                            <td style="display: none;"></td>
                                        @endif


                                </tr>
                                <?php $r++;?>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>




@endsection