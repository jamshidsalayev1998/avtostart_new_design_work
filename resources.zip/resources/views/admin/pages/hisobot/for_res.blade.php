@extends('layouts.admin')

@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="#">Inspeksiyaga hisobot</a></li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>
        <div class="container">

            <div class="row" style="margin-right: 12px;margin-left: 12px;">

                <div class="panel panel-default">

                    <div class="panel-heading">

                        {{$yil}}-yil {{$kvartal}}-chorak


                        @if(session('message'))

                            <div class="col-md-12">

                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('message') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                         @if(session('error'))

                            <div class="col-md-12">

                                <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-danger-circle"></span>

                                    </div>

                                    {{ session('error') }}

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            </div>

                        @endif

                    </div>

                </div>


                <div class="block block-condensed">

                    <br>
                    <div style="padding: 0px 5px 20px;">
                        <table class="table table-bordered datatable-extended">
                            <thead>
                                <tr>
                                    <th>
                                        #
                                    </th>
                                    <th>
                                        Viloyat
                                    </th>
                                    <th>
                                        Filiallar
                                    </th>
                                    <th>
                                        Hisobot topshirgan
                                    </th>
                                    <th>
                                        Hisobot topshirmagan
                                    </th>


                                </tr>
                            </thead>

                            <tbody>
                                <?php $r = 1;?>
                                @foreach($data as $item)
                                <tr>

                                        <td>
                                            {{$r}}
                                        </td>
                                        <td>
                                            <a href="{{route('hisobot.newshow' , ['cc' => 'branch' , 'id' => $item->id])}}">
                                                {{$item->name_uz}}
                                            </a>
                                        </td>
                                        <td>
                                            {{$item->filials}}
                                        </td>
                                        <td>
                                            {{$item->hisobot_qilgan}}
                                        </td>
                                        <td>
                                            {{$item->hisobot_qilmagan}}
                                        </td>

                                </tr>
                                <?php $r++;?>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                </div>







            </div>

        </div>


@endsection