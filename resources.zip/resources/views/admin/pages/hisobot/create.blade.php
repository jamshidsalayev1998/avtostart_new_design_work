@extends('layouts.admin')

@section('content')

<div class="app-heading-container app-heading-bordered bottom">

    <ul class="breadcrumb">

        <li><a href="/backoffice">Dashboard</a></li>

        <li><a href="{{ route('master.index') }}">Amaliy ustalar</a></li>

        <li class="active">Yangi amaliy usta qo'shish</li>

    </ul>

    <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

</div>

<div class="container">



    <form action="{{ route('master.store') }}" method="post" class="has-validation-callback">

        {{ csrf_field() }}



        <div class="block block-condensed">

            <div class="block-content">



                <div class="wizard show-submit">

                    <ul>

                        <li>

                            <a href="#step-7">

                                <span class="stepNumber">1</span>

                                <span class="stepDesc">Amaliy usta<br /><small>Shaxsiy ma'lumotlarni kiritish</small></span>

                            </a>

                        </li>



                    </ul>



                    <div id="step-7">



                        <div class="row">

                            <div class="col-md-6">



                                <!-- LENGTH EXAMPLE -->

                                <div class="block">

                                    <div class="form-group">

                                        <label>Amaliy usta FIO

                                            @if($errors->has('full_name'))

                                            <span class="text-danger"> | {{ $errors->first('full_name') }}</span>

                                            @endif

                                        </label>

                                        <input class="form-control" placeholder="FIO" value="{{ old('full_name') }}" id="full_name" name="full_name">

                                    </div>


                                    <div class="form-group">

                                        <label>Ma`lumoti

                                            @if($errors->has('info'))

                                            <span class="text-danger"> | {{ $errors->first('info') }}</span>

                                            @endif

                                        </label>

                                        <select required="" class="bs-select dynamic" id="nationality" data-live-search="true" data-dependent="nationality" name="info">
                                            <?php $i = 1;  ?>
                                            @foreach($info as $country)

                                            <option value="{{$info[$i]}}"> {{$info[$i]}}</option>
                                            <?php $i++;  ?>
                                            @endforeach

                                        </select>

                                    </div>

                                    <div class="form-group">

                                        <label>O`qitish huquqi berilgan guvohnoma seriyasi

                                            @if($errors->has('writing'))

                                            <span class="text-danger"> | {{ $errors->first('writing') }}</span>

                                            @endif

                                        </label>

                                        <input class="form-control" maxlength="9" required="" placeholder="AA1234567" value="{{old('passport_info')}}" name="writing" id="writing">



                                    </div>
                                    <div class="form-group">

                                        <label>Haydovchilik toifalari

                                            @if($errors->has('driving_category'))

                                            <span class="text-danger"> | {{ $errors->first('driving_category') }}</span>

                                            @endif

                                        </label>

                                        <input type="text" required="" class=" form-control" value="" placeholder="Masalan: А,В,С,D,ВЕ,СЕ,DЕ" name="driving_category" id="phone1" maxlength="16">



                                    </div>

                                </div>

                                <!-- END LENGTH EXAMPLE -->



                            </div>

                            <div class="col-md-6">



                                <!-- NUMBER EXAMPLE -->

                                <div class="block">
                                    <div class="form-group">

                                        <label>Tamomlagan OTM nomi

                                            @if($errors->has('finish_university'))

                                            <span class="text-danger"> | {{ $errors->first('finish_university') }}</span>

                                            @endif

                                        </label>

                                        <input class="form-control" placeholder="Tamomlagan OTM nomi" name="finish_university" value="{{old('address')}}" id="finish_university" required="">

                                    </div>

                                    <div class="form-group">

                                        <label>Haydovchilik guvohnomasi seriya raqami

                                            @if($errors->has('driving_number'))

                                            <span class="text-danger"> | {{ $errors->first('driving_number') }}</span>

                                            @endif

                                        </label>

                                        <input class="form-control" maxlength="10" required="" placeholder="AAA1234567" value="{{old('passport_info')}}" name="driving_number" id="driving_number">



                                    </div>

                                    <div class="row" style="margin-bottom: 15px;">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Guvohnoma olgan sanasi

                                                    @if($errors->has('driving_date'))

                                                    <span class="text-danger"> | {{ $errors->first('driving_date') }}</span>

                                                    @endif

                                                </label>

                                                <div class="input-group bs-datepicker">

                                                    <input type="text" class="form-control" required="" name="driving_date" id="driving_date" value="{{ old('driving_date') }}">

                                                    <span class="input-group-addon">

                                                        <span class="icon-calendar-full"></span>

                                                    </span>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group">

                                        <label>Guvohnoma kim tomonidan berilgan

                                            @if($errors->has('driving_who'))

                                            <span class="text-danger"> | {{ $errors->first('driving_who') }}</span>

                                            @endif

                                        </label>

                                        <input required="" class="form-control" placeholder="Guvohnoma kim tomonidan berilgan" name="driving_who" value="{{old('address')}}" id="driving_who">

                                    </div>

                                </div>

                                <!-- END NUMBER EXAMPLE -->

                            </div>

                        </div>



                    </div>





                </div>

            </div>

        </div>



    </form>

</div>

@endsection