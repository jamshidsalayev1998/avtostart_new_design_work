@extends('layouts.admin_alisher')
@section('content')

                <div class="title-link">
                        <div>
                            <h1>Moderatorlar</h1>
                            <p><span class="head-link-href">Bosh sahifa</span> / Moderatorlar</p>
                        </div>
                        
                    </div>
                    <div class="table-toifa-CE">
                        <div class="h1-button">
                            <h1>Moderatorlar ro’yxati</h1>
                            <button id="href_button" data-href="{{ route('moderator.create') }}" class="add-fan">
                                <p> Qo'shish</p>
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M7 1.16667V12.8333" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M1.16602 7H12.8327" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                            </button>
                        </div>
                        <div class="table-content">
                    <table class="">
                        <thead>
                        <tr>
                            <th><p>FIO </p></th>
                            @if(\Auth::user()->role==7) <th><p>Viloyati </p></th> @endif
                            @if(\Auth::user()->role==7 || \Auth::user()->role==6) <th><p>Tuman </p></th> @endif
                            <th>Login</th>
                            <th><p>Kirgan vaqti </p></th>
                            <th  width="5%"><p> </p></th>
                            <th  width="5%"><p> </p></th>
                            <th  width="5%"><p> </p></th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $item)
                            <tr>
                                <td><p>{{$item->full_name}} </p></td>
                                @if(\Auth::user()->role==7) <td><p>{{ $item->getRegion() }} </p></td> @endif
                                @if(\Auth::user()->role==7 || \Auth::user()->role==6) <td><p>{{ $item->getArea() }} </p></td> @endif
                                <td><p>{{$item->user->username}} </p></td>
                                 <td><p>{{$item->last_seen}} </p></td>
                                <td><p>
                                    <a href="{{ route('moderator.show', ['id' => $item->id]) }}" class="btn btn-default btn-icon">
                                        <i class="fa fa-eye"></i>
                                    </a> </p>
                                </td>
                                <td><p>
                                    <a href="{{ route('moderator.edit', ['id' => $item->id]) }}" class="btn btn-default btn-icon">
                                        <i class="fa fa-edit"></i>
                                    </a> </p>
                                </td>
                                <td><p>
                                    <form action="{{ route('moderator.destroy', ['id' => $item->id]) }}" method="post">
                                        {{ csrf_field() }}
                                        {{ method_field('delete') }}
                                        <button class="btn btn-default btn-icon deleteData"><i class="fa fa-trash"></i></button>
                                    </form> </p>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>

                </div>

            </div>
        
@endsection