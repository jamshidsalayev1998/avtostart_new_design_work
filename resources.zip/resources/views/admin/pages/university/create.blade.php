@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <form action="{{ route('university.store') }}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}

            <div class="col-md-6">
                <div class="block">
                    <button class="btn btn-success btn-block">Saqlash</button>

                    <label for="country_id" class="margin-top-20 control-label">
                        Joylashuv hududi
                        @if($errors->has('country_id'))
                            <span class="text-danger"> | {{ $errors->first('country_id') }}</span>
                        @endif
                    </label>
                    <select name="country_id" id="country_id" class="form-control" required>
                        @foreach($countries as $country)
                            <option value="{{ $country->id }}">{{ $country->name_uz }}</option>
                        @endforeach
                    </select>

                    <label for="image" class="margin-top-20 control-label">
                        Oliygoh surati
                        @if($errors->has('image'))
                        <span class="text-danger"> | {{ $errors->first('image') }}</span>
                        @endif
                    </label>
                    <input type="file" name="image" id="image" class="dropify" required>

                    <label for="phone" class="margin-top-20">Telefon raqami</label>
                    <input type="tel" name="phone" id="phone" value="{{ old('phone') }}" class="form-control">

                    <label for="dormitory" class="margin-top-20">
                        Yotoqxona
                        @if($errors->has('dormitory'))
                            <span class="text-danger"> | {{ $errors->first('dormitory') }}</span>
                        @endif
                    </label>
                    <br>
                    <div class="app-radio success inline">
                        <label><input type="radio" name="dormitory" value="0"> Mavjud<span></span></label>
                    </div>
                    <div class="app-radio warning inline">
                        <label><input type="radio" name="dormitory" value="1" checked=""> Mavjud emas<span></span></label>
                    </div>

                </div>
            </div>
            <div class="col-md-6">
                <div class="app-content-tabs">
                    <ul>
                        <li><a href="#uz" class="active"><span class="fa fa-globe"></span>O'zbek tili</a></li>
                        <li><a href="#ru"><span class="fa fa-globe"></span> Rus tili</a></li>
                    </ul>
                </div>

                <div class="container app-content-tab active" id="uz">
                    <div class="block">
                        <label for="name_uz">O'quv yurti nomi
                            @if($errors->has('name_uz'))
                                <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                            @endif
                        </label>
                        <input type="text" name="name_uz" id="name_uz" class="form-control" required>

                        <label for="address_uz" class="margin-top-20">O'quv yurti manzili
                            @if($errors->has('address_uz'))
                                <span class="text-danger"> | {{ $errors->first('address_uz') }}</span>
                            @endif
                        </label>
                        <input type="text" name="address_uz" id="address_uz" class="form-control" required>
                    </div>
                </div>

                <div class="container app-content-tab" id="ru">
                    <div class="block">
                        <label for="name_ru">O'quv yurti nomi
                            @if($errors->has('name_ru'))
                                <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                            @endif
                        </label>
                        <input type="text" name="name_ru" id="name_ru" class="form-control" required>

                        <label for="address_ru" class="margin-top-20">O'quv yurti manzili
                            @if($errors->has('address_ru'))
                                <span class="text-danger"> | {{ $errors->first('address_ru') }}</span>
                            @endif
                        </label>
                        <input type="text" name="address_ru" id="address_ru" class="form-control" required>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="block">

                    <label for="middle_ball">O'rtacha o'tish bali</label>
                    <input type="number" step="any" name="middle_ball" id="middle_ball" class="form-control">

                    <label for="middle_ball_grant" class="margin-top-20">O'rtacha o'tish bali (Byudjet)</label>
                    <input type="number" step="any" name="middle_ball_grant" id="middle_ball_grant" class="form-control">

                    <label for="number_people_per_seat" class="margin-top-20">Har bir o'rindagi o'rtacha kishilar soni:</label>
                    <input type="number" step="any" name="number_people_per_seat" id="number_people_per_seat" class="form-control">
                    
                </div>
            </div>

            </form>
        </div>
    </div>
@endsection