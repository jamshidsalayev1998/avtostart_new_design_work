@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Oliy o'quv yurtlari ro'yxati</h3>
                    </div>
                    <div class="panel-body">
                        @if(session('message'))
                        <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                            <div class="alert-icon">
                                <span class="icon-checkmark-circle"></span>
                            </div>
                            {{ session('message') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                        </div>
                        @endif
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="width: 2%">#</th>
                                <th>Surati</th>
                                <th>Nomi</th>
                                <th>Shahar</th>
                                <th>Telefon raqami</th>
                                <th>Manzili</th>
                                <th colspan="2" width="5%"></th>
                            </tr>
                            </thead>
                            <tbody>

                            @php $count = $data->perPage() * ($data->currentPage() - 1) @endphp
                            @foreach($data as $univer)
                            <tr>
                                <td>{{ ++$count }}</td>
                                <td class="text-center">
                                    <img src="{{ asset($univer->image) }}" width="150" height="70" alt="">
                                </td>
                                <td>{{ $univer->name_uz }}</td>
                                <td>
                                    {{ \Test\Model\Country::find($univer->country_id)->name_uz }}
                                </td>
                                <td>
                                    @if($univer->phone != null)
                                        {{ $univer->phone }}
                                    @else
                                        Raqam ko'rsatilmagan
                                    @endif
                                </td>
                                <td>{{ strip_tags(substr($univer->address_uz, 0, 70)) }}</td>
                                <td>
                                    <a href="{{ route('university.edit', ['id' => $univer->id]) }}" class="btn btn-default btn-icon">
                                        <i class="icon-pencil"></i>
                                    </a>
                                </td>
                                <td>
                                    <form action="{{ route('university.destroy', ['id' => $univer->id]) }}" method="post">
                                        {{ csrf_field() }}
                                        {{ method_field('delete') }}
                                        <button class="btn btn-default btn-icon deleteData"><i class="icon-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {!! $data->links() !!}

                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection