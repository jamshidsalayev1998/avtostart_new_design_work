@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('courses.index') }}">Ta'lim turlari</a></li>
            <li class="active">{{ $data->name }}</li>
            <li class="active">O'zgartirish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <div class="block">
                    <form action="{{ route('courses.update',['id'=>$data->id]) }}" method="post" name="course-edit" id="course-edit">
                        <div class="col-md-6">
                            <button type="button" onclick="$('#course-edit').submit()" style="cursor: pointer" class="btn btn-success form-control">Saqlash</button>
                        </div>
                        <div class="col-md-6">
                            <a href="{{ url()->previous() }}" class="btn btn-warning form-control">Bekor qilish</a>
                        </div>
                        {{ csrf_field() }}
                        {{ method_field('put') }}
                        <div class="modal-body margin-top-20">
                            <div class="form-group">
                                <label for="name" class="control-label">Ta'lim turi
                                    @if($errors->has('name'))
                                        <span class="text-danger"> | {{ $errors->first('name') }}</span>
                                    @endif
                                </label>
                                <input type="text" name="name" class="form-control" value="<?php if(old('name')=="") echo $data->name; else echo old('name')?>">
                            </div>
                            <div class="form-group">
                                <div class="col-md-6">
                                    <div class="col-md-12">
                                        <label for="hours" class="control-label">Soatlar soni
                                            @if($errors->has('hours'))
                                                <span class="text-danger"> | {{ $errors->first('hours') }}</span>
                                            @endif
                                        </label>
                                    </div>
                                    <div class="col-md-9" style="padding-right: 0">
                                        <input type="text" name="hours" class="form-control" value="<?php if(old('hours')=="") echo $data->hours; else echo old('hours')?>">
                                    </div>
                                    <div class="col-md-3" style="padding: 0;margin-top: 10px;font-size: 16px;">&nbsp;SOAT</div>
                                </div>
                                <div class="col-md-6">
                                    <div class="col-md-12">
                                        <label for="price" class="control-label">To'lov miqdori
                                            @if($errors->has('price'))
                                                <span class="text-danger"> | {{ $errors->first('price') }}</span>
                                            @endif
                                        </label>
                                    </div>
                                    <div class="col-md-9" style="padding-right: 0">
                                        <input type="text" name="price" class="form-control" value="<?php if(old('price')=="") echo $data->price; else echo old('price')?>">
                                    </div>
                                    <div class="col-md-3" style="padding: 0;margin-top: 10px;font-size: 16px;">&nbsp;SO'M</div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
@endsection