@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('student.index') }}">Ta'lim turlari</a></li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">
                    <div class="panel-heading">Ta'lim turlari</div>
                    <div class="panel-body">
                        <div class="col-md-2">
                            <button data-toggle="modal" data-target="#modal-create" class="btn btn-default"><i class="icon-plus-circle">&nbsp;</i>Yangi qo'shish</button>
                        </div>

                        @if(session('message'))
                            <div class="col-md-10">
                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        @endif
                        @if(session('error'))
                            <div class="col-md-10">
                                <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('error') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>

                <div class="block">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th style="width: 2%">#</th>
                            <th>Ta'lim  turi</th>
                            <th>Soatlar soni</th>
                            <th>To'lov miqdori</th>
                            @if(\Auth::user()->role == 7)<th colspan="1" style="width: 8%"></th>@endif
                        </tr>
                        </thead>
                        <tbody>
                        @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp
                        @foreach($data as $item)
                            <tr>
                                <td>{{ ++$count }}</td>
                                <td>{{ $item->name }}</td>
                                <td>{{ $item->getHours() }}</td>
                                <td>{{ $item->price }}</td>
                                @if(\Auth::user()->role == 7)<td>
                                    <a href="{{ route('courses.edit', ['id' => $item->id]) }}" class="btn btn-sm btn-default btn-icon">
                                        <span class="icon-pencil"></span>
                                    </a>
                                </td>@endif
                            </tr>
                        @endforeach
                        </tbody>
                    </table>

                    {!! $data->links() !!}

                </div>

            </div>


        </div>
    </div>

    <div class="modal fade" id="modal-create" tabindex="-1" role="dialog" aria-labelledby="modal-default-header">
        <div class="modal-dialog" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modal-default-header">Ta'lim turini qo'shish</h4>
                </div>
                <form action="{{ route('courses.store') }}" method="post">
                    {{ csrf_field() }}
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name" class="control-label">Ta'lim turi
                                @if($errors->has('name'))
                                    <span class="text-danger"> | {{ $errors->first('name') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name" class="form-control" value="{{ old('name') }}">
                        </div>
                        <div class="form-group">
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <label for="hours" class="control-label">Soatlar soni
                                        @if($errors->has('hours'))
                                            <span class="text-danger"> | {{ $errors->first('hours') }}</span>
                                        @endif
                                    </label>
                                </div>
                                <div class="col-md-9" style="padding-right: 0">
                                    <input type="text" name="hours" class="form-control" value="{{ old('hours') }}">
                                </div>
                                <div class="col-md-3" style="padding: 0;margin-top: 10px;font-size: 16px;">&nbsp;SOAT</div>
                            </div>
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <label for="price" class="control-label">To'lov miqdori
                                        @if($errors->has('price'))
                                            <span class="text-danger"> | {{ $errors->first('price') }}</span>
                                        @endif
                                    </label>
                                </div>
                                <div class="col-md-9" style="padding-right: 0">
                                    <input type="text" name="price" class="form-control" value="{{ old('price') }}">
                                </div>
                                <div class="col-md-3" style="padding: 0;margin-top: 10px;font-size: 16px;">&nbsp;SO'M</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-link" data-dismiss="modal">Bekor qilish</button>
                        <button type="submit" class="btn btn-default">Qo'shish</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection