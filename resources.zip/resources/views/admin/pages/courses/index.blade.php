@extends('layouts.admin_alisher')

@section('content')
	<div class="left-content">
                <div class="title-link">
                    <div>
                        <h1>Ta’lim turlari</h1>
                        <p><span>Bosh sahifa /</span> Ta’lim turlari</p>
                    </div>
                    
                </div>
                <div class="table-toifa">
                    <h1>Ta’lim turlari ro’yxati</h1>
                    <div class="table-content-toifa">
                        <table>

                            <tr>
                                <th><p>#</p></th>
                                <th><p>Ta’lim turi</p></th>
                                <th><p>Soatlar soni</p></th>
                                <th colspan="2"><p>To’lov miqdori (So’m)</p></th>
                            </tr>
                             @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp
                            @foreach($data as $item)
                        	<tr>
                                <td><p>{{ ++$count }}</p></td>
                                <td><p>{{ $item->name }}</p></td>
                                <td><p>{{ $item->getHours() }}</p></td>
                                <td><p>{{ $item->price }}</p></td>
                                <td>
                                    <button data-url="{{ route('courses.update' , ['id' => $item->id]) }}" id="edit{{ $item->id }}" onclick="edit_course({{ $item->id }})" class="t-t-ozgartir-button">
                                        <img src="{{ asset('admin/style/images/icons/t-t-ozBlue.svg') }}" alt="AAA">
                                        <p>O’zgartirish</p>
                                    </button>
                                </td>
                            </tr>
                        	@endforeach
                            
                            
                        </table>
                    </div>
                </div>

            </div>
            <div class="talim-turi-change">
		        <form  method="post" id="change_course" >
                    {{ csrf_field() }}
                    {{ method_field('put') }}
		            <div class="m-m-qush-sarlavha">
		                <h1>Yangi toifa qo’shish</h1>
		                <button type="button" class="t-t-ozgar-close-button"><img src="{{ asset('admin/style/images/icons/closex.svg') }}" alt="AAA"></button>
		            </div>
		            <div class="talimturi-name">
		                <p>Ta’lim turi nomi</p>
		                <input class="t-t-text" type="text" id="name" name="name">
		            </div>
		            <div class="talim-items">
		                <div class="talimturi-item">
		                    <p>Soatlar soni (butun son)</p>
		                    <input class="t-t-text" type="text" id="hours" name="hours">
		                </div>
		                <div class="talimturi-item">
		                    <p>To’lov miqdori</p>
		                    <input class="t-t-text" type="text" id="price" name="price">
		                </div>
		            </div>
		            <div class="t-t-qosh-submit">
		                <button type="button" class="t-t-qosh-bekor-button">Bekor qilish</button>
		                <button  class="t-t-submit-button">Qo’shish</button>
		            </div>
		        </form>
		        <div class="t-t-close-div"></div>
		    </div>
@endsection

@section('js')
<script type="text/javascript">
    function edit_course(id){
        var action = $('#edit'+id+'').attr('data-url');
        console.log(action);
        $('#change_course').attr('action' , action);
        $.ajax({
            url: '/backoffice/get_course_for_edit/'+id,
            type: 'GET',
            data: {},
            success:function(result){
                course = JSON.parse(result);
                $('#change_course #name').val(course.name);
                $('#change_course #hours').val(course.hours);
                $('#change_course #price').val(course.price);
            }
        });
        
        
        
    }
</script>
@endsection