@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('group.index') }}">Barcha guruhlar</a></li>
            <li><a href="{{ route('group.show',['id'=>$data->id]) }}">{{ $data->name_uz }}</a></li>
            <li class="active">Dars jadvali</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        @if(session('error'))
            <p>
            <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">
                <div class="alert-icon">
                    <span class="icon-sad"></span>
                </div>
                {{ session('error') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
            </div>
            </p>
        @endif
        <div class="panel panel-success">
            <div class="panel-heading">
                {{ $data->name_uz }} guruh dars jadvali.
                <button class="btn btn-default btn-icon pull-right" data-toggle="modal" data-target="#modal-remove"><span class="icon-trash text-danger"></span></button>
                <button class="btn btn-default btn-icon pull-right" data-toggle="modal" data-target="#modal-add"><span class="icon-plus-circle"></span></button>
            </div>
            <div class="panel-body" >
                {!! $calendar_details->calendar() !!}
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-add" tabindex="-1" role="dialog" aria-labelledby="modal-large-header" >
        <div class="modal-dialog modal-lg" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <div class="modal-header bg-success">
                    <h4 class="modal-title" id="modal-large-header">Guruh dars jadvalini shakllantirish</h4>
                    <p>Fanni va dars vaqtini ko'rsatib <i>Saqlash</i> tugmasini bosing.</p>
                </div>
                <div class="modal-body">
                    <div class="block-content">
                        <form method="post" name="remove-member-form" id="remove-member-form" action="{{ route('schedule.store') }}">
                            {{ csrf_field() }}
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Fan:
                                        @if($errors->has('lesson_id'))
                                            <span class="text-danger"> | {{ $errors->first('lesson_id') }}</span>
                                        @endif
                                    </label>
                                    <select class="bs-select"  data-live-search="true" name="lesson_id" id="lesson_id">
                                        <option value="" selected style="display: none">Fanni tanlang</option>
                                        @foreach($lessons as $lesson)
                                            <option value="{{ $lesson->id }}" @if(old('lesson_id')==$lesson->id) selected @endif>{{ $lesson->name_uz }} </option>
                                        @endforeach
                                    </select>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Status:</label>
                                    <select class="form-control" name="status" id="status">
                                        <option value="1">Aktiv</option>
                                        <option value="0">Passiv</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6 margin-top-20">
                                <div class="form-group">
                                    <label>Kunni belgilang:
                                        @if($errors->has('day'))
                                            <span class="text-danger"> | {{ $errors->first('day') }}</span>
                                        @endif
                                    </label>
                                    <div class="input-group bs-datepicker">
                                        <input type="text" class="form-control" name="day" value="{{ old('day') }}">
                                        <span class="input-group-addon">
                                            <span class="icon-calendar-full"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 margin-top-20">
                                <label>Boshlanish vaqti:
                                    @if($errors->has('starting_time'))
                                        <span class="text-danger"> | {{ $errors->first('starting_time') }}</span>
                                    @endif
                                </label>
                                <div class="form-group">
                                    <input type="text" class="form-control bs-timepicker" name="starting_time" id="starting_time" value="{{ old('starting_time') }}">
                                </div>
                            </div>
                            <div class="col-md-3 margin-top-20">
                                <label>Tugash vaqti:
                                    @if($errors->has('ending_time'))
                                        <span class="text-danger"> | {{ $errors->first('ending_time') }}</span>
                                    @endif
                                </label>
                                <div class="form-group">
                                    <input type="text" class="form-control bs-timepicker" name="ending_time" value="{{ old('ending_time') }}">
                                </div>
                            </div>
                            <div class="col-md-12 margin-top-20" style="opacity: 0.8">
                                <div class="alert alert-default alert-icon-block dir-left">
                                    <strong>#{{ $data->teacher->full_name }}</strong> / {{ "@".$data->assistant->full_name }}
                                    <div class="alert-icon">
                                        <span class="fa fa-info"></span>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" value="{{ $data->id }}" name="group_id">
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link" data-dismiss="modal">Yopish</button>
                    <button type="button" onclick="$('#remove-member-form').submit()" class="btn btn-success"><span class="icon-plus"></span>Saqlash</button>
                </div>
            </div>
        </div>
    </div>
@endsection