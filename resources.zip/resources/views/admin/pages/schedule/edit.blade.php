@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('group.index') }}">Barcha guruhlar</a></li>
            <li><a href="{{ route('group.show',['id'=>$data->group->id]) }}">{{ $data->group->name_uz }}</a></li>
            <li><a href="{{ url()->previous() }}">Dars jadvali</a></li>
            <li class="active">{{ $data->lesson->name_uz }}</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="block">
            <div class="row">
                <div class="col-md-3">
                    <div class="app-heading app-heading-small app-heading-condensed-horizontal">
                        <div class="title">
                            <h5>Schedule</h5>
                            <p>Mashg'ulot haqida ma'lumot</p>
                        </div>
                    </div>

                    <div class="listing" style="text-align: right">
                        <div class="listing-item">Dars nomi:</div>
                        <div class="listing-item">Mashg'ulot kuni:</div>
                        <div class="listing-item">Mashg'ulot davomiyligi:</div>
                        <div class="listing-item">Ma'sul o'qituvchi:</div>
                        <div class="listing-item">Xona:</div>
                        <div class="listing-item">Davomat:</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="app-heading app-heading-small app-heading-condensed-horizontal">
                        <div class="title">
                            <div class="dropdown pull-right">
                                <button type="button" class="btn btn-default pull-right" data-toggle="dropdown">
                                    <span class="icon-cog" ></span>Tanlov
                                </button>
                                <ul class="dropdown-menu dropdown-right">
                                    <li class="bg-success"><a href="{{ route('schedule.edit',['id'=>$data->id]) }}" ><span class="icon-pencil"></span> O'zgartirish</a></li>
                                    <li><a href="{{ route('monitoring.show',['id'=>$data->group->id]) }}" ><span class="fa fa-times">&nbsp;</span> Davomat</a></li>
                                    <li>
                                        <form action="{{ route('schedule.destroy', ['id' => $data->id]) }}" method="post">
                                            {{ csrf_field() }}
                                            {{ method_field('delete') }}
                                            <button class="btn btn-default deleteData" style="border: none;width: 100%;text-align: left;color: red">
                                                <span class="icon-trash text-danger"></span>O'chirish
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="listing">
                        <div class="listing-item listing-item-with-icon">
                            <span class="icon-book listing-item-icon"></span>
                            {{ $data->lesson->name_uz }}
                        </div>
                        <div class="listing-item listing-item-with-icon">
                            <span class="icon-calendar-full listing-item-icon"></span>
                            {{ date("d-m-Y",strtotime($data->starting_date)) }}
                        </div>
                        <div class="listing-item listing-item-with-icon">
                            <span class="icon-clock listing-item-icon"></span>
                            {{ date("H:i",strtotime($data->starting_date)) }} <span class="icon-arrow-right"></span> {{ date("H:i",strtotime($data->ending_date)) }}
                        </div>
                        <div class="listing-item listing-item-with-icon">
                            <span class="icon-briefcase listing-item-icon"></span>
                            {{ $data->group->teacher->full_name }}
                        </div>
                        <div class="listing-item listing-item-with-icon">
                            <span class="icon-home listing-item-icon"></span>
                            {{ $data->group->room->name }}
                        </div>
                        <div class="listing-item listing-item-with-icon">
                            <span class="fa fa-times listing-item-icon"></span>
                            {{ $data->toShow() }}
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <form method="post" action="{{ route('schedule.update',['id'=>$data->id]) }}">
                        {{ csrf_field() }}
                        {{ method_field('put') }}
                        <input type="hidden" value="{{ $data->group_id }}" name="group_id">
                        <div class="app-heading app-heading-small app-heading-condensed-horizontal">
                            <button class="btn btn-success form-control">Saqlash</button>
                        </div>
                        <div class="listing">
                        <div class="listing-item listing-item-with-icon">
                            <div class="form-group">
                                <label>Kunni belgilang:
                                    @if($errors->has('day'))
                                        <span class="text-danger"> | {{ $errors->first('day') }}</span>
                                    @endif
                                </label>
                                <select class="form-control" name="lesson_id">
                                    @foreach($lessons as $lesson)
                                        <option value="{{ $lesson->id }}" @if($data->lesson_id == $lesson->id) selected @endif>{{ $lesson->name_uz }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="listing-item listing-item-with-icon">
                            <div class="form-group">
                                <label>Kunni belgilang:
                                    @if($errors->has('day'))
                                        <span class="text-danger"> | {{ $errors->first('day') }}</span>
                                    @endif
                                </label>
                                <div class="input-group bs-datepicker">
                                    <input type="text" class="form-control" name="day" value="<?php if(old('day')=="") echo date('d/m/Y',strtotime($data->starting_date)); else echo old('day')?>">
                                    <span class="input-group-addon">
                                            <span class="icon-calendar-full"></span>
                                        </span>
                                </div>
                                <div class="listing-item listing-item-with-icon">
                                    <div class="col-md-6 margin-top-20">
                                        <label>Boshlanish vaqti:
                                            @if($errors->has('starting_time'))
                                                <span class="text-danger"> | {{ $errors->first('starting_time') }}</span>
                                            @endif
                                        </label>
                                        <div class="form-group">
                                            <input type="text" class="form-control bs-timepicker" name="starting_time" value="{{ date('H:i',strtotime($data->starting_date)) }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 margin-top-20">
                                        <label>Tugash vaqti:
                                            @if($errors->has('ending_time'))
                                                <span class="text-danger"> | {{ $errors->first('ending_time') }}</span>
                                            @endif
                                        </label>
                                        <div class="form-group">
                                            <input type="text" class="form-control bs-timepicker" name="ending_time" value="{{ date('H:i',strtotime($data->ending_date)) }}">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection