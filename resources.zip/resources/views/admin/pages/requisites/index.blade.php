﻿@extends('layouts.admin')
@section('content')
<style>

</style>
<style media="print">
 @page  {
  size: auto;
  margin: 20px;
  
       }
      table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}


</style>
    <!-- START PAGE HEADING -->
    <div class="app-heading app-heading-bordered app-heading-page">
        <div class="title">
            <h1>Qo'shimcha</h1>
            <p>Joriy filial rekvizitlari</p>
        </div>
        <!--<div class="heading-elements">
            <a href="#" class="btn btn-danger" id="page-like"><span class="app-spinner loading"></span> loading...</a>
            <a href="https://themeforest.net/item/boooya-revolution-admin-template/17227946?ref=aqvatarius&license=regular&open_purchase_for_item_id=17227946" class="btn btn-success btn-icon-fixed"><span class="icon-text">$24</span> Purchase</a>
        </div>-->
    </div>
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Sozlamalar</a></li>
            <li class="active">Rekvizitlar</li>
        </ul>
        @if($data != null)
            <a href="{{ route('requisites.edit',['id'=>$data->branch_id]) }}" class="pull-right btn btn-info    btn-sm"><span class="fa fa-eye">&nbsp;</span>Ko`rish</a>
        @endif
    </div>
    <!-- END PAGE HEADING -->
    <form action="/backoffice/requisit/returned?filial_id={{ $branch->id }}"  id="payment-form" class="form-horizontal" enctype="multipart/form-data" name="student-form" id="student-form">
        <input type="hidden" name="filial_id" value="{{ $branch->id }}">
    </form>
    <!-- START PAGE CONTAINER -->
    <div class="container">
        @if(session('message'))
        <div class="col-md-10">
            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                <div class="alert-icon">
                    <span class="icon-checkmark-circle"></span>
                </div>
                {{ session('message') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
            </div>
        </div>
        @endif
        @if($data != null)
        <div class="invoice">
            <div class="invoice-container">
                <div class="row">

                    <div class="col-lg-5 col-lg-offset-2">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="invoice-company">
                                    <img src="{{ asset('/extra/logo2.jpg') }}" style="max-width: 130px;margin-top: -37px;height: auto" alt="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="invoice-number text-right">
                                    <h3>{{ $branch->name_uz }}</h3>
                                    <p>{{ $branch->branchadmin->full_name }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                         <div class="col-sm-2" style="float: left; padding: 15px;">
                        <button id="btnPrint" class="btn btn-success">Rekvizitni pdfda saqlash</button> 

                     </div>
                      <div class="col-sm-2  " style="    float: right;margin-right: 20px;padding: 5px;margin-top: 9px;">
                       
                                       <?php if($data->check_filial==0):?>
                    <button type="button" class="btn btn-warning form-control" data-toggle="modal" data-target="#myModal">Tasdiqlash</button>
                                    <?php endif?>
                                    <?php if($data->check_filial==1):?>
                    <button type="button" class="btn btn-warning form-control"  >Tasdiqlangan</button>
                                    <?php endif?>
                     </div>
                </div>
            </div>
            <div class="invoice-container invoice-container-highlight">
<h1 style="padding:20 px; text-align:center; color:red">2019 yil uchun barcha guruhlarni kitirishga dostup <strong>20.01.2020</strong> qaradar ochiq holatda bo`ladi undan kegin 2019 yil guruhlarini kiritishning imkoni to`liq yopiladi va qog`oz holatda topshirilgan hisobotlar bilan solishtiriladi.</h1>               
 <div class="row">
                    <div class="col-lg-5 col-lg-offset-1">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="invoice-address" style="padding: 0">
                                    <p>
 <?php $responsible = Test\Model\Bank::where('mfo', $data->mfo)->first(); ?>
                                        BANK NOMI:: {{ $responsible->bank_name }}<br>
                                        BANK MANZILI: {{ $responsible->bank_address }}<br>
                                        BANK HISOB RAQAMI: {{ $data->hr }}<br>
                                        Shartnoma RAQAMI:  {{ $data->shartnoma_number }}    &nbsp; ---   &nbsp;
                                        MFO:  {{ $responsible->mfo }}<br>
                                        INN:  {{ $data->inn }}
                           
                                    
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                     <div class="col-lg-5 ">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="invoice-address" style="padding: 0">
                                    <p>
 <?php $branch = Test\Model\Branch::where('id', $data->branch_id)->first(); ?>
   <?php $branch_admin = Test\Model\BranchAdmin::where('branch_id', $data->branch_id)->first(); ?>
                                       FILIAL NOMI: {{ $branch->name_uz }}<br>
                                        FILIAL DIREKTORI: {{ $branch_admin->full_name }}<br>
                                        FILIAL MANZILI: {{ $branch->address }}<br>
                                       Filial RAQAMI:  {{ $branch->phone }}<br>
                                                     OKONH:  {{ $data->okonh }}<br>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="invoice-container">
                <div class="row">

                </div>

            </div>
        </div>
        @endif
        @if($data === null && \Auth::user()->role == 5)
            <strong class="text-danger">Filial rekvizitlari hali kiritilmagan. &nbsp;<a class="btn btn-success" href="{{ route('requisites.create') }}"><span class="icon-plus-circle"></span>Rekvizitlarni kiritish</a></strong>
        @endif
    </div>
    <!-- END PAGE CONTAINER -->
@endsection

<div id="myModal" class="modal fade" role="dialog" style="display: none;">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title">To`lov qaytarish</h4>
      </div>
      <div class="modal-body">
        <p style="text-align: justify;">Saqlash tugmasini bosganingizda FIlialning barcha ma`lumotlari to`gri kiritilganini tasdiqlayotganinigizni yodda tuting!  Tizim boshqichma bosqish to`lov tizimlariga ulanilmoqda kegingi to`lov tizimiga ulanganda ushbu ma`lumotlarda xatolik mavjud bo`lmasligi lozim. 
Shuni e`tiborga olgan holda tugmani bosishingizni so`rab qolamiz.</p>
      </div>
      <div class="modal-footer">
      <button type="submit" onclick="$('#payment-form').submit()" class="btn btn-success form-control">Saqlash</button>
      </div>
    </div>

  </div>
</div>
 <script>
  
        var print = "<table style='width:100%;border: 1px solid; border-collapse: collapse;'><tr ><th  style='border: 1px solid; border-collapse: collapse;'colspan='6'>BANK MA`LUMOTLARI</th> </tr><tr><td  style='border: 1px solid; border-collapse: collapse;' colspan='1'><b>BANK NOMI:</b></td><td  style='border: 1px solid; border-collapse: collapse;' colspan='5'>{{ $responsible->bank_name }}</td> </tr><tr> <td  style='border: 1px solid; border-collapse: collapse;' colspan='1'><b>BANK MANZILI:</b></td> <td  style='border: 1px solid; border-collapse: collapse;' colspan='5'>{{ $responsible->bank_address }}</td></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>BANK HISOB RAQAMI:</b>    </td><td  style='border: 1px solid; border-collapse: collapse;'>{{ $data->hr }}</td>        <td  style='border: 1px solid; border-collapse: collapse;'><b>INN</b>   </td><td  style='border: 1px solid; border-collapse: collapse;'>{{$data->inn}}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>MFO</b>   </td><td  style='border: 1px solid; border-collapse: collapse;'>{{$data->mfo}}</td></tr><tr ><th colspan='6'><b>FILIAL MA`LUMOTLARI:</b></th></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>NOMI:</b>  </td><td colspan='2' style='border: 1px solid; border-collapse: collapse;'>{{ $branch->name_uz }}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>DIREKTORI:</b> </td><td  colspan='2'   style='border: 1px solid; border-collapse: collapse;'> {{ $branch_admin->full_name }}</td></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>MANZILI:</b>   </td><td  colspan='2'   style='border: 1px solid; border-collapse: collapse;'>{{ $branch->address }}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>RAQAMI:</b>    </td><td  colspan='2'  style='border: 1px solid; border-collapse: collapse;'>{{ $branch->phone }}</td></tr></table><br><hr style='border-top: 3px dashed red;margin-top:-5px;'><table style='width:100%;border: 1px solid; border-collapse: collapse;'><tr ><th  style='border: 1px solid; border-collapse: collapse;'colspan='6'>BANK MA`LUMOTLARI</th> </tr><tr><td  style='border: 1px solid; border-collapse: collapse;' colspan='1'><b>BANK NOMI:</b></td><td  style='border: 1px solid; border-collapse: collapse;' colspan='5'>{{ $responsible->bank_name }}</td> </tr><tr> <td  style='border: 1px solid; border-collapse: collapse;' colspan='1'><b>BANK MANZILI:</b></td> <td  style='border: 1px solid; border-collapse: collapse;' colspan='5'>{{ $responsible->bank_address }}</td></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>BANK HISOB RAQAMI:</b>    </td><td  style='border: 1px solid; border-collapse: collapse;'>{{ $data->hr }}</td>        <td  style='border: 1px solid; border-collapse: collapse;'><b>INN</b>   </td><td  style='border: 1px solid; border-collapse: collapse;'>{{$data->inn}}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>MFO</b>   </td><td  style='border: 1px solid; border-collapse: collapse;'>{{$data->mfo}}</td></tr><tr ><th colspan='6'><b>FILIAL MA`LUMOTLARI:</b></th></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>NOMI:</b>  </td><td colspan='2' style='border: 1px solid; border-collapse: collapse;'>{{ $branch->name_uz }}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>DIREKTORI:</b> </td><td  colspan='2'   style='border: 1px solid; border-collapse: collapse;'> {{ $branch_admin->full_name }}</td></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>MANZILI:</b>   </td><td  colspan='2'   style='border: 1px solid; border-collapse: collapse;'>{{ $branch->address }}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>RAQAMI:</b>    </td><td  colspan='2'  style='border: 1px solid; border-collapse: collapse;'>{{ $branch->phone }}</td></tr></table><br><hr style='border-top: 3px dashed red;margin-top:-5px;'><table style='width:100%;border: 1px solid; border-collapse: collapse;'><tr ><th  style='border: 1px solid; border-collapse: collapse;'colspan='6'>BANK MA`LUMOTLARI</th> </tr><tr><td  style='border: 1px solid; border-collapse: collapse;' colspan='1'><b>BANK NOMI:</b></td><td  style='border: 1px solid; border-collapse: collapse;' colspan='5'>{{ $responsible->bank_name }}</td> </tr><tr> <td  style='border: 1px solid; border-collapse: collapse;' colspan='1'><b>BANK MANZILI:</b></td> <td  style='border: 1px solid; border-collapse: collapse;' colspan='5'>{{ $responsible->bank_address }}</td></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>BANK HISOB RAQAMI:</b>    </td><td  style='border: 1px solid; border-collapse: collapse;'>{{ $data->hr }}</td>        <td  style='border: 1px solid; border-collapse: collapse;'><b>INN</b>   </td><td  style='border: 1px solid; border-collapse: collapse;'>{{$data->inn}}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>MFO</b>   </td><td  style='border: 1px solid; border-collapse: collapse;'>{{$data->mfo}}</td></tr><tr ><th colspan='6'><b>FILIAL MA`LUMOTLARI:</b></th></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>NOMI:</b>  </td><td colspan='2' style='border: 1px solid; border-collapse: collapse;'>{{ $branch->name_uz }}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>DIREKTORI:</b> </td><td  colspan='2'   style='border: 1px solid; border-collapse: collapse;'> {{ $branch_admin->full_name }}</td></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>MANZILI:</b>   </td><td  colspan='2'   style='border: 1px solid; border-collapse: collapse;'>{{ $branch->address }}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>RAQAMI:</b>    </td><td  colspan='2'  style='border: 1px solid; border-collapse: collapse;'>{{ $branch->phone }}</td></tr></table><br><hr style='border-top: 3px dashed red;margin-top:-5px;'><table style='width:100%;border: 1px solid; border-collapse: collapse;'><tr ><th  style='border: 1px solid; border-collapse: collapse;'colspan='6'>BANK MA`LUMOTLARI</th> </tr><tr><td  style='border: 1px solid; border-collapse: collapse;' colspan='1'><b>BANK NOMI:</b></td><td  style='border: 1px solid; border-collapse: collapse;' colspan='5'>{{ $responsible->bank_name }}</td> </tr><tr> <td  style='border: 1px solid; border-collapse: collapse;' colspan='1'><b>BANK MANZILI:</b></td> <td  style='border: 1px solid; border-collapse: collapse;' colspan='5'>{{ $responsible->bank_address }}</td></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>BANK HISOB RAQAMI:</b>    </td><td  style='border: 1px solid; border-collapse: collapse;'>{{ $data->hr }}</td>        <td  style='border: 1px solid; border-collapse: collapse;'><b>INN</b>   </td><td  style='border: 1px solid; border-collapse: collapse;'>{{$data->inn}}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>MFO</b>   </td><td  style='border: 1px solid; border-collapse: collapse;'>{{$data->mfo}}</td></tr><tr ><th colspan='6'><b>FILIAL MA`LUMOTLARI:</b></th></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>NOMI:</b>  </td><td colspan='2' style='border: 1px solid; border-collapse: collapse;'>{{ $branch->name_uz }}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>DIREKTORI:</b> </td><td  colspan='2'   style='border: 1px solid; border-collapse: collapse;'> {{ $branch_admin->full_name }}</td></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>MANZILI:</b>   </td><td  colspan='2'   style='border: 1px solid; border-collapse: collapse;'>{{ $branch->address }}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>RAQAMI:</b>    </td><td  colspan='2'  style='border: 1px solid; border-collapse: collapse;'>{{ $branch->phone }}</td></tr></table><br><hr style='border-top: 3px dashed red;margin-top:-5px;'><table style='width:100%;border: 1px solid; border-collapse: collapse;'><tr ><th  style='border: 1px solid; border-collapse: collapse;'colspan='6'>BANK MA`LUMOTLARI</th> </tr><tr><td  style='border: 1px solid; border-collapse: collapse;' colspan='1'><b>BANK NOMI:</b></td><td  style='border: 1px solid; border-collapse: collapse;' colspan='5'>{{ $responsible->bank_name }}</td> </tr><tr> <td  style='border: 1px solid; border-collapse: collapse;' colspan='1'><b>BANK MANZILI:</b></td> <td  style='border: 1px solid; border-collapse: collapse;' colspan='5'>{{ $responsible->bank_address }}</td></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>BANK HISOB RAQAMI:</b>    </td><td  style='border: 1px solid; border-collapse: collapse;'>{{ $data->hr }}</td>        <td  style='border: 1px solid; border-collapse: collapse;'><b>INN</b>   </td><td  style='border: 1px solid; border-collapse: collapse;'>{{$data->inn}}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>MFO</b>   </td><td  style='border: 1px solid; border-collapse: collapse;'>{{$data->mfo}}</td></tr><tr ><th colspan='6'><b>FILIAL MA`LUMOTLARI:</b></th></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>NOMI:</b>  </td><td colspan='2' style='border: 1px solid; border-collapse: collapse;'>{{ $branch->name_uz }}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>DIREKTORI:</b> </td><td  colspan='2'   style='border: 1px solid; border-collapse: collapse;'> {{ $branch_admin->full_name }}</td></tr><tr> <td  style='border: 1px solid; border-collapse: collapse;'><b>MANZILI:</b>   </td><td  colspan='2'   style='border: 1px solid; border-collapse: collapse;'>{{ $branch->address }}</td><td  style='border: 1px solid; border-collapse: collapse;'><b>RAQAMI:</b>    </td><td  colspan='2'  style='border: 1px solid; border-collapse: collapse;'>{{ $branch->phone }}</td></tr></table><br><hr style='border-top: 3px dashed red;margin-top:-5px;'>";
    </script>