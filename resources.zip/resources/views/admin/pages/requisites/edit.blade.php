@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="#">Qo'shimcha</a></li>
            <li class="active">Rekvisiztlarni kiritish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="row">
            <form action="{{ route('requisites.update',['id'=>$data->branch_id]) }}" method="post">
                {{ csrf_field() }}
                {{ method_field('put') }}
                <div class="col-md-6">
                    <div class="block">
                        <!-- <button class="btn btn-success btn-block" type="submit">Saqlash</button>
 -->    <div class="form-group" style="margin-bottom: 5px;">
                            <label>Bank nomi
                                @if($errors->has('bank_info'))
                                    <span class="text-danger"> | {{ $errors->first('bank_info') }}</span>
                                @endif
                            </label>
                             <?php $responsible = Test\Model\Bank::where('mfo', $data->mfo)->first(); ?>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="bank_info" id="bank_info" value="<?php if(old('bank_info')=="") echo  $responsible->bank_name; 
                                else echo old('bank_info')?>">
                            </div>
                        </div>
                           <div class="form-group" >
                            <label>Bank manzili
                                @if($errors->has('address'))
                                    <span class="text-danger"> | {{ $errors->first('address') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="address" id="address" value="<?php if(old('address')=="") echo $responsible->bank_address;
                                else echo old('address')?>">
                            </div>
                        </div>
                            <div class="form-group" style="margin-bottom: 5px;">
                            <label>Hisob raqami
                                @if($errors->has('hr'))
                                    <span class="text-danger"> | {{ $errors->first('hr') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="hr" id="hr" value="<?php if(old('hr')=="") echo $data->hr; else echo old('hr')?>">
                            </div>
                        </div>
                              <div class="col-md-6" style="padding-left: 0;padding-right: 15px;">
                        <div class="form-group margin-top">
                            <label>INN
                                @if($errors->has('inn'))
                                    <span class="text-danger"> | {{ $errors->first('inn') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="inn" id="inn" value="<?php if(old('inn')=="") echo $data->inn; else echo old('inn')?>">
                            </div>
                        </div>
                        </div>
                        <div class="col-md-6" style="padding-left: 0;padding-right: 0;">
                          <div class="form-group margin-top">
                            <label>MFO
                                @if($errors->has('mfo'))
                                    <span class="text-danger"> | {{ $errors->first('mfo') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="mfo" id="mfo" value="<?php if(old('mfo')=="") echo $data->mfo; else echo old('mfo')?>">
                            </div>
                        </div>
                        </div>
                     <div class="form-group" style="margin-bottom: 5px;">
                            <label>Shartnoma raqami
                                @if($errors->has('shartnoma_number'))
                                    <span class="text-danger"> | {{ $errors->first('shartnoma_number') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="shartnoma_number" id="shartnoma_number" value="<?php if(old('shartnoma_number')=="") echo $data->shartnoma_number; else echo old('shartnoma_number')?>">
                            </div>
                        </div>
                       <!--  <div class="form-group" style="margin-bottom: 5px;">
                            <label>OKONH
                                @if($errors->has('okonh'))
                                    <span class="text-danger"> | {{ $errors->first('okonh') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="okonh" id="okonh" value="<?php if(old('okonh')=="") echo $data->okonh; else echo old('okonh')?>">
                            </div>
                        </div> -->
                    
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="app-content-tabs"  >
                        <a href="{{ route('requisites.index') }}" class="btn btn-warning btn-block">Ortga</a>

                        <div class="form-group">
                            <label>Filial nomi
                                @if($errors->has('address'))
                                    <span class="text-danger"> | {{ $errors->first('address') }}</span>
                                @endif
                            </label>
                             <?php $branch = Test\Model\Branch::where('id', $data->branch_id)->first(); ?>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="address" id="address" value="<?php if(old('address')=="") echo $branch->name_uz;
                                else echo old('address')?>">
                            </div>
                        </div>
                         <div class="form-group">
                            <label>Filial direktori
                                @if($errors->has('address'))
                                    <span class="text-danger"> | {{ $errors->first('address') }}</span>
                                @endif
                            </label>
                             <?php $branch_admin = Test\Model\BranchAdmin::where('branch_id', $data->branch_id)->first(); ?>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="address" id="address" value="<?php if(old('address')=="") echo $branch_admin->full_name;
                                else echo old('address')?>">
                            </div>
                        </div>
                         <div class="form-group">
                            <label>Filial manzili
                                @if($errors->has('address'))
                                    <span class="text-danger"> | {{ $errors->first('address') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="address" id="address" value="<?php if(old('address')=="") echo $branch->address;
                                else echo old('address')?>">
                            </div>
                        </div>

                        <div class="form-group" style="margin-bottom: 30px;">
                            <label>Filial raqami
                                @if($errors->has('phone'))
                                    <span class="text-danger"> | {{ $errors->first('phone') }}</span>
                                @endif
                            </label>
                            <div class="input-group">
                                <input readonly="" type="text" class="form-control"  name="phone" id="phone" value="<?php if(old('phone')=="") echo $branch->phone; else echo old('phone')?>">
                            </div>
                        </div>
                     
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection