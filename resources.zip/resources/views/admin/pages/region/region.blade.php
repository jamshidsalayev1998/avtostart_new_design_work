@extends('layouts.admin_alisher')

@section('content')
                <div class="title-link">
                    <div>
                        <h1>Viloyatlar</h1>
                        <p><span>Bosh sahifa /</span> Viloyatlar</p>
                    </div>
                    
                </div>
                <div class="table-toifa-CE">
                    <div class="h1-button">

                    <h1>Viloyatlar ro’yxati</h1>
                    <button class="add-fan">
                            <p>Fan Qo'shish</p>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7 1.16667V12.8333" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M1.16602 7H12.8327" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>    
                        </button>
                    </div>
                    <div class="table-content-toifa">
                        <table >
                            <tr>
                                <th style="width: 2%"><p>ID </p></th>
                                <th><p>Viloyat </p></th>
                                <th><p>Filiallar </p></th>
                                <th><p>O'quvchilar </p></th>
                                <th><p>Xodimlar </p></th>
                                <th style="width: 8%"><p> </p></th>
                            </tr>
                            @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp
                            @foreach($data as $region)
                                <tr class="clickable-row hoverjon" title="Batafsil ko'rish uchun bosing" data-href = "{{ route('region.show',['id'=>$region->id]) }}" style="cursor: pointer">
                                    <td><p>{{ ++$count }} </p></td>
                                    <td><p>{{ $region->name_uz }} </p></td>
                                    <td><p>{{ count($region->branches) }} </p></td>
                                    <td><p>{{ $region->getAllStudentsCount() }} </p></td>
                                    <td><p>{{ $region->getStuffCount() }} </p></td>
                                    <td><p>
                                        <a href="{{ route('region.edit', ['id' => $region->id]) }}" class="btn btn-sm btn-default btn-icon">
                                            <span class="icon-pencil"></span>
                                        </a> </p>
                                    </td>
                                </tr>
                            @endforeach
                        </table>
                        {!! $data->links() !!}
                    </div>
                </div>

              {{--   </div>

            </div>


        </div>
    </div>

    <div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="modal-default-header">
        <div class="modal-dialog" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modal-default-header">Yangi shahar qo'shish</h4>
                </div>
                <form action="{{ route('region.store') }}" method="post">

                    {{ csrf_field() }}

                    <div class="modal-body">

                            <label for="name_ru" class="control-label">Joy nomi (UZ)</label>
                            <input type="text" name="name_uz" class="form-control">

                            <label for="name_uz" class="margin-top-20 control-label">Viloyat nomi (RU)</label>
                            <input type="text" name="name_ru" class="form-control">

                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-link" data-dismiss="modal">Bekor qilish</button>
                        <button type="submit" class="btn btn-default">Qo'shish</button>
                    </div>
                </form>
            </div>
        </div>
    </div> --}}
@endsection