@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="block">

                    <form action="{{ route('region.update', ['id' => $data->id]) }}" method="post">

                        {{ csrf_field() }}
                        {{ method_field('put') }}

                        <div class="col-md-6">
                            <label for="name_ru">Joy nomi (RU)</label>
                            <input type="text" name="name_ru" id="name_ru" class="form-control" value="{{ $data->name_ru }}" required>
                        </div>

                        <div class="col-md-6">
                            <label for="name_uz">Joy nomi (UZ)</label>
                            <input type="text" name="name_uz" id="name_uz" class="form-control" value="{{ $data->name_uz }}" required>
                        </div>

                        <div class="col-md-4 margin-top-20">
                            <button class="btn btn-success btn-block">Saqlash</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
@endsection