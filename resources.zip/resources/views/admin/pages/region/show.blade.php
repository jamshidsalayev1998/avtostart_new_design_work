@extends('layouts.admin')
@section('content')
    <div class="app-heading app-heading-bordered app-heading-page">
        <div class="title">
            <h1 style="font-size:20px;">{{ $region->name_uz }}</h1>
            <p>Viloyat rahbari: <span class="icon-user"></span><span style="color:black">@if($region->getAdmin() != null){{ $region->getAdmin()->full_name }}@endif</span></p>
        </div>
        <!--<div class="heading-elements">
            <a href="#" class="btn btn-danger" id="page-like"><span class="app-spinner loading"></span> loading...</a>
            <a href="https://themeforest.net/item/boooya-revolution-admin-template/17227946?ref=aqvatarius&license=regular&open_purchase_for_item_id=17227946" class="btn btn-success btn-icon-fixed"><span class="icon-text">$24</span> Purchase</a>
        </div>-->
    </div>
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('region.index') }}">Hududlar</a></li>
            <li class="active">{{ $region->name_uz }}</li>
        </ul>
    </div>
        <!-- START PAGE CONTAINER -->
        <div class="container">

            <!-- NEW DEPOSITS -->
            <div class="row">
                <div class="col-md-4 ">
                    <div class="tile-basic tile-basic-icon-top clickable-row hoverjon" data-href="{{ route('region.show',['id'=>$region->id]) }}" style="cursor: pointer">
                        <div class="tile-icon">
                            <span class="fa fa-university"></span>
                        </div>
                        <div class="tile-content text-center padding-5">
                            <h3 class="tile-title">FILIALLAR</h3>
                            <div class="app-widget-tile">
                                <div class="intval intval-lg">@if($branches != null){{ count($branches) }}@endif    </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="tile-basic tile-basic-icon-top clickable-row hoverjon" data-href="{{ route('region.students',['id'=>$region->id]) }}" style="cursor: pointer">
                        <div class="tile-icon">
                            <span class="fa fa-users"></span>
                        </div>
                        <div class="tile-content text-center padding-5">
                            <h3 class="tile-title">O'QUVCHILAR</h3>
                            <div class="app-widget-tile">
                                <div class="intval intval-lg">{{ $students }}</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 ">
                    <div class="tile-basic tile-basic-icon-top clickable-row hoverjon" data-href="{{ route('region.stuff',['id'=>$region->id]) }}" style="cursor: pointer">
                        <div class="tile-icon">
                            <span class="fa fa-car"></span>
                        </div>
                        <div class="tile-content text-center padding-5">
                            <h3 class="tile-title">XODIMLAR</h3>
                            <div class="app-widget-tile">
                                <div class="intval intval-lg">{{ $stuff }}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END NEW DEPOSITS -->

            <!-- DEPOSITS -->
            <div class="block block-condensed">
                <div class="app-heading app-heading-small">
                    <div class="title">
                        <h2>FILIALLAR</h2>
                    </div>
                </div>

                <div class="block-content">
                    <table class="table table-striped table-bordered datatable-extended">
                        <thead>
                        <tr>
                            <th>Filial nomi</th>
                            <th style="text-align: center">Guruhlar</th>
                            <th style="text-align: center">O'quvchilar</th>
                            <th style="text-align: center">Xodimlar</th>
                        </tr>
                        </thead>
                        <tbody>
                        @if($branches != null)
                            @foreach($branches as $item)
                                <tr class="clickable-row hoverjon" data-href="{{ route('branch.show',['id'=>$item->id]) }}" style="cursor:pointer">
                                    <td>{{$item->name_uz}}</td>
                                    <td align="center">{{count($item->groups)}}</td>
                                    <td align="center">{{count($item->students)}}</td>
                                    <td align="center">{{$item->getStuffCount()}}</td>
                                </tr>
                            @endforeach
                        @endif
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END DEPOSITS -->

        </div>
        <!-- END PAGE CONTAINER -->
@endsection