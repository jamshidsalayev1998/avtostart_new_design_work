@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">
                    <div class="panel-heading">Viloyatlarni kiritish</div>
                    <div class="panel-body">
                        <div class="col-md-2">
                            <button data-toggle="modal" data-target="#modal-default" class="btn btn-default"><span class="fa fa-plus text-sm">&nbsp;</span>Yangi qo'shish</button>
                        </div>

                        @if(session('message'))
                            <div class="col-md-10">
                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>

                <div class="block">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="width: 2%">ID</th>
                                <th>Viloyat</th>
                                <th>Filiallar</th>
                                <th>O'quvchilar</th>
                                <th>Xodimlar</th>
                                <th style="width: 8%"></th>
                            </tr>
                            </thead>
                            <tbody>
                            @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp
                            @foreach($data as $region)
                                <tr class="clickable-row hoverjon" title="Batafsil ko'rish uchun bosing" data-href = "{{ route('region.show',['id'=>$region->id]) }}" style="cursor: pointer">
                                    <td>{{ ++$count }}</td>
                                    <td>{{ $region->name_uz }}</td>
                                    <td>{{ count($region->branches) }}</td>
                                    <td>{{ $region->getAllStudentsCount() }}</td>
                                    <td>{{ $region->getStuffCount() }}</td>
                                    <td>
                                        <a href="{{ route('region.edit', ['id' => $region->id]) }}" class="btn btn-sm btn-default btn-icon">
                                            <span class="icon-pencil"></span>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {!! $data->links() !!}

                </div>

            </div>


        </div>
    </div>

    <div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="modal-default-header">
        <div class="modal-dialog" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modal-default-header">Yangi shahar qo'shish</h4>
                </div>
                <form action="{{ route('region.store') }}" method="post">

                    {{ csrf_field() }}

                    <div class="modal-body">

                            <label for="name_ru" class="control-label">Joy nomi (UZ)</label>
                            <input type="text" name="name_uz" class="form-control">

                            <label for="name_uz" class="margin-top-20 control-label">Viloyat nomi (RU)</label>
                            <input type="text" name="name_ru" class="form-control">

                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-link" data-dismiss="modal">Bekor qilish</button>
                        <button type="submit" class="btn btn-default">Qo'shish</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection