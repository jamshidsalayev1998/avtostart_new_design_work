@extends('layouts.admin')
@section('content')
    <div class="app-heading app-heading-bordered app-heading-page">
        <div class="title">
            <h1>{{ $region->name_uz }}</h1>
            <p>Awesome way to show some quick info for your customers</p>
        </div>
        <!--<div class="heading-elements">
            <a href="#" class="btn btn-danger" id="page-like"><span class="app-spinner loading"></span> loading...</a>
            <a href="https://themeforest.net/item/boooya-revolution-admin-template/17227946?ref=aqvatarius&license=regular&open_purchase_for_item_id=17227946" class="btn btn-success btn-icon-fixed"><span class="icon-text">$24</span> Purchase</a>
        </div>-->
    </div>
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Components</a></li>
            <li class="active">Widgets &amp; Informers</li>
        </ul>
    </div>
    <!-- START PAGE CONTAINER -->
    <div class="container">

        <!-- NEW DEPOSITS -->
        <div class="row">
            <div class="col-md-4 ">
                <div class="tile-basic tile-basic-icon-top clickable-row hoverjon" data-href="{{ route('region.show',['id'=>$region->id]) }}" style="cursor: pointer">
                    <div class="tile-icon">
                        <span class="fa fa-university"></span>
                    </div>
                    <div class="tile-content text-center padding-5">
                        <h3 class="tile-title">FILIALLAR</h3>
                        <div class="app-widget-tile">
                            <div class="intval intval-lg">{{ count($branches) }}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="tile-basic tile-basic-icon-top clickable-row hoverjon" data-href="{{ route('region.students',['id'=>$region->id]) }}" style="cursor: pointer">
                    <div class="tile-icon">
                        <span class="fa fa-users"></span>
                    </div>
                    <div class="tile-content text-center padding-5">
                        <h3 class="tile-title">O'QUVCHILAR</h3>
                        <div class="app-widget-tile">
                            <div class="intval intval-lg">{{ $students_count }}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 ">
                <div class="tile-basic tile-basic-icon-top clickable-row hoverjon" data-href="{{ route('region.stuff',['id'=>$region->id]) }}" style="cursor: pointer">
                    <div class="tile-icon">
                        <span class="fa fa-car"></span>
                    </div>
                    <div class="tile-content text-center padding-5">
                        <h3 class="tile-title">XODIMLAR</h3>
                        <div class="app-widget-tile">
                            <div class="intval intval-lg">{{ $stuff }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END NEW DEPOSITS -->

        <!-- DEPOSITS -->
        <div class="block block-condensed">
            <div class="app-heading app-heading-small">
                <div class="title">
                    <h2>O'QUVCHILAR</h2>
                </div>
            </div>

            <div class="block-content">
                <table class="table table-striped table-bordered datatable-extended">
                    <thead>
                    <tr>
                        <th>FIO</th>
                        <th>Pasport info</th>
                        <th>Student ID</th>
                        <th>Ta'lim turi</th>
                        <th>Telefon</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($students as $item)
                        <tr class="clickable-row hoverjon" data-href="{{ route('student.show',['id'=>$item->id]) }}" style="cursor: pointer">
                            <td>{{$item->first_name." ".$item->last_name." ".$item->middle_name}}</td>
                            <td>{{$item->passport_serial.$item->passport_number}}</td>
                            <td>{{$item->student_number}}</td>
                            <td>{{$item->getCourse()->name}}</td>
                            <td>{{$item->phone1}}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        <!-- END DEPOSITS -->

    </div>
    <!-- END PAGE CONTAINER -->
@endsection