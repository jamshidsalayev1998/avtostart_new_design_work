@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <form action="{{ route('price.update',['id'=>$data->id]) }}" method="post">
                {{ csrf_field() }}
                {{ method_field('put') }}
                <div class="col-md-12">
                    <div class="block">
                        <div class="col-md-7">
                            <button class="btn btn-success btn-block" type="submit">Saqlash</button>

                            <div class="form-group margin-top-20">
                                <label>Ta'lim yo'nalishi
                                    @if($errors->has('edu_type'))
                                        <span class="text-danger"> | {{ $errors->first('edu_type') }}</span>
                                    @endif
                                </label>
                                <select class="bs-select dynamic"  id="course_id" data-live-search="true" data-dependent="edu_type" name="course_id">
                                    <option value="{{ $data->course_id }}">{{ $data->getCourse() }}</option>
                                </select>
                            </div>

                            <label for="menu_order" class="margin-top-20">To'lov miqdori (so'm)
                                @if($errors->has('price'))
                                    <span class="text-danger"> | {{ $errors->first('price') }}</span>
                                @endif
                            </label>
                            <input type="tel" name="price" id="price" value="<?php if(old('price')=="") echo $data->price; else echo old('price')?>" class="form-control">
                        </div>
                        <div class="col-md-5">
                            <a href="{{ url()->previous() }}" class="btn btn-warning form-control">Bekor qilish</a>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group margin-top-20">
                                <label>Ta`lim narxi vaqti<span class="text-danger">*</span>
                                    @if($errors->has('created_at'))
                                        <span class="text-danger"> | {{ $errors->first('created_at') }}</span>
                                    @endif
                                </label>
                                <div class="input-group bs-datepicker2">
                                    <input type="text" class="form-control"  name="created_at" id="created_at" value="<?php if(old('created_at')=="") echo $data->created_at; else echo old('created_at')?>"">
                                    <span class="input-group-addon">
                                                      <span class="icon-calendar-full"></span>
                                                </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection