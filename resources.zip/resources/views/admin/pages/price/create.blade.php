@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <form action="{{ route('price.store') }}" method="post">
                {{ csrf_field() }}

                <div class="col-md-12">
                    <div class="block">
                        <div class="col-md-7">
                            <button class="btn btn-success btn-block" type="submit">Saqlash</button>

                            <div class="form-group margin-top-20">
                                <label>Ta'lim yo'nalishi
                                    @if($errors->has('course_id'))
                                        <span class="text-danger"> | {{ $errors->first('course_id') }}</span>
                                    @endif
                                </label>
                                <select class="bs-select dynamic"  id="course_id" data-live-search="true" data-dependent="edu_type" name="course_id">
                                    <option value="" selected style="display: none">Toifani tanlang</option>
                                    @foreach($courses as $course)
                                        <option value="{{ $course->id }}" @if(old('course_id') == $course->id) selected @endif>{{ $course->name }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <label for="menu_order" class="margin-top-20">To'lov miqdori (so'm)
                                @if($errors->has('price'))
                                    <span class="text-danger"> | {{ $errors->first('price') }}</span>
                                @endif
                            </label>
                            <input type="tel" name="price" id="price" value="{{ old('price') }}" class="form-control">
                        </div>
                        <div class="col-md-5">
                            <a href="{{ url()->previous() }}" class="btn btn-warning form-control">Bekor qilish</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection