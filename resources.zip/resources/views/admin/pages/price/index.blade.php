@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        Ta'lim narxlari
                        <a href="{{ route('price.create') }}" class="btn btn-success pull-right"><i class="icon-plus-circle">&nbsp;</i>Yangi qo'shish</a>
                    </div>
                    @if(session('message'))
                        <div class="panel-body">
                            <div class="col-md-10">
                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        </div>
                    @endif
                    <div class="block">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="width: 2%">#</th>
                                <th>Ta'lim yo'nalishi</th>
                                <th>To'lov miqdori</th>
                                <th>Belgilagan shaxs</th>
                                <th>Belgilangan sana</th>
                                <th colspan="2" style="width: 8%"></th>
                            </tr>
                            </thead>
                            <tbody>
                            @php $i=1; @endphp
                            @foreach($data as $item)
                                <tr>
                                    <td>{{ ++$i}}</td>
                                    <td>{{ $item->getCourse() }}</td>
                                    <td>{{ $item->price }}</td>
                                    <td>{{ $item->getSetter() }}</td>
                                    <td>{{ date("d/m/Y H:i",time($item->updated_at)) }}</td>
                                    <td>
                                        <a href="{{ route('price.edit', ['id' => $item->id]) }}" class="btn btn-sm btn-default btn-icon">
                                            <span class="icon-pencil"></span>
                                        </a>
                                    </td>
                                    <td>
                                        <form action="{{ route('price.destroy', ['id' => $item->id]) }}" method="post">
                                            {{ csrf_field() }}
                                            {{ method_field('delete') }}
                                            <button class="btn btn-default btn-icon deleteData"><i class="icon-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>


        </div>
    </div>
@endsection