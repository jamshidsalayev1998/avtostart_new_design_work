@extends('layouts.admin')
@section('content')
    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
    @php $roles = [
        6 => 'Viloyat rahbarlari',
        5 => 'Filial rahbarlari',
        4 => 'Modiratorlar',
        3 => 'O\'qituvchilar',
        2 => 'Hisobchilar',
    ]
    @endphp
  <div class="container">
    <div class="row">
 <div class="col-md-12">
        <div id="container1" style="min-width: 310px; height: 600px; margin: 0 auto"></div>
   
     <br>
     <div id="container2" style="min-width: 310px; height: 400px;  margin: 0 0"></div>

 </div>
    </div> 
    </div> 
@endsection