@extends('layouts.admin')
@section('content')
    <style>
        .box.box-primary {
            border-top-color: #3c8dbc;
        }
        .box {
            position: relative;
            padding: 10px;
            border-radius: 3px;
            background: #ffffff;
            border-top: 3px solid #d2d6de;
            margin-bottom: 20px;
            width: 100%;
            box-shadow: 0 1px 1px rgba(0,0,0,0.1);
        }
    </style>
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <div class="container">
        <div class="app-heading-container app-heading-bordered bottom">
            <ul class="breadcrumb">
                <li><a href="/backoffice">Dashboard</a></li>
                <li><a href="{{action('Admin\ChatController@index',[])}}">Xabarlar</a></li>
                <li class="active">{{\Auth::user()->role == 7 ? 'Xabar yozish' : 'Adminga xabar yozish'}}</li>
            </ul>
        </div>
        <div class="row" style="margin-top: 10px">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-body no-padding">

                        <form method="post" action="{{ route('chat.store') }}">
                            {{ csrf_field() }}
                            <div class="form-group">
                                <label class="col-md-12 control-label"> Qabul qiluvchi:
                                    @if($errors->has('to_id'))
                                        <span class="text-danger"> | {{ $errors->first('to_id') }}</span>
                                    @endif
                                </label>
                                <select class="bs-select student_id"  id="student_id" data-live-search="true" data-dependent="student_id" name="to_id">
                                    <option></option>
                                    @foreach($users as $user)
                                        <option value="{{ $user->id }}">{{ $user->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            @if(\Auth::user()->role == 7)
                                <div class="form-group">
                                    <label class="checkbox-inline"><input type="checkbox" name="vil">Viloyat rahbarlari</label>
                                    <label class="checkbox-inline"><input type="checkbox" name="branch">Filial rahbarlari</label>
                                    <label class="checkbox-inline"><input type="checkbox" name="mod">Moderatorlar</label>
                                    <label class="checkbox-inline"><input type="checkbox" name="teach">O'qituvchilar</label>
                                    <label class="checkbox-inline"><input type="checkbox" name="hisob">Hisobchilar</label>
                                </div>
                            @endif
                            <div class="form-group">
                                <label for="name">Mavzu:</label>
                                @if($errors->has('subject'))
                                    <span class="text-danger"> | {{ $errors->first('subject') }}</span>
                                @endif
                                <input type="text" class="form-control" name="subject"/>
                            </div>
                            <div class="form-group">
                                <label for="price">Matn:</label>
                                @if($errors->has('subject'))
                                    <span class="text-danger"> | {{ $errors->first('body') }}</span>
                                @endif
                                <textarea type="text" class="form-control" name="body" id ='bodyText'></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Yuborish</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="http://tinymce.cachefly.net/4.0/tinymce.min.js"></script>
    <script type="application/x-javascript">
        tinymce.init({selector:'#bodyText'});
    </script>
@endsection