@extends('layouts.admin')
@section('content')
    <style>

    </style>
    <div class="container">
        <div class="app-heading-container app-heading-bordered bottom" style="margin-bottom: 10px">
            <ul class="breadcrumb">
                <li><a href="/backoffice">Dashboard</a></li>
                <li><a href="{{action('Admin\ChatController@index',[])}}">Xabarlar</a></li>
                <li class="active">{{$data->subject}}</li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3><b>Mavzu: </b>{{$data->subject}}</h3><br>
                        <h5>
                            @if($user->id == $message->from_id)
                                @php

                                  $person = 'Test\User'::where('id' , $message->to_id)->first();

                                @endphp
                                <b style="background-color: #003296;color: #ffffff;padding: 2px 7px;border-radius: 4px">{{$person->name}}</b> ga jo'natilgan
                            @else
                                @php

                                  $person = 'Test\User'::where('id' , $message->from_id)->first();

                                @endphp
                                <b style="background-color: #003296;color: #ffffff;padding: 2px 7px;border-radius: 4px"> {{$person->name}}</b> dan kelgan
                            @endif
                            xabar
                                <span class="mailbox-read-time pull-right" style="color: dimgrey;font-size: 12px">
                                    <b>Vaqti: </b>
                                    {{date('H:i d.m.Y', strtotime($data->c_date))}}
                                </span>
                        </h5>
                    </div>
                    <div class="panel-body">
                        <?=$data->body?>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection