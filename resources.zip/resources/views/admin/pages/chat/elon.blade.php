@extends('layouts.admin')

@section('content')

    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp

    @php $roles = [

        6 => 'Viloyat rahbarlari',

        5 => 'Filial rahbarlari',

        4 => 'Modiratorlar',

        3 => 'O\'qituvchilar',

        2 => 'Hisobchilar',

    ]

    @endphp

    <div class="container">

   <div class="row" style="margin-right: 12px;margin-left: 12px;">

        <div class="block block-condensed" style="background-color: #b8ffb8";>

                <br>

                

                <div class="block-content" style="width: 100%; overflow: auto;">

                    <div class="card">

                        <div class="card-body">

                            <h1>Yangi E`lon <h2>23.07.2019 21:00</h2> </h1>

                            <p style="color:black;font-size:15px;">

                               O`zgarish va Yangiliklar

                                <a href="http://www.ais.articles.uz/yangiliklar.pdf">Yuklash</a>

                            </p>

                        </div>

                      </div>

                </div>  

            </div>  

        </div>

              <div class="row" style="margin-right: 12px;margin-left: 12px;">

        <div class="block block-condensed" style="background-color: #b8ffb8";>

                <br>

                

                <div class="block-content" style="width: 100%; overflow: auto;">

                    <div class="card">

                        <div class="card-body">

                            <h1>E`lon <h2>20.06.2019 21:00</h2> </h1>

                            <p style="color:black;font-size:15px;">


                                <a href="http://www.ais.articles.uz/qaror.pdf">Yuklash</a>

                            </p>

                        </div>

                      </div>

                </div>  

            </div>  

        </div>

        <div class="row" style="margin-right: 12px;margin-left: 12px;">

        <div class="block block-condensed" style="background-color: #b8ffb8";>

                <br>

                <div class="block-content" style="width: 100%; overflow: auto;">

                    <div class="card">

                        <div class="card-body">

                            <h1> E`lon <h2>03.06.2019 17:00</h2> </h1>

                            <p style="color:black;font-size:15px;">

                                Yangi yaratilgan test tizimi uchun yo`riqnoma.

                                <a href="http://www.ais.articles.uz/test.pdf">Yuklash</a>

                            </p>

                        </div>

                      </div>

                </div>

            </div>
        	   
        </div>

    </div>

@endsection