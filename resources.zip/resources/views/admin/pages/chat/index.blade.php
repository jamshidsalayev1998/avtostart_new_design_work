@extends('layouts.admin')
@section('content')
    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
    @php $roles = [
        7 => 'Administrator',
        6 => 'Viloyat rahbari',
        5 => 'Filial rahbari',
        4 => 'Moderator',
        3 => 'O\'qituvchi',
        2 => 'Hisobchi',
    ];
    @endphp
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="block block-condensed">
                <br>
                <div class="block-content" style="width: 100%; overflow: auto;">
                    <a href="{{route('chat.create')}}" class="btn btn-success" style="margin-bottom: 10px"><?=\Auth::user()->role == 7 ? 'Xabar yozish' : 'Adminga xabar yozish'?></a>
                    <br>
                    <table class="table table-striped table-bordered" id="data-table">
                        <thead>
                        <tr class="text-center">
                            <th>#</th>
                            <th>F.I.O.</th>
                            <th>Roli</th>
                            @if($user->role == 7)
                                <th>Filiali</th>
                                <th>Viloyati</th>
                            @endif
                            <th>Mavzu</th>
                            <th>Vaqti</th>
                        </tr>
                        </thead>
                        <tbody>

                        @foreach($data as $item)
                            <tr class="clickable-row {{$item->status == 0 ? 'danger' : ''}}" data-href="{{action('Admin\ChatController@show',['id' => $item->chat_id])}}" style="cursor: pointer;">
                                @if ($item->status == 0)
                                    <td><b>{{++$i}}</b></td>
                                    <td><b>{{empty($item->name) ? $roles[$item->role_id] : $item->name}}</b></td>
                                    <td><b>{{$roles[$item->role]}}</b></td>
                                @if($user->role == 7)

                                    @if($item->from_id == 1)

                                        @if($item->role == 6)
                                                @php
                                                    $region_id = Test\Model\Admin::select('region_id')->where('user_id', $item->to_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                @endphp
                                                <td><b>{{ '-' }}</b></td>
                                                <td><b>{{ $region }}</b></td>
                                            @endif

                                        @if($item->role == 5)
                                                @php
                                                    $branchAdmin = Test\Model\BranchAdmin::select(['region_id', 'branch_id'])->where('user_id', $item->to_id)->first();
                                                    $branch_id = $branchAdmin->branch_id;
                                                    $region_id = $branchAdmin->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td><b>{{ $branch }}</b></td>
                                                <td><b>{{ $region }}</b></td>
                                            @endif

                                        @if($item->role == 4)
                                                @php
                                                    $branch_id = Test\Model\Moderator::select(['branch_id'])->where('user_id', $item->to_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td><b>{{ $branch }}</b></td>
                                                <td><b>{{ $region }}</b></td>
                                            @endif

                                        @if($item->role == 3)
                                                @php
                                                    $branch_id = Test\Model\Teacher::select(['branch_id'])->where('user_id', $item->to_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td><b>{{ $branch }}</b></td>
                                                <td><b>{{ $region }}</b></td>
                                            @endif

                                        @if($item->role == 2)
                                                @php
                                                    $branch_id = Test\Model\Accountant::select(['branch_id'])->where('user_id', $item->to_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td><b>{{ $branch }}</b></td>
                                                <td><b>{{ $region }}</b></td>
                                            @endif

                                    @elseif($item->to_id == 1)

                                        @if($item->role == 6)
                                                @php
                                                    $region_id = Test\Model\Admin::select('region_id')->where('user_id', $item->from_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                @endphp
                                                <td><b>{{ '-' }}</b></td>
                                                <td><b>{{ $region }}</b></td>
                                            @endif

                                        @if($item->role == 5)
                                                @php
                                                    $branchAdmin = Test\Model\BranchAdmin::select(['region_id', 'branch_id'])->where('user_id', $item->from_id)->first();
                                                    $branch_id = $branchAdmin->branch_id;
                                                    $region_id = $branchAdmin->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td><b>{{ $branch }}</b></td>
                                                <td><b>{{ $region }}</b></td>
                                            @endif

                                        @if($item->role == 4)
                                                @php
                                                    $branch_id = Test\Model\Moderator::select(['branch_id'])->where('user_id', $item->from_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td><b>{{ $branch }}</b></td>
                                                <td><b>{{ $region }}</b></td>
                                            @endif

                                        @if($item->role == 3)
                                                @php
                                                    $branch_id = Test\Model\Teacher::select(['branch_id'])->where('user_id', $item->from_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td><b>{{ $branch }}</b></td>
                                                <td><b>{{ $region }}</b></td>
                                            @endif

                                        @if($item->role == 2)
                                                @php
                                                    $branch_id = Test\Model\Accountant::select(['branch_id'])->where('user_id', $item->from_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td><b>{{ $branch }}</b></td>
                                                <td><b>{{ $region }}</b></td>
                                            @endif

                                    @endif

                                @endif
                                    <td><b>{{$item->subject}}</b></td>
                                    <td><b>{{date('H:i d.m.Y', strtotime($item->c_date))}}</b></td>
                                @else

                                    <td>{{++$i}}</td>
                                    <td>{{$item->name}}</td>
                                    <td>{{$roles[$item->role]}}</td>
                                    @if($user->role == 7)

                                        @if($item->from_id == 1)

                                            @if($item->role == 6)
                                                @php
                                                    $region_id = Test\Model\Admin::select('region_id')->where('user_id', $item->to_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                @endphp
                                                <td>{{ '-' }}</td>
                                                <td>{{ $region }}</td>
                                            @endif

                                            @if($item->role == 5)
                                                @php
                                                    $branchAdmin = Test\Model\BranchAdmin::select(['region_id', 'branch_id'])->where('user_id', $item->to_id)->first();
                                                    $branch_id = $branchAdmin->branch_id;
                                                    $region_id = $branchAdmin->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td>{{ $branch }}</td>
                                                <td>{{ $region }}</td>
                                            @endif

                                            @if($item->role == 4)
                                                @php
                                                    $branch_id = Test\Model\Moderator::select(['branch_id'])->where('user_id', $item->to_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td>{{ $branch }}</td>
                                                <td>{{ $region }}</td>
                                            @endif

                                            @if($item->role == 3)
                                                @php
                                                    $branch_id = Test\Model\Teacher::select(['branch_id'])->where('user_id', $item->to_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td>{{ $branch }}</td>
                                                <td>{{ $region }}</td>
                                            @endif

                                            @if($item->role == 2)
                                                @php
                                                    $branch_id = Test\Model\Accountant::select(['branch_id'])->where('user_id', $item->to_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td>{{ $branch }}</td>
                                                <td>{{ $region }}</td>
                                            @endif


                                        @elseif($item->to_id == 1)

                                            @if($item->role == 6)
                                                @php
                                                    $region_id = Test\Model\Admin::select('region_id')->where('user_id', $item->from_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                @endphp
                                                <td>{{ '-' }}</td>
                                                <td>{{ $region }}</td>
                                            @endif

                                            @if($item->role == 5)
                                                @php
                                                    $branchAdmin = Test\Model\BranchAdmin::select(['region_id', 'branch_id'])->where('user_id', $item->from_id)->first();
                                                    $branch_id = $branchAdmin->branch_id;
                                                    $region_id = $branchAdmin->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td>{{ $branch }}</td>
                                                <td>{{ $region }}</td>
                                            @endif

                                            @if($item->role == 4)
                                                @php
                                                    $branch_id = Test\Model\Moderator::select(['branch_id'])->where('user_id', $item->from_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td>{{ $branch }}</td>
                                                <td>{{ $region }}</td>
                                            @endif

                                            @if($item->role == 3)
                                                @php
                                                    $branch_id = Test\Model\Teacher::select(['branch_id'])->where('user_id', $item->from_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td>{{ $branch }}</td>
                                                <td>{{ $region }}</td>
                                            @endif

                                            @if($item->role == 2)
                                                @php
                                                    $branch_id = Test\Model\Accountant::select(['branch_id'])->where('user_id', $item->from_id)->first()->branch_id;
                                                    $region_id = Test\Model\Branch::select('region_id')->where('id', $branch_id)->first()->region_id;
                                                    $region = Test\Model\Region::select(['name_uz', 'name_ru'])->where('id', $region_id)->first()->name_uz;
                                                    $branch = Test\Model\Branch::select(['name_uz', 'name_ru'])->where('id', $branch_id)->first()->name_uz;
                                                @endphp
                                                <td>{{ $branch }}</td>
                                                <td>{{ $region }}</td>
                                            @endif

                                        @endif

                                    @endif
                                    <td>{{$item->subject}}</td>
                                    <td>{{date('H:i d.m.Y', strtotime($item->c_date))}}</td>
                                @endif
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    <div class="row">
                        <div class="col-sm-5">
                            Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries
                        </div>
                        <div class="col-sm-7">
                            {{ $data->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection