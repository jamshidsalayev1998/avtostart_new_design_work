<html>
<head>
    <style>
        body {
            font-family: DejaVu Sans;
            line-height: 1;
        }
        table{
            border-collapse: collapse;
        }
    </style>
</head>
<body>
    <table >
    <thead>
    <tr>
        <th style="width: 2%">#</th>
        <th>SANA</th>
        <th>MASHQ SOATI</th>
        <th>SHU JUMLADAN</th>
        <th>MAVZU NOMI</th>
        <th>O'QITUVCHI</th>
    </tr>
    </thead>
    <tbody>
    <?php $i=1;?>
    @foreach($group->classDate as $item)
        <tr>
            <td>{{ $i }}</td>
            <td>
                {{ date('d.m.Y',strtotime($item->start_time)) }}<br>
                {{ date('H:i',strtotime($item->start_time)) }}
            </td>
            <td>
                <table style="padding:0 ">
                    @php $j=1; @endphp
                    @foreach($item->getHours() as $key => $value)
                        <tr>
                            <td>{{ $j }}</td>
                        </tr>
                        @php $j++ @endphp
                    @endforeach
                </table>
            </td>
            <td>
                <table style="padding:0 ">
                    @foreach($item->getHours() as $key => $value)
                        <tr>
                            <td>
                                @if($item->getTopicType($value) == 1)
                                    <span> {{ "Nazariy" }} </span>
                                @endif
                                @if($item->getTopicType($value) == 2)
                                    <span> {{ "Amaliy" }} </span>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </table>
            </td>
            <td>
                <table style="padding:0 ">
                    @foreach($item->getHours() as $key => $value)
                        <tr>
                            <td>
                                {{ $item->getTopicById($value)->name_uz }}
                            </td>
                        </tr>
                    @endforeach
                </table>
            </td>
            <td>{{ $group->teacher->full_name }}</td>
            @php $i++ @endphp
        </tr>
    @endforeach
    </tbody>
</table>
</body>
</html>
