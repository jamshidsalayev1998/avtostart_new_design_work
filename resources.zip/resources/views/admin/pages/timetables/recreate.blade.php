@extends('layouts.admin')



@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('timetables.index') }}">{{ $data->name_uz }}</a></li>

            <li class="active">Dars jadvali qayta yaratish</li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>

    <div class="container">

        <form method="post" action="{{ route('timetables.store') }}">

            {{ csrf_field() }}

            <input type="hidden" name="group_id" value="{{ $data->id }}">

            <div class="col-md-4">

                <label style="margin-left: 0px">Hafta kunlari</label>

                <div class="form-group" style="border:1px solid yellowgreen">

                    <div class="col-md-6">

                        <div class="app-checkbox">

                            <label><input type="checkbox" name="mon" value="1" checked> Dushanba<span></span></label>

                        </div>

                        <div class="app-checkbox">

                            <label><input type="checkbox" name="tue" value="2" checked> Seshanba<span></span></label>

                        </div>

                        <div class="app-checkbox">

                            <label><input type="checkbox" name="wed" value="3" checked> Chorshanba<span></span></label>

                        </div>

                    </div>

                    <div class="col-md-6">

                        <div class="app-checkbox">

                            <label><input type="checkbox" name="thu" value="4" checked> Payshanba<span></span></label>

                        </div>

                        <div class="app-checkbox">

                            <label><input type="checkbox" name="fri" value="5" checked> Juma<span></span></label>

                        </div>

                        <div class="app-checkbox">

                            <label><input type="checkbox" name="sat" value="6" checked> Shanba<span></span></label>

                        </div>

                    </div>

                </div>

            </div>

            <div class="col-md-4">

                <label style="margin-left: 0px">Dars vaqti va davomiyligi</label>

                <div class="form-group" style="border:1px solid yellowgreen">

                    <div class="col-md-12">

                        <div class="form-group margin-top-10">

                            <div class="col-md-6">

                                <label style="margin-top: 5px;">Davomiyligi (soat)</label>

                            </div>

                            <div class="col-md-6">

                                <div class="spinner-wrapper">

                                    <input type="text" name="class-duration" class="form-control spinner" value="4" data-spinner-min="2" data-spinner-max="6">

                                    <button class="spinner-button-down"><span class="fa fa-angle-down"></span></button>

                                    <button class="spinner-button-up"><span class="fa fa-angle-up"></span></button>
                  @if($errors->has('class_duration'))

                                 <span class="text-danger"> | {{ $errors->first('class_duration') }}</span>

                                    @endif

                                </div>

                            </div>

                        </div>

                        <div class="form-group margin-bottom-10">

                            <div class="col-md-6">

                                <label style="margin-top: 0px;">Ta'limni boshlanish vaqti</label>

                            </div>

                            <div class="col-md-6">

                                <div class="spinner-wrapper">

                                    <input type="time" name="start_time" class="form-control timepicker" value="15:00" >

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <div class="col-md-4">

                <label style="margin-left: 0px">Info</label>

                <div class="form-group" style="border:1px solid yellowgreen;padding:10px;">

                    <div class="col-md-6">

                        <label style="margin-top: 5px;">Guruh nomi</label>

                    </div>

                    <div class="col-md-6">

                        <input value="{{ $data->name_uz." (".$data->getCourse()->name.")" }}" type="text" class="form-control" readonly="">

                    </div>

                    <div class="col-md-6">

                        <label style="margin-top: 15px;">Ta'limning boshlanish sanasi</label>

                    </div>

                    <div class="col-md-6 margin-top-15">

                        <input value="{{ $data->edu_starting_date }}" type="text" class="form-control" readonly="">

                    </div>

                </div>

            </div>

            <div class="col-md-12 padding-15"><button type="submit" style="text-transform: uppercase" class="btn btn-warning form-control"><span class="icon-trash"></span>Amaladagi dars jadvalini o'chirish va yangisini yaratish</button></div>

        </form>

    </div>

@endsection