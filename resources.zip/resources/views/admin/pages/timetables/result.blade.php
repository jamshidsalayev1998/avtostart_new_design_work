@extends('layouts.admin')



@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('timetables.index') }}">Dars jadvali</a></li>

            <li class="active">Dars jadvali yaratish</li>

        </ul>

        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

    </div>

    <div class="app-faq" style="border-radius: 0">

        <div class="app-faq-item" style="border-radius: 0">

            <div class="app-faq-item-title">Dars jadvalini boshqatdan yaratish</div>

            <div class="app-faq-item-content">

                <p class="" style="color: black;margin-left: 50px;">

                    <a href="#" class="app-widget-button app-widget-button-warning"><span class="icon-warning"></span></a>

                    <span style="font-weight: bolder;font-size: 20px;" class="text-danger">Diqqat bilan o'qing!</span><br>

                    Guruhning dars jadvalini qayta yaratsangiz joriy olib borilayotgan ta'limga aloqador bo'lgan<br>

                    <span class="fa fa-circle-thin text-danger margin-left-30">&nbsp;</span>Joriy guruh o'quvchilarining baholari<br>

                    <span class="fa fa-circle-thin text-danger margin-left-30">&nbsp;</span>Joriy guruh o'quvchilarining davomatlari<br>

                    <span class="fa fa-circle-thin text-danger margin-left-30">&nbsp;</span>Joriy guruhning amaldagi dars jadvali<br>

                    haqidagi ma'lumotlar bazadan o'chiriladi va qayta tiklashning iloji bo'lmaydi.

                </p>

                <center>

                    <div class="app-checkbox inline" id="agree-checkbox">

                        <label style="font-weight: bold"><input type="checkbox" id="agree1" name="app-checkbox-2">Roziman<span></span><span></span></label>

                    </div>

                    <div>

                        <a class="btn btn-success" href="{{ route('timetables.recreate',['id'=>$data->id]) }}" style="width: 100%;text-transform: uppercase;display: none" id="startbutton1">DARS JADVALINI BOSHQATDAN YARATISH</a>

                    </div>

                </center>

            </div>

        </div>

    </div>

    @if(session('message'))

        <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

            <div class="alert-icon">

                <span class="icon-checkmark-circle"></span>

            </div>

            {{ session('message') }}

            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

        </div>

    @endif

    <div class="container">

        <div class="app-heading app-heading-bordered app-heading-page">

            <div style="text-align: center;line-height: 0.5">

                <h1 style="text-align: center;padding: 0">{{ $data->name_uz }} - son "{{ $data->getCourse()->name }}" toifali haydovchilarni tayyorlash o'quv guruhining</h1>

                <p style="text-align: center;font-size: 30px;margin-top: 0;padding: 0;font-weight: bolder">Dars jadvali</p>

                <div class="col-md-11">

                  <!--   <p style="text-align: right">Tasdiqlangan sana: {{ date('d.m.Y',strtotime($confirmation_date->created_at)) }}</p> -->
<input type="button" onclick="tableToExcel('testTable', 'W3C Example Table')" class="btn btn-default btn-lg pull-right" value="Excelga export qilish  ">

                </div>

                <div class="col-md-1">

                    <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>

                    <ul class="dropdown-menu dropdown-left" style="min-width: 350px;">

                        <li>

                            <button data-toggle="modal" data-target="#modal-edit-time" style="border:none;text-align:left" class="btn btn-default form-control"><span class="fa fa-clock-o">&nbsp;&nbsp;</span> Dars vaqtini o'zgartirish</button>

                            <a href="{{ route('timetables.recreatefromdate',['id'=>$data->id]) }}" style="border: none" class="btn btn-default">&nbsp;<span class="fa fa-calendar">&nbsp;&nbsp;</span> Dars jadvalini sanadan boshlab qayta yaratish</a>

                            <a href="{{ route('timetables.savetopdf',['id'=>$data->id]) }}" style="border: none;text-align: left" class="btn btn-default">&nbsp;<span class="fa fa-file-pdf-o text-danger">&nbsp;&nbsp;</span> Dars jadvalini PDF da saqlash</a>

                        </li>

                    </ul>

                </div>
            </div>

            <!--<div class="heading-elements">

                <a href="#" class="btn btn-danger" id="page-like"><span class="app-spinner loading"></span> loading...</a>

                <a href="https://themeforest.net/item/boooya-revolution-admin-template/17227946?ref=aqvatarius&license=regular&open_purchase_for_item_id=17227946" class="btn btn-success btn-icon-fixed"><span class="icon-text">$24</span> Purchase</a>

            </div>-->

        </div>

        <div class="block">

            <table class="table table-bordered table-hover" id="testTable">

                <thead>

                <tr>

                    <th style="width: 2%">#</th>

                    <th>SANA</th>

                    <th>MASHQ SOATI</th>

                    <th>SHU JUMLADAN</th>

                    <th>MAVZU NOMI</th>

                    <th>O'QITUVCHI</th>

                    <th colspan="2" style="width: 8%"></th>

                </tr>

                </thead>

                <tbody>

                <?php $i=1;?>

                @foreach($class_dates as $item)

                    <tr>

                        <td>{{ $i }}</td>

                        <td>

                            {{ date('d.m.Y',strtotime($item->start_time)) }}<br>

                            {{ date('H:i',strtotime($item->start_time)) }}

                        </td>

                        <td>

                            <table style="padding:0 ">

                                @php $j=1; @endphp

                                @foreach($item->getHours() as $key => $value)

                                    <tr>

                                        <td>{{ $j }}</td>

                                    </tr>

                                    @php $j++ @endphp

                                @endforeach

                            </table>

                        </td>

                        <td>

                            <table style="padding:0 " class="table-bordered">

                                @foreach($item->getHours() as $key => $value)

                                    <tr>

                                        <td>

                                            @if($item->getTopicType($value) == 1)

                                                <span class="label label-default label-bordered label-ghost"> {{ "Nazariy" }} </span>

                                            @endif

                                            @if($item->getTopicType($value) == 2)

                                                <span class="label label-success label-bordered label-ghost"> {{ "Amaliy" }} </span>

                                            @endif

                                        </td>

                                    </tr>

                                @endforeach

                            </table>

                        </td>

                        <td>

                            <table style="padding:0 ">

                                @foreach($item->getHours() as $key => $value)

                                    <tr>

                                        <td>

                                            {{ $item->getTopicById($value)->name_uz }}

                                        </td>

                                    </tr>

                                @endforeach

                            </table>

                        </td>

                        <td>{{ $data->teacher->full_name }}</td>

                        <td>

                            <button data-toggle="modal" data-idec="{{ $item->id }}" data-target="#modal-specific-date" style="border:none" class="btn btn-sm btn-default btn-icon specific-date"><span class="icon-pencil"></span></button>

                        </td>

                        @php $i++ @endphp

                    </tr>

                @endforeach

                </tbody>

            </table>



        </div>

    </div>

    <div class="modal fade" id="modal-edit-time" tabindex="-1" role="dialog" aria-labelledby="modal-default-header">

        <div class="modal-dialog" role="document">

            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>



            <div class="modal-content">

                <div class="modal-header">

                    <h4 class="modal-title" id="modal-default-header">Mashg'ulotning boshlanish vaqtini o'zgartirish</h4>

                </div>

                <form action="{{ route('timetables.changetime',['id'=>$data->id]) }}" method="post" >

                    {{ csrf_field() }}

                    <div class="modal-body">

                        <div class="col-md-6">

                            <div class="form-group">

                                <label for="name_ru" class="control-label">Amaldagi dars boshlanish vaqti</label>

                                <input type="time" name="new_time" class="form-control timepicker" value="{{ date('H:i',strtotime($item->start_time)) }}" >

                            </div>

                        </div>

                        <div class="col-md-6">

                                <label for="name_ru" class="control-label">Mashg'ulot davomiyligi</label>

                            <div class="spinner-wrapper">

                                <input type="text" name="class_duration" class="form-control spinner" value="4" data-spinner-min="1" data-spinner-max="5">

                                <button class="spinner-button-down"><span class="fa fa-angle-down"></span></button>

                                <button class="spinner-button-up"><span class="fa fa-angle-up"></span></button>

                            </div>

                        </div>

                    </div>

                    <div class="modal-footer">

                        <button type="reset" class="btn btn-link" data-dismiss="modal">Bekor qilish</button>

                        <button type="submit" class="btn btn-default">Saqlash</button>

                    </div>

                </form>

            </div>

        </div>

    </div>

    <div class="modal fade" id="modal-specific-date" tabindex="-1" role="dialog" aria-labelledby="modal-default-header">

        <div class="modal-dialog" role="document">

            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>



            <div class="modal-content">

                <div class="modal-header">

                    <h4 class="modal-title" id="modal-default-header">Joriy kundagi mashg'ulotni o'zgartirish</h4>

                </div>

                <form method="post" id="specific-date-form">

                    {{ csrf_field() }}

                    <div class="modal-body">

                        <div class="col-md-6">

                            <div class="form-group">

                                <label for="name_ru" class="control-label">Amaldagi dars boshlanish vaqti</label>

                                <input type="time" name="new_time" id="new_time" class="form-control timepicker"  >

                            </div>

                        </div>

                        <div class="col-md-6">

                                <label for="name_ru" class="control-label">Mashg'ulot davomiyligi</label>

                            <div class="spinner-wrapper">

                                <input type="text" name="new_duration" class="form-control spinner" id="new_duration" data-spinner-min="1" data-spinner-max="5">

                                <button class="spinner-button-down"><span class="fa fa-angle-down"></span></button>

                                <button class="spinner-button-up"><span class="fa fa-angle-up"></span></button>

                            </div>

                        </div>

                        <div class="col-md-6">

                            <div class="form-group">

                                <label>Ta'limning boshlanish sanasi

                                    @if($errors->has('new_day'))

                                        <span class="text-danger"> | {{ $errors->first('new_day') }}</span>

                                    @endif

                                </label>

                                <div class="input-group bs-datepicker">

                                    <input type="text" class="form-control"  name="new_day" id="new_day">

                                    <span class="input-group-addon">

                                      <span class="icon-calendar-full"></span>

                                </span>

                                </div>

                            </div>

                        </div>

                        <div class="col-md-6"></div>

                    </div>

                    <div class="modal-footer">

                        <button type="reset" class="btn btn-link" data-dismiss="modal">Bekor qilish</button>

                        <button type="submit" class="btn btn-default">Saqlash</button>

                    </div>

                </form>

            </div>

        </div>

    </div>

@endsection