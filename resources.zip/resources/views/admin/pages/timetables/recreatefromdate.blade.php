@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('timetables.index') }}">{{ $data->name_uz }}</a></li>
            <li><a href="{{ route('timetables.result',['id'=>$data->id]) }}">Dars jadvali</a></li>
            <li class="active">Sanadan boshlan qayta yaratish yaratish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>

    <div class="container">
        @if(session('error'))
            <div class="alert alert-error alert-icon-block alert-dismissible" role="alert">
                <div class="alert-icon">
                    <span class="icon-checkmark-circle"></span>
                </div>
                {{ session('error') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
            </div>
        @endif
    </div>
    <div class="container">
        <form method="post" action="{{ route('timetables.recreatefromdatestore',['id'=>$data->id]) }}">
            {{ csrf_field() }}
            <div class="col-md-6">
                <div class="form-group">
                    <label>Sanadan boshlab o'zgartirish
                        @if($errors->has('from_date'))
                            <span class="text-danger"> | {{ $errors->first('from_date') }}</span>
                        @endif
                    </label>
                    <div class="input-group bs-datepicker">
                        <input type="text" class="form-control" value="{{ date('d/m/Y',time()) }}"  name="from_date" id="from_date" required>
                        <span class="input-group-addon">
                              <span class="icon-calendar-full"></span>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>&nbsp;</label>
                    <div class="input-group bs-datepicker">
                        <button type="button" data-toggle="modal" data-target="#holiday-days" class="btn btn-default form-control"><span class="fa fa-eye">&nbsp;</span>Bayram kunlarin ko'rish</button>
                    </div>
                </div>
            </div>
            <div style="clear: both;height: 20px;"></div>
            <div class="col-md-4">
                <label style="margin-left: 0px">Hafta kunlari</label>
                <div class="form-group" style="border:1px solid yellowgreen">
                    <div class="col-md-6">
                        <div class="app-checkbox">
                            <label><input type="checkbox" name="mon" value="1" checked> Dushanba<span></span></label>
                        </div>
                        <div class="app-checkbox">
                            <label><input type="checkbox" name="tue" value="2" checked> Seshanba<span></span></label>
                        </div>
                        <div class="app-checkbox">
                            <label><input type="checkbox" name="wed" value="3" checked> Chorshanba<span></span></label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="app-checkbox">
                            <label><input type="checkbox" name="thu" value="4" checked> Payshanba<span></span></label>
                        </div>
                        <div class="app-checkbox">
                            <label><input type="checkbox" name="fri" value="5" checked> Juma<span></span></label>
                        </div>
                        <div class="app-checkbox">
                            <label><input type="checkbox" name="sat" value="6" checked> Shanba<span></span></label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <label style="margin-left: 0px">Dars vaqti va davomiyligi</label>
                <div class="form-group" style="border:1px solid yellowgreen">
                    <div class="col-md-12">
                        <div class="form-group margin-top-10">
                            <div class="col-md-6">
                                <label style="margin-top: 5px;">Davomiyligi (soat)</label>
                            </div>
                            <div class="col-md-6">
                                <div class="spinner-wrapper">
                                    <input type="text" name="class-duration" class="form-control spinner" value="4" data-spinner-min="1" data-spinner-max="5">
                                    <button class="spinner-button-down"><span class="fa fa-angle-down"></span></button>
                                    <button class="spinner-button-up"><span class="fa fa-angle-up"></span></button>
                                </div>
                            </div>
                        </div>
                        <div class="form-group margin-bottom-10">
                            <div class="col-md-6">
                                <label style="margin-top: 0px;">Ta'limni boshlanish vaqti</label>
                            </div>
                            <div class="col-md-6">
                                <div class="spinner-wrapper">
                                    <input type="time" name="start_time" class="form-control timepicker" value="15:00" >
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <label style="margin-left: 0px">Info</label>
                <div class="form-group" style="border:1px solid yellowgreen;padding:10px;">
                    <div class="col-md-6">
                        <label style="margin-top: 5px;">Guruh nomi</label>
                    </div>
                    <div class="col-md-6">
                        <input value="{{ $data->name_uz." (".$data->getCourse()->name.")" }}" type="text" class="form-control" readonly="">
                    </div>
                    <div class="col-md-6">
                        <label style="margin-top: 15px;">Ta'limning boshlanish sanasi</label>
                    </div>
                    <div class="col-md-6 margin-top-15">
                        <input value="{{ $data->edu_starting_date }}" type="text" class="form-control" readonly="">
                    </div>
                </div>
            </div>
            <div class="col-md-12 padding-15"><button type="submit" style="text-transform: uppercase" class="btn btn-warning form-control">Ko'rsatilgan sanadan boshlab qayta yaratish</button></div>
        </form>
    </div>
    <div class="modal fade" id="holiday-days" tabindex="-1" role="dialog" aria-labelledby="modal-default-header">
        <div class="modal-dialog" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modal-default-header">Bayram kunlari</h4>
                </div>
                <form method="post">
                    {{ csrf_field() }}
                    <div class="modal-body">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="width: 2%">#</th>
                                <th>Nomlanishi</th>
                                <th>Sana</th>
                            </tr>
                            </thead>
                            <tbody>
                            @php $i = 0; @endphp
                            @foreach($holidays as $item)
                                <tr>
                                    <td>{{ ++$i }}</td>
                                    <td>{{ $item->name }}</td>
                                    <td>{{ $item->exception_date }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-link" data-dismiss="modal">Yopish</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection