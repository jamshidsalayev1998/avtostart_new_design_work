@extends('layouts.admin')
@section('content')
    @php $i = ($data->currentPage() - 1) * $data->perPage() + 1 @endphp
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li class="active">Yangiliklar</li>
        </ul>
    </div>
    <!-- START PAGE CONTAINER -->
    <div class="container">
        <div class="col-lg-12">
            <div class="panel panel-default">
		<div class="panel-heading">
			<a href="{{ route('news.create') }}" class="btn btn-success">Qo'shish</a>
		</div>
                <div class="panel-body">
                    <table class="table table-striped table-bordered">

                        <thead>

                        <tr>

                            <th># </th>

                            <th>Qisqa nomi</th>

                            <th width="50px"></th>

                            <th width="50px"></th>

                        </tr>

                        </thead>

                        <tbody>



                        @foreach($data as $item)

                            <tr>

                                <td>{{ $i }}</td>

                                <td>{{$item->name_uz}}</td>

                                <td>

                                    <a href="{{ route('news.show', ['id' => $item->id]) }}" class="btn btn-default btn-icon">

                                        <i class="fa fa-eye"></i>

                                    </a>

                                </td>

                                <td>

                                    <a href="{{ route('news.edit', ['id' => $item->id]) }}" class="btn btn-default btn-icon">

                                        <i class="icon-pencil"></i>

                                    </a>

                                </td>

                            </tr>

                            @php $i++ @endphp

                        @endforeach

                        </tbody>

                        {{ $data->links() }}



                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- END PAGE CONTAINER -->
@endsection