@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="/backoffice/news/index">Yangiliklar</a></li>
            <li class="active">Yangilik yaratish</li>
        </ul>
    </div>
    <!-- START PAGE CONTAINER -->
    <div class="container">
        <form action="{{ route('news.store') }}" method="post" enctype="multipart/form-data">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <b>Sarlavha</b>
                    </div>
                    <div class="panel-body">
                            {{ csrf_field() }}
                            <input type="hidden" name="id" id="news_id" value="{{ $model->id }}">
                            <div class="col-sm-4">
                                <b>O'zbek</b>
                                <textarea name="name_uz" id="" class="form-control editor-full" cols="30" rows="10" style="min-height: 50px; min-width: 100%;"><?=$model->name_uz?></textarea>
                            </div>
                            <div class="col-sm-4">
                                <b>Rus</b>
                                <textarea name="name_ru" id="" class="form-control editor-full" cols="30" rows="10" style="min-height: 50px; min-width: 100%;"><?=$model->name_ru?></textarea>
                            </div>
                            <div class="col-sm-4">
                                <b>kiril</b>
                                <textarea name="name_eng" id="" class="form-control editor-full" cols="30" rows="10" style="min-height: 50px; min-width: 100%;"><?=$model->name_eng?></textarea>
                            </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <b>Asosiy qism</b>
                    </div>
                    <div class="panel-body">
                        {{ csrf_field() }}
                        <input type="hidden" name="id" id="news_id" value="{{ $model->id }}">
                        <div class="col-sm-4">
                            <b>O'zbek</b>
                            <textarea name="body_uz" id="" class="form-control editor-full" cols="30" rows="10" style="min-height: 50px; min-width: 100%;"><?=$model->body_uz?></textarea>
                        </div>
                        <div class="col-sm-4">
                            <b>Rus</b>
                            <textarea name="body_ru" id="" class="form-control editor-full" cols="30" rows="10" style="min-height: 50px; min-width: 100%;"><?=$model->body_ru?></textarea>
                        </div>
                        <div class="col-sm-4">
                            <b>kiril</b>
                            <textarea name="body_eng" id="" class="form-control editor-full" cols="30" rows="10" style="min-height: 50px; min-width: 100%;"><?=$model->body_eng?></textarea>
                        </div>
                    </div>
                </div>
                <div class="block">
                    <button class="btn btn-success btn-block col-md-6">Saqlash</button>
                </div>
            </div>
        </form>
    </div>
    <!-- END PAGE CONTAINER -->
    <style>
        textarea { resize: vertical; min-height: 50px;}
    </style>
@endsection