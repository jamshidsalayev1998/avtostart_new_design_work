@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('news.index') }}">Yangiliklar</a></li>
            <li class="active"><?=$news['name_uz']?></li>
        </ul>
    </div>
    <!-- START PAGE CONTAINER -->
    <div class="container">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <b>O'zbek tilida</b>
                    <hr>
                    <?=$news['name_uz']?>
                </div>
                <div class="panel-body">
                    <?=$news['body_uz']?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <b>Rus tilida</b>
                    <hr>
                    <?=$news['name_ru']?>
                </div>
                <div class="panel-body">
                    <?=$news['body_ru']?>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <b>O'zbek tilida (Kiril)</b>
                    <hr>
                    <?=$news['name_eng']?>
                </div>
                <div class="panel-body">
                    <?=$news['body_eng']?>
                </div>
            </div>
        </div>
    </div>
    <!-- END PAGE CONTAINER -->
@endsection