<table class="table table-bordered datatable-extended">
	               			<thead>
	               				<tr>
	               					<th>#</th>
	               					<th>F.I.O</th>
	               					<th>Jinsi</th>
	               					<th>Tug`ilgan sanasi</th>
	               					<th>Passport</th>
	               					<th>Holati</th>
	               					<th>Davolanayotgan muassasa</th>
	               					<th>Viloyat , tuman</th>
	               					<th>Yashash manzili</th>
	               					<th>Telefon</th>
	               					<th>Kimdan yuqgan</th>
	               					<th>Qo`shimcha</th>
	               					<th>Tuzalgan sana</th>
	               					<th>Kiritilgan vaqt</th>
	               					<th></th>
	               				</tr>
	               			</thead>
	               			<tbody>
	               				@php $i=1; @endphp
	               				@foreach($data as $item)
	               				<tr>
	               					<td>{{ $i }}@php $i++; @endphp</td>
	               					<td>{{ $item->fio() }}</td>
	               					<td>
	               						@if($item->gender == 0)
	               						Ayol
	               						@else
	               						Erkak
	               						@endif
	               					</td>
	               					<td>
	               						{{ $item->birth_date }}
	               					</td>
	               					<td>{{ $item->passport_serial }}{{ $item->passport_number }}</td>
	               					<td>
	               						@if($item->status == 1)
	               						Kasal
	               						@endif
	               						@if($item->status == 2)
	               						Tuzalgan
	               						@endif
	               						@if($item->status == 0)
	               						@if($item->degree == 2)
	               						Bemor bilan bevosita aloqa
	               						@endif
	               						@if($item->degree == 3)
	               						Bemor bilan bilvosita aloqa
	               						@endif
	               						@endif
	               					</td>
	               					<td>{{ $item->hospital }}</td>
	               					<td>{{ $item->region()->name_uz }} {{ $item->area()->name  }}</td>
	               					<td>{{ $item->adress }}</td>
	               					<td>{{ $item->phone }}</td>
	               					<td>
	               						@if($item->patientBy() != null)
	               						{{ $item->patientBy()->fio() }}
	               						@endif
	               					</td>
	               					<td>{{ $item->additional }}</td>
	               					<td>{{ $item->recovered_date }}</td>
	               					<td>{{ $item->created_at }}</td>
	               					
	               				</tr>
	               				@endforeach
	               			</tbody>
	               		</table>