<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title></title>
</head>
<style type="text/css">
	body{
		 font-family: DejaVu Sans;
	}
	table.minimalistBlack {
  border: 1px solid #000000;
  width: 100%;
  text-align: left;
  border-collapse: collapse;
}
table.minimalistBlack td, table.minimalistBlack th {
  border: 1px solid #000000;
  padding: 2px 2px;
}
table.minimalistBlack tbody td {
  font-size: 13px;
}
table.minimalistBlack thead {
  background: #CFCFCF;
  background: -moz-linear-gradient(top, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
  background: -webkit-linear-gradient(top, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
  background: linear-gradient(to bottom, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
  border-bottom: 1px solid #000000;
}
table.minimalistBlack thead th {
  font-size: 15px;
  font-weight: bold;
  color: #000000;
  text-align: left;
  border-left: 0px solid #D0E4F5;
}
table.minimalistBlack thead th:first-child {
  border-left: none;
}

table.minimalistBlack tfoot {
  font-size: 14px;
  font-weight: bold;
  color: #000000;
  border-top: 1px solid #000000;
}
table.minimalistBlack tfoot td {
  font-size: 14px;
}
</style>
<body>
		<div style="width: 100%; text-align: center;">
			Bemorlarning yosh oraliqi bo`yicha hisoboti
			
			{{ date('Y-m-d') }}
			
		</div>
	<table class="minimalistBlack">
		<thead>
			<tr>
				<th>#</th>
	               					<th>
										Yosh oraliqlari
		               				</th>
	               					<th>Erkaklar</th>
	               					<th>Ayollar</th>
	               					<th>Jami</th>
	               					
			</tr>
		</thead>
		
		<tbody>
			@php $i=1; $e = 0; $a = 0; $u = 0;@endphp
	               				@foreach($data as $item)
	               				<tr>
	               					<td>{{ $i }}@php $i++; @endphp</td>
	               					<td>{{ $item['name_uz'] }}</td>
	               					<td>{{ $item['erkaklar'] }} @php $e = $e + $item['erkaklar'];@endphp </td>
	               					<td>{{ $item['ayollar'] }} @php $a = $a + $item['ayollar'];@endphp </td>
	               					<td>{{ $item['erkaklar']+$item['ayollar'] }} @php $u = $u + $item['erkaklar']+$item['ayollar']; @endphp </td>
	               					
	               				</tr>
	               				@endforeach
	               				<tr>
	               					<td>
	               						#
	               					</td>
	               					<td>
	               						Jami
	               					</td>
	               					<td>
	               						{{ $e }}
	               					</td>
	               					<td>
	               						{{ $a }}
	               					</td>
	               					<td>
	               						{{ $u }}
	               					</td>
	               				</tr>
		</tbody>
		</tr>
	</table>

</body>
</html>