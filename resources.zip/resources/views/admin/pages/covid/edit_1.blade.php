@extends('layouts.admin')

@section('content')
    <div class="container">
        

        <div class="block block-condensed">
        	 @if(session('message'))

                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                        <div class="alert-icon">

                            <span class="icon-checkmark-circle"></span>

                        </div>

                        {{ session('message') }}

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                    </div>

                @endif
        	<form action="{{  route('cov.update' , ['id' => $data->id]) }}" method="post">
    			{{ csrf_field() }}
    			{{ method_field('put') }}
        		
            <div class="block-content">
                <div class="row" style="margin-top: 20px; ">
                	
	                	<div class="col-md-12" style="margin-bottom: 15px; z-index: 3 !important; position: sticky;">
	                		<a class="btn btn-primary" style="z-index: 3 !important"><span class="fa fa-plus"></span> Qo`shish</a>
	                		<button class="btn btn-success" style="z-index: 3 !important"><span class="fa fa-save"></span> Saqlash</button>
	                	</div>
	                
                	<div class="col-md-12" >
                		<div class="col-md-6 ">
                			<div class="form-group">
	                			<label>Ism:</label>
	                			<input type="text" class="form-control" name="first_name" value="{{ $data->first_name }}" required>
	                		</div>
	                		<div class="form-group">
	                			<label>Familiya:</label>
	                			<input type="text" class="form-control" name="last_name" value="{{ $data->last_name }}" required>
	                		</div>
	                		<div class="form-group">
	                			<label>Otasining ismi:</label>
	                			<input type="text" class="form-control" name="middle_name" value="{{ $data->middle_name }}" required>
	                		</div>
	                		<div class="form-group">
	                			<label>Jinsi:</label><br>
	                			<div class="app-radio danger inline">

	                                <label><input type="radio" name="gender" id="gender"  value="0" @if($data->gender == 0) checked @endif> Ayol<span></span></label>

	                            </div>

	                            <div class="app-radio success inline">

	                                <label><input type="radio" name="gender" id="gender" value="1" @if($data->gender == 1) checked @endif  @if(old('gender')==1) checked @endif> Erkak<span></span></label>

	                            </div>
	                		</div>
	                		<div class="form-group">
	                			<div class="col-md-6">
	                				<label>Tug`ilgan sanasi</label>
		                			<div class="input-group bs-datepicker ">


		                                <input type="text" class="form-control"  name="birth_date"  required value="{{ $data->birth_date }}">

		                                <span class="input-group-addon">

		                                                  <span class="icon-calendar-full"></span>

		                                            </span>

		                            </div>
		                        </div>
	                		</div>
	                		<div class="form-group">
	                			<div class="col-md-6">
		                			<label>Telefon raqam
	                                     @if($errors->has('phone'))
	                                         <span class="text-danger"> | {{ $errors->first('phone') }}</span>
	                                     @endif
	                                </label>
	                                <input type="text" class="mask_tin form-control" value="{{ $data->phone }}" required  name="phone" id="phone">
	                                <span class="help-block">Masalan: 90-1234567</span>
	                            </div>
	                		</div>
	                		<div class="form-group">
	                			<div class="col-md-12">
	                			 	<label>Pasport seriyasi va raqami <span class="text-danger">*</span></label>
	                			</div>
	                			<div class="col-md-2">
		                            @if($errors->has('passport_serial'))

		                                <span class="text-danger"> | {{ $errors->first('passport_serial') }}</span>

		                            @endif

			                        <input class="form-control" required  placeholder="AA" value="{{ $data->passport_serial }}" id="passport_serial" name="passport_serial" maxlength="5" minlength="2">
				                </div>
				                <div class="col-md-10">
				                	@if($errors->has('passport_number'))

									        <span class="text-danger"> | {{ $errors->first('passport_number') }}</span>

									    @endif

									<input class="form-control" required  placeholder="1234567" value="{{ $data->passport_number }}" id="passport_number" name="passport_number" minlength="1" maxlength="7">
				                </div>
	                		</div>
                		</div>
                		<div class="col-md-6">
                			<div class="form-group">
                				<label>Kim bilan aloqada bo`lgan</label>
                				<select class="bs-select" data-live-search="true" name="patient_by">
                					<option>Tanlang</option>
                					@foreach($patients as $item)
                					@if($data->patient_by == $item->id)
                					<option selected value="{{ $item->id }}">{{ $item->fio() }}</option>
                					@else
                					<option value="{{ $item->id }}">{{ $item->fio() }}</option>
                					@endif
                					@endforeach
                				</select>
                			</div>
                			<div class="col-md-12" style="padding:0 0 15px 0">
		                        <div class="form-group">

									<label>Viloyati<span class="text-danger">*</span>

								    @if($errors->has('citizenship'))

								        <span class="text-danger"> | {{ $errors->first('citizenship') }}</span>

								    @endif

									</label>

									<select class="bs-select dynamic" name="region_id"  id="regions" data-live-search="true" data-dependent="citizenship" >
										<option>Tanlang</option>


								    @foreach($regions as $country)

								    @if($data->region_id == $country->id)
								     <option selected value="{{$country->id}}" >{{$country->name_uz}}</option>
								     @else
								     <option value="{{$country->id}}" >{{$country->name_uz}}</option>

								    @endif

								        
								    @endforeach

									</select>

								</div>
	                        </div>
	                        <div class="col-md-12" style="padding:0 0 15px 0">
	                        
		                        <div class="form-group">

									<label>Tumanni tanlang<span class="text-danger">*</span>

									    
									</label>
									@php $areas = 'Test\Model\Area'::where('region_id' , $data->region_id)->get(); @endphp
									<select required class="form-control" id="areas" data-live-search="true" data-dependent="area" name="area_id">
										@foreach($areas as $area)
										@if($data->area_id == $area->id)
										<option selected value="{{ $area->id }}">{{ $area->name }}</option>
										@else
										<option  value="{{ $area->id }}">{{ $area->name }}</option>
										@endif
										@endforeach
									</select>

								</div>
	                        </div>
	                        <div class="form-group">
	                        	<label>Uy manzili</label> 
	                        	<input type="text" class="form-control" name="adress" value="{{ $data->adress }}" required>
	                        </div>
	                       {{--  <div class="form-group">
		                        <div class="col-md-6">
			                        <div class="form-group">
			                        	<label>Holati</label>
			                        	<select class="form-control bs-select" name="status" required>
			                        		<option>Tanlang</option>
			                        		<option onclick="sog()" value="2" @if($data->status == 2) selected @endif>Sog`aygan</option>
			                        		<option value="1" @if($data->status == 1) selected @endif>Kasal</option>
			                        		<option value="0" @if($data->status == 0) selected @endif>Vafot etgan</option>
			                        	</select>
			                        </div>
		                    	</div>
		                        <div class="col-md-6">

			                        <div class="form-group" id="sog" >
			                        	<label>Sog`aygan sanasi</label>
			                        	<input type="date" class="form-control" value="{{ $data->recovered_date }}" name="recovered_date">
			                        </div>
			                    </div>
			                </div> --}}
	                        <div class="form-group">
	                        	<label>Davolanayotgan (davolangan) muassasa</label>
	                        	<input type="text" class="form-control" value="{{ $data->hospital }}" name="hospital">
	                        </div>
	                        <div class="form-group">
	                        	<label>Qo`shimcha ma`lumot</label>
	                        	<textarea class="form-control" name="additional" value="{{ $data->additional }}"></textarea>
	                        </div>
                		</div>
                	</div>
                	
                </div>
            </div>
        </form>
        </div>
        
    </div>



    <script type="text/javascript">
    	function sog(){
    		alert("dd");
    		document.getElementById("sog").style.display = 'block';
    	}
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script >
        $('#regions').change(function() {
            if ($(this).val() != '') {
                var _token = $('input[name="_token"]').val();
                var region_id = $(this).val();
                var url = '/backoffice/areas/' + region_id;
                $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        _token: _token,
                    },
                    success: function(result) {
                        var areas = JSON.parse(result);
                        var html = '<option>Tanlang</option>';
                        $.each(areas, function(key, value) {
                            html = html + '<option value="' + value["id"] + '">' + value['name'] + '</option>';
                        });
                        $('#areas').html(html);
                    }
                });
            }
        });
    </script>
    
@endsection