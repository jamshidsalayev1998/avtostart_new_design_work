@extends('layouts.admin')

@section('content')
<style type="text/css">
	.ddd{
		padding: 10px;
		border-bottom: 1px solid black;
		border-top: 1px solid black;
		font-weight: bold;
	}
</style>
    <div class="container">
        <div class="app-heading-container app-heading-bordered bottom">
	        <ul class="breadcrumb">
	            
	            @if($data->degree == 1)
	             <li><a href="{{ route('cov.index') }}">Bemorlar</a></li>
	             @endif
	             @if($data->degree == 2)
	             <li><a href="{{ route('cov.index_1') }}">1-darajali aloqada bo`lganlar</a></li>
	             @endif
	             @if($data->degree == 3)
	             <li><a href="{{ route('cov.index_2') }}">2-darajali aloqada bo`lganlar</a></li>
	             @endif
	        </ul>
	        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

	    </div>
	    <div class="app-heading app-heading-bordered app-heading-page">
	    	<div class="col-md-12" style="margin-top: 15px;">

	               		@if($data->degree == 2 || $data->degree == 3)
	               		<a href="#" class="btn btn-danger" onclick="return confirm('Bu bemorda kasallik tasdiqlandimi?')">Kasallikni tasdiqlash</a>
	               		@endif
	               		@if($data->degree == 1)
	               		<a href="#" data-toggle="modal" data-target="#myModal" class="btn btn-danger" >Bemor holatini o`zgartirish</a>
	               		 <div class="modal fade" id="myModal">
						    <div class="modal-dialog modal-sm">
						    	<form action="{{ route('cov.change.status' , ['id' => $data->id]) }}" method="post">
						    		{{ @csrf_field() }}
						    		{{ method_field('put') }}
						      <div class="modal-content">
						      
						        <!-- Modal Header -->
						        <div class="modal-header">
						          <h4 class="modal-title">Bemorning yangi holatini tanlang</h4>
						          <button type="button" class="close" data-dismiss="modal">&times;</button>
						        </div>
						        
						        <!-- Modal body -->
						        <div class="modal-body">
						          <div class="row">
						          	<div class="col-md-12">
						          		<div class="col-md-1"><input type="radio" value="2" id="status" name="status"></div>
						          		<div class="col-md-8"><label>Tuzalgan</label></div><br><hr>
						          		<div class="col-md-1"><input type="radio" value="0" id="status" name="status"></div>
						          		<div class="col-md-8"><label>Vafot etgan</label></div>
						          	</div>
						          </div>
						        </div>
						        
						        <!-- Modal footer -->
						        <div class="modal-footer">
						          <a type="button" class="btn btn-secondary" data-dismiss="modal">Close</a>
						          <button  type="submit" class="btn btn-success" >Saqlash</button>

						        </div>
						        
						      </div>
						  	</form>
						    </div>
						  </div>
	               		@endif
	               		<a href="{{ route('aloqada_bolganlar' , ['id' => $data->id]) }}" class="btn btn-info"> <span class="fa fa-list"></span> Aloqada bo`lganlar</a>
	               		<a href="{{ route('cov.edit' , ['id' => $data->id]) }}" class="btn btn-default"> <span class="fa fa-pencil"></span></a>
	               	</div>
			    </div>
        <div class="block block-condensed">
        	 @if(session('message'))

                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                        <div class="alert-icon">

                            <span class="icon-checkmark-circle"></span>

                        </div>

                        {{ session('message') }}

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                    </div>

                @endif
	            <div class="block-content">
	               <div class="row"  style="padding-right: 10%; padding-left: 10%;">

	               	
	               	<div class="col-md-12 text-center" style="margin-top: 15px;">
	               		@if($data->degree == 1 && $data->status != 3)
	               		<h2>Bemor</h2>
	               		@endif
	               		@if($data->degree == 2)
	               		<h2>Birinchi darajali aloqada bo`lgan</h2>
	               		@endif
	               		@if($data->degree == 3)
	               		<h2>Ikkinchi darajali aloqada bo`lgan</h2>
	               		@endif
	               	</div>
	               	<div class="col-md-12 ddd" style="margin-top: 15px;">
	               		<div class="col-md-6">
	               			F.I.O
	               		</div>
	               		<div class="col-md-6">
	               			{{ $data->fio() }}
	               		</div>
	               	</div>
	               	<div class="col-md-12 ddd">
	               		<div class="col-md-6">
	               			Passport
	               		</div>
	               		<div class="col-md-6">
	               			{{ $data->passport_serial }} {{ $data->passport_number }}
	               		</div>
	               	</div>
	               	<div class="col-md-12 ddd">
	               		<div class="col-md-6">
	               			Viloyat , tuman
	               		</div>
	               		<div class="col-md-6">
	               			{{ $data->region()->name_uz }} {{ $data->area()->name }}
	               		</div>
	               	</div>
	               	<div class="col-md-12 ddd">
	               		<div class="col-md-6">
	               			Yashash manzili
	               		</div>
	               		<div class="col-md-6">
	               			{{ $data->adress }}
	               		</div>
	               	</div>
	               	<div class="col-md-12 ddd">
	               		<div class="col-md-6">
	               			Telefon
	               		</div>
	               		<div class="col-md-6">
	               			{{ $data->phone }}
	               		</div>
	               	</div>
	               	<div class="col-md-12 ddd">
	               		<div class="col-md-6">
	               			Kim bilan aloqada bo`lgan
	               		</div>
	               		<div class="col-md-6">
	               			@if($data->patientBy() != null)
	               			{{ $data->patientBy()->fio() }}
	               			@endif
	               		</div>
	               	</div>
	               	<div class="col-md-12 ddd">
	               		<div class="col-md-6">
	               			Holati
	               		</div>
	               		<div class="col-md-6">
	               			@if($data->status == 1)
	               			Kasal
	               			@endif
	               			@if($data->status == 2)
	               			Tuzalgan
	               			@endif
	               			@if($data->status == 3)
	               			Vafot etgan
	               			@endif
	               			@if($data->status == 0)
	               			@if($data->degree == 2)
	               			Bemor bilan bevosita muloqot
	               			@endif
	               			@if($data->degree == 3)
	               			Bemor bilan bilvosita muloqot
	               			@endif
	               			@endif
	               		</div>
	               	</div>
	               	<div class="col-md-12 ddd">
	               		<div class="col-md-6">
	               			Davolanayotgan muassasa
	               		</div>
	               		<div class="col-md-6">
	               			{{ $data->hospital }}
	               		</div>
	               	</div>
	               	<div class="col-md-12 ddd">
	               		<div class="col-md-6">
	               			Qo`shimcha malumot
	               		</div>
	               		<div class="col-md-6">
	               			{{ $data->additional }}
	               		</div>
	               	</div>
	               </div>
	            </div>
	        
        </div>
        
    </div>



    
    
@endsection