@extends('layouts.admin')

@section('content')
    <div class="container">
    	 @if(isset($stt) && $stt == 'tuman')
    	<div class="app-heading-container app-heading-bordered bottom">
	        <ul class="breadcrumb">
	            
	            <li><a href="{{ route('cov.hisobot') }}">Hisobot</a></li>
	        </ul>
	        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

	    </div>
	    @endif
        <div class="app-heading app-heading-bordered app-heading-page">
        	<div class="col-md-12">

			        @if(isset($stt) && $stt == 'tuman')
			        <b style="margin-right: 10px;">{{ $region->name_uz }} viloyati bo`yicha hisobot</b>
			                        	<a class="btn btn-default" href="{{ route('cov.hisobot_area_pdf' , ['id' => $region->id]) }}" >
			                        		<span  class="fa fa-file-pdf-o">&nbsp;&nbsp;</span> Pdf ga export
			                        	</a>
			                        	@else
			                        	 <div class="col-md-3"><b style="font-size: 17px;">Hisobotlar</b></div>
			                        	<div class="col-md-1">
			                        		<a id="for_pdf" class="btn btn-default" href="{{ route('cov.hisobot_pdf') }}" >
				                        		<span  class="fa fa-file-pdf-o">&nbsp;&nbsp;</span> Pdf ga export
				                        	</a>
			                        	</div>
			                        	
			                        	
			                        	
			                        	@endif
			</div>
		</div>
        <div class="block block-condensed">
        	 @if(session('message'))

                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                        <div class="alert-icon">

                            <span class="icon-checkmark-circle"></span>

                        </div>

                        {{ session('message') }}

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                    </div>

                @endif
                
	            <div class="block-content"  >
	               <div class="row" >
	               	<div class="col-md-12" style="margin-top: 0px">
	               		@if($stt != 'tuman')
	               		<div class="app-content-tabs">
	                        <ul>
	                            <li><a id="by_region" href="#viloyat" class="active">Viloyatlar bo`yicha</a></li>
			        			@if($stt != 'tuman')

	                            <li id="age"><a id="by_age" href="#yosh"> Bemorlar yoshi bo`yicha</a></li>
	                            @endif
	                        </ul>
	                    </div>
	                    @endif
	               		
	               	</div>
	               	<div class="container app-content-tab active" id="viloyat">
		               	<div class="col-md-12" style="margin-top: 20px">
		               		<table class="table hh table-bordered ">
		               			<thead>
		               				<tr>
		               					<th>#</th>
		               					<th>
			               					@if(isset($stt) && $stt == 'tuman')
											Tumanlar
											@else
											Viloyatlar
											@endif

			               				</th>
		               					<th>Erkaklar</th>
		               					<th>Ayollar</th>
		               				</tr>
		               			</thead>
		               			<tbody>
		               				@php $i=1; @endphp
		               				@foreach($data as $item)
		               				<tr href="{{ route('cov.hisobot.area' , ['id' => $item->id]) }}">
		               					<td>{{ $i }}@php $i++; @endphp</td>
		               					<td>{{ $item->name_uz }}</td>
		               					<td>{{ $item->erkaklar }}</td>
		               					<td>{{ $item->ayollar}}</td>
		               					
		               				</tr>
		               				@endforeach
		               				<tr>
		               					<td>
		               						#
		               					</td>
		               					<td>
		               						Jami
		               					</td>
		               					<td>
		               						{{ $data->sum('erkaklar') }}
		               					</td>
		               					<td>
		               						{{ $data->sum('ayollar') }}
		               					</td>
		               				</tr>
		               			</tbody>
		               		</table>
		               	</div>
		            </div>
			        @if($stt != 'tuman')

		            <div class="container app-content-tab" id="yosh">
		               	<div class="col-md-12" style="margin-top: 20px">
		               		<table class="table table-bordered ">
		               			<thead>
		               				<tr>
		               					<th>#</th>
		               					<th>
			               					Yosh oraliqlari
			               				</th>
		               					<th>Erkaklar</th>
		               					<th>Ayollar</th>
		               					<th>Jami</th>
		               				</tr>
		               			</thead>
		               			<tbody>
		               				@php $i=1; $e = 0; $a = 0; $u = 0; @endphp
		               				@foreach($data2 as $item)
		               				<tr>
		               					<td>{{ $i }}@php $i++; @endphp</td>
		               					<td>{{ $item['name_uz'] }}</td>
		               					<td>{{ $item['erkaklar'] }} @php $e = $e + $item['erkaklar'];@endphp </td>
		               					<td>{{ $item['ayollar'] }} @php $a = $a + $item['ayollar'];@endphp </td>
		               					<td>{{ $item['erkaklar']+$item['ayollar'] }} @php $u = $u + $item['erkaklar']+$item['ayollar']; @endphp </td>
		               					
		               				</tr>
		               				@endforeach
		               				<tr>
		               					<td>
		               						#
		               					</td>
		               					<td>
		               						Jami
		               					</td>
		               					<td>
		               						{{ $e }}
		               					</td>
		               					<td>
		               						{{ $a }}
		               					</td>
		               					<td>
		               						{{ $u }}
		               					</td>
		               				</tr>
		               			</tbody>
		               		</table>
		               	</div>
		            </div>
		            @endif
	               </div>
	            </div>
	        
        </div>
        
    </div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

@if(!isset($stt) || $stt != 'tuman')
<script type="text/javascript">
	$(document).ready(function(){
		$('table tr').css({
			'cursor' : 'pointer',

		});
		$('table tr').hover(function() {
			$(this).css({
				'background-color':'#EDEFF0',
			});
		}, function() {
			$(this).css({
				'background-color':'#FFFFFF',
			});
		});
		
        $('.hh').on('click' , 'tr' , function(){
            window.location = $(this).attr('href');
            return false;

        })
        $('#by_age').click(function() {
        	var url = '/backoffice/cov_hisobot_age_pdf';
        	$('#for_pdf').attr('href' , url);
        });
        $('#by_region').click(function() {
        	var url = '/backoffice/cov_hisobot_pdf';
        	$('#for_pdf').attr('href' , url);
        });
    });
</script>
@endif
    
    
@endsection