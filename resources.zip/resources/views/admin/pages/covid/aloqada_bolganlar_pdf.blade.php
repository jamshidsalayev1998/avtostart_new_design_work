<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title></title>
</head>
<style type="text/css">
	body{
		 font-family: DejaVu Sans;
	}
	table.minimalistBlack {
  border: 1px solid #000000;
  width: 100%;
  text-align: left;
  border-collapse: collapse;
}
table.minimalistBlack td, table.minimalistBlack th {
  border: 1px solid #000000;
  padding: 2px 2px;
}
table.minimalistBlack tbody td {
  font-size: 13px;
}
table.minimalistBlack thead {
  background: #CFCFCF;
  background: -moz-linear-gradient(top, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
  background: -webkit-linear-gradient(top, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
  background: linear-gradient(to bottom, #dbdbdb 0%, #d3d3d3 66%, #CFCFCF 100%);
  border-bottom: 1px solid #000000;
}
table.minimalistBlack thead th {
  font-size: 15px;
  font-weight: bold;
  color: #000000;
  text-align: left;
  border-left: 0px solid #D0E4F5;
}
table.minimalistBlack thead th:first-child {
  border-left: none;
}

table.minimalistBlack tfoot {
  font-size: 14px;
  font-weight: bold;
  color: #000000;
  border-top: 1px solid #000000;
}
table.minimalistBlack tfoot td {
  font-size: 14px;
}
</style>
<body>
	<div style="width: 100%; text-align: center;">
		Aloqada bo`lgan shaxslar ro`yhati <br>
		<p>
		{{ $self->first_name }} {{ $self->last_name }} {{ $self->middle_name }} 
	</p>
	</div>
	
	<table class="minimalistBlack">
		<thead>
			<tr>
				<th>#</th>
	               					<th>F.I.O</th>
	               					<th>Davolanayotgan muassasa</th>
	               					<th>Viloyat , tuman</th>
	               					<th>Yashash manzili</th>
	               					<th>Tug`ilgan sanasi</th>
	               					<th>Passport</th>
	               					<th>Holati</th>
	               					<th>Telefon</th>
			</tr>
		</thead>
		
		<tbody>
			@php $i=1; @endphp
			@foreach($data as $item)
			<tr>
				<td class="tdb">{{ $i }}@php $i++; @endphp</td>
	               					<td class="tdb">{{ $item->fio() }}</td>
	               					<td class="tdb">{{ $item->hospital }}</td>
	               					<td class="tdb">{{ $item->region()->name_uz }} {{ $item->area()->name  }}</td>
	               					<td class="tdb">{{ $item->adress }}</td>
	               					<td class="tdb">{{ $item->birth_date }}</td>
	               					<td class="tdb">{{ $item->passport_serial }}{{ $item->passport_number }}</td>
	               					<td class="tdb">
	               						@if($item->status == 1)
	               						Kasal
	               						@endif
	               						@if($item->status == 2)
	               						Tuzalgan
	               						@endif
	               						@if($item->status == 0)
	               						Vafot etgan
	               						@endif
	               					</td>
	               					<td class="tdb">{{ $item->phone }}</td>
			</tr>
			@endforeach
		</tbody>
		</tr>
	</table>

</body>
</html>