@extends('layouts.admin')

@section('content')
    <div class="container">
       <div class="app-heading app-heading-bordered app-heading-page">

			        
			        <div class="col-md-12">
			        	<div class="col-md-8">
			        		<b style="font-size: 17px;">Bemorlar bilan 1-darajali aloqa qilganlar ro`yhati</b>
			        	</div>
	               		<div class="col-md-2 text-right">
	               			<a href="{{  route('cov.create_1') }}" class="btn btn-info"><span class="fa fa-plus"></span> Qo`shish</a>
	               			
	               		</div>
	               		<div class="col-md-2">
	               			<a class="btn btn-default" href="{{ route('cov.excel.export' , ['id' => '2']) }}" >
			                        		<span  class="fa fa-file-excel-o">&nbsp;&nbsp;</span> Excelga export
			                        	</a>
	               		</div>
	               		
	               		
	               	</div>
			    </div>
        <div class="block block-condensed">
        	 @if(session('message'))

                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                        <div class="alert-icon">

                            <span class="icon-checkmark-circle"></span>

                        </div>

                        {{ session('message') }}

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                    </div>

                @endif
	            <div class="block-content">
	               <div class="row" >
	               	
	               	<div class="col-md-12" style="margin-top: 20px">
	               		<table class="table table-bordered datatable-extended">
	               			<thead>
	               				<tr>
	               					<th>#</th>
	               					<th>F.I.O</th>
	               					<th>Davolanayotgan muassasa</th>
	               					<th>Viloyat , tuman</th>
	               					<th>Yashash manzili</th>
	               					<th>Telefon</th>
	               					<th>Kiritilgan vaqt</th>
	               					<th></th>
	               					<th></th>
	               					<th>Kasallikni tasdiqlash</th>
	               				</tr>
	               			</thead>
	               			<tbody>
	               				@php $i=1; @endphp
	               				@foreach($data as $item)
	               				<tr>
	               					<td>{{ $i }}@php $i++; @endphp</td>
	               					<td>{{ $item->fio() }}</td>
	               					<td>{{ $item->hospital }}</td>
	               					<td>{{ $item->region()->name_uz }} {{ $item->area()->name  }}</td>
	               					<td>{{ $item->adress }}</td>
	               					<td>{{ $item->phone }}</td>
	               					<td>{{ $item->created_at }}</td>
	               					<td>
	               						<a href="{{ route('cov.show', ['id' => $item->id]) }}" class="btn btn-default btn-icon">
	                                        <i class="fa fa-eye"></i>
	                                    </a>
	               					</td>
	               					<td>
	               						<a href="{{ route('cov.edit_1', ['id' => $item->id]) }}" class="btn btn-default btn-icon">
	                                        <i class="icon-pencil"></i>
	                                    </a>
	               					</td>
	               					<td>
	               						<a  onclick="return confirm('Bu bemorda kasallik tasdiqlandimi?')" href="{{ route('cov.tasdiqlash', ['id' => $item->id]) }}" class="btn btn-danger btn-icon">
	                                        <i class="icon-checkmark-circle"></i>
	                                    </a>
	               					</td>
	               				</tr>
	               				@endforeach
	               			</tbody>
	               		</table>
	               	</div>
	               </div>
	            </div>
	        
        </div>
        
    </div>



    
    
@endsection