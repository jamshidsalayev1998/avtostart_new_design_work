@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="app-heading-container app-heading-bordered bottom">
            <ul class="breadcrumb">
                <li><a href="/backoffice">Dashboard</a></li>
               
            </ul>
        </div>

        <div class="block block-condensed">
            <div class="block-content">
                jkhskhdf
            </div>
        </div>
        
    </div>
    
    
@endsection