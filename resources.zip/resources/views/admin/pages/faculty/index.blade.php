@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">

                    <div class="panel-heading">
                        <h3 class="panel-title"></h3>
                    </div>

                    <div class="panel-body">

                        @if(session('message'))
                        <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                            <div class="alert-icon">
                                <span class="icon-checkmark-circle"></span>
                            </div>
                            {{ session('message') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                        </div>
                        @endif

                        <div class="col-md-12 pull-left" style="height: 100vh; margin-bottom: 20px">
                            <div class="app-accordion" data-type="full-height" data-open="close-other">

                                @foreach($university as $univer)
                                <div class="item">
                                    <div class="heading">
                                        <div class="title">{{ $univer->name_uz }}</div>
                                    </div>
                                    <div class="content">
                                        <div class="block">

                                            @php $count = 0 @endphp

                                            <h3>O'zbek guruh yo'nalishlari</h3>

                                            <table class="table table-hover table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center" style="width: 2%;">#</th>
                                                        <th class="text-center">Yo'nalish nomi</th>
                                                        <th class="text-center">Yo'nalish kodi</th>
                                                        <th class="text-center">Qabul kvotasi</th>
                                                        <th class="text-center">O'tish bali</th>
                                                        <th colspan="2" style="width: 5%;"></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                @foreach(\Test\Model\Faculty::where([['univer_id', $univer->id], ['type', 'uz']])->get() as $faculty)
                                                    <tr>
                                                        <td class="text-center">{{ ++$count }}</td>
                                                        <td class="text-center">{{ $faculty->name_uz }}</td>
                                                        <td class="text-center">{{ $faculty->code }}</td>
                                                        <td class="text-center">
                                                            @php $plan = json_decode($faculty->plan, true); @endphp

                                                            {{ $plan['plan'] }}<br>
                                                            {{ $plan['plan_grant'] }} / {{ $plan['plan_contract'] }}
                                                        </td>
                                                        <td class="text-center">
                                                            @php $pas_score = json_decode($faculty->passing_score, true); @endphp

                                                            {{ $pas_score['passing_score'] }}<br>
                                                            {{ $pas_score['passing_score_all'] }}
                                                        </td>
                                                        <td>
                                                            <a href="{{ route('faculty.edit', ['id' => $faculty->id]) }}" class="btn btn-default btn-icon">
                                                                <i class="fa fa-pencil"></i>
                                                            </a>
                                                        </td>
                                                        <td>
                                                            <form action="{{ route('faculty.destroy', ['id' => $faculty->id]) }}" method="post">
                                                                {{ csrf_field() }}
                                                                {{ method_field('delete') }}
                                                                <button class="btn btn-default btn-icon deleteData">
                                                                    <i class="fa fa-trash-o"></i>
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                </tbody>
                                            </table>

                                            <h3>Rus guruh yo'nalishlari</h3>

                                            <table class="table table-hover table-bordered">
                                                <thead>
                                                <tr>
                                                    <th class="text-center" style="width: 2%;">#</th>
                                                    <th class="text-center">Yo'nalish nomi</th>
                                                    <th class="text-center">Yo'nalish kodi</th>
                                                    <th class="text-center">Qabul kvotasi</th>
                                                    <th class="text-center">O'tish bali</th>
                                                    <th colspan="2" style="width: 5%;"></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                @foreach(\Test\Model\Faculty::where([['univer_id', $univer->id], ['type', 'ru']])->get() as $faculty)
                                                <tr>
                                                    <td class="text-center">{{ ++$count }}</td>
                                                    <td class="text-center">{{ $faculty->name_uz }}</td>
                                                    <td class="text-center">{{ $faculty->code }}</td>
                                                    <td class="text-center">
                                                        @php $plan = json_decode($faculty->plan, true); @endphp

                                                        {{ $plan['plan'] }}<br>
                                                        {{ $plan['plan_grant'] }} / {{ $plan['plan_contract'] }}
                                                    </td>
                                                    <td class="text-center">
                                                        @php $pas_score = json_decode($faculty->passing_score, true); @endphp

                                                        {{ $pas_score['passing_score'] }}<br>
                                                        {{ $pas_score['passing_score_all'] }}
                                                    </td>
                                                    <td>
                                                        <a href="{{ route('faculty.edit', ['id' => $faculty->id]) }}" class="btn btn-default btn-icon">
                                                            <i class="fa fa-pencil"></i>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <form action="{{ route('faculty.destroy', ['id' => $faculty->id]) }}" method="post">
                                                            {{ csrf_field() }}
                                                            {{ method_field('delete') }}
                                                            <button class="btn btn-default btn-icon deleteData">
                                                                <i class="fa fa-trash-o"></i>
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                                @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                @endforeach

                            </div>
                        </div>

                        {!! $university->links() !!}
                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection