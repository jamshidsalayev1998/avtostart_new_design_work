@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">

            <form action="{{ route('faculty.update', ['id' => $data->id]) }}" method="post">
                {{ csrf_field() }}
                {{ method_field('put') }}

                <div class="col-md-3">
                    <div class="panel panel-default">

                        <div class="panel-heading">
                            <h3 class="panel-title">Yangi yo'nalish qo'shish</h3>
                        </div>

                        <div class="panel-body">

                            <button class="btn btn-success btn-block">Saqlash</button>

                            <label for="code" class="margin-top-20 ">Yo'nalish kodi</label>
                            @if($errors->has('code'))
                                <span class="text-danger">{{ $errors->first('code') }}</span>
                            @endif
                            <input type="number" value="{{ $data->code }}" name="code" id="code" class="form-control" required>

                            <label for="type" class="margin-top-20">Qaysi guruh uchun</label>
                            @if($errors->has('type'))
                                <span class="text-danger">{{ $errors->first('type') }}</span>
                            @endif
                            <select name="type" id="type" class="form-control">
                                <option @if($data->type == 'ru') selected @endif value="ru">Rus guruh uchun</option>
                                <option @if($data->type == 'uz') selected @endif value="uz">O'zbek guruh uchun</option>
                            </select>

                            <label for="univer_id" class="margin-top-20">Oliygohni tanlang</label>
                            @if($errors->has('univer_id'))
                                <span class="text-danger">{{ $errors->first('univer_id') }}</span>
                            @endif
                            <select name="univer_id" id="univer_id" class="form-control">

                                @foreach($university as $univer)
                                    <option @if($data->univer_id == $univer->id) selected @endif value="{{ $univer->id }}">{{ $univer->name_uz }}</option>
                                @endforeach

                            </select>

                        </div>

                    </div>
                </div>

                <div class="col-md-9">
                    <div class="panel panel-default">

                        <div class="panel-heading">
                            <h3 class="panel-title"></h3>
                        </div>

                        <div class="panel-body">
                            <div class="app-heading app-heading-small app-heading-condensed">
                                <div class="title">
                                    <h2>Administrator uchun eslatma!</h2>
                                    <p>O'zbek guruh va rus guruh qismidagi ma'lumotlarning barchasi o'sha tilda to'ldirilishi kerak. Barcha kiritilgan ma'lumotlar saytga to'g'ridan to'gri taqdim etiladi</p>
                                </div>
                            </div>

                            <div>
                                <ul class="nav nav-pills nav-justified nav-pills-bordered">
                                    <li class="active"><a href="#pills-10" data-toggle="tab" aria-expanded="true">O'zbek guruh</a></li>
                                    <li class=""><a href="#pills-11" data-toggle="tab" aria-expanded="false">Rus guruh</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="pills-10">

                                        <label for="name_uz">Yo'nalish nomi</label>
                                        @if($errors->has('name_uz'))
                                            <span class="text-danger">{{ $errors->first('name_uz') }}</span>
                                        @endif
                                        <input type="text" value="{{ $data->name_uz }}" name="name_uz" id="name_uz" class="form-control" required>

                                        <label for="science_uz" class="margin-top-20">Fanlar ro'yxati</label>
                                        @if($errors->has('science_uz'))
                                            <span class="text-danger">{{ $errors->first('science_uz') }}</span>
                                        @endif
                                        <input type="text" value="{{ $data->science_uz }}" name="science_uz" id="science_uz" class="form-control" required>


                                    </div>
                                    <div class="tab-pane" id="pills-11">

                                        <label for="name_ru">Yo'nalish nomi</label>
                                        @if($errors->has('name_ru'))
                                            <span class="text-danger">{{ $errors->first('name_ru') }}</span>
                                        @endif
                                        <input type="text" value="{{ $data->name_ru }}" name="name_ru" id="name_ru" class="form-control">

                                        <label for="science_ru" class="margin-top-20">Fanlar ro'yxati</label>
                                        @if($errors->has('science_ru'))
                                            <span class="text-danger">{{ $errors->first('science_ru') }}</span>
                                        @endif
                                        <input type="text" value="{{ $data->science_ru }}" name="science_ru" id="science_ru" class="form-control">

                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="panel-body">

                            @php $plan = json_decode($data->plan, true) @endphp
                            <div class="col-md-4">
                                <label for="plan">Qabul kvotasi (Umumiy)</label>
                                <input type="number" value="{{ $plan['plan'] }}" step="any" name="plan" id="plan" class="form-control">
                            </div>

                            <div class="col-md-4">
                                <label for="plan_grant">Qabul kvotasi (Grant)</label>
                                <input type="number" value="{{ $plan['plan_grant'] }}" step="any" name="plan_grant" id="plan_grant" class="form-control">
                            </div>

                            <div class="col-md-4">
                                <label for="plan_contract">Qabul kvotasi (Shartnoma)</label>
                                <input type="number" value="{{ $plan['plan_contract'] }}" step="any" name="plan_contract" id="plan_contract" class="form-control">
                            </div>

                            @php $competition = json_decode($data->competition, true) @endphp
                            <div class="margin-top-20 col-md-6">
                                <label for="competition">Konkurs</label>
                                <input type="number" value="{{ $competition['competition'] }}" step="any" name="competition" id="competition" class="form-control">
                            </div>

                            <div class="margin-top-20 col-md-6">
                                <label for="competition_all">Konkurs (Umumiy)</label>
                                <input type="number" value="{{ $competition['competition_all'] }}" step="any" name="competition_all" id="competition_all" class="form-control">
                            </div>

                            @php $pas_score = json_decode($data->passing_score, true) @endphp
                            <div class="col-md-6 margin-top-20">
                                <label for="passing_score">O'tish bali</label>
                                <input type="number" value="{{ $pas_score['passing_score'] }}" step="any" name="passing_score" id="passing_score" class="form-control">
                            </div>

                            <div class="col-md-6 margin-top-20">
                                <label for="passing_score_all">O'tish bali (yuqorisi)</label>
                                <input type="number" value="{{ $pas_score['passing_score_all'] }}" step="any" name="passing_score_all" id="passing_score_all" class="form-control">
                            </div>

                            @php $budget = json_decode($data->budget, true) @endphp
                            <div class="col-md-6 margin-top-20">
                                <label for="budget">Byudjet</label>
                                <input type="number" value="{{ $budget['budget'] }}" step="any" name="budget" id="budget" class="form-control">
                            </div>

                            <div class="col-md-6 margin-top-20">
                                <label for="budget_all">Byudjet (yuqorisi)</label>
                                <input type="number" value="{{ $budget['budget_all'] }}" step="any" name="budget_all" id="budget_all" class="form-control">
                            </div>
                        </div>

                    </div>
                </div>

            </form>

        </div>
    </div>
@endsection