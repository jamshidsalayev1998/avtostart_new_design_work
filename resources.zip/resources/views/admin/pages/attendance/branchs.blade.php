@extends('layouts.admin')
@section('content')
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="block block-condensed">
                <br>
                <div class="block-content" style="width: 100%; overflow: auto;">

                    <table class="table table-striped table-bordered datatable-extended" id="data-table">
                        <thead>
                        <tr>
                            <th>FIO</th>
                            <th>Viloyat</th>
                            <th>Tuman</th>
                            <th>Filial</th>
                            <th>Qoldirilgan darslar soni</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $item)
                            <tr>
                                <td><a href="{{ route('student.show',['id'=>$item->student_id]) }}" >{{$item->last_name.' '.$item->first_name.' '.$item->middle_name}} </a></td>
                                <td>{{$item->region}}</td>
                                <td>{{$item->tuman}}</td>
                                <td>{{$item->branch}}</td>
                                <td>{{$item->cnt}}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection