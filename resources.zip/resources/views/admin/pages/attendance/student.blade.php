@extends('layouts.admin')
@section('content')
    @php $i = ($data->currentPage() - 1) * $data->perPage() + 1 @endphp
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="block block-condensed">
                <br>
                <div class="block-content" style="width: 100%; overflow: auto;">

                    <table class="table table-striped table-bordered" id="data-table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>FIO</th>
                            <th>Filial</th>
                            <th>Guruh</th>
                            <th>Ta'lim boshlanish vaqti</th>
                            <th>Ta'lim boshlanish vaqti</th>
                            <th>Qoldirilgan darslar soni</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $item)
                            <tr>
                                <th>{{$i++}}</th>
                                <td><a href="{{ route('student.show',['id'=>$item->student_id]) }}" >{{$item->last_name.' '.$item->first_name.' '.$item->middle_name}} </a></td>
                                <td><a href="branch/{{$item->branch_id}}" >{{$item->branch}}</a></td>
                                <td><a href="group/{{$item->group_id}}" >{{$item->group_name}}</a></td>
                                <td>{{$item->edu_starting_date}}</td>
                                <td>{{$item->edu_ending_date}}</td>
                                <td>{{$item->cnt}}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    <div class="row">
                        <div class="col-sm-5">
                            Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i - 1}} of {{$data->total()}} entries
                        </div>
                        <div class="col-sm-7">
                            {{ $data->links() }}
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection