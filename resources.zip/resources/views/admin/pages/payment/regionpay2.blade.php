@extends('layouts.admin_alisher')



@section('content')

    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp


                    <div class="title-link">
                        <div>
                            <h1>Qarzdorlar</h1>
                            <p><span>Bosh sahifa</span>/Qarzdorlar</p>
                        </div>
                        
                    </div>
                    <div class="table-toifa">
                    <h1>Qarzdorlar  </h1>
                    <div class="table-content">
                        <table class="table-hover">

                        <thead>

                        <tr>

                            <th style="width: 2%" rowspan="2"  ><p># </p></th>

                            <th style="text-align: center" rowspan="2"><p>{{($data) ? ' Viloyat  Nomi' : 'Filial nomi'}}

                             </p></th>

                                <th style="text-align: center" colspan="5"><p>{{empty($branch) ? 'Yillar bo`yicha tushum summasi' : 'Filial nomi'}} </p></th>

                          

                        </tr>
                                <th style="text-align: center"><p>{{$now_year_new-4}} </p></th>
                                <th style="text-align: center"><p>{{$now_year_new-3}} </p></th>
                                <th style="text-align: center"><p>{{$now_year_new-2}} </p></th>
                                <th style="text-align: center"><p>{{$now_year_new-1}} </p></th>
                                <th style="text-align: center"><p>{{$now_year_new}} </p></th>
                        </thead>

                            <tbody>

                            @foreach($count as $item)
                            @if(($item->name_uz))
                                <tr>

                                    <td><p>{{++$i}} </p></td>

                                    <td><p><a class="paygroup-a" href="{{'branchpay4'}}/{{ $item->id }}">{{$item->name_uz}}</a></p></td>

                                    <td style="text-align: center"><p>
                                        @if(($item->sum4))
                                        {{number_format($item->sum4, 0, ',', ' ')}}
                                        @endif
                                        @if(!($item->sum4))
                                             0
                                        @endif </p>
                                        </td>
                                        <td style="text-align: center"><p>
                                        @if(($item->sum3))
                                        {{number_format($item->sum3, 0, ',', ' ')}}
                                        @endif
                                        @if(!($item->sum3))
                                             0
                                        @endif </p>
                                        </td>
                                        <td style="text-align: center"><p>
                                        @if(($item->sum2))
                                        {{number_format($item->sum2, 0, ',', ' ')}}
                                        @endif
                                        @if(!($item->sum2))
                                             0
                                        @endif </p>
                                        </td>
                                        <td style="text-align: center"><p>
                                        @if(($item->sum1))
                                        {{number_format($item->sum1, 0, ',', ' ')}}
                                        @endif
                                        @if(!($item->sum1))
                                             0
                                        @endif </p>
                                        </td>
                                        <td style="text-align: center"><p>
                                        @if(($item->sum))
                                        {{number_format($item->sum, 0, ',', ' ')}}
                                        @endif
                                        @if(!($item->sum))
                                             0
                                        @endif </p>
                                        </td>

                                   

                                </tr>
                                @endif
                            @endforeach

                            

                            </tbody>

                        </table>

                       

                    </div>

                </div>




@endsection