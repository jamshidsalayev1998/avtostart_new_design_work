@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>
            <li><a href="/backoffice/region/{{ $data->region->id }}">{{ $data->region->name_uz }}</a></li>
            <li class="active">{{ $data->name_uz }}</li>
        </ul>
    </div>
    <!-- START PAGE CONTAINER -->
    <div class="container">

        <!-- NEW DEPOSITS -->
        <div class="row">
            <div class="col-md-12 ">
                <div class="tile-basic tile-basic-icon-top">
                    <div class="tile-icon">
                        <span class="fa fa-university"></span>
                    </div>
                    <div class="tile-content text-center padding-5">
                        <h3 class="tile-title">{{ $data->name_uz }}</h3>
                        <div class="col-md-2" style="text-align: left">
                            &nbsp;&nbsp;Yil bo'yicha:<br>&nbsp;
                            To'lanishi kerak:<br> &nbsp;
                            To'landi:<br>
                        </div>
                        <div class="col-md-10" style="text-align: left">
                            <span>{{ date('Y',time()) }} </span><br>
                            <span style="font-weight: bold" class="text-danger">{{ $data->getTotalFee(2018) }}</span><br>
                            <span style="font-weight: bold">{{ $data->getDeposits(2018) }}</span><br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END NEW DEPOSITS -->

        <!-- DEPOSITS -->
        <div class="block block-condensed">
            <div class="app-heading app-heading-small">
                <div class="title">
                    <h2>TOIFALAR</h2>
                </div>
            </div>

            <div class="block-content">
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th style="text-align: center">Toifalar</th>
                        <th style="text-align: center">O'quvchilar soni</th>
                        <th style="text-align: center">To'lanishi kerak</th>
                        <th style="text-align: center">To'landi</th>
                        <th style="width: 3%"></th>
                    </tr>
                    </thead>
                    <tbody>
                    @if($courses != null)
                        @foreach($courses as $item)
                            <tr>
                                <td style="text-align: center">{{$item->name}}</td>
                                <td align="center">{{ $item->getStudentsCount(2018, $data->id) }}</td>
                                <td align="center">{{ $item->getTotalFee(2018, $data->id) }}</td>
                                <td align="center">{{ $item->getDeposits(2018, $data->id) }}</td>
                                <td>
                                    <a href="/backoffice/payment/group/{{ $data->id }}/{{ $item->id }}" class="btn btn-default btn-icon">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                </table>
            </div>
        </div>
        <!-- END DEPOSITS -->

    </div>
    <!-- END PAGE CONTAINER -->
@endsection