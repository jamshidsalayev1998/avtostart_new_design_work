    @extends('layouts.admin')



    @section('content')

        @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp

        <div class="container">

            <div class="row">

  



                <div class="col-md-12">

                    <div class="panel panel-default">

                        <div class="panel-heading">
                            <form method="get" action="#" style="text-align: right">
                                <input type="date" name="start" value="<?=$start?>"> dan
                                <input type="date" name="end" value="<?=$end?>"> gacha
                                <input type="submit" class="btn btn-success" value="Ok">
                            </form>

                            </h3>

                        </div>

                        <div class="panel-body">

                            @if(session('message'))

                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('message') }}

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            @endif

                            <table class="table table-bordered table-hover">

                                <thead>

                                <tr>

                                     <th style="width: 2%" rowspan="2">#</th>

                                    <th style="text-align: center" rowspan="2">{{($branch) ? ' Filial  Nomi' : 'Viloyat nomi'}}
                                    </th>
                                    <th style="text-align: center" colspan="3"><b><?=$branch.' '.date('d.m.Y', strtotime($start))?></b> dan <b><?=date('d.m.Y', strtotime($end))?></b> gacha oraliqdagi guruhlar soni</th>
                                </tr>
                                <tr>

                                    <th style="text-align: center">Yaratilgan</th>
                                    <th style="text-align: center">Yakunlanmagan</th>
                                    <th style="text-align: center">Yakunlangan</th>
                                </tr>   
                                </thead>

                                <tbody>

                                @foreach($count as $item)

                                    <tr>

                                            @if($item->name_uz!="")

                                        <td>{{++$i}}</td>

                                        <td><a href="{{empty($data2) ? 'payreg' : '../paybranch'}}/{{ $item->id }}">{{$item->name_uz}}</a></td>
                                        <td style="text-align: center">
                                            @if(($item->sum2))
                                                {{$item->sum2}}
                                            @endif
                                            @if(!($item->sum2))
                                                0
                                            @endif
                                        </td>
                                        <td style="text-align: center">
                                        @if(($item->sum1))
                                        {{$item->sum1}}
                                        @endif
                                        @if(!($item->sum1))
                                             0
                                        @endif
                                        </td>
                                        <td style="text-align: center">
                                        @if(($item->sum))
                                        {{$item->sum}}
                                        @endif
                                        @if(!($item->sum))
                                             0
                                        @endif
                                        </td>

                                        @endif

                                    </tr>

                                @endforeach

                                

                                </tbody>

                            </table>

                            <div class="row">

                                <div class="col-sm-5">

                                    Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries

                                </div>

                                <div class="col-sm-7">

                            

                                </div>

                            </div>

                        </div>

                    </div>



                </div>

            </div>

        </div>

    @endsection