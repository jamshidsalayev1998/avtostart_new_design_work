                @extends('layouts.admin')

                @section('content')

                    @php $x = ($data->currentPage() - 1) * $data->perPage() @endphp
                    @php $i = 0 @endphp
<style>
td{
    text-align:center;
}
</style>

                    <div class="app-heading-container app-heading-bordered bottom">

                        <ul class="breadcrumb">

                            <li><a href="/backoffice">Dashboard</a></li>

                            <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>



                            <li class="active"></li>

                        </ul>

                    </div>

                    <!-- START PAGE CONTAINER -->

                    <div class="container">



                        <!-- NEW DEPOSITS -->

                        <div class="row">

                            <div class="col-md-12 ">

                                <div class="tile-basic tile-basic-icon-top">

                                    <div class="tile-icon">

                                        <span class="fa fa-university"></span>

                                    </div>

                                    <div class="tile-content text-center padding-5">

                                        <h3 class="tile-title"></h3>

                                        <div class="col-md-2" style="text-align: left">

                                        

                                        </div>



                                        <div class="col-md-4" style="float:right">
                <select class="bs-select group-decision"  id="group_id" data-live-search="true" data-dependent="student_id" name="student_id">
                    <option style="display: none">Yilni tanlang</option>
                    @foreach($groups as $group)
                        <option value="{{ $groups[$x] }}"  
                        <?php if($groups[$x]==$year):?>
                                selected
                                <?php endif?>
                        data-href="../payments/hisobotviloyatpost/{{ $groups[$x] }}" name="year" >{{$groups[$x] }}
                        
                        </option>
                        <?php $x++; ?>
                    @endforeach
                </select>
            </div>


                                    </div>

                                </div>

                            </div>

                        </div>

                        <!-- END NEW DEPOSITS -->



                        <!-- DEPOSITS -->

                        <div class="block block-condensed">

                            <div class="app-heading app-heading-small">

                                <div class="title">

                                    <h2>Viloyatlar</h2>

                                </div>
<input type="button" onclick="tableToExcel('testTable', 'W3C Example Table')" class="btn btn-danger btn-lg pull-right" value="Excelga export qilish  ">

                            </div>



                            <div class="block-content" style="overflow-x: scroll;
    transform: rotateX(180deg);">

                                <table id="testTable" class="table table-striped table-bordered" style="transform: rotateX(180deg); ">


                <tr>
                    <td rowspan=2>№</td>
                    <td rowspan=2>Viloyat nomi</td>
                    <td rowspan=2>O`tgan yil tushgan mablag'</td>
                    <td rowspan=2>Jami to`lanishi kerak</td>
                   <td rowspan=2>O`quvchilardan tushgan mablag'</td>
              
                    <td rowspan=2>O`quvchilar soni</td>
                    <td rowspan=2>O`rtacha kalkulyatsiya narxi</td>
                    <td rowspan=2>Berilgan guvohnomalar soni</td>

                    <td colspan="12">Shu jumladan</td>
                    <td rowspan=2>Hisob davri oxiriga qoldiq</td>
                    <td rowspan=2>Chetlashtirilganlar soni</td>
                </tr>
                <tr>
                    <td>Yanvar</td>
                    <td>Fevral</td>
                    <td>Mart</td>
                    <td>Aprel</td>
                    <td>May</td>
                    <td>Iyun</td>
                    <td>Iyul</td>
                    <td>Avgust</td>
                    <td>Sentyabr</td>
                    <td>Oktyabr</td>
                    <td>Noyabr</td>
                    <td>Dekabr</td>
                </tr>
                @foreach($data as $item)
                <tr class="clickable-row" data-href="/backoffice/payments/hisobotfilial/{{$item->id}}" style="cursor: pointer">
                            <td>{{++$i}}</td>
                     <td>
                   {{$item->name_uz}}
                     </td>
                 
                    <?php
                      $count = DB::table('test_sys_payment as pa')
                      ->select(DB::Raw('rg.name_uz'),
                       DB::Raw("rg.id"),
          
                   
                      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')) THEN pa.amount else 0 end) as student_sum_now"),
                      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year'-1)) THEN pa.amount else 0 end) as student_sum_now_1"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 5, 1) = '1')) THEN pa.amount else 0 end) as student_sum_1"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 5, 1) = '2'))  THEN pa.amount else 0 end) as student_sum_2"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 5, 1) = '3'))  THEN pa.amount else 0 end) as student_sum_3"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 5, 1) = '4'))  THEN pa.amount else 0 end) as student_sum_4"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 5, 1) = '5'))  THEN pa.amount else 0 end) as student_sum_5"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 5, 1) = '6'))  THEN pa.amount else 0 end) as student_sum_6"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 5, 1) = '7'))  THEN pa.amount else 0 end) as student_sum_7"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 5, 1) = '8'))  THEN pa.amount else 0 end) as student_sum_8"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 5, 1) = '9'))  THEN pa.amount else 0 end) as student_sum_9"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 4, 2) = '10'))  THEN pa.amount else 0 end) as student_sum_10"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 4, 2) = '11'))  THEN pa.amount else 0 end) as student_sum_11"),
      DB::Raw("sum(case when ((SUBSTR(pa.payment_date, 7, 4) = '$year')&&(SUBSTR(pa.payment_date, 4, 2) = '12'))  THEN pa.amount else 0 end) as student_sum_12"),
      DB::Raw("sum(case when (YEAR(st.created_at) = '$year'&&pa.returned_sum=1) THEN 1 else 0 end) as student_count_chet")
      )
                      ->leftJoin("test_sys_student as st","pa.student_id", "st.id")
                      ->leftJoin("test_sys_grouped_student as gs","gs.student_id", "st.id")
                      ->leftJoin("test_sys_branch as br","st.branch_id","br.id")
                      ->leftJoin("test_sys_group as gr","gr.id","gs.group_id")
                      ->leftJoin("test_sys_region as rg","br.region_id","rg.id")
                      ->groupBy('rg.name_uz', 'rg.id')
                      ->orderBY('rg.name_uz')
                      ->where('br.region_id', '=', $item->id)
                      ->first(1000);

            
                    ?>
                       <?php
                      $count2 = DB::table('test_sys_student as st')
                      ->select(DB::Raw('rg.name_uz'),
                       DB::Raw("rg.id"),
                      DB::Raw("sum(case when YEAR(gr.edu_ending_date) = '$year' THEN 1 else 0 end) as student_count"),
                      DB::Raw("sum(case when YEAR(gr.edu_ending_date) = '$year' THEN gr.tuition_fee else 0 end) as group_sum")
                      )
                      ->leftJoin("test_sys_grouped_student as gs","gs.student_id", "st.id")
                      ->leftJoin("test_sys_branch as br","st.branch_id","br.id")
                      ->leftJoin("test_sys_group as gr","gr.id","gs.group_id")
                      ->leftJoin("test_sys_region as rg","br.region_id","rg.id")
                      ->groupBy('rg.name_uz', 'rg.id')
                      ->orderBY('rg.name_uz')
                      ->where('br.region_id', '=', $item->id)
                      ->first(1000);

            
                    ?>
                <td>
                {{$count->student_sum_now_1}} 
                     </td>
                     <td>
                     {{$count2->group_sum}}
                     </td>
                     <td>
                    {{$count->student_sum_now}}
                    </td>
                  
                    <td>
                    {{$count2->student_count}}
                    </td>
                   
                    <td>
                    <?php if($count2->student_count):?>
                    <?php echo round(($count2->group_sum/$count2->student_count),0) ?>
                    <?php endif?>
                    <?php if(!$count2->student_count):?>
                         0
                    <?php endif?>
                    </td>
                    <td>
                    <?php 
                     $all2=Test\Model\Guvohnoma::
                         whereYear('created_at', '=', $year)
                        ->where('region_id', $item->id)
                        ->sum('count');
                     echo $all2;
                    ?>
                    </td>
                    <td>
                    {{$count->student_sum_1}}
                    </td>
                    <td>
                    {{$count->student_sum_2}}
                    </td>
                    <td>
                    {{$count->student_sum_3}}
                    </td>
                    <td>
                    {{$count->student_sum_4}}
                    </td>
                    <td>
                    {{$count->student_sum_5}}
                    </td>
                    <td>
                    {{$count->student_sum_6}}
                    </td>
                    <td>
                    {{$count->student_sum_7}}
                    </td>
                    <td>
                    {{$count->student_sum_8}}
                    </td>
                    <td>
                    {{$count->student_sum_9}}
                    </td>
                    <td>
                    {{$count->student_sum_10}}
                    </td>
                    <td>
                    {{$count->student_sum_11}}
                    </td>
                    <td>
                    {{$count->student_sum_12}}
                    </td>

                    <td>
                    {{$count2->group_sum-$count->student_sum_now}}
                    
                    </td>
                    <td>    {{$count->student_count_chet}}</td>
                   
                </tr>
  
                @endforeach
                <tfoot>
                    <td>Jami</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
              
                </tfoot>


                                </table>

                                <div class="row">

                                    <div class="col-sm-5" style="transform: rotateX(180deg); ">

                                        Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries

                                    </div>

                                    <div class="col-sm-7">

                                        {{ $data->links() }}

                                    </div>

                                </div>

                            </div>

                        </div>

                        <!-- END DEPOSITS -->



                    </div>

                    <!-- END PAGE CONTAINER -->

                @endsection