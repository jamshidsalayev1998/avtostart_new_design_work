@extends('layouts.admin')

@section('content')

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>

            <li><a href="/backoffice/payment/region/{{ $group->branch->region->id }}">{{ $group->branch->region->name_uz }}</a></li>

            <li><a href="/backoffice/payment/branch/{{ $group->branch->id }}">{{ $group->branch->name_uz }}</a></li>

            <li><a href="">{{ $group->getCourse()->name }}</a></li>

            <li class="active">{{ $group->name_uz }}</li>

        </ul>

    </div>

    <!-- START PAGE CONTAINER -->

    <div class="container">



        <!-- NEW DEPOSITS -->

        <div class="row">

            <div class="col-md-12 ">

                <div class="tile-basic tile-basic-icon-top">

                    <div class="tile-icon">

                        <span class="fa fa-university"></span>

                    </div>

                    <div class="tile-content text-center padding-5">

                        <h3 class="tile-title">{{ $group->name_uz }} &nbsp; - <strong>{{ $group->getCourse()->name }}</strong> toifa</h3>

                        <h3 class="tile-title">{{ $group->edu_starting_date }} &nbsp; ---&nbsp; {{ $group->edu_ending_date }}</h3>
                        
                        <div class="col-md-2" style="text-align: left">

                            &nbsp;&nbsp;Guruh holati:<br>&nbsp;

                            To'lanishi kerak:<br> &nbsp;

                            To'landi:<br>&nbsp;

                            Yil:<br>

                        </div>

                        <div class="col-md-10" style="text-align: left">

                            <span>{{  $group->getStatus() }} </span><br>

                            <span style="font-weight: bold" class="text-danger">
                                {{ number_format($group->getTotalFee(2018), 0, ',', ' ') }}
                            </span><br>

                            <span style="font-weight: bold">
                                {{ number_format($group->getDeposits(2018), 0, ',', ' ') }}
                            </span><br>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!-- END NEW DEPOSITS -->



        <!-- DEPOSITS -->

        <div class="block block-condensed">

            <div class="app-heading app-heading-small">

                <div class="title">

                    <h2>TOIFALAR</h2>

                </div>
<input type="button" onclick="tableToExcel('testTable', 'W3C Example Table')"  class="btn btn-default btn-lg pull-right" value="Excelga export qilish  " />

            </div>



            <div class="block-content" id="dvData">

                <table class="table table-striped table-bordered" id="testTable">

                    <thead>

                    <tr>

                        <th width="2%">#</th>

                        <th style="text-align: left">FIO</th>

                        <th style="text-align: left">To'lanishi kerak</th>

                        <th style="text-align: left">To'landi</th>

                        <th style="text-align: left">Yil</th>

                        <th style="width: 3%"></th>

                    </tr>

                    </thead>

                    <tbody>

                    @if($group->students != null)

                        @php $i = 0; @endphp

                        @foreach($array2 as $student)

                            @php $student = $student->student; @endphp
   @if($student != null)
      
<?php $a=$group->tuition_fee-$student->payments->pluck('amount')->sum();?>
                            <tr 
   @if($a > 0)
                            style="background-color: #b3b3b3;"
     @endif
   @if($a >= 0)
  
                             style="background-color: white"; 
     @endif
                              >

                                <td>{{ ++$i }}</td>

                                <td style="text-align: left">{{ $student->fio() }}</td>

                                <td align="left">{{ number_format($group->tuition_fee, 0, ',', ' ')  }}</td>

                                <td align="left">{{
                              number_format($student->payments->pluck('amount')->sum() , 0, ',', ' ')     
                              }}</td>

                                <td>{{   number_format($group->tuition_fee , 0, ',', ' ')   }}</td>

                                <td>

                                    <a href="{{ route('payment.show',['id'=>$student->id]) }}" class="btn btn-default btn-icon">

                                        <i class="fa fa-eye"></i>

                                    </a>

                                </td>

                            </tr>
     @endif
                        @endforeach

                    @endif

                    </tbody>

                </table>

            </div>

        </div>

        <!-- END DEPOSITS -->



    </div>

    <!-- END PAGE CONTAINER -->

@endsection