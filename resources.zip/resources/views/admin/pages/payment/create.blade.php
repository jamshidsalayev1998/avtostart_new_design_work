@extends('layouts.admin')

@section('content')

    <div class="container">

        <div class="app-heading-container app-heading-bordered bottom">

            <ul class="breadcrumb">

                <li><a href="/backoffice">Dashboard</a></li>

                <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>

                <li class="active">Yangi to'lovni kiritish</li>

            </ul>

        </div>

        <div class="block block-condensed">

            <div class="app-heading app-heading-small">

                <div class=" col-md-6 title">

                    <h2>To'lovni kiritish</h2>

                    <p>Barcha maydonlar to'ldirilishi shart</p>

                </div>

                <div class="col-md-6"> 

                    <button type="submit" onclick="$('#payment-form').submit()" class="btn btn-success form-control">Saqlash</button>

                </div>

            </div>

        

            <div class="block-content">



                <form action="{{ route('payment.store') }}" id="payment-form" method="post" class="form-horizontal" enctype="multipart/form-data" name="student-form" id="student-form">

                    {{ csrf_field() }}

                    <div class="row">

                        <div class="col-md-6 ">



                            <div class="form-group " style="    margin-top: -32px;"> 

                                <label class="col-md-12 control-label">

                                    @if($errors->has('student_id'))

                                        <span class="text-danger"> | {{ $errors->first('student_id') }}</span>

                                    @endif

                                </label>

                               

                                <div class="col-md-3" >
 <label>Yil</label>
                                    <select class="form-control "  id="year"  name="groups_id">

                                    </select>

                                </div>

                                <div class="col-md-3" >
 <label>Guruh</label>
                                    <select class="form-control "  id="groups"  name="groups_id">

                                    </select>

                                </div>

                                <div class="col-md-6">
 <label>O`quvchi FIO:</label>
                                    <select class="form-control "  id="students" data-live-search="true" data-dependent="area" name="student_id">



                                    </select>

                                </div>

                            </div>

                            <div class="form-group">

                                <label class="col-md-12 control-label">To'lov miqdori

                                    @if($errors->has('amount'))

                                        <span class="text-danger"> | {{ $errors->first('amount') }}</span>

                                    @endif

                                </label>

                                <div class="col-md-12">

                                    <input type="text" class="form-control" name="amount" id="amount" value="{{ old('amount') }}">

                                </div>

                            </div>

                       <!--      <div class="form-group">

                                <label class="col-md-12 control-label">Status</label>

                                <div class="col-md-12">

                                    <select name="status" id="status" class="form-control">

                                        <option value="1">Aktiv</option>

                                        <option value="0">Passiv</option>

                                    </select>

                                </div>

                            </div> -->

                            <div class="form-group">

                                <label class="col-md-12 control-label margin-bottom-0">To'lov amalga oshirilgan sana

                                    @if($errors->has('payment_date'))

                                        <span class="text-danger"> | {{ $errors->first('payment_date') }}</span>

                                    @endif

                                </label>

                                <div class="col-md-12 input-group bs-datepicker control-label margin-left-20 margin-right-10">

                                    <input type="text" class="form-control"  name="payment_date" id="payment_date" value="{{ old('payment_date') }}">

                                    <span class="input-group-addon">

                                          <span class="icon-calendar-full"></span>

                                    </span>

                                </div>

                            </div>

                        </div>

                       <div class="col-md-6">
                            <div class="block block-condensed" id="student_info" style="padding-bottom: 15px;">
                            <p style="padding: 0px 0 0px 10px;   font-size: 18px;text-align: center;">O'quvchi haqida ma'lumot shu  yerda ko'rinadi</p>
                            <span style="font-size:16px;margin-left: 10px;" id="students_name">FIO:</span>
                            <br>
                            <br>
                            <span id="students_sum"  style="font-size: 16px;margin-left: 10px;">Qolgan to`lov: </span>
                            <br>

                            </div>
                            <div> 
                              
                                 
                                
                            </div>
                        </div>

                    </div>

                </form>
 <br>
                <br>
                <br>
                <br>
                <br>
                <br>


            </div>

        </div>

    </div>

@endsection