@extends('layouts.admin')

@section('content')

    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp

    <?php 



    $k=0;

    $x=0;

        foreach ($data as $key) {

         $all_sum[$k]=$key->all_sum;

         $sum2[$k]=$key->sum2;

         $pay1[$k]=$key->pay1;

         $pay2[$k]=$key->pay2;

         

                $k++;

        }

    

    

    ?>

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>



            <li class="active">{{ $region->name_uz }}</li>

        </ul>

    </div>

    <!-- START PAGE CONTAINER -->

    <div class="container">



        <!-- NEW DEPOSITS -->

        <div class="row">

            <div class="col-md-12 ">

                <div class="tile-basic tile-basic-icon-top">

                    <div class="tile-icon">

                        <span class="fa fa-university"></span>

                    </div>

                    <div class="tile-content text-center padding-5">

                        <h3 class="tile-title">{{ $region->name_uz }}</h3>

                        <div class="col-md-2" style="text-align: left">

                            &nbsp;&nbsp;

                            To'lanishi kerak:<br> &nbsp;

                            To'landi:<br>

                        </div>

                        <div class="col-md-10" style="text-align: left">



                            

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!-- END NEW DEPOSITS -->



        <!-- DEPOSITS -->

        <div class="block block-condensed">

            <div class="app-heading app-heading-small">

                <div class="title">

                    <h2>FILIALLAR</h2>

                </div>

            </div>



            <div class="block-content">

                <table class="table table-striped table-bordered">

                    <thead>

                    <tr>

                        <th style="width: 2%">#</th>

                        <th>Filial nomi</th>

                       

                        <th style="text-align: center">Umumiy summa</th>

                        <th style="text-align: center">To'langan summa</th>

                        <th style="text-align: center;">To'lanishi lozim</th>

                        <th style="text-align: center;">Qarzdor</th>

                    </tr>

                    </thead>

                    <tbody>

                    @if($data != null)

                        @foreach($count2 as $item)

                            <tr>

                                

                                 <td>{{++$i}}</td>

                                <td><a href="/backoffice/payment/group/{{ $item->id }}">{{$item->name_uz}}</a></td>

                                

                                <td>{{$item->all_sum == 0 ? 0 : number_format($item->all_sum, 0, ',', ' ')}}</td>

                                

                                <td> <?php echo number_format($all_sum[$x], 0, ',', ' ');?>
                                    
                                </td>

                                <td> <?php 

                                    echo  number_format($item->pay_x-$pay1[$x], 0, ',', ' ');

                                    ?></td>

                              <td> <?php 

                                echo   number_format( $item->pay_y-$pay2[$x], 0, ',', ' ');

                                ?></td>  

                            </tr>

                            <?php 

                                                

                                $x++

                               

                                ?>

                        @endforeach

                        <tr>

                          

                    @endif

                    </tbody>

                </table>

                <div class="row">

                    <div class="col-sm-5">

                        Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries

                    </div>

                    <div class="col-sm-7">

                        {{ $data->links() }}

                    </div>

                </div>

            </div>

        </div>

        <!-- END DEPOSITS -->



    </div>

    <!-- END PAGE CONTAINER -->

@endsection