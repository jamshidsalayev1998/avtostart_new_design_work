@extends('layouts.admin')



@section('content')

    @php $i = 0 @endphp

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">

                    <div class="panel-heading">

                        <h3 class="panel-title">

                        </h3>

                        <a class="btn btn-success" onclick="exportTableToExcel('tableGroup', '{{$group['name_uz']}}')"><i class="fa fa-file-excel-o"></i> Excel</a>

                    </div>

                    <div class="panel-body" id="tableGroup">

                        @if(session('message'))

                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                <div class="alert-icon">

                                    <span class="icon-checkmark-circle"></span>

                                </div>

                                {{ session('message') }}

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                            </div>

                        @endif

                        @php $oy = ['Январь','Февраль','Март', 'Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь', 'Декабрь']; @endphp

                        <h1 style="text-align: center">{{$group['name_uz']}}</h1>

                        Начало обучения {{date('d.m.Y', strtotime($group['start']))}}  года<br>

                        Завершение обучения {{date('d.m.Y', strtotime($group['end']))}}  года <br>

                        Сумма платежа по калькуляции {{number_format($group['sum'], 0, ',', ' ')}} сум<br>

                        Начиная с {{date('d.m.Y', strtotime($group['start']))}}  года  {{number_format($group['sum'], 0, ',', ' ')}} сум<br>

                        Сумма платежа при завершении обучения {{number_format($group['sum'], 0, ',', ' ')}} сум<br>

                        <div style="overflow-x: scroll">

                            <table class="table table-bordered table-hover">

                                <thead>

                                <tr>

                                    <th style="width: 10%">№</th>

                                  

                                    <th style="text-align: center">Фамилияси Исми Отасининг исми sds</th>

                                    <th style="text-align: center;">Калькуляция нархи</th>

                                    <th style="text-align: center;">Жами тушган маблаглар</th>

                                  

                                    <th style="text-align: center">Qarzdor</th>

                                </tr>

                                </thead>

                                <tbody>

                                @foreach($data as $item)

                                @if($group['sum'] - $item['sum']<=0)

                                    <tr style="background-color:white">

                                        <td>{{++$i}}</td>

                                       

                                        <td>{{$item['name']}}</td>

                                        <td>{{number_format($group['sum'], 0, ',', ' ')}}</td>

                                        <td>{{number_format($item['sum'], 0, ',', ' ')}}</td>

                                      

                                        <td>{{number_format($group['sum'] - $item['sum'], 0, ',', ' ')}}</td>

                                    </tr>

                                   @else

                                    <tr style="background-color:#f1acac">

                                        <td>{{++$i}}</td>

                                       

                                        <td>{{$item['name']}}</td>

                                       <td>{{number_format($group['sum'], 0, ',', ' ')}}</td>

                                        <td>{{number_format($item['sum'], 0, ',', ' ')}}</td>

                                      

                                        <td>{{number_format($group['sum'] - $item['sum'], 0, ',', ' ')}}</td>

                                    </tr>

                                    @endif

                                @endforeach

                                <tr>

                                    <th>Итог:</th>

                                    <th>

                                        

                                        

                                    </th>

                                    <th>

                                           

                                    </th>

                                

                                    <th>{{$group['summ']}}</th>

                                   

                                    <th>{{$group['sum'] * count($data) - $group['summ']}}</th>

                                </tr>

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <script>

        function exportTableToExcel(tableID, filename = ''){

            var downloadLink;

            var dataType = 'application/vnd.ms-excel';

            var tableSelect = document.getElementById(tableID);

            var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');



            // Specify file name

            filename = filename?filename+'.xls':'excel_data.xls';



            // Create download link element

            downloadLink = document.createElement("a");



            document.body.appendChild(downloadLink);



            if(navigator.msSaveOrOpenBlob){

                var blob = new Blob(['\ufeff', tableHTML], {

                    type: dataType

                });

                navigator.msSaveOrOpenBlob( blob, filename);

            }else{

                // Create a link to the file

                downloadLink.href = 'data:' + dataType + ', ' + tableHTML;



                // Setting the file name

                downloadLink.download = filename;



                //triggering the function

                downloadLink.click();

            }

        }

    </script>

@endsection