@extends('layouts.admin')



@section('content')

    @php $i = 0 @endphp

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">

                    <div class="panel-heading">

                        <h3 class="panel-title">

                        </h3>

                        <a class="btn btn-success" onclick="exportTableToExcel('tableGroup', '{{$group['name_uz']}}')"><i class="fa fa-file-excel-o"></i> Excel</a>

                    </div>

                    <div class="panel-body" id="tableGroup">

                        @if(session('message'))

                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                <div class="alert-icon">

                                    <span class="icon-checkmark-circle"></span>

                                </div>

                                {{ session('message') }}

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                            </div>

                        @endif

                        @php $oy = ['Январь','Февраль','Март', 'Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь', 'Декабрь']; @endphp

                        <h1 style="text-align: center">{{$group['name_uz']}}</h1>

                        Начало обучения {{date('d.m.Y', strtotime($group['start']))}}  года<br>

                        Завершение обучения {{date('d.m.Y', strtotime($group['end']))}}  года <br>

                        Сумма платежа по калькуляции {{number_format($group['sum'], 0, ',', ' ')}} сум<br>

                        Начиная с {{date('d.m.Y', strtotime($group['start']))}}  года  {{number_format($group['sum'], 0, ',', ' ')}} сум<br>

                        Сумма платежа при завершении обучения {{number_format($group['sum'], 0, ',', ' ')}} сум<br>

                        <div style="overflow-x: scroll">

                            <table class="table table-bordered table-hover">

                                <thead>

                                <tr>

                                    <th style="width: 2%">№</th>

                                    <th style="text-align: center">Утган йил тушган маблаг dsadas</th>

                                    <th style="text-align: center">Йил бошига колдик asdas</th>

                                    <th style="text-align: center">Фамилияси Исми Отасининг исми</th>

                                    <th style="text-align: center;">Калькуляция нархи</th>

                                    <th style="text-align: center;">Жами тушган маблаглар</th>

                                    @foreach($oy as $item)

                                        <th style="text-align: center;">{{$item}}</th>

                                    @endforeach

                                    <th style="text-align: center">Хисобот даври охирига колдик</th>

                                </tr>

                                </thead>

                                <tbody>

                                @foreach($data as $item)

                                    <tr>

                                        <td>{{++$i}}</td>

                         <td style="min-width: 100px;">{{number_format($item['sum2'], 0, ',', ' ')}}

                                        </td>

                                        <td style="min-width: 100px;">{{number_format($group['sum']-$item['sum2'], 0, ',', ' ')}}</td>

                                        <td>{{$item['name']}}</td>

                                        <td>{{number_format($group['sum'], 0, ',', ' ')}}</td>

                                        <td>{{number_format($item['sum'], 0, ',', ' ')}}</td>

                                        @for($y = 1; $y < 13; $y ++)

                                 <td>{{empty($item['y']) ? '' : $item['y']}}</td>

                                        @endfor

                                        <td>{{number_format($group['sum']-$item['sum'], 0, ',', ' ')}}</td>

                                    </tr>

                                @endforeach

                                <tr>

                                    <th>Итог:</th>

                                    <th>

                                        <?php 

                                        $a=0;

                                 foreach($data as $item)

                                        

                                        $a+=$item['sum2'];

                                        echo($a);

                                        ?>

                                    </th>

                                    <th>

                                            <?php 

                                            $a=0;

                                     foreach($data as $item)

                                            

                                            $a+=$group['sum']-$item['sum2'];

                                               echo($a);

                                            ?>

                                    </th>

                                    <th></th>

                                    <td></td>

                                    <th>{{$group['summ']}}</th>

                                    @for($y = 1; $y < 13; $y ++)

                             <th>{{empty(($group['y'])) ? '' : $group['y']}}</th>

                                    @endfor

                       <th style="min-width: 100px;">
                       {{number_format($group['sum'] * count($data) - $group['summ'], 0, ',', ' ')}}</th>

                                </tr>

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <script>

        function exportTableToExcel(tableID, filename = ''){

            var downloadLink;

            var dataType = 'application/vnd.ms-excel';

            var tableSelect = document.getElementById(tableID);

            var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');



            // Specify file name

            filename = filename?filename+'.xls':'excel_data.xls';



            // Create download link element

            downloadLink = document.createElement("a");



            document.body.appendChild(downloadLink);



            if(navigator.msSaveOrOpenBlob){

                var blob = new Blob(['\ufeff', tableHTML], {

                    type: dataType

                });

                navigator.msSaveOrOpenBlob( blob, filename);

            }else{

                // Create a link to the file

                downloadLink.href = 'data:' + dataType + ', ' + tableHTML;



                // Setting the file name

                downloadLink.download = filename;



                //triggering the function

                downloadLink.click();

            }

        }

    </script>

@endsection