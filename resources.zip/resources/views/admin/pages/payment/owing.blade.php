@extends('layouts.admin')

@section('content')
    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                        </h3>
                    </div>
                    <div class="panel-body">
                        <form action="">
                            <div class="col-sm-6"><div id="DataTables_Table_0_filter" class="dataTables_filter"><label><input class="form-control" placeholder="" name="search" aria-controls="DataTables_Table_0" type="search"></label> <label><input type="submit" name="" value="Search" class="btn btn-light"></label></div></div>
                        </form>
                        @if(session('message'))
                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-checkmark-circle"></span>
                                </div>
                                {{ session('message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        @endif
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="width: 2%">#</th>
                                <th style="text-align: center">Guruh nomi</th>
                                <th style="text-align: center">Darslar boshlanish vaqti</th>
                                <th style="text-align: center">Darslar tugash vaqti</th>
                                <th style="text-align: center;">Narxi</th>
                            </tr>
                            </thead>
                            <tbody>

                            @foreach($data as $item)
                                <tr>
                                    <td>{{++$i}}</td>
                                    <td><a href="../payment/{{ $item->id }}">{{$item->last_name.' '.$item->first_name.' '.$item->middle_name}}</a></td>
                                    <td>{{$item->edu_starting_date}}</td>
                                    <td>{{$item->edu_ending_date}}</td>
                                    <td>{{$item->summ}}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col-sm-5">
                                Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries
                            </div>
                            <div class="col-sm-7">
                                {{ $data->links() }}
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection