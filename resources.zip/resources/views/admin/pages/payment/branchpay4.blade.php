    @extends('layouts.admin')



    @section('content')

        @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp

        <div class="container">

            <div class="row">

  



                <div class="col-md-12">

                    <div class="panel panel-default">

                        <div class="panel-heading">

                        

                            </h3>

                        </div>

                        <div class="panel-body">

                            @if(session('message'))

                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('message') }}

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            @endif

                            <table class="table table-bordered table-hover">

                            <thead>

<tr>

<th style="width: 2%" rowspan="2"  >#</th>

<th style="text-align: center" rowspan="2">{{($data) ? ' Viloyat  Nomi' : 'Filial nomi'}}

</th>

    <th style="text-align: center" colspan="5">{{empty($branch) ? 'Yillar bo`yicha tushum summasi' : 'Filial nomi'}}</th>

  

</tr>
<th style="text-align: center">{{$now_year_new-4}}</th>
        <th style="text-align: center">{{$now_year_new-3}}</th>
        <th style="text-align: center">{{$now_year_new-2}}</th>
        <th style="text-align: center">{{$now_year_new-1}}</th>
        <th style="text-align: center">{{$now_year_new}}</th>
</thead>

                                <tbody>

                                @foreach($count as $item)

                                    <tr>

                                        <td>{{++$i}}</td>

                                        <td><a href="{{ action('Admin\PaymentController@paybranch4',$item->id) }}">{{$item->name_uz}}</a></a></td>

                                        <td>
                                        @if(($item->sum4))
                                        {{number_format($item->sum4, 0, ',', ' ')}}
                                        @endif
                                        @if(!($item->sum4))
                                             0
                                        @endif
                                        </td>
                                        <td>
                                        @if(($item->sum3))
                                        {{number_format($item->sum3, 0, ',', ' ')}}
                                        @endif
                                        @if(!($item->sum3))
                                             0
                                        @endif
                                        </td>
                                        <td>
                                        @if(($item->sum2))
                                        {{number_format($item->sum2, 0, ',', ' ')}}
                                        @endif
                                        @if(!($item->sum2))
                                             0
                                        @endif
                                        </td>
                                        <td>
                                        @if(($item->sum1))
                                        {{number_format($item->sum1, 0, ',', ' ')}}
                                        @endif
                                        @if(!($item->sum1))
                                             0
                                        @endif
                                        </td>
                                        <td>
                                        @if(($item->sum))
                                        {{number_format($item->sum, 0, ',', ' ')}}
                                        @endif
                                        @if(!($item->sum))
                                             0
                                        @endif
                                        </td>

                                       

                                    </tr>

                                @endforeach

                                

                                </tbody>

                            </table>

                            <div class="row">

                                <div class="col-sm-5">

                                    Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries

                                </div>

                                <div class="col-sm-7">

                            

                                </div>

                            </div>

                        </div>

                    </div>



                </div>

            </div>

        </div>

    @endsection