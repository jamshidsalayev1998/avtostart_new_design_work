<?php

namespace Test\Http\Controllers\Admin;

use Test\User;
use Test\Model\Admin;
use Test\Model\Group;
use Test\Model\Price;
use Test\Model\Branch;
use Test\Model\Course;
use Test\Model\Region;
use Test\Model\Payment;
use Test\Model\Student;
use Test\Model\Accountant;
use Test\Model\BranchAdmin;
use Illuminate\Http\Request;
use Test\Model\GroupedStudent;
use Illuminate\Support\Facades\DB;
use Test\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use DateTime;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function owing(\Request $request)
    {
        if (\Auth::user()->role == 5) {
            $responsible = BranchAdmin::where('user_id', '=', \Auth::user()->id)->first();
            $branch = Branch::find($responsible->branch_id);
            
        $data = Group::where(['branch_id' => $branch->id])->paginate();
        $branch = Branch::where(['id' => $branch->id])->first();

        return view('admin.pages.payment.paybranch3', [
            'branch' => $branch,
            'data' => $data,
            'role' => \Auth::user()->role,
        ]);
        }
        if (\Auth::user()->role == 2) {
            $responsible = Accountant::where('user_id', '=', \Auth::user()->id)->first();
            $branch = Branch::find($responsible->branch_id);
            
        $data = Group::where(['branch_id' => $branch->id])->paginate();
        $branch = Branch::where(['id' => $branch->id])->first();

        return view('admin.pages.payment.paybranch3', [
            'branch' => $branch,
            'data' => $data,
            'role' => \Auth::user()->role,
        ]);
        }
       
    }

    public function index()
    {
        if (\Auth::user()->role == 2) {
            $responsible = Accountant::where('user_id', '=', \Auth::user()->id)->first();
            $branch = Branch::find($responsible->branch_id);
            $students = Student::where('branch_id', '=', $responsible->branch_id)->pluck('id');
            $data = Payment::whereIn('student_id', $students)->orderBy('id', 'desc')->paginate();
            $now_date = new DateTime('now');
            foreach ($now_date as $date) {
                $now_second = strtotime($date) + 7200;
            }

            return view('admin.pages.payment.index', [             // rendering to view page
                'data' => $data, 'branch' => $branch, 'now_second' => $now_second, ]);
        }
        if (\Auth::user()->role == 5) {
            $responsible = BranchAdmin::where('user_id', '=', \Auth::user()->id)->first();
            $branch = Branch::find($responsible->branch_id);
            $students = Student::where('branch_id', '=', $responsible->branch_id)->pluck('id');
            $data = Payment::whereIn('student_id', $students)->orderBy('id', 'desc')->paginate();
            $now_date = new DateTime('now');
            foreach ($now_date as $date) {
                $now_second = strtotime($date) + 7200;
            }

            return view('admin.pages.payment.index', [             // rendering to view page
                'data' => $data, 'branch' => $branch, 'now_second' => $now_second, ]);
        }
        if (\Auth::user()->role == 6) {
            return redirect()->action('Admin\PaymentController@region', ['id' => Admin::where('user_id', \Auth::user()->id)->first()->region_id]);
        }

        if (\Auth::user()->role == 7) {
            // $data = GroupedStudent::select(['test_sys_region.id as id', 'test_sys_region.name_uz as name',
            // DB::raw('count(*) as cnt'),
            //  DB::raw('sum( case when test_sys_group.status = 2 then 0 ELSE test_sys_group.tuition_fee end ) as summ1'),
            //  DB::raw('count(*) as cnt'),
            // DB::raw('sum( case when test_sys_group.status < 2 then 0 ELSE test_sys_group.tuition_fee end ) as summ2'),
            //  DB::raw('(SELECT sum(p.amount) FROM test_sys_payment p LEFT JOIN test_sys_student s on s.id = p.student_id LEFT JOIN test_sys_branch b on b.id = s.branch_id LEFT JOIN test_sys_region r on r.id = b.region_id LEFT JOIN test_sys_grouped_student gs on gs.student_id = s.id LEFT JOIN test_sys_group g on g.id = gs.group_id where r.id = test_sys_region.id and g.status < 2   ) as tolov1'),
            //  DB::raw('(SELECT sum(p.amount) FROM test_sys_payment p LEFT JOIN test_sys_student s on s.id = p.student_id LEFT JOIN test_sys_branch b on b.id = s.branch_id LEFT JOIN test_sys_region r on r.id = b.region_id LEFT JOIN test_sys_grouped_student gs on gs.student_id = s.id LEFT JOIN test_sys_group g on g.id = gs.group_id where r.id = test_sys_region.id and g.status = 2  ) as tolov2'), ])
            //  ->leftJoin('test_sys_group', 'test_sys_grouped_student.group_id', 'test_sys_group.id')
            //  ->leftJoin('test_sys_branch', 'test_sys_group.branch_id', 'test_sys_branch.id')
            //  ->leftJoin('test_sys_region', 'test_sys_branch.region_id', 'test_sys_region.id')
            //  ->leftJoin('test_sys_payment', 'test_sys_grouped_student.student_id', 'test_sys_payment.student_id')
            //  ->groupBy('test_sys_region.id', 'test_sys_region.name_uz')
            //  ->whereRaw("DATE_FORMAT(test_sys_payment.created_at, '%Y') = 2018")
            //  ->paginate();

            // $sum = GroupedStudent::select([DB::raw('count(*) as cnt'), DB::raw('sum( case when test_sys_group.status = 2 then 0 ELSE test_sys_group.tuition_fee end ) as summ1'),
            //  DB::raw('count(*) as cnt'), DB::raw('sum( case when test_sys_group.status < 2 then 0 ELSE test_sys_group.tuition_fee end ) as summ2'),
            //  DB::raw('(SELECT sum(p.amount) FROM test_sys_payment p LEFT JOIN test_sys_student s on s.id = p.student_id LEFT JOIN test_sys_branch b on b.id = s.branch_id LEFT JOIN test_sys_region r on r.id = b.region_id LEFT JOIN test_sys_grouped_student gs on gs.student_id = s.id LEFT JOIN test_sys_group g on g.id = gs.group_id where g.status < 2  ) as tolov1'),
            //   DB::raw('(SELECT sum(p.amount) FROM test_sys_payment p LEFT JOIN test_sys_student s on s.id = p.student_id LEFT JOIN test_sys_branch b on b.id = s.branch_id LEFT JOIN test_sys_region r on r.id = b.region_id LEFT JOIN test_sys_grouped_student gs on gs.student_id = s.id LEFT JOIN test_sys_group g on g.id = gs.group_id where g.status = 2) as tolov2'), ])
            //   ->leftJoin('test_sys_group', 'test_sys_grouped_student.group_id', 'test_sys_group.id')->leftJoin('test_sys_branch', 'test_sys_group.branch_id', 'test_sys_branch.id')
            //  ->leftJoin('test_sys_region', 'test_sys_branch.region_id', 'test_sys_region.id')
            //  ->leftJoin('test_sys_payment', 'test_sys_grouped_student.student_id', 'test_sys_payment.student_id')

            //  ->whereRaw("DATE_FORMAT(test_sys_payment.created_at, '%Y') = 2018")

            //  ->first();
            $data = Region::select(['test_sys_region.id', 'test_sys_region.name_uz', DB::raw('count(*) as son'), DB::raw('sum(test_sys_group.tuition_fee) as all_sum'), DB::raw('sum(test_sys_payment.amount) as all_pay'), DB::raw('sum(case when test_sys_group.status = 2 then 0 else test_sys_payment.amount end) as pay1'), DB::raw('sum(case when test_sys_group.status = 2 then test_sys_payment.amount else 0 end) as pay2'), DB::raw('sum(case when test_sys_group.status = 2 then 0 else test_sys_group.tuition_fee end) as sum1'), DB::raw('sum(case when test_sys_group.status = 2 then test_sys_group.tuition_fee else 0 end) as sum2')])->join('test_sys_branch', 'test_sys_region.id', '=', 'test_sys_branch.region_id')->join('test_sys_group', 'test_sys_group.branch_id', '=', 'test_sys_branch.id')->join('test_sys_grouped_student', 'test_sys_grouped_student.group_id', '=', 'test_sys_group.id')->leftJoin('test_sys_payment', 'test_sys_payment.student_id', '=', 'test_sys_grouped_student.student_id')->groupBy(['test_sys_region.id', 'test_sys_region.name_uz'])->where('test_sys_region.id', '<', 20)->paginate();
            $sum = Region::select([DB::raw('count(*) as son'), DB::raw('sum(test_sys_group.tuition_fee) as all_sum'), DB::raw('sum(test_sys_payment.amount) as all_pay'), DB::raw('sum(case when test_sys_group.status = 2 then 0 else test_sys_payment.amount end) as pay1'), DB::raw('sum(case when test_sys_group.status = 2 then test_sys_payment.amount else 0 end) as pay2'), DB::raw('sum(case when test_sys_group.status = 2 then 0 else test_sys_group.tuition_fee end) as sum1'), DB::raw('sum(case when test_sys_group.status = 2 then test_sys_group.tuition_fee else 0 end) as sum2')])->join('test_sys_branch', 'test_sys_region.id', '=', 'test_sys_branch.region_id')->join('test_sys_group', 'test_sys_group.branch_id', '=', 'test_sys_branch.id')->join('test_sys_grouped_student', 'test_sys_grouped_student.group_id', '=', 'test_sys_group.id')->leftJoin('test_sys_payment', 'test_sys_payment.student_id', '=', 'test_sys_grouped_student.student_id')->where('test_sys_region.id', '<', 20)->first();

            return view('admin.pages.payment.index7', [             // rendering to view page
                'data' => $data, 'sum' => $sum, ]);
        }

        return view('norights');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (\Auth::user()->role == 5) {
            $responsible = BranchAdmin::where('user_id', \Auth::user()->id)->first();
            if (Price::where('branch_id', $responsible->branch_id)->count() == Course::count()) {
                $students = Student::where('branch_id', $responsible->branch_id)->get();

                return view('admin.pages.payment.create', ['students' => $students]);
            } else {
                echo "To'lovlarni kiritish uchun dastlab Ta'lim narxlarini kiriting";
                die();
            }
        }
        if (\Auth::user()->role == 2) {
            $responsible = Accountant::where('user_id', \Auth::user()->id)->first();
            if (Price::where('branch_id', $responsible->branch_id)->count() == Course::count()) {
                $students = Student::where('branch_id', $responsible->branch_id)->get();

                return view('admin.pages.payment.create', ['students' => $students]);
            } else {
                echo "To'lovlarni kiritish uchun dastlab Ta'lim narxlarini kiriting";
                die();
            }
        } else {
            return view('norights');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();

        $validator = Validator::make($input, ['student_id' => 'required|filled', 'amount' => 'required|integer', 'payment_date' => 'required']);
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }
        $now_date = new DateTime('now');
        foreach ($now_date as $date) {
            $now_second = strtotime($date) + 871200;
            $permission_date = date('Y/m/d H:i:s', $now_second);
        }
        $data = new Payment();
        $data->student_id = $input['student_id'];
        $data->amount = $input['amount'];
        $data->payment_date = $input['payment_date'];
        $data->status = $input['status'];
        $data->permission_time = $permission_date;
        $data->created_by = \Auth::user()->id;
        $data->updated_by = \Auth::user()->id;
        if ($data->save()) {
            return redirect()->route('payment.index')->with('message', 'To\'lov qo\'shildi ');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $student = Student::find($id);
        $sum = Payment::where('test_sys_payment.student_id', $id)
                ->select([DB::raw('sum(test_sys_payment.amount) as sum')])
                ->join('test_sys_student', 'test_sys_student.id', 'test_sys_payment.student_id')
                ->groupBy(['test_sys_payment.student_id'])
                ->first();
        $data = GroupedStudent::where('test_sys_grouped_student.student_id', $id)
                ->select([DB::raw('(test_sys_group.tuition_fee) as sum')])
               ->join('test_sys_student', 'test_sys_grouped_student.student_id', 'test_sys_student.id')
               ->join('test_sys_group', 'test_sys_group.id', 'test_sys_grouped_student.group_id')
               ->first();
      
        if ($sum == '') {
            return view('admin.pages.payment.show2', ['student' => $student, 'sum' => $sum->sum, 'sum1' => $data->sum]);
            die();
        }
        

        if (\Auth::user()->role == 2) {
            if (Student::where('id', $id)->exists()) {
                $responsible = Accountant::where('user_id', \Auth::user()->id)->first();

                if ($responsible->branch_id == $student->branch_id) {
                    return view('admin.pages.payment.show', ['student' => $student, 'sum' => $sum->sum, 'sum1' => $data->sum]);
                }
            } else {
                echo "Ma'lumot topilmadi";
                die();
            }
        }
        if (\Auth::user()->role == 5) {
            if (Student::where('id', $id)->exists()) {
                $responsible = BranchAdmin::where('user_id', \Auth::user()->id)->first();
                if ($responsible->branch_id == $student->branch_id) {
                    return view('admin.pages.payment.show', ['student' => $student, 'sum' => $sum->sum, 'sum1' => $data->sum]);
                }
            } else {
                echo "Ma'lumot topilmadi";
                die();
            }
        }
        if (\Auth::user()->role == 6) {
            if (Student::where('id', $id)->exists()) {
                $responsible = Admin::where('user_id', \Auth::user()->id)->first();
                if ($responsible->region_id == $student->branch->region_id) {
                    return view('admin.pages.payment.show', ['student' => $student, 'sum' => $sum->sum, 'sum1' => $data->sum]);
                }
            } else {
                echo "Ma'lumot topilmadi";
                die();
            }
        }
        if (\Auth::user()->role == 7) {
            $sum = Payment::where('test_sys_payment.student_id', $id)
            ->select([DB::raw('sum(test_sys_payment.amount) as sum')])
            ->join('test_sys_student', 'test_sys_student.id', 'test_sys_payment.student_id')
            ->groupBy(['test_sys_payment.student_id'])
            ->first();
            $data = GroupedStudent::where('test_sys_grouped_student.student_id', $id)
            ->select([DB::raw('(test_sys_group.tuition_fee) as sum')])
           ->join('test_sys_student', 'test_sys_grouped_student.student_id', 'test_sys_student.id')
           ->join('test_sys_group', 'test_sys_group.id', 'test_sys_grouped_student.group_id')
           ->first();

            if (Student::where('id', $id)->exists() && ($sum != '')) {
                return view('admin.pages.payment.show', ['student' => $student, 'sum' => $sum->sum, 'sum1' => $data->sum]);
            } elseif ($sum == '') {
                echo 'O`quvchiga to`lov qo`shilmagan';
                die();
            }
        }
       

        return view('norights');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $idf
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
    
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int                      $id
     *
     * @return \Illuminate\Http\Response
     */
    public function update2($id)
    {
        $sum = Payment::where('test_sys_payment.student_id', $id)
        ->select([DB::raw('sum(test_sys_payment.amount) as sum')])
        ->join('test_sys_student', 'test_sys_student.id', 'test_sys_payment.student_id')
        ->groupBy(['test_sys_payment.student_id'])
        ->first();
$data = GroupedStudent::where('test_sys_grouped_student.student_id', $id)
        ->select([DB::raw('(test_sys_group.tuition_fee) as sum')])
       ->join('test_sys_student', 'test_sys_grouped_student.student_id', 'test_sys_student.id')
       ->join('test_sys_group', 'test_sys_group.id', 'test_sys_grouped_student.group_id')
       ->first();
   

        if (\Auth::user()->role == 5) {
            $user_id = \Auth::user()->id;
            $responsible = BranchAdmin::where('user_id', \Auth::user()->id)->first();
            $payment_id = $id;
            if (Price::where('branch_id', $responsible->branch_id)->count() == Course::count()) {
                $students = Student::where('test_sys_student.id', $id)
                ->where('branch_id', $responsible->branch_id)
                ->get();
          
                return view('admin.pages.payment.update2', ['students' => $students, 'payment_id' => $payment_id,'sum'=>$sum->sum, 'sum1' => $data->sum]);
            } else {
                die();
            }
        }
        if ((\Auth::user()->role == 2)) {
            $responsible = Accountant::where('user_id', \Auth::user()->id)->first();

            $payment_id = $id;
       
            if (Price::where('branch_id', $responsible->branch_id)->count() == Course::count()) {
                $students = Student::where('test_sys_student.id', $id)
                ->where('branch_id', $responsible->branch_id)
                ->get();

                return view('admin.pages.payment.update2', ['students' => $students, 'payment_id' => $payment_id, 'sum' => $sum->sum, 'sum1' => $data->sum]);
            } else {
                die();
            }
        } else {
            return view('norights');
        }
    }

    public function update($id)
    {
        if (\Auth::user()->role == 5) {
            $user_id = \Auth::user()->id;
            $responsible = BranchAdmin::where('user_id', \Auth::user()->id)->first();
            $payment_id = $id;
            if (Price::where('branch_id', $responsible->branch_id)->count() == Course::count()) {
                $students = Payment::where('test_sys_payment.id', $id)
                ->join('test_sys_student', 'test_sys_student.id', 'test_sys_payment.student_id')
                ->where('branch_id', $responsible->branch_id)
                ->get();
                $now_date = new DateTime('now');
                foreach ($now_date as $date) {
                    $now_second = strtotime($date) + 7200;
                }
                foreach ($students as $item2) {
                    $permission_time = strtotime($item2->permission_time);
                }

                $day = $permission_time - $now_second;

                if ($day > 0) {
                    return view('admin.pages.payment.update', ['students' => $students, 'payment_id' => $payment_id]);
                }
                if ($day < 0) {
                    echo "To'lovlarni yangilash muddati o`tib ketgan";
                }
            } else {
                die();

            }
        }
        if ((\Auth::user()->role == 2)) {
            $responsible = Accountant::where('user_id', \Auth::user()->id)->first();

            $payment_id = $id;
            if (Price::where('branch_id', $responsible->branch_id)->count() == Course::count()) {
                $students = Payment::where('test_sys_payment.id', $id)
                ->join('test_sys_student', 'test_sys_student.id', 'test_sys_payment.student_id')
                ->where('branch_id', $responsible->branch_id)
                ->get();
                $now_date = new DateTime('now');
                foreach ($now_date as $date) {
                    $now_second = strtotime($date) + 7200;
                }
                foreach ($students as $item2) {
                    $permission_time = strtotime($item2->permission_time);
                }

                $day = $permission_time - $now_second;

                if ($day > 0) {
                    return view('admin.pages.payment.update', ['students' => $students, 'payment_id' => $payment_id]);
                }
                if ($day < 0) {
                    echo "To'lovlarni yangilash muddati o`tib ketgan";
                }
            } else {
                die();
            }
        } else {
            return view('norights');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
    }

    public function region($id)
    {
        $user = \Auth::user();
        if (!($user->role == 7 || $user->role == 6 && Admin::where('user_id', $user->id)->first()->region_id == $id || $user->role == 5)) {
            abort(404);
        }
        $region = Region::where('id', $id)->first();
        if (empty($region)) {
            abort(404);
        }
        $data = Branch::select(['test_sys_branch.id', 'test_sys_branch.name_uz',
         DB::raw('count(*) as son'), DB::raw('sum(test_sys_group.tuition_fee) as all_sum'),
          DB::raw('sum(test_sys_payment.amount) as all_pay'), 
          DB::raw('sum(case when test_sys_group.status = 2 then 0 else test_sys_payment.amount end) as pay1'), 
          DB::raw('sum(case when test_sys_group.status = 2 then test_sys_payment.amount else 0 end) as pay2'), 
          DB::raw('sum(case when test_sys_group.status = 2 then 0 else test_sys_group.tuition_fee end) as sum1'),
           DB::raw('sum(case when test_sys_group.status = 2 then test_sys_group.tuition_fee else 0 end) as sum2')])
           ->join('test_sys_group', 'test_sys_group.branch_id', '=', 'test_sys_branch.id')->join('test_sys_grouped_student', 'test_sys_grouped_student.group_id', '=', 'test_sys_group.id')
           ->leftJoin('test_sys_payment', 'test_sys_payment.student_id', '=', 'test_sys_grouped_student.student_id')
           ->groupBy(['test_sys_branch.id', 'test_sys_branch.name_uz'])
           ->where('test_sys_branch.region_id', '=', $id)
           ->paginate();
        $sum = Branch::select([DB::raw('count(*) as son'), DB::raw('sum(test_sys_group.tuition_fee) as all_sum'),
         DB::raw('sum(test_sys_payment.amount) as all_pay'), DB::raw('sum(case when test_sys_group.status = 2 then 0 else test_sys_payment.amount end) as pay1'), 
         DB::raw('sum(case when test_sys_group.status = 2 then test_sys_payment.amount else 0 end) as pay2'),
          DB::raw('sum(case when test_sys_group.status = 2 then 0 else test_sys_group.tuition_fee end) as sum1'), 
          DB::raw('sum(case when test_sys_group.status = 2 then test_sys_group.tuition_fee else 0 end) as sum2')])
          ->join('test_sys_group', 'test_sys_group.branch_id', '=', 'test_sys_branch.id')->join('test_sys_grouped_student', 'test_sys_grouped_student.group_id', '=', 'test_sys_group.id')
          ->leftJoin('test_sys_payment', 'test_sys_payment.student_id', '=', 'test_sys_grouped_student.student_id')
          ->where('test_sys_branch.region_id', '=', $id)->first();
    
        return view('admin.pages.payment.region', ['data' => $data, 'region' => $region, 'sum' => $sum]);
        if (\Auth::user()->role == 7) {
            if (Region::where('id', $id)->exists()) {
                $region = Region::find($id);
            }
            echo "Ma'lumot topilmadi!";
            die();
        } else {
            return view('norights');
        }
    }

    public function branch($id)
    {
        if (\Auth::user()->role == 6) {
            if (Branch::where('id', $id)->exists()) {
                $responsible = Admin::where('user_id', \Auth::user()->id)->first();
                $branch = Branch::find($id);
                $courses = Course::all();
                if ($responsible->region_id == $branch->region_id) {
                    return view('admin.pages.payment.branch', ['data' => $branch, 'courses' => $courses]);
                } else {
                    return view('norights');
                }
            }
            echo "Ma'lumot topilmadi!";
            die();
        }
        if (\Auth::user()->role == 7) {
            if (Branch::where('id', $id)->exists()) {
                $courses = Course::all();
                $branch = Branch::find($id);

                return view('admin.pages.payment.branch', ['data' => $branch, 'courses' => $courses]);
            }
            echo "Ma'lumot topilmadi!";
            die();
        } else {
            return view('norights');
        }
    }

    public function group($branch_id, $edu_type)
    {
        if (\Auth::user()->role == 6) {
            if (Branch::where('id', $branch_id)->exists()) {
                $responsible = Admin::where('user_id', \Auth::user()->id)->first();
                $branch = Branch::find($branch_id);
                $groups = Group::where('branch_id', $branch->id)->where('edu_type', $edu_type)->get();
                $course = Course::find($edu_type);
                if ($responsible->region_id == $branch->region_id) {
                    return view('admin.pages.payment.group', ['branch' => $branch, 'groups' => $groups, 'course' => $course]);
                } else {
                    return view('norights');
                }
            }
            echo "Ma'lumot topilmadi!";
            die();
        }
        if (\Auth::user()->role == 7) {
            if (Branch::where('id', $branch_id)->exists()) {
                $branch = Branch::find($branch_id);
                $groups = Group::where('branch_id', $branch->id)->where('edu_type', $edu_type)->get();
                $course = Course::find($edu_type);

                return view('admin.pages.payment.group', ['branch' => $branch, 'groups' => $groups, 'course' => $course]);
            }
            echo "Ma'lumot topilmadi!";
            die();
        } else {
            return view('norights');
        }
    }

    public function members($id)
    {
        if (\Auth::user()->role == 2) { //accountant
            $responsible = Accountant::where('user_id', \Auth::user()->id)->first();
            $group = Group::find($id);
            if ($responsible->branch_id == $group->branch_id) {
                return view('admin.pages.payment.members', ['group' => $group]);
            }
        }
        if (\Auth::user()->role == 5) { //Branch's managaer
            $group = Group::find($id);
            if ($responsible->branch_id == $group->branch_id) {
                return view('admin.pages.payment.members', ['group' => $group]);
            }
        }
        if (\Auth::user()->role == 6) { // Region's manager
            $responsible = Admin::where('user_id', \Auth::user()->id)->first();
            $group = Group::find($id);
            if ($responsible->region_id == $group->branch->region->id) {
                $group = Group::find($id);

                return view('admin.pages.payment.members', ['group' => $group]);
            }
        }
        if (\Auth::user()->role == 7) { // Super Admin which is Republic
            $group = Group::find($id);

            return view('admin.pages.payment.members', ['group' => $group]);
        } else {
            return view('norights');
        }
    }

    public function fetch($id)
    {
        $student = Student::find($id);
        $history = '';
        if (Payment::where('student_id', $id)) {
            $payments = Payment::where('student_id', $id)->get();
            foreach ($payments as $payment) {
                $history = $history.'<li>'.$payment->payment_date.' - '.$payment->amount." so'm".'</li>';
            }
        } else {
            $history = '...';
        }
        $output = '<div class="block-heading margin-bottom-0">
                        <div class="app-heading app-heading-small">
                            <div class="contact contact-rounded contact-bordered contact-lg margin-bottom-0">';
        if ($student->image === null) {
            if ($student->gender == 0) {
                $output = $output.'<img src = '.asset('/extra/avatarmale.png').'/>';
            }
            if ($student->gender == 1) {
                $output = $output.'<img src = '.asset('/extra/avatarfemale.png').'/>';
            }
        } else {
            $output = $output.'<img src='.asset($student->image).'/>';
        }

        $output = $output.'<div class="contact-container">
                                    <a href="#">'.$student->fio().'</a>
                                    <span>ID: '.$student->student_number.'</span>
                                </div>
                            </div>
                        </div>        
                    </div>
                    <div class="block-content row-table-holder" >
                                    <div class="row row-table">
                                        <div class="col-md-6 col-xs-12">
                                            <span class="text-bolder text-uppercase text-sm">Passport:</span>
                                            <p>'.$student->passport_serial.' '.$student->passport_number.'</p>
                                        </div>
                                        <div class="col-md-6 col-xs-12">
                                            <span class="text-bolder text-uppercase text-sm">Telefon:</span>
                                            <p>'.$student->phone1.'</p>
                                        </div>
                                    </div>
                                    <div class="row row-table">
                                        <div class="col-md-6 col-xs-12">
                                            <div style="margin: 0px;padding: 0px;">
                                                <span class="text-bolder text-uppercase text-sm margin-0">Ta\'lim turi:</span>
                                                <p class="margin-0">'.$student->getCourse()->name.'</p>
                                            </div>
                                            <div style="margin: 0px;padding: 0px;">
                                                <span class="text-bolder text-uppercase text-sm margin-0">Guruh raqami:</span>
                                                <p class="margin-0"></p>
                                            </div>
                                            <div style="margin: 0px;padding: 0px;">
                                                <span class="text-bolder text-uppercase text-sm margin-0">Ta\'lim Yakunlanish sanasi:</span>
                                                <p class="margin-0">'.$student->edu_ending_date.'</p>
                                            </div>

                                        </div>
                                        <div class="col-md-6 col-xs-12">
                                            <span class="text-bolder text-uppercase text-sm">To\'lovlar tarixi:</span>
                                            <p>
                                                <ul>'.$history.'</ul>
                                            </p>
                                        </div>
                                    </div>

                                    <div class="row row-table">
                                        <div class="col-xs-12">
                                            <a href="'.route('test_sys_student.show', ['id' => $id]).'" target="_blank" class="btn btn-info pull-right hidden-mobile">Student haqida Batafsil</a>
                                        </div>
                                    </div>

                                </div>';
        echo $output;
    }

    public function pechat()
    {
        $query = [];
        if (\Auth::user()->role == 7) {
            $query = [];
        } elseif (\Auth::user()->role == 6) {
            $query = ['test_sys_branch.region_id' => Admin::where('user_id', \Auth::user()->id)->first()->region_id];
        } elseif (\Auth::user()->role == 5) {
            $query = ['test_sys_branch.id' => BranchAdmin::where('user_id', \Auth::user()->id)->first()->branch_id];
        } else {
            abort(404);
        }
        $d = Payment::select(['test_sys_student.last_name', 'test_sys_student.middle_name', 'test_sys_student.first_name', 'test_sys_payment.amount', 'test_sys_payment.payment_date', 'test_sys_branch.name_uz as branch_name'])->leftjoin('test_sys_student', 'test_sys_student.id', 'student_id')->leftjoin('test_sys_branch', 'test_sys_branch.id', 'test_sys_student.branch_id')->where($query)->orderBy('test_sys_payment.id', 'desc')->get();
        $text = "<table><thead><tr><td>F.I.O.</td><td>Fillial nomi</td><td>To'lov miqdori</td><td>To'langan vaqt</td></tr></thead><tbody>";
        foreach ($d as $item) {
            $text .= '<tr><td>'.$item->last_name.' '.$item->first_name.' '.$item->middle_name.'</td><td>'.$item->branch_name.'</td><td>'.$item->amount.'</td><td>'.$item->payment_date.'</td></tr>';
        }

        return $text.'</tbody></table>';
    }

    public function list(\Request $request)
    {
        $search = $request::get('search');
        if (\Auth::user()->role == 7) {
            $query = [];
        } elseif (\Auth::user()->role == 6) {
            $query = ['test_sys_branch.region_id' => Admin::where('user_id', \Auth::user()->id)->first()->region_id];
        } elseif (\Auth::user()->role == 5) {
            $query = ['test_sys_branch.id' => BranchAdmin::where('user_id', \Auth::user()->id)->first()->branch_id];
        } else {
            abort(404);
        }
        $payments = Payment::select(['test_sys_payment.id as id', 'test_sys_student.id as student_id', 'test_sys_student.last_name', 'test_sys_student.middle_name', 'test_sys_student.first_name', 'test_sys_payment.amount', 'test_sys_payment.payment_date', 'test_sys_payment.created_by', 'test_sys_payment.created_at', 'test_sys_branch.id as branch_id', 'test_sys_branch.name_uz as branch_name'])->leftjoin('test_sys_student', 'test_sys_student.id', 'student_id')->leftjoin('test_sys_branch', 'test_sys_branch.id', 'test_sys_student.branch_id')->whereRaw('concat(test_sys_student.first_name, \' \', test_sys_student.middle_name, \' \', test_sys_student.last_name) like \'%'.$search.'%\'')->where($query)->orderBy('test_sys_payment.id', 'desc')->paginate(25);

        return view('admin.pages.payment.list', [
            'data' => $payments,
            'role' => \Auth::user()->role,
        ]);
    }

    public function delete($id)
    {
        if (\Auth::user()->role == 7) {
            $del = Payment::where(['test_sys_payment.id' => $id])->first();
            $del->delete();

            return redirect()->action('Admin\PaymentController@list', []);
        }
        if (\Auth::user()->role == 5) {
            $responsible = BranchAdmin::where('user_id', \Auth::user()->id)->first();

            if (Price::where('branch_id', $responsible->branch_id)->count() == Course::count()) {
                $students = Payment::where('test_sys_payment.id', $id)
                ->join('test_sys_student', 'test_sys_student.id', 'test_sys_payment.student_id')
                ->where('branch_id', $responsible->branch_id)
                ->get();
                $now_date = new DateTime('now');
                foreach ($now_date as $date) {
                    $now_second = strtotime($date) + 7200;
                }
                foreach ($students as $item2) {
                    $permission_time = strtotime($item2->permission_time);
                }

                $day = $permission_time - $now_second - 777600;

                if ($day > 0) {
                    $del = Payment::where(['test_sys_payment.id' => $id])->first();
                    $del->delete();

                    return redirect()->route('payment.index')->with('message', 'To\'lov o\'chirildi ');
                }
                if ($day < 0) {
                    echo "To'lovlarni o`chirish muddati o`tib ketgan";
                }
            } else {
                die();
            }
        }
        if (\Auth::user()->role == 2) {
            $responsible = Accountant::where('user_id', \Auth::user()->id)->first();

            if (Price::where('branch_id', $responsible->branch_id)->count() == Course::count()) {
                $students = Payment::where('test_sys_payment.id', $id)
                ->join('test_sys_student', 'test_sys_student.id', 'test_sys_payment.student_id')
                ->where('branch_id', $responsible->branch_id)
                ->get();
                $now_date = new DateTime('now');
                foreach ($now_date as $date) {
                    $now_second = strtotime($date) + 7200;
                }
                foreach ($students as $item2) {
                    $permission_time = strtotime($item2->permission_time);
                }

                $day = $permission_time - $now_second - 777600;

                if ($day > 0) {
                    $del = Payment::where(['test_sys_payment.id' => $id])->first();
                    $del->delete();

                    return redirect()->route('payment.index')->with('message', 'To\'lov o\'chirildi ');
                }
                if ($day < 0) {
                    echo "To'lovlarni o`chirish muddati o`tib ketgan";
                }
            } else {
                die();
            }
        } else {
            abort(404);
        }
    }

    public function payregion()
    {
        $region = Region::paginate();
        $branch = Branch::get();
        $group = Group::get();
        $data = Region::paginate();

        $count = DB::table('test_sys_region as rw')
        ->select(DB::Raw('name_uz'),
        DB::Raw('id'),
        DB::Raw('(SELECT count(*) FROM test_sys_group gr 
        JOIN test_sys_branch br on gr.branch_id = br.id 
        join test_sys_region rg on br.region_id = rg.id 
        where YEAR(gr.edu_ending_date) = 2018 and rw.id = rg.id 
        GROUP by rg.id) as sum1'),
        DB::Raw('(SELECT count(*) FROM test_sys_group gr 
        JOIN test_sys_branch br on gr.branch_id = br.id 
        join test_sys_region rg on br.region_id = rg.id 
        where YEAR(gr.edu_ending_date) = 2019 and rw.id = rg.id 
        GROUP by rg.id) as sum2'))
        ->get();

        if (\Auth::user()->role != 200) {
            return view('admin.pages.payment.payreg', [
            'count' => $count,
            'branch' => '',
            'group' => $group,
            'data' => $data,
            'data2' => '',
        ]);
        }
    }

    public function payreg($id)
    {
        $data = Branch::where(['region_id' => $id])->paginate();
        $count = DB::table('test_sys_branch as bw')->where(['region_id' => $id])
        ->select(DB::Raw('name_uz'),
        DB::Raw('id'),
        DB::Raw('(SELECT count(*) FROM test_sys_group gr 
        JOIN test_sys_branch br on gr.branch_id = br.id 
        join test_sys_region rg on br.region_id = rg.id 
        where YEAR(gr.edu_ending_date) = 2018 and bw.id = br.id 
        GROUP by br.id) as sum1'),
        DB::Raw('(SELECT count(*) FROM test_sys_group gr 
        JOIN test_sys_branch br on gr.branch_id = br.id 
        join test_sys_region rg on br.region_id = rg.id 
        where YEAR(gr.edu_ending_date) = 2019 and bw.id = br.id 
        GROUP by br.id) as sum2'))
        ->get();

        return view('admin.pages.payment.payreg', [
                'count' => $count,
                'data' => $data,
                'data2' => 'sa',
        ]);
    }

    public function payregs()
    {
        $responsible = Admin::where('user_id', \Auth::user()->id)->first();
        $region_id = ($responsible->region_id);

        $data = Branch::where(['region_id' => $region_id])->paginate();
        $count = DB::table('test_sys_branch as bw')->where(['region_id' => $region_id])
        ->select(DB::Raw('name_uz'),
        DB::Raw('id'),
        DB::Raw('(SELECT count(*) FROM test_sys_group gr 
        JOIN test_sys_branch br on gr.branch_id = br.id 
        join test_sys_region rg on br.region_id = rg.id 
        where YEAR(gr.edu_ending_date) = 2018 and bw.id = br.id 
        GROUP by br.id) as sum1'),
        DB::Raw('(SELECT count(*) FROM test_sys_group gr 
        JOIN test_sys_branch br on gr.branch_id = br.id 
        join test_sys_region rg on br.region_id = rg.id 
        where YEAR(gr.edu_ending_date) = 2019 and bw.id = br.id 
        GROUP by br.id) as sum2'))
        ->get();

        return view('admin.pages.payment.payreg2', [
                'count' => $count,
                'data' => $data,
                'data2' => 'sa',
        ]);
    }

    public function pay()
    {
        if (\Auth::user()->role == 7) {
            return $this->payregion();
        }
        if (\Auth::user()->role == 2) {
            return $this->paybranch(Accountant::where(['user_id' => \Auth::user()->id])->first()->branch_id);
        } else {
            abort(404);
        }
    }

    public function paybranch($id)
    {
//        return print_r();
     
        $data = Group::where(['branch_id' => $id])->paginate();
        $branch = Branch::where(['id' => $id])->first();
      
        return view('admin.pages.payment.paybranch', [
            'branch' => $branch,
            'data' => $data,
            'role' => \Auth::user()->role,
        ]);
        
    }
    public function paybranch4($id)
    {
//        return print_r();
     
        $data = Group::where(['branch_id' => $id])->paginate();
        $branch = Branch::where(['id' => $id])->first();
   
        return view('admin.pages.payment.paybranch4', [
            'branch' => $branch,
            'data' => $data,
            'role' => \Auth::user()->role,
        ]);
        
    }
    public function paylist($id)
    {
        $now_date = new DateTime('now');
      
        $now_year=($now_date->format('Y')+0);

        $group = Group::where(['id' => $id])->first();
       
        $data = GroupedStudent::select('test_sys_group.id', 'test_sys_group.name_uz', 'test_sys_group.name_ru', 'test_sys_group.tuition_fee', 'test_sys_group.edu_starting_date', 'test_sys_group.edu_ending_date', 'test_sys_student.first_name', 'test_sys_student.last_name', 'test_sys_student.id as student_id', 'test_sys_student.middle_name', 'test_sys_payment.amount', 'test_sys_payment.payment_date')->leftJoin('test_sys_student', 'test_sys_grouped_student.student_id', 'test_sys_student.id')->leftJoin('test_sys_payment', 'test_sys_payment.student_id', 'test_sys_student.id')->leftJoin('test_sys_group', 'test_sys_group.id', 'test_sys_grouped_student.group_id')->where(['test_sys_group.id' => $id])->get();
        $array =  (array) $data;
        foreach ($array as $key) {
            if(!$key){
           echo("Bu guruhga hali o`quvchi qo`shilmagan");
                die();
            }
        }
        $students = [];
        $group = [];
      
        foreach ($data as $item) {
            
            $m = intval(substr($item->payment_date, 3, 2));
            $m2 = intval(substr($item->payment_date, 6, 4));
         
            $students[$item->student_id]['name'] = $item->last_name.' '.$item->first_name.' '.$item->middle_name;
       
            $group['sum'] = $item->tuition_fee;
         
            if (empty($students[$item->student_id]['sum2'])) {
                if(($m2)==($now_year-1)){
                    $students[$item->student_id]['sum2'] = $item->amount;
                }
                else{
                    $students[$item->student_id]['sum2']=0;
                }
                
            } else {
                if(($m2)==$now_year-1){
                    $students[$item->student_id]['sum2'] += $item->amount;
                }
                else{
                    if(($m2)==$now_year-1){
                    $students[$item->student_id]['sum2']+=$item->amount;
                    }
                }
                
            }
            if (empty($students[$item->student_id]['sum'])) {
                
                    $students[$item->student_id]['sum'] = $item->amount;
                
                
                
            } else {
                $students[$item->student_id]['sum'] += $item->amount;
                
            }
            if (empty($students[$item->student_id][$m])) {
                if(($m2)==$now_year){
                $students[$item->student_id][$m] = $item->amount;
                }
                else{
                    $students[$item->student_id][$m] =0;  
                }
            } else {
                if(($m2)==$now_year){
                $students[$item->student_id][$m] += $item->amount;
                }
                else{
                    $students[$item->student_id][$m]=0;
                }


            }
            if (empty($group['summ'])) {

                $group['summ'] = $item->amount;
                
            } else {
                $group['summ'] += $item->amount;
            }
           
            if (empty($group[$m])) {
                if(($m2)==$now_year){
                $group[$m] = $item->amount;
                }
            } else {
                if(($m2)==$now_year){
                $group[$m] += $item->amount;
                }
            }
            
            $group['name_uz'] = $item->name_uz;
            $group['name_ru'] = $item->name_ru;
            $group['start'] = $item->edu_starting_date;
            $group['end'] = $item->edu_ending_date;
        }

        return view('admin.pages.payment.paylist', [
            'data' => $students,
            'group' => $group,
        ]);
        //"<pre>".print_r($students, true)."</pre><pre>".print_r($group, true)."</pre>";
    }
    public function regionpay2()
    {
        $region = Region::paginate();
        $branch = Branch::get();
        $group = Group::get();
        $data = Region::paginate();

        $count = DB::table('test_sys_region as rw')
        ->select(DB::Raw('name_uz'),
        DB::Raw('id'),
        DB::Raw('(SELECT sum(pa.amount) FROM test_sys_payment pa 
        JOIN test_sys_student st on pa.student_id = st.id 
        JOIN test_sys_branch br on st.branch_id = br.id 
        JOIN test_sys_group gr on gr.branch_id = br.id 
        JOIN test_sys_region rg on br.region_id = rg.id
        where YEAR(gr.edu_ending_date) = 2018  and rg.id=rw.id 
         GROUP BY rg.id)  as sum1'),
        DB::Raw(' (SELECT sum(pa.amount) FROM test_sys_payment pa 
        JOIN test_sys_student st on pa.student_id = st.id 
        JOIN test_sys_branch br on st.branch_id = br.id 
        JOIN test_sys_group gr on gr.branch_id = br.id 
        JOIN test_sys_region rg on br.region_id = rg.id
        where YEAR(gr.edu_ending_date) = 2019 and rg.id=rw.id 
         GROUP BY rg.id) as sum2'))
        ->get();

        if (\Auth::user()->role <= 7) {
            return view('admin.pages.payment.regionpay2', [
            'count' => $count,
            'branch' => '',
            'group' => $group,
            'data' => $data,
            'data2' => '',
        ]);
        }
    }
    public function regionpay()
    {
        $region = Region::paginate();
        $branch = Branch::get();
        $group = Group::get();
        $data = Region::paginate();

        $count = DB::table('test_sys_region as rw')
        ->select(DB::Raw('name_uz'),
        DB::Raw('id'),
        DB::Raw('(SELECT sum(pa.amount) FROM test_sys_payment pa 
        JOIN test_sys_student st on pa.student_id = st.id 
        JOIN test_sys_branch br on st.branch_id = br.id 
        JOIN test_sys_group gr on gr.branch_id = br.id 
        JOIN test_sys_region rg on br.region_id = rg.id
        where YEAR(gr.edu_ending_date) = 2018  and rg.id=rw.id 
         GROUP BY rg.id)  as sum1'),
        DB::Raw(' (SELECT sum(pa.amount) FROM test_sys_payment pa 
        JOIN test_sys_student st on pa.student_id = st.id 
        JOIN test_sys_branch br on st.branch_id = br.id 
        JOIN test_sys_group gr on gr.branch_id = br.id 
        JOIN test_sys_region rg on br.region_id = rg.id
        where YEAR(gr.edu_ending_date) = 2019 and rg.id=rw.id 
         GROUP BY rg.id) as sum2'))
        ->get();

        if (\Auth::user()->role <= 7) {
            return view('admin.pages.payment.regionpay', [
            'count' => $count,
            'branch' => '',
            'group' => $group,
            'data' => $data,
            'data2' => '',
        ]);
        }
    }

    public function branchpay($id)
    {
        $region = Region::paginate();
        $branch = Branch::get();
        $group = Group::get();
        $data = Region::paginate();

        $count = DB::table('test_sys_branch as bw')->where(['region_id' => $id])
        ->select(DB::Raw('name_uz'),
        DB::Raw('id'),
        DB::Raw('(SELECT sum(pa.amount) FROM test_sys_payment pa 
        JOIN test_sys_student st on pa.student_id = st.id 
        JOIN test_sys_branch br on st.branch_id = br.id 
        JOIN test_sys_group gr on gr.branch_id = br.id 
        JOIN test_sys_region rg on br.region_id = rg.id
        where YEAR(gr.edu_ending_date) = 2018  and  bw.id = br.id 
         GROUP BY rg.id)  as sum1'),
        DB::Raw(' (SELECT sum(pa.amount) FROM test_sys_payment pa 
        JOIN test_sys_student st on pa.student_id = st.id 
        JOIN test_sys_branch br on st.branch_id = br.id 
        JOIN test_sys_group gr on gr.branch_id = br.id 
        JOIN test_sys_region rg on br.region_id = rg.id
        where YEAR(gr.edu_ending_date) = 2019 and  bw.id = br.id 
         GROUP BY br.id) as sum2'))
        ->get();

        if (\Auth::user()->role <= 7) {
            return view('admin.pages.payment.branchpay', [
            'count' => $count,
            'branch' => '',
            'group' => $group,
            'data' => $data,
            'data2' => '',
        ]);
        }
    }
    public function branchpay4($id)
    {
        $region = Region::paginate();
        $branch = Branch::get();
        $group = Group::get();
        $data = Region::paginate();

        $count = DB::table('test_sys_branch as bw')->where(['region_id' => $id])
        ->select(DB::Raw('name_uz'),
        DB::Raw('id'),
        DB::Raw('(SELECT sum(pa.amount) FROM test_sys_payment pa 
        JOIN test_sys_student st on pa.student_id = st.id 
        JOIN test_sys_branch br on st.branch_id = br.id 
        JOIN test_sys_group gr on gr.branch_id = br.id 
        JOIN test_sys_region rg on br.region_id = rg.id
        where YEAR(gr.edu_ending_date) = 2018  and  bw.id = br.id 
         GROUP BY rg.id)  as sum1'),
        DB::Raw(' (SELECT sum(pa.amount) FROM test_sys_payment pa 
        JOIN test_sys_student st on pa.student_id = st.id 
        JOIN test_sys_branch br on st.branch_id = br.id 
        JOIN test_sys_group gr on gr.branch_id = br.id 
        JOIN test_sys_region rg on br.region_id = rg.id
        where YEAR(gr.edu_ending_date) = 2019 and  bw.id = br.id 
         GROUP BY br.id) as sum2'))
        ->get();

        if (\Auth::user()->role <= 7) {
            return view('admin.pages.payment.branchpay4', [
            'count' => $count,
            'branch' => '',
            'group' => $group,
            'data' => $data,
            'data2' => '',
        ]);
        }
    }

    public function branchpays()
    {
        $region = Region::paginate();
        $branch = Branch::get();
        $group = Group::get();
        $data = Region::paginate();

        $responsible = Admin::where('user_id', \Auth::user()->id)->first();
        $region_id = ($responsible->region_id);

        $count = DB::table('test_sys_branch as bw')->where(['region_id' => $region_id])
        ->select(DB::Raw('name_uz'),
        DB::Raw('id'),
        DB::Raw('(SELECT sum(pa.amount) FROM test_sys_payment pa 
        JOIN test_sys_student st on pa.student_id = st.id 
        JOIN test_sys_branch br on st.branch_id = br.id 
        JOIN test_sys_group gr on gr.branch_id = br.id 
        JOIN test_sys_region rg on br.region_id = rg.id
        where YEAR(gr.edu_ending_date) = 2018  and  bw.id = br.id 
         GROUP BY rg.id)  as sum1'),
        DB::Raw(' (SELECT sum(pa.amount) FROM test_sys_payment pa 
        JOIN test_sys_student st on pa.student_id = st.id 
        JOIN test_sys_branch br on st.branch_id = br.id 
        JOIN test_sys_group gr on gr.branch_id = br.id 
        JOIN test_sys_region rg on br.region_id = rg.id
        where YEAR(gr.edu_ending_date) = 2019 and  bw.id = br.id 
         GROUP BY br.id) as sum2'))
        ->get();

        if (\Auth::user()->role <= 7) {
            return view('admin.pages.payment.branchpay4', [
            'count' => $count,
            'branch' => '',
            'group' => $group,
            'data' => $data,
            'data2' => '',
        ]);
        }
    }

    public function editpayment(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, ['student_id' => 'required|filled',
         'amount' => 'required|integer', 'payment_date' => 'required', ]);
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $data = Payment::where('id', $input['payment_id'])->first();

        $data->amount = $input['amount'];
        $data->payment_date = $input['payment_date'];
        $data->status = $input['status'];

        $data->created_by = \Auth::user()->id;
        $data->updated_by = \Auth::user()->id;
        if ($data->save()) {
            return redirect()->route('payment.index')->with('message', 'To\'lov o\'zgartirildi ');
        }
    }
    public function getstudentlist($id){
        $sum = Payment::where('test_sys_payment.student_id', $id)
        ->select([DB::raw('sum(test_sys_payment.amount) as sum')])
        ->join('test_sys_student', 'test_sys_student.id', 'test_sys_payment.student_id')
        ->groupBy(['test_sys_payment.student_id'])
        ->first();
        $data = GroupedStudent::where('test_sys_grouped_student.student_id', $id)
        ->select([DB::raw('(test_sys_group.tuition_fee) as sum')])
       ->join('test_sys_student', 'test_sys_grouped_student.student_id', 'test_sys_student.id')
       ->join('test_sys_group', 'test_sys_group.id', 'test_sys_grouped_student.group_id')
       ->first();
   
        $sum1=$data->sum-$sum->sum; 
        return json_encode($sum1);

    }
    public function paygroup()
    {
        if (\Auth::user()->role == 5) {
            $responsible = BranchAdmin::where('user_id', '=', \Auth::user()->id)->first();
            $branch = Branch::find($responsible->branch_id);
            
        $data = Group::where(['branch_id' => $branch->id])->paginate();
        $branch = Branch::where(['id' => $branch->id])->first();

        return view('admin.pages.payment.paybranch2', [
            'branch' => $branch,
            'data' => $data,
            'role' => \Auth::user()->role,
        ]);
        }
    }
    public function paylist2($id)
    {
        $now_date = new DateTime('now');
      
        $now_year=($now_date->format('Y')+0);

        $group = Group::where(['id' => $id])->first();
       
        $data = GroupedStudent::select('test_sys_group.id', 'test_sys_group.name_uz', 'test_sys_group.name_ru', 'test_sys_group.tuition_fee', 'test_sys_group.edu_starting_date', 'test_sys_group.edu_ending_date', 'test_sys_student.first_name', 'test_sys_student.last_name', 'test_sys_student.id as student_id', 'test_sys_student.middle_name', 'test_sys_payment.amount', 'test_sys_payment.payment_date')->leftJoin('test_sys_student', 'test_sys_grouped_student.student_id', 'test_sys_student.id')->leftJoin('test_sys_payment', 'test_sys_payment.student_id', 'test_sys_student.id')->leftJoin('test_sys_group', 'test_sys_group.id', 'test_sys_grouped_student.group_id')->where(['test_sys_group.id' => $id])->get();
        $array =  (array) $data;
  
     
        foreach ($array as $key) {
            if(!$key){
           echo("Bu guruhga hali o`quvchi qo`shilmagan");
                die();
            }
        }
           
        $students = [];
        $group = [];
      
        foreach ($data as $item) {
            
            $m = intval(substr($item->payment_date, 3, 2));
            $m2 = intval(substr($item->payment_date, 6, 4));
         
            $students[$item->student_id]['name'] = $item->last_name.' '.$item->first_name.' '.$item->middle_name;
       
            $group['sum'] = $item->tuition_fee;
         
            if (empty($students[$item->student_id]['sum2'])) {
                if(($m2)==($now_year-1)){
                    $students[$item->student_id]['sum2'] = $item->amount;
                }
                else{
                    $students[$item->student_id]['sum2']=0;
                }
                
            } else {
                if(($m2)==$now_year-1){
                    $students[$item->student_id]['sum2'] += $item->amount;
                }
                else{
                    if(($m2)==$now_year-1){
                    $students[$item->student_id]['sum2']+=$item->amount;
                    }
                }
                
            }
            if (empty($students[$item->student_id]['sum'])) {
                
                    $students[$item->student_id]['sum'] = $item->amount;
                
                
                
            } else {
                $students[$item->student_id]['sum'] += $item->amount;
                
            }
            if (empty($students[$item->student_id][$m])) {
                if(($m2)==$now_year){
                $students[$item->student_id][$m] = $item->amount;
                }
                else{
                    $students[$item->student_id][$m] =0;  
                }
            } else {
                if(($m2)==$now_year){
                $students[$item->student_id][$m] += $item->amount;
                }
                else{
                    $students[$item->student_id][$m]=0;
                }


            }
            if (empty($group['summ'])) {

                $group['summ'] = $item->amount;
                
            } else {
                $group['summ'] += $item->amount;
            }
           
            if (empty($group[$m])) {
                if(($m2)==$now_year){
                $group[$m] = $item->amount;
                }
            } else {
                if(($m2)==$now_year){
                $group[$m] += $item->amount;
                }
            }
            
            $group['name_uz'] = $item->name_uz;
            $group['name_ru'] = $item->name_ru;
            $group['start'] = $item->edu_starting_date;
            $group['end'] = $item->edu_ending_date;
        }

        return view('admin.pages.payment.paylist2', [
            'data' => $students,
            'group' => $group,
        ]);
        //"<pre>".print_r($students, true)."</pre><pre>".print_r($group, true)."</pre>";
    }

}
