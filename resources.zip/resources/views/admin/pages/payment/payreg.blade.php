    @extends('layouts.admin')



    @section('content')

        @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp

        <div class="container">

            <div class="row">

  



                <div class="col-md-12">

                    <div class="panel panel-default">

                        <div class="panel-heading">
                            <form method="get" action="#" style="text-align: right">
                                <input type="date" name="start"> dan
                                <input type="date" name="end"> gacha
                                <input type="submit" class="btn btn-success" value="Ok">
                            </form>
                        </div>

                        <div class="panel-body">

                            @if(session('message'))

                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                    <div class="alert-icon">

                                        <span class="icon-checkmark-circle"></span>

                                    </div>

                                    {{ session('message') }}

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                                </div>

                            @endif

                            <table class="table table-bordered table-hover">

                                <thead>

                                <tr>

                                     <th style="width: 2%" rowspan="2"  >#</th>

                                    <th style="text-align: center" rowspan="2">{{($branch) ? ' Filial  Nomi' : 'Viloyat nomi'}}

                                    </th>

                                    <th style="text-align: center"  colspan="5">{{empty($branch1) ? $branch.' Yillar bo`yicha tugatgan guruhlar soni statistikasi' : 'Filial nomi'}}</th>

                                   
                                </tr>
                               
                                <tr>
                                <th style="text-align: center">{{$now_year_new-4}}-yilda tugatgan Guruhlar soni</th>
                                <th style="text-align: center">{{$now_year_new-3}}-yilda tugatgan Guruhlar soni</th>
                                <th style="text-align: center">{{$now_year_new-2}}-yilda tugatgan Guruhlar soni</th>
                                <th style="text-align: center">{{$now_year_new-1}}-yilda tugatgan Guruhlar soni</th>
                                <th style="text-align: center">{{$now_year_new}}-yilda tugatgan Guruhlar soni</th>

                                </tr>   
                                </thead>

                                <tbody>

                                @foreach($count as $item)

                                    <tr>

                                            @if($item->name_uz!="")

                                        <td>{{++$i}}</td>

                                        <td><a href="{{empty($data2) ? 'payreg' : '../paybranch'}}/{{ $item->id }}">{{$item->name_uz}}</a></a></td>

                                        <td>
                                        @if(($item->sum4))
                                        {{$item->sum4}}
                                        @endif
                                        @if(!($item->sum4))
                                             0
                                        @endif
                                        </td>
                                        <td>
                                        @if(($item->sum3))
                                        {{$item->sum3}}
                                        @endif
                                        @if(!($item->sum3))
                                             0
                                        @endif
                                        </td>
                                        <td>
                                        @if(($item->sum2))
                                        {{$item->sum2}}
                                        @endif
                                        @if(!($item->sum2))
                                             0
                                        @endif
                                        </td>
                                        <td>
                                        @if(($item->sum1))
                                        {{$item->sum1}}
                                        @endif
                                        @if(!($item->sum1))
                                             0
                                        @endif
                                        </td>
                                        <td>
                                        @if(($item->sum))
                                        {{$item->sum}}
                                        @endif
                                        @if(!($item->sum))
                                             0
                                        @endif
                                        </td>

                                        @endif

                                    </tr>

                                @endforeach

                                

                                </tbody>

                            </table>

                            <div class="row">

                                <div class="col-sm-5">

                                    Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries

                                </div>

                                <div class="col-sm-7">

                            

                                </div>

                            </div>

                        </div>

                    </div>



                </div>

            </div>

        </div>

    @endsection