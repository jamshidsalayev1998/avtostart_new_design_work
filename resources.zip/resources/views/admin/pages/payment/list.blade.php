@extends('layouts.admin_alisher')

@section('content')

    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
                     <div class="title-link">
                        <div>
                            <h1>To`lovlar tarixi</h1>
                            <p><span class="head-link-href">Bosh sahifa</span> / To`lovlar tarixi</p>
                        </div>
                        
                    </div>
                    <div class="table-toifa-CE">
                        <div class="h1-button">
                            <h1>To`lovlar tarixi</h1>
                            <button id="href_button"  class="add-fan">
                                <p> Excel</p>
                                
                            </button>
                        </div>
                        <div class="table-content">

                        <table class=" table-hover">

                            <thead>

                            <tr>

                                <th style="width: 2%"><p># </p></th>

                                <th style="text-align: center"><p>F.I.O. </p> </th>

                                <th style="text-align: center"><p>Filial nomi </p></th>

                                <th style="text-align: center;"><p>To'lov </p></th>

                                <th style="text-align: center;"><p>To'lov vaqti </p></th>

                                <?php if($role == 7):?>

                                <th style="text-align: center;"><p> </p></th>

                                <?php endif;?>

                            </tr>

                            </thead>

                            <tbody>

                            @foreach($data as $item)

                                <tr>

                                    <td><p>{{++$i}} </p></td>

                                    <td><p><a href="../payment/{{ $item->student_id }}">{{$item->first_name}} {{$item->middle_name}} {{$item->last_name}}</a> </p></td>

                                    <td><p><a href="../payment/branch/{{$item->branch_id}}">{{$item->branch_name}}</a> </p></td>

                                    <td><p>{{number_format($item->amount, 0, ',', ' ')}} </p></td>

                                    <td><p>{{$item->created_at}} </p></td>

                                    <?php if($role == 7):?>

                                    <td><p><a href="delete/{{$item->id}}"><i class="fa fa-remove btn btn-outline-primary"></i></a> </p></td>

                                    <?php endif;?>

                                </tr>

                            @endforeach

                            </tbody>

                        </table>

                        

                    </div>

                </div>



           

@endsection