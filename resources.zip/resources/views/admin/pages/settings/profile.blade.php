@extends('layouts.admin')
@section('content')
    <!-- START PAGE HEADING -->
    <div class="app-heading app-heading-background app-heading-light" style="background: url({{ asset('extra/header/header-2.jpg') }}) center center no-repeat;">
        <div class="contact contact-rounded contact-bordered contact-xlg status-online margin-bottom-0">
            <img @if(\Auth::user()->image  === null) src="/admin/img/user/no-image.png" @endif @if(\Auth::user()->image != null) src="{{ asset(\Auth::user()->image) }}" @endif>
            <div class="contact-container">
                <a href="#">{{ $data->name}}</a>
                <span>{{\Auth::user()->getRole()}}</span>
                <p>
                    <?php
                    if(($branch)){
                         echo $branch->name_uz;
                    }
                    if(!($branch)){
                    }
                ?>
                </p>
            </div>
        </div>
        <!--<div class="heading-elements">
            <a href="#" class="btn btn-danger" id="page-like"><span class="app-spinner loading"></span> loading...</a>
            <a href="https://themeforest.net/item/boooya-revolution-admin-template/17227946?ref=aqvatarius&license=regular&open_purchase_for_item_id=17227946" class="btn btn-success btn-icon-fixed"><span class="icon-text">$24</span> Purchase</a>
        </div>-->
    </div>
    <!-- END PAGE HEADING -->

    <!-- START PAGE SEPARATED CONTAINER -->
    <div class="app-content-separate app-content-separated-left" style="background:whitesmoke">

        <div class="app-content-separate-left" data-separate-control-height="true">
            <div class="app-content-separate-panel padding-20 visible-mobile">
                <div class="pull-left">
                    <h4 class="text-sm text-uppercase text-bolder margin-bottom-0">Sozlamalar</h4>
                    <p class="subheader">Desktop ekranda yaxshiroq masshtabli ko'rishga ega bo'lasiz!</p>
                </div>
                <button class="btn btn-default btn-icon pull-right" data-separate-toggle-panel=".app-content-separate-left"><span class="icon-menu"></span></button>
            </div>
            <div class="app-content-separate-content padding-20">

                <div class="list-group list-group-noborder">
                    <div class="list-group-title">Favorite</div>
                    <a href="#" class="form-control btn btn-primary btn-clean" data-toggle="modal" data-target="#modal-password"><span class="fa fa-lock">&nbsp;</span>Parolni o'zgartirish</a>
                    <a href="#" class="form-control btn btn-primary btn-clean margin-top-10" data-toggle="modal" data-target="#modal-image"><span class="fa fa-image">&nbsp;</span>Rasmni o'zgartirish</a>
                </div>
            </div>
        </div>
        <div class="app-content-separate-content" style="background: white">
            <!-- CONTENT CONTAINER -->
            <div class="container">
                <div class="row">
                    @if(session('message'))
                        <div class="col-md-12">
                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-checkmark-circle"></span>
                                </div>
                                {{ session('message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        </div>
                    @endif
                    @if(session('error'))
                        <div class="col-md-12">
                            <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-warning"></span>
                                </div>
                                {{ session('error') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        </div>
                    @endif
                    <div class="col-lg-12 col-md-6">
                        <div class="block block-condensed padding-top-20">
                            <div class="block-content">
                                @if(\Auth::user()->role == 7)
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <h3>Jamoa</h3>
                                        <p>Viloyat Rahbarlari</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($regionadmins as $admin)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 160px;">
                                                <img @if($admin->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($admin->user->image != null) src="{{ asset($admin->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $admin->full_name }}</a>
                                                    <strong>{{ $admin->region->name_uz }}</strong>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                @endif
                                @if(\Auth::user()->role == 6)
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <h3>Jamoa</h3>
                                        <p>Filiallar Rahbarlari</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($branchadmins as $admin)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($admin->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($admin->user->image != null) src="{{ asset($admin->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $admin->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                @endif
                                @if(\Auth::user()->role == 5)
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <h3>Jamoa</h3>
                                        <p>O'qituvchilar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($teachers as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>Moderatorlar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($moderators as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>Hisobchilar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($accountants as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                @endif

                                @if(\Auth::user()->role == 4)
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <h3>Jamoa</h3>
                                        <p>Filial rahbari</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    <div class="col-md-3 col-xs-6 col-sm-4">
                                        <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                            <img @if($branch->getManager()->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($branch->getManager()->user->image != null) src="{{ asset($branch->getManager()->user->image) }}" @endif>
                                            <div class="contact-container">
                                                <a href="#">{{ $branch->getManager()->user->name }}</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>O'qituvchilar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($teachers as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>Moderatorlar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($moderators as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>Hisobchilar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($accountants as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                @endif

                                @if(\Auth::user()->role == 3)
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <h3>Jamoa</h3>
                                        <p>Filial rahbari</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    <div class="col-md-3 col-xs-6 col-sm-4">
                                        <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                            <img @if($branch->getManager()->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($branch->getManager()->user->image != null) src="{{ asset($branch->getManager()->user->image) }}" @endif>
                                            <div class="contact-container">
                                                <a href="#">{{ $branch->getManager()->user->name }}</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>O'qituvchilar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($teachers as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>Moderatorlar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($moderators as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>Hisobchilar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($accountants as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                @endif

                                @if(\Auth::user()->role == 2)
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <h3>Jamoa</h3>
                                        <p>Filial rahbari</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    <div class="col-md-3 col-xs-6 col-sm-4">
                                        <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                            <img @if($branch->getManager()->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($branch->getManager()->user->image != null) src="{{ asset($branch->getManager()->user->image) }}" @endif>
                                            <div class="contact-container">
                                                <a href="#">{{ $branch->getManager()->user->name }}</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>O'qituvchilar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($teachers as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>Moderatorlar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($moderators as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>Hisobchilar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($accountants as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="#">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END CONTENT CONTAINER -->
        </div>
    </div>
    <!-- END PAGE SEPARATED CONTAINER -->
    <!-- MODAL PASSWORD -->
    <div class="modal fade" id="modal-password" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <div class="modal-body">

                    <div class="app-heading app-heading-small app-heading-condensed margin-bottom-30">
                        <div class="title">
                            <h5>Parolni o'zgartirish</h5>
                            <p>O'z parolingizni o'zgartiring</p>
                        </div>
                    </div>

                    <form  method="post" action="{{ route('settings.change_password') }}">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-12">
                                    <label>Amaldagi parol
                                            @if($errors->has('old_password'))
                                                <span class="text-danger"> | {{ $errors->first('old_password') }}</span>
                                            @endif
                                            @if(session('error_old'))
                                                <span class="text-danger"> | {{ session('error_old') }}</span>
                                            @endif
                                    </label>
                                    <input type="password" class="form-control" id="old_password" autocomplete="off" name="old_password" value="{{ old('old_password') }}" placeholder="Amaldagi parol">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6">
                                    <label>Yangi parol
                                        @if($errors->has('new_password'))
                                            <span class="text-danger"> | {{ $errors->first('new_password') }}</span>
                                        @endif
                                    </label>
                                    <input type="password" class="form-control" id="new_password" name="new_password" placeholder="Yangi parol" value="{{ old('new_password') }}">
                                </div>
                                <div class="col-md-6">
                                    <label>Yangi parolni takrorlang
                                        @if($errors->has('new_password_confirmation'))
                                            <span class="text-danger"> | {{ $errors->first('new_password_confirmation') }}</span>
                                        @endif
                                    </label>
                                    <input type="password" class="form-control" id="repeat" name="new_password_confirmation" placeholder="Yangi parolni takrorlang" value="{{ old('new_password_confirmation') }}">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="app-checkbox">
                                        <label><input type="checkbox" value="1" id="show_password"> Parolni ko'rsatish</label>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <button type="submit" class="btn btn-default pull-right">Saqlash</button>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- END MODAL PASSWORD -->
    <!-- MODAL PASSWORD -->
    <div class="modal fade" id="modal-image" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <div class="modal-body">

                    <div class="app-heading app-heading-small app-heading-condensed margin-bottom-30">
                        <div class="title">
                            <h5>Rasmni o'zgartirish</h5>
                        </div>
                    </div>

                    <form  method="post" action="{{ route('settings.changeimage') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <label for="image" class="control-label">
                                Amaldagi rasm
                                @if($errors->has('image'))
                                    <span class="text-danger"> | {{ $errors->first('image') }}</span>
                                @endif
                            </label>
                            <input type="file" name="image" id="image" class="dropify" @if(\Auth::user()->image  === null) data-default-file="/admin/img/user/no-image.png" @endif @if(\Auth::user()->image != null) data-default-file="{{ asset(\Auth::user()->image) }}" @endif step="any">
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <div class="app-checkbox">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <button type="submit" class="btn btn-default pull-right">Saqlash</button>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- END MODAL PASSWORD -->

@endsection