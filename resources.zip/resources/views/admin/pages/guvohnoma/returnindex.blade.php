@extends('layouts.admin')
@section('content')
@php $i = ($data->currentPage() - 1) * $data->perPage() @endphp

<div class="app-heading-container app-heading-bordered bottom">
    <ul class="breadcrumb">
        <li><a href="/backoffice">Dashboard</a></li>
        <li><a href="{{ route('payment.index') }}">Guvohnomalar</a></li>
    </ul>
    <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
</div>
<div class="container">
    <div class="row" style="margin-right: 12px;margin-left: 12px;">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="col-md-12">
                    <div class="col-md-6">
                        <h3 style="float: left"> Barcha berilgan guvohnomalar ro'yxati</h3>
                    </div>
                    <div class="col-lg-3">
                        <a href="../guvohnoma/serialnumber" class="btn btn-success pull-right"><span
                                class="fa fa-plus text-sm">&nbsp;</span>Seria raqamini kiritish</a>
                    </div>
                    @if(($guvohnoma_count))
                    <div class="col-lg-3">
                        <a href="../guvohnoma/return"  class="btn btn-success pull-right"><span
                                class="fa fa-plus text-sm">&nbsp;</span>Guvohnoma berish</a>
                    </div>
                    @endif
                </div>

                @if(session('message'))
                <div class="col-md-10">
                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                        <div class="alert-icon">
                            <span class="icon-checkmark-circle"></span>
                        </div>
                        {{ session('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                class="fa fa-times"></span></button>
                    </div>
                </div>
                @endif
            </div>
        </div>
        <div class="block block-condensed">
            <div style="padding: 10px;">
               
            </div>
            <div class="block-content">

                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Filial nomi</th>
                            <th>Guruh nomi</th>
                            <th>Berilgan guvohnomalar soni</th>
                            <th>Boshlanish seria raqami</th>
                            <th>Tugash seria raqami</th>
                            <th>Berilgan guvohnomalar soni</th>
                            <th>Guvohnomalarni olgan shaxs</th>
                            <th>Yaratilgan sana</th>
                     
                            
                        </tr>
                    </thead>
                    <tbody>
                             {{$data}}
                        @foreach($data as $item)

                        <tr style="@if(0) background: lightsalmon @endif">
                            <td>{{++$i}}</td>
                            <td>
                                <?php      $responsible=Test\Model\Branch::where('id', $item->branch_id )->first();?>
                                {{ $responsible->name_uz }}

                            </td>
                    
                            <td>
                                <?php      $responsible=Test\Model\Group::where('id', $item->group_id )->first();?>
                                {{ $responsible->name_uz }}

                            </td>
                            <td>{{ $item->count }}</td>
                            <td>{{ $item->count_1 }}</td>
                            <td>{{ $item->count_2 }}</td>
                            <td>{{ $item->take_person }}</td>
                            <td>{{ $item->date }}</td>
                
                                <td>
                                        <a class="justify-content-center" href="{{ route('student.show',['id'=>$item->student_id]) }}">
                                            <span class="icon-eye"></span>
                                        </a>
                                </td>
                            </tr>
            @endforeach
            </tbody>
            </table>
            <div class="row">
                <div class="col-sm-5">
                    Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}}
                    entries
                </div>
                <div class="col-sm-7">
               
                </div>     {{ $data->links() }}
            </div>
        </div>

    </div>
</div>
</div>
@endsection