@extends('layouts.admin')

@section('content')

    <?php 

    $summa=0;

?>

    <div class="app-heading-container app-heading-bordered bottom">

        <ul class="breadcrumb">

            <li><a href="/backoffice">Dashboard</a></li>

            <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>

            <li class="active">{{ $student->fio() }}</li>

            <li class="active">Barcha to'lovlari</li>

        </ul>

    </div>

    <div class="container">

        <div class="row" style="margin-right: 12px;margin-left: 12px;">

            <div class="block block-condensed">

                <div class="app-heading app-heading-small">

                    <div class="title">

                        <h2>{{ $student->fio() }}</h2>

                        <p>O'quvchining barcha to'lovlari ro'yxati.</p>

                    </div>

                    <div class="heading-elements">

                        <div class="input-group margin-right-5" style="width: 200px;">

                            <div class="input-group-addon">

                                <span class="fa fa-search"></span>

                            </div>

                            <input type="text" class="form-control" placeholder="Search">

                        </div>

                        <button class="btn btn-default btn-icon"><span class="icon-printer"></span></button>

                    </div>

                </div>



                <div class="block-content">

                    <table class="table table-bordered table-striped margin-bottom-10">

                        <thead>

                        <tr>

                            <th>To'lovchi FIO</th>

                            <th>To'langan summa</th>

                            <th>To'langan yili</th>

                            <th>Qolgan to'lov</th>

                            <th>Qo`shimcha funksiyalar</th>

                        </tr>

                        </thead>

                        <tbody>

                        @foreach($student->payments as $item)

                        

                        <tr style="@if(0) background: lightsalmon @endif">

                            <td>{{$item->student->fio()}}</td>

                            <td>{{ number_format($item->amount, 0, ',', ' ')  }}</td>

                            <td>{{ $item->created_at->format('Y')}}</td>

                            <td>

                             <?php 

                     

                                  $summa=$summa+$item->amount;

                                  echo(number_format($sum1-$summa, 0, ',', ' ') );

                             ?>

                            </td>

                            <td>

                                <div class="dropdown">

                                    <button type="button" class="btn btn-default btn-icon" data-toggle="dropdown" aria-expanded="false"><span class="icon-list"></span></button>

                                    <ul class="dropdown-menu dropdown-left">

                                            <li><a href="{{'update2'}}/{{ $item->student_id }}"><span class="icon-plus-circle"></span> To'lovni kiritish</a>

                                            </li>

                                        <li><a href="{{ route('payment.show',['id'=>$item->student_id]) }}"><span class="icon-list"></span> Barcha to'lovlar</a></li>

                                        <li><a href="{{ route('student.show',['id'=>$item->student_id]) }}"><span class="icon-user"></span> O'quvchini ko'rish</a></li>

                                        <li class="divider"></li>

                                    </ul>

                                </div>

                            </td>

                        </tr>

                        

                     

                        @endforeach

                        <tr style="@if(0) background: lightsalmon @endif">

                            <td>Umumiy summa</td>

                            <td>{{number_format($sum, 0, ',', ' ')}}</td>

                            <td>
                             @if(!empty($item->created_at))
                            {{ $item->created_at->format('Y')}}
                                 @endif
                            </td>

                            <td>

                            {{number_format($sum1-$sum, 0, ',', ' ')}}

                            </td>

                            <td>

                             

                            </td>

                        </tr>   

                        </tbody>

                    </table>

                </div>

            </div>



        </div>

    </div>

@endsection