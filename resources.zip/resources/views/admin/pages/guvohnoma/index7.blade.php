@extends('layouts.admin')
@section('content')
    @php $i = ($count2->currentPage() - 1) * $count2->perPage() @endphp
    <?php 
$k=0;
$x=0;
    foreach ($count as $key) {
        if ($key->name_uz!="") {
     $all_sum[$k]=$key->all_sum;

     $name[$k]=$key->name_uz;

     $sum2[$k]=$key->sum2;



     $pay1[$k]=$key->pay1;

     $pay2[$k]=$key->pay2;

     $pay_x[$k]=$key->pay_x;

     $pay_y[$k]=$key->pay_y;

            $k++;
}
        

    }  





?>

    <div class="container">

        <div class="row">

        

            <div class="col-md-12">

                <div class="panel panel-default">

                    <div class="panel-heading">

                        <h3 class="panel-title">Viloyatlar bo'yicha</h3>
                     
              
            <div class="col-md-4" style="float:right">
                <select class="bs-select group-decision"  id="group_id" data-live-search="true" data-dependent="student_id" name="student_id">
                    <option style="display: none">Guruhni tanlang</option>
=
                    @foreach($groups as $group)
                        <option value="{{ $groups[$i] }}"  data-href="payment/{{ $groups[$i] }}" name="year" >{{$groups[$i] }}</option>
                        <?php $i++; ?>
                    @endforeach
                </select>
            </div>

                    </div>
                    
                    <div class="panel-body">

                        @if(session('message'))

                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                <div class="alert-icon">

                                    <span class="icon-checkmark-circle"></span>

                                </div>

                                {{ session('message') }}

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                            </div>

                        @endif

                        <table class="table table-bordered table-hover">

                            <thead>

                            <tr>

                                <th style="width: 2%">#</th>

                                <th>Viloyat nomi</th>

                                <th style="text-align: center">O'quvchilar soni</th>

                                <th style="text-align: center">Umumiy summa</th>

                                <th style="text-align: center">To'langan summa</th>

                                <th style="text-align: center;">To'lanishi lozim</th>

                                <th style="text-align: center;">Qarzdor</th>

                            </tr>

                            <tr>

                            

                            </tr>

                            </thead>

                            

                            <tbody>

                                <?php 

                       foreach ($count2  as $item2):?>

                                     @if($item2->name_uz!="")

                                    <tr>

                                        <td>{{++$i}}</td>

                                        <td><a href="payment/region/{{$item2->id}}">{{$item2->name_uz}}</a></td>

                                        <td>{{$item2->student_count == 0 ? 0 : $item2->student_count}}</td>

                                    

                                      <td>{{$item2->all_sum == 0 ? 0 : number_format($item2->all_sum, 0, ',', ' ') }}</td>

                                       

                                        <td>

                                                <?php 

                                                

                                                echo  number_format($all_sum[$x], 0, ',', ' ');

                                               

                                                ?>

                                        </td>

                                     

                                        <td> <?php 

                                            echo number_format($item2->pay_x-$pay1[$x], 0, ',', ' ');

                                            ?></td>

                                        <td> <?php 

                                            echo   number_format( $item2->pay_y-$pay2[$x], 0, ',', ' ');

                                            ?></td>     

                                          </tr>

                                             <?php 

                                                

                                          $x++

                                         

                                          ?>

                                  @endif

                                  <?php endforeach; ?>

                                  

                                <tr>

                                    <th></th>

                                    <th>Umumiy summa</th>



                                    <th>

                                           

                                    

                                    </th>



                                    <th></th>

                                    <th></th>

                                    <th></th>

                                    <th></th>

                                </tr>

                            </tbody>

                        </table>

                        <div class="row">

                            <div class="col-sm-5">

                                Showing {{($count2->currentPage() - 1) * $count2->perPage() + 1}} to {{$i}} of {{$count2->total()}} entries

                            </div>

                    

                                {{ $count2->links() }}

                         

                        </div>

                    </div>

                </div>



            </div>

        </div>

    </div>

@endsection