@extends('layouts.admin')
@section('content')
<div class="container">
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('payment.index') }}">Guvohnomalar</a></li>
            <li class="active">Guvohnomalar berish</li>
        </ul>
    </div>
    <div class="block block-condensed">
        <div class="app-heading app-heading-small">
            <div class=" col-md-6 title">
                <h2 style="color: red;">Guvohnomalar berish</h2>
            </div>
            <div class="col-md-6">
                <button type="button" class="btn btn-success form-control"
                    onclick="$('#payment-form').submit()">Saqlash</button>

            </div>
        </div>

        <div class="block-content">

            <form action="../guvohnoma/serialnumbered" id="payment-form" method="post" class="form-horizontal"
                enctype="multipart/form-data" name="student-form" id="student-form">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-6 ">
                        <div class="form-group">
                            <label class="col-md-12 control-label">Guvohnoma seria raqami boslanishini kiriting
                                @if($errors->has('guvohnoma_count'))
                                <span class="text-danger"> | {{ $errors->first('guvohnoma_count') }}</span>
                                @endif
                            </label>
                            <div class="col-md-12">
                                <input type="text" class="form-control" name="guvohnoma_count" id="guvohnoma_count"
                                    value="<?=$guvohnoma_count?>" placeholder="00AA" maxlength="4">
                            </div>
                        </div>
                       
            </form>

        </div>
    </div>
</div>


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">To`lov qaytarish</h4>
            </div>
            <div class="modal-body">
                <p>Saqlash tugmasini bosganingizda o`quvchi guruhdan va monitoring, baholash bo`limidan o`chib
                    ketadi.Shuni e`tiborga olgan holda tugmani bosishingizni so`rab qolamiz.</p>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success form-control">Saqlash</button>
            </div>
        </div>

    </div>
</div>
@endsection