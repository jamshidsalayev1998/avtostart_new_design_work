@extends('layouts.admin')
@section('content')
<div class="container">
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('payment.index') }}">Guvohnomalar</a></li>
            <li class="active">Guvohnomalar berish</li>
        </ul>
    </div>
    <div class="block block-condensed">
        <div class="app-heading app-heading-small">
            <div class=" col-md-6 title">
                <h2 style="color: red;">Guvohnomalar berish</h2>
            </div>
            <div class="col-md-6">
                <button type="button" class="btn btn-success form-control"
                    onclick="$('#payment-form').submit()">Saqlash</button>

            </div>
        </div>

        <div class="block-content">

            <form action="../guvohnoma/returned" id="payment-form" method="post" class="form-horizontal"
                enctype="multipart/form-data" name="student-form" id="student-form">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-6 ">

                        <div class="form-group " style="margin-top: -32px;">

                            <label class="col-md-12 control-label">

                                @if($errors->has('student_id'))

                                <span class="text-danger"> | {{ $errors->first('student_id') }}</span>

                                @endif

                            </label>
                            <div class="col-md-5">
                                <label>Filialni tanlang:</label>
                                <select class="form-control " id="filial" data-live-search="true" data-dependent="area"
                                    name="filial_id">


                                </select>

                            </div>
                            <div class="col-md-3">
                                <label>Yil</label>
                                <select class="form-control " id="year_guvohnoma" name="groups_id">

                                </select>

                            </div>
                            <div class="col-md-4">
                                <label>Guruh</label>
                                <select class="form-control " id="groups_filial" name="groups_id">

                                </select>

                            </div>



                        </div>
                        <div class="form-group">
                            <label class="col-md-12 control-label"> Beriladigan guvohnomalar soni
                                @if($errors->has('guvohnoma_count'))
                                <span class="text-danger"> | {{ $errors->first('guvohnoma_count') }}</span>
                                @endif
                            </label>
                            <div class="col-md-12">
                                <input type="text" class="form-control" name="guvohnoma_count" id="guvohnoma_count"
                                    value="{{ old('guvohnoma_count') }}">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="col-md-12 control-label"> Guvohnomalar boshlanish seriyasi
                                        @if($errors->has('count_1'))
                                        <span class="text-danger"> | {{ $errors->first('count_1') }}</span>
                                        @endif
                                    </label>
                                    <div class="col-md-12">
                             <input type="text" class="form-control" name="count_1" value="<?=$guvohnoma_count?>"
                                           >
                                        <input type="text" class="form-control" name="count_1" type="number" maxlength="7" placeholder="Masalan:1234567"
                                            id="count_1" value="{{ old('count_1') }}">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="col-md-12 control-label">  Guvohnomalar tugash seriyasi
                                        @if($errors->has('count_2'))
                                        <span class="text-danger"> | {{ $errors->first('count_2') }}</span>
                                        @endif
                                    </label>
                                    <div class="col-md-12">
                                    <input type="text" class="form-control"   value="<?=$guvohnoma_count?>"  >
                                        <input type="text" class="form-control" name="count_2" type="number"  placeholder="Masalan:1234567"
                                            id="count_2" value="{{ old('count_2') }}">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-12 control-label"> Guvohnoma olgan shaxs
                                @if($errors->has('guvohnoma_take_person'))
                                <span class="text-danger"> | {{ $errors->first('guvohnoma_take_person') }}</span>
                                @endif
                            </label>
                            <div class="col-md-12">
                                <input type="text" class="form-control" name="guvohnoma_take_person" id="take_person"
                                    value="{{ old('guvohnoma_take_person') }}">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-12 control-label margin-bottom-0">Berilgan guvohnomalar sanasi
                                @if($errors->has('guvohnoma_date'))
                                <span class="text-danger"> | {{ $errors->first('guvohnoma_date') }}</span>
                                @endif
                            </label>
                            <div
                                class="col-md-12 input-group bs-datepicker control-label margin-left-20 margin-right-10">
                                <input type="text" class="form-control" name="guvohnoma_date" id="guvohnoma_date"
                                    value="{{ old('guvohnoma_date') }}">
                                <span class="input-group-addon">
                                    <span class="icon-calendar-full"></span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="block block-condensed" id="student_info" style="padding-bottom: 15px;">
                            <p style="padding: 0px 0 0px 10px;   font-size: 18px;text-align: center;">Guruh haqida
                                ma'lumot shu yerda ko'rinadi</p>
                            <span style="font-size:16px;margin-left: 10px;" id="students_name">Jami berilish kerak
                                bol`gan guvohnomalar soni :</span>
                            <br>
                            <br>
                            <span style="font-size: 16px;margin-left: 10px;">Guruh nomi:<span style="color:red"
                                    id="group_name"> </span>
                                <br>

                                <br>
                                <span style="font-size: 16px;margin-left: 10px;">O`quvchilar soni:<span
                                        style="color:red" id="student_correct1"></span> </span>
                                <br>
                                <br>
                                <span style="font-size: 16px;margin-left: 10px;">Testga ruxsat berilganlar soni:<span
                                        style="color:red" id="student_correct2"> </span>
                                    <br>
                                    <br>
                                    <span style="font-size: 16px;margin-left: 10px;">Testdan o`tganlar soni:<span
                                            style="color:red" id="student_correct3"> </span>
                                        <br>
                                        <br>
                                        <span style="font-size: 16px;margin-left: 10px;">Berilgan guvohnomalar
                                            soni:<span style="color:red" id="student_correct4"> </span>
                                            <br>
                                            <br>


                        </div>
                        <div>



                        </div>
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">To`lov qaytarish</h4>
            </div>
            <div class="modal-body">
                <p>Saqlash tugmasini bosganingizda o`quvchi guruhdan va monitoring, baholash bo`limidan o`chib
                    ketadi.Shuni e`tiborga olgan holda tugmani bosishingizni so`rab qolamiz.</p>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success form-control">Saqlash</button>
            </div>
        </div>

    </div>
</div>
@endsection