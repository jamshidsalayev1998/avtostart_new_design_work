@extends('layouts.admin')

@section('content')

@php $i = ($data->currentPage() - 1) * $data->perPage() @endphp



<div class="app-heading-container app-heading-bordered bottom">

    <ul class="breadcrumb">

        <li><a href="/backoffice">Dashboard</a></li>

        <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>

    </ul>

    <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>

</div>

<div class="container">

    <div class="row" style="margin-right: 12px;margin-left: 12px;">

        <div class="panel panel-default">

            <div class="panel-body">

                <div class="col-md-12">

                    <div class="col-md-6">

                        <h3 style="float: left"> Barcha to'lovlar ro'yxati</h3>

                    </div>

                    <div class="col-lg-6">

                        <a href="{{route('payment.create')}}" class="btn btn-success pull-right"><span

                                class="fa fa-plus text-sm">&nbsp;</span>Yangi to'lov kiritish</a>

                    </div>

                </div>



                @if(session('message'))

                <div class="col-md-10">

                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                        <div class="alert-icon">

                            <span class="icon-checkmark-circle"></span>

                        </div>

                        {{ session('message') }}

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span

                                class="fa fa-times"></span></button>

                    </div>

                </div>

                @endif

            </div>

        </div>

        <div class="block block-condensed">

            <div style="padding: 10px;">

                <strong style="padding: 20px;font-size:16px;">Ja'mi to'lovlar:

                    &nbsp;{{ $branch->getTotalDeposits() }}</strong>

            </div>

            <div class="block-content">



                <table class="table table-striped table-bordered">

                    <thead>

                        <tr>

                            <th>#</th>

                            <th>To'lovchi FIO</th>

                            <th>To'langan summa</th>

                            <th>Yaratilgan sana</th>

                            <th>To'langan sana</th>

                            <th>O`zgartirish</th>

                            <th>O`chirish</th>

                            <th>Qo`shimcha funksiyalar</th>

                        </tr>

                    </thead>

                    <tbody>

                             {{$data}}

                        @foreach($data as $item)



                        <tr style="@if(0) background: lightsalmon @endif">

                            <td>{{++$i}}</td>

                            <td>{{$item->student->fio()}}</td>

                            <td>{{ number_format($item->amount, 0, ',', ' ')  }}</td>

                            

                            <td>{{date("d/m/Y H:i",strtotime($item->created_at))}}</td>

                           

                            <td>{{date(($item->payment_date))}}</td>

                                <td>

                             

                                @if(strtotime($item->permission_time)-($now_second)>0)

                                <a class="justify-content-center" href="{{'payment/update'}}/{{ $item->id }}">

                                    <span class="icon-pencil"></span>

                                </a> 

                                @endif

                                </td>

                                <td>

                                @if(strtotime($item->permission_time)-($now_second)-777600>0)

                                <a class="justify-content-center" href="{{'payment/delete'}}/{{ $item->id }}">

                                    <span class="icon-trash"></span>

                                </a>

                                @endif

                                </td>

                                <td>

                                <div class="dropdown">

                                    <button type="button" class="btn btn-default btn-icon" data-toggle="dropdown"

                                        aria-expanded="false"><span class="icon-list"></span></button>

                                    <ul class="dropdown-menu dropdown-left">

                                        <li><a href="{{'payment/update2'}}/{{ $item->student_id }}"><span class="icon-plus-circle"></span> To'lovni kiritish</a>

                                        </li>

                                        <li><a href="{{ route('payment.show',['id'=>$item->student_id]) }}"><span

                                                    class="icon-list"></span> Barcha to'lovlari</a></li>

                                        <li><a href="{{ route('student.show',['id'=>$item->student_id]) }}"><span

                                                    class="icon-user"></span> O'quvchini ko'rish</a></li>

                                        <li class="divider"></li>

                                    </ul>

                                </div>  

                                

                            </td>

                            </tr>

            @endforeach

            </tbody>

            </table>

            <div class="row">

                <div class="col-sm-5">

                    Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}}

                    entries

                </div>

                <div class="col-sm-7">

               

                </div>     {{ $data->links() }}

            </div>

        </div>



    </div>

</div>

</div>

@endsection