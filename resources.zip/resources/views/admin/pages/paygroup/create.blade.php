@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('paylist.index') }}">Ma'lumotlar</a></li>
            <li class="active">Ma'lumotlarni yangilash</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="col-12">
            <form action="{{ route('paylist.store') }}" method="post">
                <div class="panel panel-default">
                    <div class="panel-heading">

                    </div>
                    <div class="panel-body">
                        {{ csrf_field() }}
                        <table class="table">
                            <tbody>
                            <tr>
                                <th>Tashkilot nomi</th>
                                <td>
                                    <input type="text" class="form-control" name="name" value="{{ empty(old('name')) ? $data->name : old('name') }}">
                                </td>
                            </tr>
                            <tr>
                                <th>Manzil</th>
                                <td>
                                    <input type="text" class="form-control" name="address" value="{{ empty(old('address')) ? $data->address : old('address') }}">
                                </td>
                            </tr>
                            <tr>
                                <th>Telfon raqami</th>
                                <td>
                                    <input type="text" class="form-control" name="phone" value="{{ empty(old('phone')) ? $data->phone : old('phone') }}">
                                </td>
                            </tr>
                            <tr>
                                <th>Bank</th>
                                <td>
                                    <input type="text" class="form-control" name="bank" value="{{ empty(old('bank')) ? $data->bank : old('bank') }}">
                                </td>
                            </tr>
                            <tr>
                                <th>Hisob raqam</th>
                                <td>
                                    <input type="text" class="form-control" name="bill" value="{{ empty(old('bill')) ? $data->bill : old('bill') }}">
                                </td>
                            </tr>
                            <tr>
                                <th>INN</th>
                                <td>
                                    <input type="text" class="form-control" name="inn" value="{{ empty(old('inn')) ? $data->inn : old('inn') }}">
                                </td>
                            </tr>
                            <tr>
                                <th>MFO</th>
                                <td>
                                    <input type="text" class="form-control" name="mfo" value="{{ empty(old('mfo')) ? $data->mfo : old('mfo') }}">
                                </td>
                            </tr>
                            <tr>
                                <th>Bitta o'quvchi uchun narx</th>
                                <td><input type="number" min="100" class="form-control" name="price" value="{{ empty(old('price')) ? $data->price : old('price') }}"></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="panel-footer text-right">
                        <button class="btn btn-success" type="submit">Saqlash</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection