@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                    Tasdiqlanmagan to`lovlar
                    </div>
                    <div class="panel-body">
                            <table id="DataTables_Table_0" class="table  table-bordered datatable-extended dataTable ">
                                <thead>
                                <tr>
                                    <th>
                                        Filial
                                    </th>
                                    <th>
                                        To`lov raqami
                                    </th>
                                    <th>
                                        Guruhlar va tolangan foizlar
                                    </th>
                                    <th>
                                        To`langan pul
                                    </th>
                                    <th>
                                        Tolangan sana
                                    </th>
                                    <th>
                                        Korish
                                    </th>
                                    <th>
                                        PDF
                                    </th>
                                    <th>
                                        Tasdiqlash
                                    </th>
                                </tr>
                            </thead>
                            <tbody >
                               @foreach ($data as $item)
                               <tr>
                                    <td>
                                        <?php $branch = 'Test\Model\Branch'::where('id', $item[0]->branch_id)->first();?>
                                        {{$branch->name_uz}}
                                    </td>
                                    <td>
                                        {{ $item[0]->pay_number }}
                                    </td>
                                    <td>
                                        @foreach ($item as $pyg)
                                            {{ $pyg->group->name_uz }} | {{ $pyg->percent }}% <br>
                                        @endforeach
                                    </td>
                                    <td>
                                        {{ $item->sum('payment') }}
                                    </td>
                                    <td>
                                        {{ $item[0]->payment_date }}
                                    </td>
                                    <td>
                                            <a href="{{route('newshow' , ['id' => $pyg->pay_number])}}" class="btn btn-sm btn-default btn-icon">
                                                <span  class="fa fa-eye"></span>
                                            </a>
                                    </td>
                                    <td>
                                        <a href="{{route('forprint' , ['pay_number' => $pyg->pay_number])}}" class="btn btn-icon "><span style="font-size: 34px;" class="fa fa-print"></span></a>

                                    </td>
                                    <td>
                                       <form action="{{route('checking' , ['pay_number' => $item[0]->pay_number])}}" method="post">
                                            {{ csrf_field() }}
                                            {{ method_field('put') }}
                                            <button type="submit " onclick="return confirm('Siz bu to`lovni tasdiqlaysizmi?')" class="btn btn-sm btn-default btn-icon"><span class="fa fa-check"></span></button>
                                        </form>
                                    </td>
                               </tr>
                               @endforeach
                            </tbody>


                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script type="text/javascript">
    $(document).ready( function () {
        $('#jmtable').DataTable();
    } );
</script>



<script !src="">inputdate.max = new Date().toISOString().split("T")[0];</script>
@endsection