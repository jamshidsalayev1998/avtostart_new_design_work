<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">

    <title>Document</title>

</head>

<style media="print">
    .col{
         float: left;
    }
    .borderr{
        border: 1px solid black;
        padding: 2px;
    }
    .mt5{
        margin-top: 10px;
        margin-bottom: 10px;
    }
    .p3{
        padding: 3px;
    }
    .p10{
        padding: 10px;
    }
    .bggrey{
        background-color: #E9EEF2;
    }
    .fbold{
        font-weight: bold;
    }
</style>
<body class="p10" >


   <div   style="padding: 7px;background-color: white; border: 1px solid black; margin-top: 20px; color: black" >
       <div class="row">
           <div class="col-lg-12 text-center fbold" >
               Платежное поручение
           </div>
           <div class="col-lg-12">
               <hr style="border: 1px solid black" class="w-100">
           </div>
       </div>

       <div class="row ">
           <div class="col-lg-6">
               <div class="col-lg-4 text-right">
                   Номер документа
               </div>
               <div class="col-lg-4 borderr bggrey"  >
                   123456789
               </div>
           </div>
           <div class="col-lg-6">
               <div class="col-lg-6 text-right">
                   Data dokumenta
               </div>
               <div class="col-lg-3 borderr bggrey" >
                   24.01.2020
               </div>

           </div>
       </div>
       <div class="row mt5" >
           <div class="col-lg-12 text-center fbold">
               Debet plateleshika
           </div>

       </div>
       <div class="row mt5">
           <div class="col-lg-2">
                Naimenovaniya  platelshika:
           </div>
           <div class="col-lg-5 borderr">
               <span class="border p3">
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. A error explicabo fuga magni minima mollitia quod, vel vero! Ab, ipsam?
               </span>
           </div>
           <div class="col-lg-1">
               INN platyojka:
           </div>
           <div class="col-lg-3 h-auto borderr p3">

                <span class="w-100">
                     123456456789
                </span>

           </div>
       </div>
       <div class="row mt5">
           <div class="col-lg-2">
              Shot platyojka
           </div>
           <div class="col-lg-3 borderr bggrey  ">
               <span class=" p3">
                  456456456456456456
               </span>
           </div>
           <div class="col-lg-4 text-right">
                Kod banka
           </div>
           <div class="col-lg-2 borderr bggrey">
                 123456
           </div>
       </div>
       <div class="row mt-5">
           <div class="col-lg-2">
                 Naimenovanie banka
           </div>
           <div class="col-lg-8 borderr p3 bggrey">
               Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti esse exercitationem explicabo, fugiat in laborum maiores numquam pariatur quae quis recusandae vero.
           </div>
       </div>
       <div class="row mt-5" style="margin-top: 10px;">
           <div class="col-lg-2">
               Summa platyoja
           </div>
           <div class="col-lg-3 fbold borderr bggrey p3 text-right">
               45647895.123
           </div>
       </div>
       <div class="row mt-5" style="margin-top: 10px;">
             <div class="col-lg-12 fbold text-center">
                 Kredit poluchatelya
             </div>
       </div>
       <div class="row mt5">
           <div class="col-lg-2">
               Naimenovaniya  poluchatelya:
           </div>
           <div class="col-lg-5 borderr">
               <span class="border p3">
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. A error explicabo fuga magni minima mollitia quod, vel vero! Ab, ipsam?
               </span>
           </div>
           <div class="col-lg-1">
               INN poluchatelya:
           </div>
           <div style="margin-left: 7px;" class="col-lg-3 h-auto borderr p3">

                <span class="w-100">
                     123456456789
                </span>

           </div>
       </div>
       <div class="row mt5">
           <div class="col-lg-2">
               Shot paluchatelya:
           </div>
           <div class="col-lg-3 borderr bggrey  ">
               <span class=" p3">
                  456456456456456456
               </span>
           </div>
           <div class="col-lg-4 text-right">
               Kod banka poluchatelya:
           </div>
           <div class="col-lg-2 borderr bggrey">
               123456
           </div>
       </div>
       <div class="row mt-5">
           <div class="col-lg-2">
               Naimenovanie banka
           </div>
           <div class="col-lg-8 borderr p3 bggrey">
               Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti esse exercitationem explicabo, fugiat in laborum maiores numquam pariatur quae quis recusandae vero.
           </div>
       </div>
       <div class="row mt5">
           <div class="col-lg-2">
               summa propisano:
           </div>
           <div class="col-lg-8 fbold">
               Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt, reiciendis?
           </div>
       </div>
       <div class="row mt5">
           <div class="col-lg-2">
               Nazvaniya platyoja:
           </div>
           <div class="col-lg-8 borderr p3">
               Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur ipsam quo soluta? Ad delectus dolore est facere iure laborum numquam quasi reprehenderit velit veritatis? Iste labore necessitatibus repellendus sit voluptatum?
           </div>
       </div>


   </div>




   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>