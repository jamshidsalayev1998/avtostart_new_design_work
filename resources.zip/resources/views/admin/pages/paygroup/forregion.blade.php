@extends('layouts.admin_alisher')

@section('content')
    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
            <div class="title-link">
                <div>
                    <h1>Toifalar</h1>
                    <p><span>Darsliklar</span>/Toifalar</p>
                </div>
                                    
            </div>
            <div class="table-toifa">
                <h1>Ta’lim turini tanlang</h1>
                <div class="table-content">


                        <table >
                            <tr>
                                <th class="text-center"><p># </p></th>
                                <th class="text-center"><p>{{ $link == 'region' ? 'Viloyat' : 'Filial' }} </p></th>
                                <th class="text-center"><p>Barcha guruhlar </p></th>
                                <th class="text-center"><p>To`liq to'langanlar </p></th>
                                <th class="text-center"><p>Qisman to'langanlar</th>
                                <th class="text-center"><p>Tasdiqlash kutilayotgan (guruhlar) </p></th>
                                <th class="text-center"><p>To'lamanganlar </p></th>
                            </tr>
                            @php $i = 0 @endphp
                            @foreach($branches as $branch)
                                <tr style="@if(0) background: lightsalmon @endif">
                                    <td class="text-center"><p>{{++$i}}</p></td>
                                    <td><p><a href="{{ route('paygroup.'.$link, ['id' => $branch->id]) }}">{{ $branch->name_uz }}</a></td>
                                    <td class="text-center"><p>{{ count('Test\Model\Group'::where('branch_id' , $branch->id)->where('status' , '=' ,  1)->orWhere('status' , '=' , 2)->get()) }}</td>
                                    <?php
                                        $count_tolangan = 0;
                                        $tolamagan = 0;
                                        $count_tasdiqlanmagan = 0;
                                        $qisman = 0;
                                        foreach ($branch->groups as $group) {
                                        	if ($group->status == 1 || $group->status == 2) {
                                        		if (count('Test\Model\Paygroup'::where('group_id', $group->id)->where('percent', '!=', 100)->where('status', 2)->get()) == 1) {
                                        			$qisman++;
                                        		}
                                        		if ('Test\Model\Paygroup'::where('group_id', $group->id)->get()->sum('percent') == 100) {
                                        			$ttt = 0;
                                        			foreach ('Test\Model\Paygroup'::where('group_id', $group->id)->get() as $pygs) {
                                        				if ($pygs->status == 1) {
                                        					$ttt = 1;
                                        				}
                                        			}
                                        			if ($ttt == 0) {
                                        				$count_tolangan++;
                                        			}
                                        		}

                                        		if (!'Test\Model\Paygroup'::where('group_id', $group->id)->exists()) {
                                        			$tolamagan++;
                                        		} else {
                                         			$ddd = 0;
                                        			foreach ('Test\Model\Paygroup'::where('group_id', $group->id)->get() as $pygr) {
                                        				if ($pygr->status == 2) {
                                        					$ddd = 1;
                                        				}
                                        			}
                                        			if ($ddd == 0) {
                                        				$tolamagan++;
                                        			}
                                        		}
                                        	}
                                        }

                                    ?>
                                    <td class="text-center"><p>
                                        {{$count_tolangan}}</p>
                                    </td>
                                    <td class="text-center"><p>
                                        {{$qisman}}</p>
                                    </td>
                                    <td class="text-center"><p>
                                        {{count('Test\Model\Paygroup'::where('branch_id' , $branch->id)->where('status' , '!=' , 2)->get()->groupBy('group_id'))}}</p>
                                    </td>
                                    <td class="text-center"><p>
                                        {{$tolamagan}}</p>
                                    </td>
                                </tr>
                            @endforeach

                        </table>
                        Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}}
                        {{ $data->links() }}
                    </div>
                </div>

@endsection