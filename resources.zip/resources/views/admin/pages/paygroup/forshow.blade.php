@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                            <div class="col-sm-5 text-center">To`lov raqami : <b>{{$paygroups[0]->pay_number}}</b></div>
                        <div class="col-sm-5 text-center">To`lov qilingan sana: <b>{{$paygroups[0]->payment_date}}</b></div>
                        <div class="col-sm-2 text-right"><a href="{{route('forprint' , ['pay_number' => $paygroups[0]->pay_number])}}" class="btn btn-icon "><span style="font-size: 34px;" class="fa fa-print"></span></a></div>

                    </div>
                    <div class="panel-body">
                        <table class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>
                                    #
                                </th>
                                <th>
                                    Guruh nomi
                                </th>
                                <th>
                                   To`langan foiz
                                </th>
                                <th>
                                    Guruh o`quvchilar soni
                                </th>
                                <th>
                                    To`langan pul miqdori
                                </th>
                                <th>
                                    Qolgan qarz
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $ii =1; ?>

                                @foreach($paygroups as $pyg)
                                   @if(isset($pyg))
                                       <tr>
                                           <td>
                                               {{$ii}}
                                           </td>
                                           <td>
                                               {{$pyg->group->name_uz}}
                                           </td>
                                           <td>
                                               {{$pyg->percent}}
                                           </td>
                                           <td>
                                               {{count($pyg->group->students)}}
                                           </td>
                                           <td>
                                               {{count($pyg->group->students)*$price[0]->price*$pyg->percent/100}}
                                           </td>
                                           <td>
                                                   <?php $tolangan = Test\Model\Paygroup::where('group_id' , $pyg->group_id)->sum('percent'); ?>
                                               @if($tolangan != 100)
                                                     {{count($pyg->group->students)*$price[0]->price-count($pyg->group->students)*$price[0]->price*$pyg->percent/100}}
                                                   @endif
                                           </td>
                                       </tr>
                                       @endif

                                   <?php $ii++; ?>
                                    @endforeach


                            </tbody>
                        </table>
                        <div class="col-sm-12 text-center">
                        @if(session('message'))
                            <div class="col-12">
                                <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                      
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        @endif
                        </div>
                        <style>
                            div.rowj{
                                width: 50%;
                            }
                        </style>
                        <div class="col-sm-12" style="display: flex; justify-content: flex-end;">
                            
                            <div class="rowj" style="display: flex; justify-content: flex-end;">
                                <a href="{{url()->previous()}}" class="btn btn-dark">Orqaga</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
@endsection