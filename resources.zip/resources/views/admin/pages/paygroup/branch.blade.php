@extends('layouts.admin')

@section('content')
@php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        @if(\Illuminate\Support\Facades\Auth::user()->role == 2 ||  \Illuminate\Support\Facades\Auth::user()->role == 5)
                            <form action="/backoffice/pay/create" class="row" method="post">
                                {{ csrf_field() }}
                                <div class="col-sm-2">
                                    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Yangi</button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="myModal" role="dialog">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title">To`lov yaratish</h4>
                                                    <p>
                                                        @if(session('message'))
                                                            {{session('message')}}
                                                        @endif
                                                    </p>
                                                </div>

                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-sm-12">
                                                                <table class="table table-striped table-bordered">
                                                                    <thead>
                                                                    <tr>
                                                                        <td>
                                                                            Tanlash
                                                                        </td>
                                                                        <td>
                                                                            Guruh nomi
                                                                        </td>
                                                                        <td>
                                                                            O`quvchilar soni
                                                                        </td>
                                                                        <td>
                                                                            Guruh uchun to`lov
                                                                        </td>
                                                                        <td>
                                                                            To`lanadigan foiz
                                                                        </td>

                                                                    </tr>
                                                                    </thead>
                                                                    <tbody class="bodyy">
                                                                        <?php $ee = 0;
$ftu = 1;?>
                                                                        @foreach($groups as $group)
                                                                            @if(!isset($group->paygroups[0]))
                                                                                 <tr id="tr{{$ftu}}">
                                                                                    <td>
                                                                                        <input type="checkbox" name="input[check][{{$group->id}}]" value="{{$group->id}}" class="form-control leftt">
                                                                                    </td>
                                                                                    <td>
                                                                                        {{$group->name_uz}}
                                                                                    </td>
                                                                                    <td>
                                                                                        {{count($group->students)}}
                                                                                    </td>
                                                                                    <td class="centerr">
                                                                                        {{count($group->students)*$price_gr->price}}
                                                                                    </td>
                                                                                    <td>
                                                                                        <select  name="input[percent][{{$group->id}}]" class="form-control rightt" >
                                                                                            <option value="100">100%</option>
                                                                                            <option value="70">70%</option>
                                                                                            <option value="30">30%</option>
                                                                                        </select>
                                                                                    </td>

                                                                                </tr>
                                                                                <?php $ee++;
$ftu++;?>
                                                                            @endif
                                                                            @if(isset($group->paygroups[0]) && count($group->paygroups) == 1 && $group->paygroups[0]->percent != 100)
                                                                                <tr id="tr{{$ftu}}">
                                                                                    <td>
                                                                                        <input type="checkbox" name="input[check][{{$group->id}}]" value="{{$group->id}}" class="form-control leftt">
                                                                                    </td>
                                                                                    <td>
                                                                                        {{$group->name_uz}}
                                                                                    </td>
                                                                                    <td>
                                                                                        {{count($group->students)}}
                                                                                    </td>
                                                                                    <td class="centerr">
                                                                                        {{count($group->students)*$price_gr->price}}
                                                                                    </td>
                                                                                    <td>
                                                                                        <select name="input[percent][{{$group->id}}]" class="form-control rightt" >
                                                                                            @if($group->paygroups[0]->percent == 30)
                                                                                                <option value="70">70%</option>
                                                                                            @else
                                                                                                <option value="30">30%</option>
                                                                                            @endif
                                                                                        </select>
                                                                                    </td>

                                                                                </tr>
                                                                                <?php $ee++;
$ftu++;?>
                                                                            @endif
                                                                        @endforeach
                                                                    </tbody>
                                                                </table>
                                                                @if($ee != 0)
                                                                    <div class="col-sm-4">
                                                                        <label for="">Tolangan vaqti</label>
                                                                        @if($errors->has('paydate'))

                                                                            <span class="text-danger"> | {{ $errors->first('paydate') }}</span>

                                                                        @endif
                                                                        <input required type="date" class="form-control" name="paydate">
                                                                    </div>
                                                                    <div class="col-sm-8">
                                                                        <strong >Umumiy summa:</strong> <b style="color:green" class="summa"></b>
                                                                    </div>
                                                                @else
                                                                    <div class="col-sm-12 text-center"><label for="">To`lov qilinmagan guruhlar yo`q</label></div>
                                                                @endif

                                                            </div>
                                                        </div>
                                                    </div>

                                                <div class="modal-footer">
                                                    @if($ee != 0)
                                                        <button type="submit" class="btn btn-default" >Yaratish</button>
                                                    @else
                                                        <button  type="submit" class="btn btn-default" disabled="" >Yaratish</button>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                 <strong>To`lovlar faqat  aktiv guruhlar uchun amalga oshadi!</strong>
                            </form>
                        @endif

                        @if(\Illuminate\Support\Facades\Auth::user()->role == 7 || \Illuminate\Support\Facades\Auth::user()->role == 6)
                          <div class=" col-sm-12">
                              <div class="col-sm-4">  Filial nomi: {{$branch->name_uz}}</div>
                              <div class="col-sm-4">Viloyat: {{$branch->region->name_uz}}</div>
                          </div>
                        @endif
                    </div>
                    <div class="panel-body">
                        @if(session('message'))
                            <div class="col-12">
                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        @endif
                            @if(session('message_error'))
                                <div class="col-12">
                                    <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">

                                        {{ session('message_error') }}
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                    </div>
                                </div>
                            @endif

                            <table id="DataTables_Table_0" class="table  table-bordered ">
                                <thead>
                                <tr>
                                    <th>№
                                    </th>

                                    <th>
                                        To`lov raqami
                                    </th>
                                    <th>
                                        Guruhlar va tolangan foizlar
                                    </th>
                                    <th>
                                        To`langan pul
                                    </th>
                                    <th>
                                        Tolangan sana
                                    </th>
                                    <th>
                                        Ko`rish
                                    </th>

                                   @if(\Illuminate\Support\Facades\Auth::user()->role == 2 || \Illuminate\Support\Facades\Auth::user()->role == 5)
                                        <th>
                                            Holati
                                        </th>
                                        <th>
                                            O`chirish
                                        </th>
                                       @endif

                                    @if(\Illuminate\Support\Facades\Auth::user()->role == 7)
                                        <th>
                                            Tasdiqlash
                                        </th>
                                    @endif

                                    <th>
                                        PDF
                                    </th>


                                </tr>
                            </thead>
                            <tbody >
                            <?php $ii = 1?>
                            @foreach($paygroups as $paygroup)
                                <?php $tt = 0;?>
                                <?php $summa = $paygroup->sum('payment');?>
                                @foreach($paygroup as $pyg)
                                    <tr>
                                        @if($tt == 0)
                                            <td rowspan="{{count($paygroup)}}">
                                                 {{$ii}}
                                                <?php $ii++;?>
                                            </td>
                                            <td rowspan="{{count($paygroup)}}">
                                                {{$pyg->pay_number}}
                                            </td>
                                            @endif
                                        <td style="border: 1px solid #DBE0E4;">
                                            {{$pyg->group->name_uz}} | {{$pyg->percent}}%
                                        </td>
                                        @if($tt == 0)
                                            <td rowspan="{{count($paygroup)}}">
                                                  {{$summa}} so`m
                                            </td>
                                            <td rowspan="{{count($paygroup)}}">
                                                  {{$pyg->payment_date}}
                                            </td>
                                            <td rowspan="{{count($paygroup)}}">
                                                <a href="{{route('newshow' , ['id' => $pyg->pay_number])}}" class="btn btn-sm btn-default btn-icon">
                                                    <span  class="fa fa-eye"></span>
                                                </a>
                                            </td>
                                                @if(\Illuminate\Support\Facades\Auth::user()->role == 2 || \Illuminate\Support\Facades\Auth::user()->role == 5 )

                                                    @if($pyg->status == 2)
                                                                <td rowspan="{{count($paygroup)}}" style="background-color: #7fff24">
                                                                    Tasdiqlangan
                                                                        @else
                                                                <td rowspan="{{count($paygroup)}}" style="background-color: #ff6817">
                                                                    Tasdiqlanmagan
                                                           @endif
                                                            </td>
                                                            @if($pyg->status == 1)
                                                                <td rowspan="{{count($paygroup)}}">
                                                                    <form action="{{route('newdelete' , ['pay_number' => $pyg->pay_number])}}" method="post">
                                                                        {{ csrf_field() }}
                                                                        {{ method_field('delete') }}
                                                                        <button onclick="return confirm('Bu ma`lumot o`chirilsinmi?')" class="btn btn-sm btn-default btn-icon">
                                                                            <span  class="fa fa-trash"></span>
                                                                        </button>
                                                                    </form>
                                                                </td>
                                                            @endif

                                                @endif
                                            @if(\Illuminate\Support\Facades\Auth::user()->role == 7 && $pyg->status == 1)
                                                <td  rowspan="{{count($paygroup)}}">
                                                    <form action="{{route('checking' , ['pay_number' => $pyg->pay_number])}}" method="post">
                                                        {{ csrf_field() }}
                                                        {{ method_field('put') }}
                                                        <button type="submit " onclick="return confirm('Siz bu to`lovni tasdiqlaysizmi?')" class="btn btn-sm btn-default btn-icon"><span class="fa fa-check"></span></button>
                                                    </form>

                                                </td >
                                                @elseif($pyg->status == 2)
                                                <td  rowspan="{{count($paygroup)}}"></td>
                                                @endif
                                                        <td  rowspan="{{count($paygroup)}}">
                                                            <a href="{{route('forprint' , ['pay_number' => $pyg->pay_number])}}" class="btn btn-icon "><span style="font-size: 34px;" class="fa fa-print"></span></a>
                                                        </td>
                                            @endif
                                    </tr>
                                    <?php $tt++;?>
                                    @endforeach

                                @endforeach
                            </tbody>


                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script >

        function bustan(){

            var s = 0;
            var t = 0;
        var tt = $("tbody.bodyy tr");
            for(var i = 1; i <= tt.length; i++){
                var tr = $("#tr"+i).find(".centerr");
                if($("#tr"+i).find(".leftt").is(':checked')){
                    var tr = $("#tr"+i).find(".centerr");
                    var f = $("#tr"+i).find(".rightt");
                    var foiz = parseInt(f.val());
                    var price = parseInt(tr.text());
                    var summa = price*foiz/100;
                    s=s+summa;
                }
            }
            var sum = $(".summa");
            sum.html(s);
        }



        $(document).ready(function() {
            $(".leftt").change(function(){
                bustan();
            });
        $(".rightt").change(function(){
            bustan();
        });
            var s = 0;
            var t = 0;
        var tt = $("tbody.bodyy tr");
            for(var i = 1; i <= tt.length; i++){
                var tr = $("#tr"+i).find(".centerr");
                if($("#tr"+i).find(".leftt").is(':checked')){
                    var tr = $("#tr"+i).find(".centerr");
                    var f = $("#tr"+i).find(".rightt");
                    var foiz = parseInt(f.val());
                    var price = parseInt(tr.text());
                    var summa = price*foiz/100;
                    s=s+summa;
                }
            }
            var sum = $(".summa");
            sum.html(s);


        });
</script>

<script type="text/javascript">
    $(document).ready( function () {
        $('#jmtable').DataTable();
    } );
</script>



<script !src="">inputdate.max = new Date().toISOString().split("T")[0];</script>
@endsection