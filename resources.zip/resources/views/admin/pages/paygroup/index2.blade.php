@extends('layouts.admin')

@section('content')
@php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">
                    <div class="panel-heading">

                    </div>
                    <div class="panel-body">
                        @if(session('message'))
                            <div class="col-12">
                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        @endif
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-center">{{ $link == 'region' ? 'Viloyat' : 'Tuman' }}</th>
                                    <th class="text-center">barcha guruhlar</th>
                                    <th class="text-center">To'langanlar</th>
                                    <th class="text-center">Tasdiqlash kutilayotgan (guruhlar)</th>
                                    <th class="text-center">To'lamanganlar</th>
                                </tr>
                            </thead>
                            <tbody>
                            @php $i = 0 @endphp
                            @foreach($regions as $region)
                                <tr style="@if(0) background: lightsalmon @endif">
                                    <td class="text-center">{{++$i}}</td>
                                    <td><a href="{{ route('paygroup.'.$link, ['id' => $region->id]) }}">{{ $region->name_uz }}</a></td>
                                    <?php $count_gr = 0; $count_tolangan = 0; $count_tasdiqlanmagan=0; $tolamagan = 0;  $branchs = $region->branches;  ?>
                                    @foreach($region->branches as $branch)
                                        <?php
                                            $count = count('Test\Model\Group'::where('branch_id' , $branch->id)->where('status' , '<>' ,  0)->where('edu_starting_date' ,  '>' , '2019-09-20')->get());
                                            $count_gr = $count_gr+$count;
                                            foreach ($branch->groups as $group){
                                                 if ($group->status ==1 || $group->status == 2){
                                                     if ('Test\Model\Paygroup'::where('group_id' , $group->id)->sum('percent') == 100 && 'Test\Model\Paygroup'::where('group_id' , $group->id)->first()->status == 2){
                                                         $count_tolangan++;
                                                     }
                                                 if (!'Test\Model\Paygroup'::where('group_id' , $group->id)->exists()){
                                                         $tolamagan++;
                                                     }
                                                 else{
                                                         $ddd= 0;
                                                         foreach ('Test\Model\Paygroup'::where('group_id' , $group->id)->get() as $pygr){
                                                             if ($pygr->status == 2){
                                                                 $ddd=1;
                                                             }
                                                         }
                                           if ($ddd == 0){
                                               $tolamagan++;
                                           }
                                        }
                                                 if ('Test\Model\Paygroup'::where('group_id' , $group->id)->exists()){
                                                         $ff = 0;
                                                         foreach ('Test\Model\Paygroup'::where('group_id' , $group->id)->get() as $pygs){
                                                             if ($pygs->status == 1){
                                                                 $ff = 1;
                                                             }
                                                         }
                                                     if ($ff == 1){
                                                         $count_tasdiqlanmagan++;
                                                     }
                                                }
                                                 }  

                                            }
//                                        $count_tasdiqlanmagan = $count_tasdiqlanmagan + count('Test\Model\Paygroup'::where('branch_id' , $branch->id)->where('status' , '1')->get());
                                        ?>
                                    @endforeach
                                    <td class="text-center">
                                        {{$count_gr}}
                                    </td>

                                    <td class="text-center">
                                        {{$count_tolangan}}
                                    </td>
                                    <td class="text-center">
                                        {{$count_tasdiqlanmagan}}
                                    </td>
                                    <td class="text-center"> {{$tolamagan}} </td>
                                </tr>
                            @endforeach
                            </tbody>

                        </table>
                        Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}}
                        {{ $data->links() }}
                    </div>
                </div>
            </div>


        </div>
    </div>
@endsection


