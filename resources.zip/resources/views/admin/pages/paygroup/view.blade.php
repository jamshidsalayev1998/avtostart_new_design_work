@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('topics.index') }}">Fanlar & Mavzular</a></li>
            <li class="active">Mavzuni ko'rish</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">

        <!-- SEARCH FORM -->
        <div class="block padding-top-20">
            <div class="row">
                <div class="col-md-10">
                    <div class="form-group">
                        <div class="input-group">
                            <a class="btn btn-default btn-icon">
                                <i class="fa fa-search"></i>
                            </a>&nbsp;&nbsp;&nbsp;<span style="font-size: 16px;">{{$data->name_uz}}</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-2 text-right">
                    <div class="col-md-12">
                        <form action="{{ route('lesson.destroy', ['id' => $data->id]) }}" method="post">
                            {{ csrf_field() }}
                            {{ method_field('delete') }}
                            <button class="btn btn-danger btn-icon-fixed deleteLesson pull-right"><span class="icon-trash"></span> O'chirish</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- END SEARCH FORM -->


        <div class="block block-arrow-top padding-top-20">
            <div class="row">
                <div class="listing listing-separated margin-bottom-0">
                    <div class="listing-item margin-bottom-10">
                        <a class="text-lg">Ko'rish</a>
                    </div>
                    <div class="col-md-10" style="font-weight: bold;">
                        <p style="margin-left: 20px;font-size: 14px;"><span style="font-weight: 500"></span><span>{{ $data->name_uz }} ({{ $data->name_ru }})</span></p>
                    </div>
                    <div class="col-md-2">
                        <p><span class="fa fa-clock-o">&nbsp;</span>{{ date('d.m.Y H:i',strtotime($data->updated_at)) }}</p>
                    </div>
                    <div style="margin-left: 50px;margin-top: 20px;margin-right: 50px;">
                        <ul>
                            @foreach($data->topics as $topic)
                                <li style="padding: 4px;"><a href="{{ route('topics.show',['id'=>$topic->id]) }}">{{ $topic->name_uz }}</a></li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection