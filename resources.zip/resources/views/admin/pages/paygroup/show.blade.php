<!DOCTYPE html>
<html lang="en">
<head>
    <!-- META SECTION -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style media="all">
        body {
            font-family: DejaVu Sans;
            font-size: 12px !important;
            line-height: 1;
        }

        .text-center {
            text-align: center;
        }
        table{
            border-collapse: collapse;
            width: 100%;
        }
        table, td, th {
            border: 1px solid black;
            padding-top: 2px;
            padding-bottom: 2px;
        }
        .text-right {
            text-align: right;
        }
    </style>
    <!-- EOF CSS INCLUDE -->
</head>
<body>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading"></div>
            <div class="panel-body">
                <table class="table table-bordered">
                    <tr>
                        <th colspan="3" style="text-align: center">< ЭЛЕКТРОННО > Платежное поручение № ____ <?=date('d.m.Y')?></th>
                    </tr>
                    <tr>
                        <th>Наименование плательщика</th>
                        <td><?=$data['branch']['name']?></td>
                        <th class="text-center">ИНН плательщика</th>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="text-center"><?=$data['branch']['inn']?></td>
                    </tr>
                    <tr>
                        <th>Счет плательщика</th>
                        <td><?=$data['branch']['bill']?></td>
                        <th class="text-center">Код банка плательщика</th>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="text-center"><?=$data['branch']['mfo']?></td>
                    </tr>
                    <tr>
                        <th>Наим. банка плательщика</th>
                        <td colspan="2"><?=$data['branch']['bank']?></td>
                    </tr>
                    <tr>
                        <th>СУММА:</th>
                        <td colspan="2"><?=$data['price']?></td>
                    </tr>
                    <tr>
                        <th>Наименование получателя</th>
                        <td><?=$data['me']['name']?></td>
                        <th class="text-center">ИНН получателя</th>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="text-center"><?=$data['me']['inn']?></td>
                    </tr>
                    <tr>
                        <th>Счет получателя</th>
                        <td><?=$data['me']['bill']?></td>
                        <th class="text-center">Код банка получателя</th>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="text-center"><?=$data['me']['mfo']?></td>
                    </tr>
                    <tr>
                        <th>Наим. банка получателя</th>
                        <td colspan="2"><?=$data['me']['bank']?></td>
                    </tr>
                    <tr>
                        <th>Сумма прописью:</th>
                        <td colspan="2">{{ $data['price_text'] }}</td>
                    </tr>
                    <tr>
                        <th>Детали платежа:</th>
                        <td colspan="2"><?=$data['group']['name']?> (id:<?=$data['group']['id']?>)</td>
                    </tr>
                    <tr>
                        <th>М. П.</th>
                        <td colspan="2">Руководитель: {{ $data['branch']['director'] }}<br>Гл. бухгалтер:</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="2"><span style="margin-right: 20px;">БАНК</span><span style="margin-right: 20px;">Проверен</span><span style="margin-right: 20px;">Одобрен</span>Проведено банком</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="text-right"><?=date('d.m.Y')?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</body>
</html>