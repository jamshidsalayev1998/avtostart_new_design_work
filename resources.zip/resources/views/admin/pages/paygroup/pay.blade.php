@extends('layouts.admin')

@section('content')
@php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                @if($view == 1)
                <div class="panel panel-default">
                    <div class="panel-heading">To'lov qo'shish</div>
                    <div class="panel-body">
                        <form action="/backoffice/pay/create" class="row">
                            <input type="text" hidden value="<?=$id?>" name="group">
                            <div class="col-sm-5">
                                <label for="summ">To'lov summasi</label>
                                <select class="form-control" name="sum" required>
                                    <option value="100">100%</option>
                                </select>
                            </div>
                            <div class="col-sm-5">
                                <label for="paydate">To'langan vaqt</label>
                                <input type="date" class="form-control" name="date" id="inputdate" placeholder="To'langan vaqt" required>
                            </div>
                            <div class="col-sm-2">
                                <br>
                                <input type="submit" class="btn btn-success" style="width: 100%" value="Saqlash">
                            </div>
                        </form>
                    </div>
                </div>
                @endif
                <div class="panel panel-default">
                    <div class="panel-heading">
                        @if (!empty($group))
                            <form action="/backoffice/pay/create" class="row">
                                <div class="col-sm-5">
                                    <label for="group">Guruh</label>
                                    <select name="group" id="group" class="form-control">
                                        @foreach($group as $key => $item)
                                            <option value="{{ $key }}">{{ $item }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-sm-2">
                                    <label for="summ">To'lov summasi</label>
                                    <select class="form-control" name="sum" required>
                                        <option value="100">100%</option>
                                    </select>
                                </div>
                                <div class="col-sm-3">
                                    <label for="paydate">To'langan vaqt</label>
                                    <input type="date" class="form-control" name="date" placeholder="To'langan vaqt" required id="inputdate">
                                </div>
                                <div class="col-sm-2">
                                    <br>
                                    <input type="submit" class="btn btn-success" style="width: 100%" value="Saqlash">
                                </div>
                            </form>
                        @endif
                    </div>
                    <div class="panel-body">
                        @if(session('message'))
                            <div class="col-12">
                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        @endif
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-center">Filial nomi</th>
                                    <th class="text-center">Guruh nomi</th>
                                    <th class="text-center">To'lov summasi</th>
                                    <th class="text-center">To'langan vaqt</th>
                                    <th class="text-center">Holati</th>
                                    <th class="text-center">Kiritilgan sana</th>
                                </tr>
                            </thead>
                            <tbody>
                            @php $i = 0 @endphp
                            @if (!empty($data))
                            @foreach($data as $item)
                                <tr style="@if($item->status != 2) background: lightsalmon @endif">
                                    <td class="text-center">{{++$i}}</td>
                                    <td class="text-center">{{ $item->getBranch() }}</td>
                                    <td class="text-center">{{ $item->getGroup() }}</td>
                                    <td class="text-center">{{ $item->summ }}</td>
                                    <td class="text-center">{{ $item->paydate }}</td>
                                    <td class="text-center">
                                        @if ($item->status == 2) Tasdiqlangan @else Tasdiqlanmagan
                                         @if ($status == 1) <a href="{{ route('paygroup.check', ['id' => $item->id]) }}"><i class="fa fa-check-circle-o"></i></a> @endif
                                        @endif
                                    </td>
                                    <td class="text-center">{{ $item->created_at }}</td>
                                </tr>
                            @endforeach
                            @endif
                            </tbody>

                        </table>
                        Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}}
                        {{ $data->links() }}
                    </div>
                </div>
            </div>


        </div>
    </div>
<script !src="">inputdate.max = new Date().toISOString().split("T")[0];</script>
@endsection