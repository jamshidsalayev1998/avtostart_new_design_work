<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
        .tableone{
            border: 1px solid black;
            width: 100%;
            height: 400px;
        }
        .tableone tr td {
            border: 1px solid black;
            padding: 5px;
        }
        .textc{
            text-align: center;
        }
        body {
    font-family: DejaVu Sans;
}
    </style>
</head>
<body>

<table class="tableone" cellpadding="0" cellspacing="0" >
    <tr class="textc">
        <td colspan="2 " >
           {{ $accountant->full_name }}

        </td>
    </tr>
    <tr class="textc">
        <td colspan="2">
            <b>
                {{$paygroups[0]->pay_number}}
            </b>

        </td>
    </tr>
    <tr class="textc">
        <td colspan="2">
            Qabul qiluvchi
        </td>
    </tr>
    <tr>
        <td>
            Nomi
        </td>
        <td>
            {{ $our->name }}
        </td>
    </tr>
    <tr>
        <td>
            Hisob raqam

        </td>
        <td>
            {{ $our->bill }}
        </td>
    </tr>
    <tr>
        <td>
            INN

        </td>
        <td>
            {{ $our->inn }}

        </td>
    </tr>
    <tr>
        <td>
            Bank
        </td>
        <td>
            <?php $ourbank = Test\Model\Bank::where('mfo' , $our->mfo)->get()->first(); ?>
            {{ $ourbank->bank_name }}
        </td>
    </tr>
    <tr class="textc">
        <td colspan="2">
            To`lovchi
        </td>
    </tr>
    <tr>
        <td>
            Nomi

        </td>
        <td>
            {{ $branch->name_uz }}

        </td>
    </tr>
    <tr>
        <td>
            Hisob raqam

        </td>
        <td>
           {{ $branch->requisite->hr }}

        </td>
    </tr>
    <tr>
        <td>
            INN

        </td>
        <td>
            {{ $branch->requisite->inn }}

        </td>
    </tr>
    <tr>
        <td>
            Bank

        </td>
        <td>
            {{ $bank->bank_name }}

        </td>
    </tr>
    <tr>
        <td>
            <b>SUMMA:</b>

        </td>
        <td>
            <b>{{ $paygroups->sum('payment') }} So`m</b>

        </td>
    </tr>
    <tr>
        <td>
            To`lov izohi

        </td>
        <td>

         To`lov raqami-{{$paygroups[0]->pay_number}}<br>
            <table  style="border: none">
                <thead>
                    <tr  style="border: none">
                        <td  style="border: none">
                            Guruhlar
                        </td >
                        <td  style="border: none">
                            O`quvchilari
                        </td>
                        <td  style="border: none">
                            Foizlar
                        </td>
                    </tr>
                </thead>
                <tbody>
                @foreach($paygroups as $paygroup)
                    <tr style="border: none">
                        <td  style="border: none">
                            {{ $paygroup->group->name_uz }}
                        </td >
                        <td  style="border: none">
                            <?php echo count('Test\Model\GroupedStudent'::where('group_id' , $paygroup->group->id )->get()) ?>
                        </td>
                        <td  style="border: none">
                            {{$paygroup->percent}}%
                        </td>
                    </tr>

                @endforeach

                </tbody>
            </table>



        </td>
    </tr>

</table>

</body>
</html>