<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style media="print">
        .btpr{
            display: none;
        }
        *{
            box-sizing: border-box;
            font-size: 11px;
        }
        .body{
            padding: 4px;
            font-size: 11px;
            

        }
        div.top{
            display: flex;
            font-size: 11px;

        }
        div.row_t{
            width: 50%;
            display: flex;
            align-items: center;
            font-size: 11px;
        }
        b.all{
            font-size: 11px;
        }
        span.border{
            margin-left: 10px;
            border: 1px solid #999999;
            width: 60%;
            padding: 5px;
            font-size: 11px;
        }
        span.left{
            width: 38%;
            display: flex;
            justify-content: flex-end;
            font-size: 11px;
        }
        div.two{
            display: flex;
            align-items: center;
            margin-bottom: 4px;
            margin-top: 3px;
            font-size: 4px;
        }
        div.span{
            width: 20%;
        }
        span.big{
            border: 1px solid #999999;
            width: 50%;
            padding: 5px;
            font-size: 11px;
        }
        span.big2{
            border: 1px solid #999999;
            width: 80%;
            padding: 5px;
            font-size: 11px;
        }
        span.big3{
            /*border: 1px solid #999999;*/
            width: 50%;
            font-size: 11px;
        }
        div.right{
            display: flex;
            width: 30%;
            margin-left: 10px;
            justify-content: flex-end;
            font-size: 11px;
        }
        .jamshid{
            width: 80%;
            font-size: 11px;
        }
        .tree{
            width: 80%;
            display: flex;
            margin-top: 30px;
            justify-content: flex-end;
            font-size: 11px;
        }
        .tree p{
            margin: 5px 0px;
            font-size: 11px;
        }
        .row_tree{
            width: 30%;
            margin-left: 20px;
            font-size: 11px;
        }
        .bor_top{
            border-top: 1px solid #999999;
            font-size: 11px;
        }
        .bor_to{
            border-top: 1px solid white;
            font-size: 11px;
        }
        .bottom{
            height: 30px;
            width: 100%;
            border: 1px solid #999999;
            font-size: 11px;
        }
        .jamshid2{
            width: 40%;
            font-size: 11px;
        }
        span.bor{
            border: 1px solid #999999;
            padding: 5px;
            font-size: 11px;
        }
        .orta{
            padding-bottom = -3px;
            padding-top = -3px;
            
        }

    </style>
    <style >
        .orta{
            padding-bottom = -3px;
            padding-top = -3px;
            
        }
        
        *{
            box-sizing: border-box;
            font-size: 11px;
        }
        .body{
            padding: 4px;
            font-size: 11px;
            

        }
        div.top{
            display: flex;
            font-size: 11px;

        }
        div.row_t{
            width: 50%;
            display: flex;
            align-items: center;
            font-size: 11px;
        }
        b.all{
            font-size: 11px;
        }
        span.border{
            margin-left: 10px;
            border: 1px solid #999999;
            width: 60%;
            padding: 5px;
            font-size: 11px;
        }
        span.left{
            width: 38%;
            display: flex;
            justify-content: flex-end;
            font-size: 11px;
        }
        div.two{
            display: flex;
            align-items: center;
            margin-bottom: 3px;
            margin-top: 4px;
            font-size: 11px;
        }
        div.span{
            width: 20%;
        }
        span.big{
            border: 1px solid #999999;
            width: 50%;
            padding: 5px;
            font-size: 11px;
        }
        span.big2{
            border: 1px solid #999999;
            width: 80%;
            padding: 5px;
            font-size: 11px;
        }
        span.big3{
            /*border: 1px solid #999999;*/
            width: 50%;
            font-size: 11px;
        }
        div.right{
            display: flex;
            width: 30%;
            margin-left: 10px;
            justify-content: flex-end;
            font-size: 11px;
        }
        .jamshid{
            width: 80%;
            font-size: 11px;
        }
        .tree{
            width: 80%;
            display: flex;
            margin-top: 30px;
            justify-content: flex-end;
            font-size: 11px;
        }
        .tree p{
            margin: 5px 0px;
            font-size: 11px;
        }
        .row_tree{
            width: 30%;
            margin-left: 20px;
            font-size: 11px;
        }
        .bor_top{
            border-top: 1px solid #999999;
            font-size: 11px;
        }
        .bor_to{
            border-top: 1px solid white;
            font-size: 11px;
        }
        .bottom{
            height: 30px;
            width: 100%;
            border: 1px solid #999999;
            font-size: 11px;
        }
        .jamshid2{
            width: 40%;
            font-size: 11px;
        }
        span.bor{
            border: 1px solid #999999;
            padding: 5px;
            font-size: 11px;
        }
        

    </style>
    <style>
        body{
            font-family: DejaVu Sans;
        }
    </style>
</head>
<body>
<p class="orta" style="text-align: center">Платежное поручение</p>
<button class="btpr" style="padding: 5px; border-radius: 6px; background-color: rgba(86,58,255,0.19); border: 1px solid black; font-size: 20px; cursor: pointer;" onclick=" window.print()">chop etish</button>
<div class="top">

    <div class="row_t">
        <span class="left"><b class="all">Номер документа</b></span>
        <span class="border">{{$paygroups[0]->pay_number}}</span>
    </div>
    <div class="row_t">
        <span class="left"><b class="all">Дата документа</b></span>
        <span class="border">{{$paygroups[0]->payment_date}}</span>
    </div>

</div>
<p class="orta" style="text-align: center">Дебет плательщика</p>
<div class="two">
    <div class="span"><b>Наименование плательщика:</b></div>
    <span class="big">{{ $branch->name_uz }} </span>
    <div class="right"><b> ИНН  плательщика<span class="bor">{{ $branch->requisite->inn }}</span></b></div>
</div>

<div class="two">
    <div class="span"><b> Счет плательщика:</b></div>
    <span class="big3"><span class="bor">{{ $branch->requisite->hr }}</span></span>
    <div class="right"><b> Код банка плательщика<span class="bor">123456789</span></b></div>
</div>
<div class="two">
    <div class="span"><b>Наименование банка:</b></div>
    <span class="big2">{{ $bank->bank_name }}</span>
</div>

<div class="two">
    <div class="span"><b>Cумма платежа:</b></div>
    <span class="big">{{ $paygroups->sum('payment') }}   </span>
</div>
<p style="text-align: center">Кредит  получателя</p>
<div class="two">
    <div class="span"><b>Наименование получателя:</b></div>
    <span class="big">{{ $our->name }}</span>
    <div class="right"><b> ИНН  получателя<span class="bor">{{ $our->inn }}</span></b></div>
</div>

<div class="two">
    <div class="span"><b> Счет получателя:</b></div>
    <span class="big3"><span class="bor">{{ $our->bill }}</span></span>
    <div class="right"><b> Код банка получателя<span class="bor">{{ $our->mfo }}</span></b></div>
</div>
<div class="two">
    <div class="span"><b>Наименование банка:</b></div>
    <span class="big2">
         <?php $ourbank = Test\Model\Bank::where('mfo' , $our->mfo)->get()->first(); ?>
        {{ $ourbank->bank_name }}
    </span>
</div>
<div class="two">
    <div class="span"><b> Сумма прописю:</b></div>
    <span  class="jamshid">
         <?php
            
            $num = $paygroups->sum('payment');
            $nul='ноль';
            $ten=array(
                array('','один','два','три','четыре','пять','шесть','семь', 'восемь','девять'),
                array('','одна','две','три','четыре','пять','шесть','семь', 'восемь','девять'),
            );
            $a20=array('десять','одиннадцать','двенадцать','тринадцать','четырнадцать' ,'пятнадцать','шестнадцать','семнадцать','восемнадцать','девятнадцать');
            $tens=array(2=>'двадцать','тридцать','сорок','пятьдесят','шестьдесят','семьдесят' ,'восемьдесят','девяносто');
            $hundred=array('','сто','двести','триста','четыреста','пятьсот','шестьсот', 'семьсот','восемьсот','девятьсот');
            $unit=array( // Units
                array('тийин' ,'тийин' ,'тийин',	 1),
                array('сӯм'   ,'сӯм'   ,'сӯм'    ,0),
                array('тысяча'  ,'тысячи'  ,'тысяч'     ,1),
                array('миллион' ,'миллиона','миллионов' ,0),
                array('миллиард','милиарда','миллиардов',0),
            );
            //
            list($rub,$kop) = explode('.',sprintf("%015.2f", floatval($num)));
            $out = array();
            if (intval($rub)>0) {
                foreach(str_split($rub,3) as $uk=>$v) { // by 3 symbols
                    if (!intval($v)) continue;
                    $uk = sizeof($unit)-$uk-1; // unit key
                    $gender = $unit[$uk][3];
                    list($i1,$i2,$i3) = array_map('intval',str_split($v,1));
                    // mega-logic
                    $out[] = $hundred[$i1]; # 1xx-9xx
                    if ($i2>1) $out[]= $tens[$i2].' '.$ten[$gender][$i3]; # 20-99
                    else $out[]= $i2>0 ? $a20[$i3] : $ten[$gender][$i3]; # 10-19 | 1-9
                    // units without rub & kop
                    if ($uk>1) $out[]= morph($v,$unit[$uk][0],$unit[$uk][1],$unit[$uk][2]);
                } //foreach
            }
            else $out[] = $nul;
            $out[] = morph(intval($rub), $unit[1][0],$unit[1][1],$unit[1][2]); // rub
            $out[] = $kop.' '.morph($kop,$unit[0][0],$unit[0][1],$unit[0][2]); // kop
        echo trim(preg_replace('/ {2,}/', ' ', join(' ',$out)));


        function morph($n, $f1, $f2, $f5) {
            $n = abs(intval($n)) % 100;
            if ($n>10 && $n<20) return $f5;
            $n = $n % 10;
            if ($n>1 && $n<5) return $f2;
            if ($n==1) return $f1;
            return $f5;
        }

         ?>
    </span>
</div>
<div class="two">
    <div class="span"><b>Назначение платежа:</b></div>
        <span class="big2">
            {{$paygroups[0]->pay_number}}
                @foreach($paygroups as $paygroup)
                    ({{ $paygroup->group->name_uz }})  ,
                @endforeach

                  №  {{ $branch->requisite->shartnoma_number }} га асосан 


        </span>
</div>
<div class="two">
    <div class="span"><b> М.П:</b></div>
    <span  class="jamshid2">
        {{$branchadmin->full_name}}
    </span>
    <span  class="jamshid2">
        {{ $accountant->full_name }}
    </span>
</div>

<div class="two">
    <div class="span"><b> Банк:</b></div>
    <div class="tree">
        <div class="row_tree bor_top">
            <p>Проверено</p>
            <div class="bottom"></div>
        </div>
        <div class="row_tree bor_to">
            <p>Одобрено</p>
            <div class="bottom"></div>
        </div>
        <div class="row_tree bor_top">
            <p>Проведено банком</p>
            <div class="bottom">
                {{$paygroups[0]->payment_date}}
            </div>
        </div>

    </div>
</div>
</body>
</html>