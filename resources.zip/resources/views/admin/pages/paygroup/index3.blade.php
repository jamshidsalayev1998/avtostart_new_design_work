@extends('layouts.admin_alisher')

@section('content')
@php $i = ($data->currentPage() - 1) * $data->perPage() @endphp

                <div class="title-link">
                    <div>
                        <h1>Toifalar</h1>
                        <p><span>Darsliklar</span>/Toifalar</p>
                    </div>
                    
                </div>
                <div class="table-toifa">
                    <h1>Ta’lim turini tanlang</h1>
                    <div class="table-content">
                        <table>
                            <tr>
                                <th><p>#</p></th>
                                <th><p>Ta’lim turi</p></th>
                                <th><p>Jami soatlar</p></th>
                                <th><p>Nazariy</p></th>
                                <th><p>Amaliy</p></th>
                            </tr>
                            <tr>
                                <td><p>1</p></td>
                                <td><a href="A_Tayyorlash.html"><p>A tayyorlash</p></a></td>
                                <td><p>204</p></td>
                                <td><p>204</p></td>
                                <td><p>204</p></td>
                            </tr>
                            <tr>
                                <td><p>2</p></td>
                                <td><a href="#"><p>B tayyorlash</p></a></td>
                                <td><p>204</p></td>
                                <td><p>204</p></td>
                                <td><p>204</p></td>
                            </tr>
                            <tr>
                                <td><p>3</p></td>
                                <td><a href="#"><p>BC tayyorlash</p></a></td>
                                <td><p>204</p></td>
                                <td><p>204</p></td>
                                <td><p>204</p></td>
                            </tr>
                            <tr>
                                <td><p>4</p></td>
                                <td><a href="CE_Qayta_Toyorlash.html"><p>CE qayta tayyorlash</p></a></td>
                                <td><p>204</p></td>
                                <td><p>204</p></td>
                                <td><p>204</p></td>
                            </tr>
                            <tr>
                                <td><p>5</p></td>
                                <td><a href="#"><p>Malaka oshirish</p></a></td>
                                <td><p>204</p></td>
                                <td><p>204</p></td>
                                <td><p>204</p></td>
                            </tr>
                        </table>
                    </div>
                </div>

    @endsection

