@extends('layouts.admin_alisher')

@section('content')
<style type="text/css">
    .paygroup-a{
        color: #333333 !important;
    }
    .paygroup-a:hover{
        color: #45D99E !important;
    }
</style>
@php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
            <div class="title-link">
                <div>
                    <h1>Toifalar</h1>
                    <p><span>Darsliklar</span>/Toifalar</p>
                </div>
                                    
            </div>
            <div class="table-toifa">
                <h1>Ta’lim turini tanlang</h1>
                <div class="table-content">
                       
                        <table >
                                <tr>
                                    <th class="text-center"><p>#</p></th>
                                    <th class="text-center"><p>{{ $link == 'region' ? 'Viloyat' : 'Tuman' }}</p></th>
                                    <th class="text-center"><p>barcha guruhlar</p></th>
                                    <th class="text-center"><p>To'langanlar</p></th>
                                    <th class="text-center"><p>Tasdiqlash kutilayotgan (guruhlar)</p></th>
                                    <th class="text-center"><p>To'lamanganlar</p></th>
                                </tr>
                            @php $i = 0 @endphp
                            @foreach($regions as $region)
                                <tr style="@if(0) background: lightsalmon @endif">
                                    <td class="text-center"><p>{{++$i}}</p></td>
                                    <td ><p><a class="paygroup-a" href="{{ route('paygroup.'.$link, ['id' => $region->id]) }}">{{ $region->name_uz }}</a></p></td>
                                    <?php $count_gr = 0; $count_tolangan = 0; $count_tasdiqlanmagan=0; $tolamagan = 0;  $branchs = $region->branches;  ?>
                                    @foreach($region->branches as $branch)
                                        <?php
                                            $count = count('Test\Model\Group'::where('branch_id' , $branch->id)->where('status' , '<>' ,  0)->where('edu_starting_date' ,  '>' , '2019-09-20')->get());
                                            $count_gr = $count_gr+$count;
                                            foreach ($branch->groups as $group){
                                                 if ($group->status ==1 || $group->status == 2){
                                                     if ('Test\Model\Paygroup'::where('group_id' , $group->id)->sum('percent') == 100 && 'Test\Model\Paygroup'::where('group_id' , $group->id)->first()->status == 2){
                                                         $count_tolangan++;
                                                     }
                                                 if (!'Test\Model\Paygroup'::where('group_id' , $group->id)->exists()){
                                                         $tolamagan++;
                                                     }
                                                 else{
                                                         $ddd= 0;
                                                         foreach ('Test\Model\Paygroup'::where('group_id' , $group->id)->get() as $pygr){
                                                             if ($pygr->status == 2){
                                                                 $ddd=1;
                                                             }
                                                         }
                                           if ($ddd == 0){
                                               $tolamagan++;
                                           }
                                        }
                                                 if ('Test\Model\Paygroup'::where('group_id' , $group->id)->exists()){
                                                         $ff = 0;
                                                         foreach ('Test\Model\Paygroup'::where('group_id' , $group->id)->get() as $pygs){
                                                             if ($pygs->status == 1){
                                                                 $ff = 1;
                                                             }
                                                         }
                                                     if ($ff == 1){
                                                         $count_tasdiqlanmagan++;
                                                     }
                                                }
                                                 }  

                                            }
//                                        $count_tasdiqlanmagan = $count_tasdiqlanmagan + count('Test\Model\Paygroup'::where('branch_id' , $branch->id)->where('status' , '1')->get());
                                        ?>
                                    @endforeach
                                    <td class="text-center"><p>
                                        {{$count_gr}}</p>
                                    </td>

                                    <td class="text-center"><p>
                                        {{$count_tolangan}}</p>
                                    </td>
                                    <td class="text-center"><p>
                                        {{$count_tasdiqlanmagan}}</p>
                                    </td>
                                    <td class="text-center"><p> {{$tolamagan}} </p></td>
                                </tr>
                            @endforeach

                        </table>
                        Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}}
                        {{ $data->links() }}
                    </div>
                </div>

@endsection