@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('accountant.index') }}">Hisobchilar</a></li>
            <li class="active">Yangi hisobchi qo'shish</li>
        </ul>
    </div>
    <div class="container">

        <form action="{{ route('accountant.store') }}" method="post" class="has-validation-callback">
            {{ csrf_field() }}

            <div class="block block-condensed">
                <div class="block-content">

                    <div class="wizard show-submit">
                        <ul>
                            <li>
                                <a href="#step-7">
                                    <span class="stepNumber">1</span>
                                    <span class="stepDesc">Hisobchi<br /><small>Shaxsiy ma'lumotlarni kiritish</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#step-8">
                                    <span class="stepNumber">2</span>
                                    <span class="stepDesc">User<br /><small>Login va Parol berish</small></span>
                                </a>
                            </li>
                        </ul>

                        <div id="step-7">

                            <div class="row">
                                <div class="col-md-6">

                                    <!-- LENGTH EXAMPLE -->
                                    <div class="block">
                                        <div class="form-group">
                                            <label>Hisobchi FIO
                                                @if($errors->has('full_name'))
                                                    <span class="text-danger"> | {{ $errors->first('full_name') }}</span>
                                                @endif
                                            </label>
                                            <input class="form-control"  placeholder="FIO" value="{{ old('full_name') }}" id="full_name" name="full_name">
                                        </div>

                                        <div class="form-group">
                                            <label>Jinsi {{old('gender')}}
                                                @if($errors->has('gender'))
                                                    <span class="text-danger"> | {{ $errors->first('gender') }}</span>
                                                @endif
                                            </label>
                                            <br>
                                            <div class="app-radio danger inline">
                                                <label><input type="radio" name="gender" id="gender" value="1" checked=""> Ayol<span></span></label>
                                            </div>
                                            <div class="app-radio success inline">
                                                <label><input type="radio" name="gender" id="gender" value="0" @if(old('gender')==0) checked @endif> Erkak<span></span></label>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Passport Info
                                                @if($errors->has('passport_info'))
                                                    <span class="text-danger"> | {{ $errors->first('passport_info') }}</span>
                                                @endif
                                            </label>
                                            <input class="form-control" placeholder="Pasport ma'lumotini kiriting" value="{{old('passport_info')}}" name="passport_info" id="passport_info">
                                            <span class="help-block">Masalan: AA 1234567</span>
                                        </div>

                                    </div>
                                    <!-- END LENGTH EXAMPLE -->

                                </div>
                                <div class="col-md-6">

                                    <!-- NUMBER EXAMPLE -->
                                    <div class="block">
                                        <div class="form-group">
                                            <label>Tavallud kuni
                                                @if($errors->has('birthdate'))
                                                    <span class="text-danger"> | {{ $errors->first('birthdate') }}</span>
                                                @endif
                                            </label>
                                            <div class="input-group bs-datepicker">
                                                <input type="text" class="form-control"  name="birthdate" id="birthdate" value="{{ old('birthdate') }}">
                                                <span class="input-group-addon">
                                                      <span class="icon-calendar-full"></span>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Manzil
                                                @if($errors->has('address'))
                                                    <span class="text-danger"> | {{ $errors->first('address') }}</span>
                                                @endif
                                            </label>
                                            <input class="form-control" placeholder="Manzilni kiriting"  name="address" value="{{old('address')}}" id="address">
                                        </div>
                                        <div class="form-group">
                                            <label>Telefon raqam
                                                @if($errors->has('phone'))
                                                    <span class="text-danger"> | {{ $errors->first('phone') }}</span>
                                                @endif
                                            </label>
                                            <input type="text" class="mask_tin form-control" value="{{old('phone')}}"  name="phone" id="phone">
                                            <span class="help-block">Masalan: 90-1234567</span>
                                        </div>
                                    </div>
                                    <!-- END NUMBER EXAMPLE -->
                                </div>
                            </div>

                        </div>

                        <div id="step-8">

                            <div class="form-group">
                                <div class="row">
                                    <label class="col-md-12 control-label">Login
                                        @if($errors->has('login'))
                                            <span class="text-danger"> | {{ $errors->first('login') }}</span>
                                        @endif
                                    </label>
                                    <div class="col-md-8">
                                        <input type="text" readonly class="form-control" name="login" id="login" placeholder="login" value="<?php if(old('login')=="") echo $login; else echo old('login')?>">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <label class="col-md-12 control-label">Parol
                                        @if($errors->has('password'))
                                            <span class="text-danger"> | {{ $errors->first('password') }}</span>
                                        @endif
                                    </label>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="password" id="password" value="{{old('password')}}"  placeholder="Parolni kiriting yoki generatsiya qiling">
                                    </div>
                                    <div class="col-md-3">
                                        <button type="button" class="btn btn-default" onclick="password_generator(10)"><span class="fa fa-key">&nbsp;</span>Parol generator</button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
@endsection