@extends('layouts.admin')

@section('content')
    @php $i = 0; $alll = 0; $a = 0; $b = 0; @endphp
    <div class="container">
        <div class="row">
        
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Viloatlar bo'yicha</h3>
                    </div>
                    <div class="panel-body">
                        @if(session('message'))
                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-checkmark-circle"></span>
                                </div>
                                {{ session('message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        @endif
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="width: 2%">#</th>
                                <th>Viloyat nomi</th>
                                <th style="text-align: center">O'quvchilar soni</th>
                                <th style="text-align: center">Test ishga ruxsat berilganlar o'quvchilar soni</th>
                                <th style="text-align: center">Testdan o'tgan o'quvchilar soni</th>
                                <th style="text-align: center;"></th>
                            </tr>
                            <tr>
                            
                            </tr>
                            </thead>
                            
                            <tbody>
                                <?php 
                                foreach ($data  as $item):?>
                                <tr>
                                    <td>{{++$i}}</td>
                                    <td><a href="region/{{$item->id}}">{{$item->name_uz}}</a></td>
                                    <td style="text-align: center">{{$item->alll}}</td>
                                    <td style="text-align: center">{{$item->a}}</td>
                                    <td style="text-align: center">{{$item->b}}</td>
                                    <td style="text-align: center">{{$item->b > 0 && $item->a > 0 ? intval($item->b / $item->a * 100) : 0}}%</td>
                                </tr>
                                <?php
                                $alll += $item->alll;
                                $a += $item->a;
                                $b += $item->b;
                                endforeach; ?>
                                <tr>
                                    <th></th>
                                    <th>Umumiy summa</th>
                                    <th style="text-align: center"><?=$alll?></th>
                                    <th style="text-align: center"><?=$a?></th>
                                    <th style="text-align: center"><?=$b?></th>
                                    <th style="text-align: center">{{$b > 0 && $a > 0 ? intval($b / $a * 100) : 0}}%</th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection