@extends('layouts.admin_alisher')
@section('content')
    @php $i = ($data->currentPage() - 1) * $data->perPage() + 1 @endphp
                    <div class="title-link">
                        <div>
                            <h1>Yakuniy testga ruxsat berish</h1>
                            <p><span class="head-link-href" data-href="/backoffice">Darsliklar</span> / Yakuniy testga ruxsat berish</p>
                        </div>
                        
                    </div>
                    <div class="table-toifa">
                        <h1>Yakuniy testga ruxsat berish</h1>
                        <div class="table-content">
                    <table class="" id="data-table">
                        <thead>
                        <tr>
                            <th><p># </p></th>
                            <th><p>Guruh nomi </p></th>
                            <th><p>Filial </p></th>
                            <th><p>Dars boshlangan vaqt </p></th>
                            <th><p>Dars tugagan vaqt </p></th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $item)
                            <tr>
                                <td><p>{{$i}} </p></td>
                                <td><p><a href="test/reg/{{ $item->id }}">{{ $item->name_uz }}</a> </p></td>
                                <td><p>{{ $item->branch_name }} </p></td>
                                <td><p>{{ $item->edu_starting_date }} </p></td>
                                <td><p>{{ $item->edu_ending_date }} </p></td>
                            </tr>
                            @php $i ++ @endphp
                        @endforeach
                        </tbody>
                    </table>
                    
                </div>
            </div>
      
@endsection