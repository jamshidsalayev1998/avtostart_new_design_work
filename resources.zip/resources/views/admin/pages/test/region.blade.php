@extends('layouts.admin_alisher')

@section('content')
    @php $i = 0; $alll = 0; $a = 0; $b = 0; @endphp
                        <div class="title-link">
                            <div>
                                <h1>Filiallar bo`yicha</h1>
                                <p><span class="head-link-href" data-href="/backoffice">Darsliklar</span> / <span class="head-link-href" data-href="/backoffice/tests/res">Yakuniy test statistika</span> / {{ $region->name_uz }}  </p>
                            </div>
                            
                        </div>
                        <div class="table-toifa">
                        <h1>{{$region->name_uz}} bo'yicha</h1>
                        <div class="table-content">
                        <table class="">
                            <thead>
                            <tr>
                                <th style="width: 2%"><p># </p></th>
                                <th><p>Viloyat nomi </p></th>
                                <th style="text-align: center"><p>O`quvchilar  </p></th>
                                <th style="text-align: center"><p>Yakuniy test topshirganlar </p> </th>
                                <th style="text-align: center"><p>Yakuniy testdan o`tganlar </p></th>
                                <th style="text-align: center"><p>Guvohnoma berilganlar </p></th>
                                <th style="text-align: center;"><p>Foiz </p></th>
                            </tr>
                            <tr>

                            </tr>
                            </thead>

                            <tbody>
                            <?php
                            foreach ($data  as $item):?>
                            <tr>
                                <td><p>{{++$i}} </p></td>
                                <td><p><a href="../branch/{{$item->id}}">{{$item->name_uz}}</a> </p></td>
                                <td style="text-align: center"><p>{{$item->alll}} </p></td>
                                <td style="text-align: center"><p>{{$item->a}} </p></td>
                                <td style="text-align: center"><p>{{$item->b}} </p></td>
                                <td style="text-align: center"><p>
                                
                                <?php foreach ($data2  as $item2)
                                    if($item->id==$item2->id){
                                        echo $item2->sum;
                                    }
                                    else{
                                        echo "0";
                                    }
                                ?> </p>

                            </td>
                                <td style="text-align: center"><p>{{$item->b > 0 && $item->a > 0 ? intval($item->b / $item->a * 100) : 0}}% </p></td>
                            </tr>
                            <?php
                            $alll += $item->alll;
                            $a += $item->a;
                            $b += $item->b;
                            endforeach; ?>
                            <tr>
                                <th><p> </p></th>
                                <th style="text-transform: uppercase; "><p>Viloyat ko`rsatkichi </p></th>
                                <th style="text-align: center"><p><?=$alll?> </p></th>
                                <th style="text-align: center"><p><?=$a?> </p></th>
                                <th style="text-align: center"><p><?=$b?> </p></th>
                                <th style="text-align: center"><p> </p></th>
                                <th style="text-align: center"><p>{{$b > 0 && $a > 0 ? intval($b / $a * 100) : 0}}% </p></th>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

@endsection