@extends('layouts.admin')
@section('content')
    @php $i = 1; $j = 0; $t = 0; $arr = []; @endphp
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="block block-condensed">
                <br>

                <div id="group" class="text-center" data-id="<?=$group->edu_type?>">
                        <h3 class="tile-title" style="color: blue">{{ $group->name_uz." (".$group->getCourseName().")" }}</h3>
                        @if($group->assistant_id != null)
                            <h5>#{{ $group->teacher->full_name }} / {{ "@".$group->assistant->full_name }}</h5>
                        @endif
                        {{ $group->edu_starting_date }} <span class="fa fa-long-arrow-right"></span> {{ $group->edu_ending_date }}<br>
                        <div class="col-md-12">
                            <p class="text-left margin-0">Guruhning Hozirgi holati: <strong>{{ $group->getStatus() }}</strong></p>
                            @if($group->status == 0)<p class="text-left margin-0"><span class="fa fa-info" style="color: blue;text-align: justify">&nbsp;</span>Eslatma: <span style="opacity: 0.8">Guruhni 15-25 ta o'quvchilar bilan to'ldirsangiz guruh avtomatik ravishda <strong>Aktiv</strong> holatga o'tadi!</span></p>@endif
                        </div>
                </div>
                <div class="col-12">
                    <div class="col-sm-10" style="color:red;text-align:center;">
                        <b>
                            <h3>
                                Diqqat! "Testga ruxsat" tugmasi bosilgandan so'ng test ishlash uchun ajratilgan vaqt boshlanadi.<br>
                        Guruh test topshirishga tayyor bo'lmasa tekshirish uchun testga ruxsat tugmasini bosmang! 

                        <div class="text-right">
                            <input type="submit" class="btn btn-success" value="Testga ruxsat">
                        </div>
                            </h3>
                        </b>
                    </div>
                    <div class="col-sm-2" style="text-align:right">
                        <button id="btnPrint" class="btn btn-success">Chiqarish</button>
                    </div>
                </div>
                <br>
                <div class="block-content" style="width: 100%; overflow: auto;">
                    <form action="..\..\tests\owing" method="get">
                        <table class="table table-striped table-bordered" id="data-table">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>F.I.O.</th>
                                <th>Login</th>
                                <th>Davomat</th>
                                <th>Qarz</th>
                                <th>Parol</th>
                                <th>Ruxsat berish</th>
                                <th>Testga kirish vaqti</th>
                                <th>Natija</th>
                                <th>Qayta topshirish sanasi</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($data as $item)
                                <tr>
                                    <td>{{ $i }}</td>
                                    <td>{{ $item->last_name }} {{ $item->first_name }} {{ $item->middle_name }}</td>
                                    <td>{{ $item->passport_serial }}{{ $item->passport_number }}</td>
                                    <td>{{ !empty($monitor[$i - 1]) ? round($monitor[$i - 1]->summ / $monitor[$i - 1]->cnt * 100, 2) : 0 }} %</td>
                                    <td>{{ $group->tuition_fee - $item->summ }}</td>
                                    @if(empty($lists[$item->passport_serial.$item->passport_number]))
                                        <td></td>
                                        <td>@if($group->tuition_fee <= $item->summ && !empty($monitor[$i - 1]) && round($monitor[$i - 1]->summ / $monitor[$i - 1]->cnt * 100, 2) >= 70)<input type="checkbox" name="i{{ $item->id }}" checked>@php $j ++  @endphp @else<span style="color: #aa0000">Ruxsat berilmagan</span></td> @endif</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    @else
                                    @php
                                        $arr[] = [
                                            'name' => $item->last_name.' '.$item->first_name.' '.$item->middle_name,
                                            'passport' => $item->passport_serial.$item->passport_number,
                                            'password' => ($lists[$item->passport_serial.$item->passport_number]->password - 1342),
                                        ];
                                    @endphp
                                    <td>{{ ($lists[$item->passport_serial.$item->passport_number]->password - 1342) }}</td>
                                    <td><span style="color: #2ab27b">Ruxsat berilgan</span></td>
                                    <td>{{ $lists[$item->passport_serial.$item->passport_number]->start_date }} -  {{ $lists[$item->passport_serial.$item->passport_number]->end_date }}</td>
                                    <td>{{ $lists[$item->passport_serial.$item->passport_number]->ball   }}</td>
                                    <td></td>
                                    @endif
                                </tr>
                                @php $i ++ @endphp
                            @endforeach
                            </tbody>
                        </table>
                        @if($j > 0)
                        <div class="text-right">
                            <input type="submit" class="btn btn-success" value="Testga ruxsat">
                        </div>
                        @endif
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        var le = <?=--$i?>;
		var print = "<table style='border: 1px solid;width:100%;text-align:center'><tr><th style='border: 1px solid;'>F.I.O.</th><th style='border: 1px solid;width:100px'>Login</th><th style='border: 1px solid;width:50px'>Parol</th></tr>@php
                            foreach ($arr as $item)
                                echo "<tr><td style='border: 1px solid;text-align:left'>".$item['name']."</td><td style='border: 1px solid;'>".$item['passport']."</td><td style='border: 1px solid;'>".$item['password']."</td></tr>";
                        @endphp</table>";
    </script>
@endsection