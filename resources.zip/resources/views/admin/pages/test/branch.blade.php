@extends('layouts.admin_alisher')



@section('content')

@php $i = 0; $alll = 0; $a = 0; $b = 0;$c = 0; @endphp

                        <div class="title-link">
                            <div>
                                <h1>Guruhlar bo`yicha</h1>
                                <p><span class="head-link-href" data-href="/backoffice">Darsliklar</span> / <span class="head-link-href" data-href="/backoffice/tests/res">Yakuniy test statistika</span> / <span class="head-link-href" data-href="/backoffice/tests/region/{{ $branch->region->id }}">{{ $branch->region->name_uz }}</span> / {{ $branch->name_uz }}</p>
                            </div>
                            
                        </div>
                        <div class="table-toifa">
                        <h1>{{ $branch->name_uz }}</h1>
                        <div class="table-content">
                        

                        <table class=" table-hover">

                            <thead>

                                <tr>

                                    <th style="width: 2%"><p># </p></th>

                                    <th><p>Guruh nomi </p></th>

                                    <th style="text-align: center"><p>O'quvchilar soni </p></th>
                                    <th style="text-align: center"><p>Test ishga ruxsat berilganlar o'quvchilar soni </p></th>
                                    <th style="text-align: center"><p>Testdan o'tgan o'quvchilar soni </p></th>
                                    <th style="text-align: center"><p>Guvohnoma berilgan </p></th>
                                    <th style="text-align: center"><p>Guvohnoma berilishi kerak </p></th>
                           
                                

                                    <th style="text-align: center;"><p>Foiz </p></th>

                                </tr>

                                <tr>



                                </tr>

                            </thead>



                            <tbody>

                                <?php

                            foreach ($data  as $item):?>

                                <tr>

                                    <td><p>{{++$i}} </p></td>

                                    <td><p><a href="../../test/reg/{{$item->id}}">{{$item->name_uz}}</a> </p></td>

                                    <td style="text-align: center"><p>{{$item->alll}} </p></td>

                                    <td style="text-align: center"><p>{{$item->a}} </p></td>

                                    <td style="text-align: center"><p>{{$item->b}} </p></td>

                           
                                    <td style="text-align: center"><p>
                                
                                <?php foreach ($data2  as $item2)
                                    if($item->id==$item2->id){
                                        echo $item2->sum;
                                    }
                                    else{
                                        echo "0";
                                    }
                                ?> </p>

                            </td>
                            <td style="text-align: center"><p>
                                
                                <?php foreach ($data2  as $item2)
                                    if($item->id==$item2->id){
                                        echo $item->b-$item2->sum;
                                    }
                                    else{
                                        echo "0";
                                    }
                                ?> </p>

                            </td>
                                    <td style="text-align: center"><p>
                                        {{$item->b > 0 && $item->a > 0 ? intval($item->b / $item->a * 100) : 0}}% </p></td>

                                </tr>

                                <?php

                            $alll += $item->alll;

                            $a += $item->a;

                            $b += $item->b;
                         

                            endforeach; ?>
                        <?php foreach ($data2  as $item2)
                               
                                        $c= $c+ $item2->sum;
                                    
                                   
                                ?>
                                <tr>

                                    <th><p></th>

                                    <th><p>Umumiy summa </p></th>

                                    <th style="text-align: center"><p><?=$alll?> </p></th>

                                    <th style="text-align: center"><p><?=$a?> </p></th>

                                    <th style="text-align: center"><p><?=$b?> </p></th>
                                    <th style="text-align: center"><p><?=$c?> </p></th>
                                    <th style="text-align: center"><p><?=$b-$c?> </p></th>
                                   

                                    <th style="text-align: center"><p>{{$b > 0 && $a > 0 ? intval($b / $a * 100) : 0}}% </p>
                                    </th>

                                </tr>

                            </tbody>

                        </table>

                    </div>
    </div>




@endsection