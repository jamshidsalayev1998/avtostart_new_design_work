<html>

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style media="all" type="text/css">
        body {
            font-family: DejaVu Sans;
            /*font-size: 11px;*/
        }
        table {
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
    </style>
</head>

<body>
    @php $i = 1; @endphp
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;text-align: center">
            <div class="block block-condensed">
                <br>

                <div>
                	 <b>Filial nomi:{{ " ".$group->getBranchName() }}</b><br>
                    <b>Guruh nomi:{{ $group->name_uz." (".$group->getCourseName().")" }}</b><br>
                        @if($group->assistant_id != null)
                         O`qituvchilar:   {{ $group->teacher->full_name }} / {{ "@".$group->assistant->full_name }}<br>
                        @endif
                       Ta`lim tugash vaqti:{{date('d.m.Y', strtotime($group->edu_ending_date))}}<br>
                </div>
                <div class="block-content" style="width: 100%; overflow: auto;">
                    <table style="width: 100%;border: 1px black;">
                        <thead>
                        <tr>
                            <th style="text-align: center">#</th>
                            <th style="text-align: center">F.I.O.</th>
                            <th style="text-align: center">Pasport</th>
                            <th style="text-align: center">Ball</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $item)
                            <tr>
                                <td style="text-align: center">{{ $i }}</td>
                                <td>{{ $item->last_name }} {{ $item->first_name }} {{ $item->middle_name }}</td>
                                <td style="text-align: center">{{ $item->login }}</td>
                                <td style="text-align: center">{{ $item->ball }}</td>
                            </tr>
                        @php $i ++ @endphp
                        @endforeach
                        </tbody>
                    </table>

                </div>
                <br>
                <br>
                <?php 
 $responsible = Test\Model\BranchAdmin::where('branch_id', $group->branch_id)->first();

                ?>
  Filial direktori:   {{ $responsible->full_name}}&nbsp;&nbsp;  ______________
            </div>
        </div>
    </div>
</body>
</html>