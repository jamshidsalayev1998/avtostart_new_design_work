@extends('layouts.admin_alisher')

@section('content')
    @php $i = 0; $alll = 0; $a = 0; $b = 0; @endphp
                    <div class="title-link">
                        <div>
                            <h1>Viloatlar bo'yicha</h1>
                            <p><span class="head-link-href" data-href="/backoffice">Darsliklar</span> / Yakuniy test statistika</p>
                        </div>
                        
                    </div>
                    <div class="table-toifa">
                        <h1>Viloatlar bo'yicha</h1>
                        <div class="table-content">
                        <table class=" table-hover">
                            <thead>
                            <tr>
                                <th style="width: 2%"><p># </p></th>
                                <th><p>Viloyat nomi </p></th>
                                <th style="text-align: center"><p>O'quvchilar soni </p></th>
                                <th style="text-align: center"><p>Test ishga ruxsat berilganlar o'quvchilar soni </p></th>
                                <th style="text-align: center"><p>Testdan o'tgan o'quvchilar soni </p></th>
                                <th style="text-align: center;"><p> </p></th>
                            </tr>
                            <tr>
                            
                            </tr>
                            </thead>
                            
                            <tbody>
                                <?php 
                                foreach ($data  as $item):?>
                                <tr>
                                    <td><p>{{++$i}} </p></td>
                                    <td><p><a href="region/{{$item->id}}">{{$item->name_uz}}</a> </p></td>
                                    <td style="text-align: center"><p>{{$item->alll}} </p></td>
                                    <td style="text-align: center"><p>{{$item->a}} </p></td>
                                    <td style="text-align: center"><p>{{$item->b}} </p></td>
                                    <td style="text-align: center"><p>{{$item->b > 0 && $item->a > 0 ? intval($item->b / $item->a * 100) : 0}}% </p></td>
                                </tr>
                                <?php
                                $alll += $item->alll;
                                $a += $item->a;
                                $b += $item->b;
                                endforeach; ?>
                                <tr>
                                    <th><p> </p></th>
                                    <th>Umumiy  </th></th>
                                    <th style="text-align: center"><p><?=$alll?> </p></th>
                                    <th style="text-align: center"><p><?=$a?> </p></th>
                                    <th style="text-align: center"><p><?=$b?> </p></th>
                                    <th style="text-align: center"><p>{{$b > 0 && $a > 0 ? intval($b / $a * 100) : 0}}% </p></th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            
@endsection