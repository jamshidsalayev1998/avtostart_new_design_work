@extends('layouts.admin')



@section('content')

    @php $i = 0; $alll = 0; $a = 0; $b = 0; @endphp

    <div class="container">

        <div class="row">



            <div class="col-md-12">

                <div class="panel panel-default">

                    <div class="panel-heading">

                        <h3 class="panel-title">{{$group->name_uz}} bo'yicha</h3>
<input type="button" onclick="tableToExcel('testTable', 'W3C Example Table')"  class="btn btn-default btn-lg pull-right" value="Excelga export qilish  " />
                    </div>

                    <div class="panel-body">

                        @if(session('message'))

                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                <div class="alert-icon">

                                    <span class="icon-checkmark-circle"></span>

                                </div>

                                {{ session('message') }}

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                            </div>

                        @endif

                            <center>

                Ўқувчиларнинг гуруҳлар бўйича<br>РЎЙХАТИ<center><span style='text-align:left'>
                    <table width='100%' ><tr><td colspan='2'>Филиал номи: <b> {{ $group->getBranch() }}</td></tr><tr><td style='vertical-align:top;width:100px'>Ўқитувчи(лар):</td><td><b>{{ !empty($group->teacher->full_name) ? $group->teacher->full_name : ''}} <?=!empty($group->assistant->full_name) ? '<br>'.$group->assistant->full_name : ''?></td></tr></table><table width='100%'><tr><td></b></td><td></td></tr><tr><td>Гуруҳ: <b>{{ $group->name_uz." (".$group->getCourseName().")" }}</b></td><td style='text-align: right'>Сана: <?=date('d.m.Y')?></td></tr></table>

                        </center>
<div id="dvData">
                        <table class="table table-bordered table-hover"  id="testTable">

                            <thead>

                            <tr>

                                <th style="width: 2%">#</th>

                                <th>F.I.O.</th>

                                <th>Pasport</th>

                                <th style="text-align: center;">ball</th>

                                <th style="text-align: center;">Test ishlangan vaqt</th>

                            </tr>

                            <tr>


                            </tr>

                            </thead>



                            <tbody>

                            <?php

                            foreach ($data  as $item):?>

                            <tr>

                                <td>{{++$i}}</td>

                                <td>{{$item->last_name.' '.$item->first_name.' '.$item->middle_name}}</td>

                                <td>{{$item->passport_serial.' '.$item->passport_number}}</td>

                                <td style="text-align: center">{{$item->ball != null ? $item->ball : '-'}}</td>

                                <td style="text-align: center">{{$item->ball != null ? date('d.m.Y', strtotime($item->start_date )) : '-'}}</td>

                            </tr>

                            <?php

                            endforeach; ?>

                            </tbody>

                        </table>
</div>

                        <br><p style='text-align:center'>Директор&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;                ______________________</p>

                    </div>

                </div>

            </div>

        </div>

    </div>

@endsection