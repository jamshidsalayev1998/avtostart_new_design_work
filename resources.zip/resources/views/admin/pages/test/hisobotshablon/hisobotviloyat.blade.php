                @extends('layouts.admin')

                @section('content')

                @php $x = ($data->currentPage() - 1) * $data->perPage() @endphp
                @php $i = 0 @endphp
                <?php $a1 = 0;
                $a2 = 0;
                $a3 = 0;
                $a4 = 0;
                $a5 = 0; ?>
                <style>
                    td {
                        text-align: center;
                    }
                </style>

                <div class="app-heading-container app-heading-bordered bottom">

                    <ul class="breadcrumb">

                        <li><a href="/backoffice">Dashboard</a></li>

                        <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>
                        <li class="active"></li>
                    </ul>

                </div>

                <!-- START PAGE CONTAINER -->

                <div class="container">



                    <!-- NEW DEPOSITS -->

                    <div class="row">

                        <div class="col-md-12 ">

                            <div class="tile-basic tile-basic-icon-top">

                                <div class="tile-icon">

                                    <span class="fa fa-university"></span>

                                </div>

                                <div class="tile-content text-center padding-5">

                                    <h3 class="tile-title"></h3>

                                    <div class="col-md-2" style="text-align: left">
                                    </div>
                                    <div class="col-md-4" style="float:right">
                                        <select class="bs-select group-decision" id="group_id" data-live-search="true" data-dependent="student_id" name="student_id">
                                            <option style="display: none">Yilni tanlang</option>
                                            @foreach($groups as $group)
                                            <option value="{{ $groups[$x] }}" <?php if ($groups[$x] == $year) : ?> selected <?php endif ?> data-href=" {{ action('Admin\TestController@hisobotresshablonpost',[$groups[$x]]) }}" name="year">{{$groups[$x] }}

                                            </option>
                                            <?php $x++; ?>
                                            @endforeach
                                        </select>
                                    </div>


                                </div>

                            </div>

                        </div>

                    </div>

                    <!-- END NEW DEPOSITS -->
                    <!-- DEPOSITS -->

                    <div class="block block-condensed">

                        <div class="app-heading app-heading-small">

                            <div class="title">

                                <h2>Viloyatlar</h2>

                            </div>
                            <input type="button" onclick="tableToExcel('testTable', 'W3C Example Table')" class="btn btn-danger btn-lg pull-right" value="Excelga export qilish  ">

                        </div>



                        <div class="block-content" style="overflow-x: scroll;transform: rotateX(180deg);">

                            <table id="testTable" class="table table-striped table-bordered" style="transform: rotateX(180deg); ">


                                <tr>
                                    <td>№</td>
                                    <td>Viloyat nomi</td>
                                    <td>Barcha o`quvchilar soni</td>
                                    <td>Umumiy ball o`quvchi(shablon)</td>
                                    <td>Barcha o`qituvchilar soni</td>
                                    <td>Umumiy ball o`qituvchilar(shablon)</td>

                                </tr>
                                @foreach($data as $item)
                                <tr class="clickable-row" data-href="/backoffice/payments/hisobotfilialshablon/{{$item->id}}" style="cursor: pointer">
                                    <td>{{++$i}}</td>
                                    <td>
                                        {{$item->name_uz}}
                                    </td>


                                    <?php
                                    $count2 = DB::table('test_sys_student as st')
                                        ->select(
                                            DB::Raw('rg.name_uz'),
                                            DB::Raw("rg.id"),
                                            DB::Raw("sum(case when YEAR(gr.edu_ending_date) = '$year' THEN 1 else 0 end) as student_count"),
                                            DB::Raw("sum(case when ((YEAR(gr.edu_ending_date) = '$year')&&(gr.status = 1)) THEN 1 else 0 end) as student_count_aktiv"),
                                            DB::Raw("sum(case when ((YEAR(gr.edu_ending_date) = '$year')&&(gr.status = 2)) THEN 1 else 0 end) as student_count_neaktiv"),
                                            DB::Raw("sum(case when YEAR(gr.edu_ending_date) = '$year' THEN gr.tuition_fee else 0 end) as group_sum")
                                        )
                                        ->leftJoin("test_sys_grouped_student as gs", "gs.student_id", "st.id")
                                        ->leftJoin("test_sys_branch as br", "st.branch_id", "br.id")
                                        ->leftJoin("test_sys_group as gr", "gr.id", "gs.group_id")
                                        ->leftJoin("test_sys_region as rg", "br.region_id", "rg.id")
                                        ->groupBy('rg.name_uz', 'rg.id')
                                        ->orderBY('rg.name_uz')
                                        ->where('br.region_id', '=', $item->id)
                                        ->first(1000);

                                    $teacher = DB::table('test_sys_teacher as t')
                                        ->leftJoin("test_sys_branch as br", "t.branch_id", "br.id")
                                        ->leftJoin("test_sys_region as rg", "br.region_id", "rg.id")
                                        ->orderBY('rg.name_uz')
                                        ->where('br.region_id', '=', $item->id)
                                        ->where('t.status', '!=', 0)
                                        ->count();
                                    ?>
                                    <?php
                                    $a = Test\Model\ShablonResult::where('region_id', '=', $item->id)
                                        ->whereYear('create_at', '=', $year)
                                        ->where('group_id', '!=', 3)
                                        ->sum('ball')
                                    ?>
                                    <?php
                                    $b = Test\Model\ShablonResult::where('region_id', '=', $item->id)
                                        ->where('group_id', '=', 3)
                                        ->whereYear('create_at', '=', $year)
                                        ->sum('ball')
                                    ?>
                                    <td>{{$count2->student_count}}</td>
                                    <td> @if(!empty($a))
                                        {{round(($a/($count2->student_count*7)),2)}}
                                        @endif
                                        @if(empty($a))
                                        0
                                        @endif%
                                    </td>
                                    <td> {{$teacher}}</td>
                                    <td>
                                        @if(!empty($teacher))
                                        {{round(($b/($teacher*7)),2)}}
                                        @endif
                                        @if(empty($teacher))
                                        0
                                        @endif%
                                    </td>

                                </tr>
                                <?php
                                $a1 = $a1 + $count2->student_count;

                                ?>
                                @endforeach

                                <!-- <tfoot>
                                    <td>#</td>
                                    <td>Jami</td>
                                    <td>{{$a1}}</td>
                                    <td>{{$a2}}</td>
                                    <td>{{$a3}}</td>
                                    <td>{{$a4}}</td>
                                    <td>{{$a5}}</td>
                                    
                                   

                                </tfoot> -->
                            </table>

                            <div class="row">

                                <div class="col-sm-5" style="transform: rotateX(180deg); ">

                                    Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries

                                </div>

                                <div class="col-sm-7">

                                    {{ $data->links() }}

                                </div>

                            </div>

                        </div>

                    </div>

                    <!-- END DEPOSITS -->



                </div>

                <!-- END PAGE CONTAINER -->

                @endsection