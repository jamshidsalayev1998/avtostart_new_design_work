@extends('layouts.admin')

@section('content')

@php $x = ($data->currentPage() - 1) * $data->perPage() @endphp
@php $i = 0 @endphp
<style>
    td {
        text-align: center;
    }
</style>
<div class="app-heading-container app-heading-bordered bottom">
    <ul class="breadcrumb">
        <li><a href="/backoffice">Dashboard</a></li>
        <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>
        <li class="active"></li>
    </ul>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="tile-basic tile-basic-icon-top">
                <div class="tile-icon">
                    <span class="fa fa-university"></span>
                </div>
                <div class="tile-content text-center padding-5">
                    <h3 class="tile-title"></h3>
                    <div class="col-md-2" style="text-align: left">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="block block-condensed">
        <div class="app-heading app-heading-small">
            <div class="title">
                <h2>Guruhlar</h2>
            </div>
            <input type="button" onclick="tableToExcel('testTable', 'W3C Example Table')" class="btn btn-danger btn-lg pull-right" value="Excelga export qilish  ">
        </div>
        <div class="block-content" style="overflow-x: scroll;transform: rotateX(180deg);">
            <table id="testTable" class="table table-striped table-bordered" style="transform: rotateX(180deg); ">
                <tr>
                    <td>№</td>
                    <td>O`quvchi nomi( {{$student->last_name}} {{$student->first_name}} {{$student->middle_name}})</td>
                    <td>O`zlashtirish ko`rsatkichi(%)</td>
                </tr>
                @foreach($data as $item)
                <tr class="clickable" data="/backoffice/payments/hisobotstudentresultshablon/{{$item->id}}" style="cursor: pointer">
                    <td>{{++$i}}</td>
                    <td>
                       {{$item->temp_id}}-shablon
                    </td>
                    
                    <td>
                    {{$item->ball*10}}%
                    </td>
                </tr>
                @endforeach
            </table>
            <div class="row">
                <div class="col-sm-5" style="transform: rotateX(180deg); ">
                    Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries
                </div>
                <div class="col-sm-7">
                    {{ $data->links() }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection