@extends('layouts.admin')

@section('content')

@php $x = ($data->currentPage() - 1) * $data->perPage() @endphp
@php $i = 0 @endphp
<style>
    td {
        text-align: center;
    }
</style>

<div class="app-heading-container app-heading-bordered bottom">

    <ul class="breadcrumb">

        <li><a href="/backoffice">Dashboard</a></li>

        <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>



        <li class="active"></li>

    </ul>

</div>

<!-- START PAGE CONTAINER -->

<div class="container">



    <!-- NEW DEPOSITS -->

    <div class="row">

        <div class="col-md-12 ">

            <div class="tile-basic tile-basic-icon-top">

                <div class="tile-icon">

                    <span class="fa fa-university"></span>

                </div>

                <div class="tile-content text-center padding-5">

                    <h3 class="tile-title"></h3>

                    <div class="col-md-2" style="text-align: left">



                    </div>


                    <form action="/backoffice/payments/hisobotguruhshablonpost" method="GET">
                        <div class="col-md-4" style="float:right">
                            <select class="form-control" onchange="this.form.submit();" id="group_id" name="year">
                                <option style="display: none">Yilni tanlang</option>
                                @foreach($groups as $group)
                                <option value="{{ $groups[$x] }}" <?php if ($groups[$x] == $year) : ?> selected <?php endif ?>>{{$groups[$x] }}

                                </option>
                                <?php $x++; ?>

                                @endforeach
                                <input name="region_id" type="hidden" value="{{$id}}">
                            </select>
                        </div>

                    </form>


                </div>

            </div>

        </div>

    </div>

    <!-- END NEW DEPOSITS -->



    <!-- DEPOSITS -->

    <div class="block block-condensed">

        <div class="app-heading app-heading-small">

            <div class="title">

                <h2>Guruhlar</h2>

            </div>
            <input type="button" onclick="tableToExcel('testTable', 'W3C Example Table')" class="btn btn-danger btn-lg pull-right" value="Excelga export qilish  ">

        </div>



        <div class="block-content" style="overflow-x: scroll;
transform: rotateX(180deg);">

            <table id="testTable" class="table table-striped table-bordered" style="transform: rotateX(180deg); ">


                <tr>
                    <td>№</td>
                    <td>Guruh nomi</td>
                    <td>O`quvchilar soni</td>
                    <td>O`zlashtirish ko`rsatkichi(%)</td>
                </tr>
                @foreach($data as $item)
                <tr class="clickable-row" data-href="/backoffice/payments/hisobotstudentsshablon/{{$item->id}}" style="cursor: pointer">
                    <td>{{++$i}}</td>
                    <td>
                        {{$item->name_uz}}
                    </td>

                    <?php
                    $count2 = DB::table('test_sys_group as gr')
                        ->select(
                            DB::Raw('gr.name_uz'),
                            DB::Raw("gr.id"),
                            DB::Raw("sum(case when YEAR(gr.edu_ending_date) = '$year' THEN 1 else 0 end) as student_count"),
                            DB::Raw("sum(case when YEAR(gr.edu_ending_date) = '$year' THEN gr.tuition_fee else 0 end) as group_sum")
                        )
                        ->leftJoin("test_sys_grouped_student as gs", "gs.group_id", "gr.id")
                        ->leftJoin("test_sys_student as st", "gs.student_id", "st.id")
                        ->groupBy('gr.name_uz', 'gr.id')
                        ->orderBY('gr.name_uz')
                        ->where('gr.id', '=', $item->id)
                        ->first(1000);
                    ?>
                    <?php
                    $a = Test\Model\ShablonResult::where('group_id', '=', $item->id)
                   
                        ->sum('ball')
                    ?>
                    <td>
                        {{$count2->student_count}}
                    </td>
                    <td>
                        {{round(($a/($count2->student_count*7)),2)}}%
                    </td>


                </tr>

                @endforeach



            </table>

            <div class="row">

                <div class="col-sm-5" style="transform: rotateX(180deg); ">

                    Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries

                </div>

                <div class="col-sm-7">

                    {{ $data->links() }}

                </div>

            </div>

        </div>

    </div>

    <!-- END DEPOSITS -->



</div>

<!-- END PAGE CONTAINER -->

@endsection