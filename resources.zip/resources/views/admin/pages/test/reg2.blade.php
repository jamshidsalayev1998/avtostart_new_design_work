@extends('layouts.admin')
@section('content')
@php $true = 0; @endphp
    <?php $i = 1; ?>
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="block block-condensed">
                 <div class="col-sm-7" style="    float: left;
    padding: 5px;">
                        <button id="btnPrint" class="btn btn-success">Parollarni pdfda saqlash</button> 

                     </div>
                     <div class="col-sm-1" style="text-align:right">
                     </div>
                    <div class="col-sm-3" style="text-align:right;    float: right;
    padding: 5px;">
                        <a href="/backoffice/test/print/{{$group->id}}" class="btn btn-warning"><i class="fa fa-file-pdf-o"></i> Natijalarni pdfda saqlash</a>
                    </div>
                    <br>
                <br>

                <div id="group" class="text-center" data-id="<?=$group->edu_type?>">
                        <h3 class="tile-title" style="color: blue">{{ $group->name_uz." (".$group->getCourseName().")" }}</h3>
                        @if($group->assistant_id != null)
                            <h5>#{{ $group->teacher->full_name }} / {{ "@".$group->assistant->full_name }}</h5>
                        @endif
                        {{ $group->edu_starting_date }} <span class="fa fa-long-arrow-right"></span> {{ $group->edu_ending_date }}<br>
                        <div class="col-md-12">
                            <p class="text-left margin-0">Guruhning Hozirgi holati: <strong>{{ $group->getStatus() }}</strong></p>
                            @if($group->status == 0)<p class="text-left margin-0"><span class="fa fa-info" style="color: blue;text-align: justify">&nbsp;</span>Eslatma: <span style="opacity: 0.8">Guruhni 15-25 ta o'quvchilar bilan to'ldirsangiz guruh avtomatik ravishda <strong>Aktiv</strong> holatga o'tadi!</span></p>@endif
                        </div>
                </div>
                <div>

                </div>
                <div class="col-12">
                    <div class="col-sm-10" style="color:red;text-align:center;">
                        <b>
                            <h3>
                                Diqqat! "Testga ruxsat" tugmasi bosilgandan so'ng test ishlash uchun ajratilgan vaqt boshlanadi.<br>
                        Guruh test topshirishga tayyor bo'lmasa tekshirish uchun testga ruxsat tugmasini bosmang!
                            </h3>
                        </b>
                    </div>

                </div>
                <br>
                <div class="block-content" style="width: 100%; overflow: auto;">
                    <form action="..\..\tests\owing" method="get">
                        <table class="table table-striped table-bordered" id="data-table" style="text-align:center">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>F.I.O.</th>
                                <th>Login</th>
                                <th>Davomat</th>
                                <th>Qarz</th>
                                <th>Parol</th>
                                <th>Ruxsat berish</th>
                                <th>Testga kirish vaqti</th>
                                <th>Natija</th>
                                <th>Qayta topshirish sanasi</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($data as $item)
                                <tr>
                                    <td>{{ $i }}</td>
                                    <td style="text-align:left">{{ $item['name'] }}</td>
                                    <td>{{ $item['login'] }}</td>
                                    <td>{{ !empty($item['cnt']) ? $item['cnt'] : 0 }} %</td>
                                    <td>{{ !empty($item['sum']) ? $item['sum'] : 0 }}</td>
                                    <td>{{ !empty($item['password']) ? $item['password'] : '' }}</td>
                                    <td><?=!empty($item['rux']) ? $item['rux'] : '-'?></td>
                                    <td><?=(!empty($item['start_date']) ? ($item['start_date'].' '.$item['end_date']) : '')?></td>
                                    <td><?=!empty($item['ball']) ? $item['ball'] : ''?></td>
                                    <td><?=!empty($item['restart']) ? $item['restart'] : ''?></td>
                                    @php $true = $true || $item['t'] == 1; @endphp
                                </tr>
                                @php $i ++ @endphp
                            @endforeach
                            </tbody>
                        </table>
                        @if ($true)
                        <div class="text-right">
                            <input type="submit" class="btn btn-success" value="Testga ruxsat">
                        </div>
                        @endif
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        var print = "<center>Ўқувчиларнинг гуруҳлар бўйича<br>РЎЙХАТИ<center><span style='text-align:left'><table width='100%'><tr><td colspan='2'>Филиал номи: <b> {{ $group->getBranch() }}</td></tr><tr><td style='vertical-align:top;width:100px'>Ўқитувчи(лар):</td><td><b><?= !empty($group->teacher->full_name) ? $group->teacher->full_name : '' ?><?=!empty($group->assistant->full_name) ? '<br>'.$group->assistant->full_name : '' ?></td></tr></table><table width='100%'><tr><td></b></td><td></td></tr><tr><td>Гуруҳ: <b>{{ $group->name_uz." (".$group->getCourseName().")" }}</b></td><td style='text-align: right'>Сана: <?=date('d.m.Y')?></td></tr></table><table style='border: 1px solid;width:100%;text-align:center'><tr><th style='border: 1px solid;width:35px'>Т/р</th><th style='border: 1px solid;'>Ўқувчининг фамилия, исм, отасининг исми</th><th style='border: 1px solid;width:100px'>Паспорт серияси ва рақами</th><th style='border: 1px solid;width:50px'>Вақтинчалик парол</th><th style='border: 1px solid;width:100px'>Якуний балл</th><th style='border: 1px solid;'>Имзо</th></tr>@php
                            $i = 0;
                            foreach ($data as $item)

                                if (!empty($item['rux']) && $item['rux'] == '<span style="color: #2ab27b">Ruxsat berilgan</span>' && !empty($item['password']))
                                echo "<tr><td style='border: 1px solid;'>".(++$i)."</td><td style='border: 1px solid;text-align:left'>".$item['name']."</td><td style='border: 1px solid;'>".$item['login']."</td><td style='border: 1px solid;'>".(!empty($item['password']) ? $item['password'] : '')."</td><td style ='width:100px;border: 1px solid;'></td><td style ='width:100px;border: 1px solid;'></td></tr>";
                        @endphp</table><br><p style='text-align:center'>Директор&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;                ______________________</p>";
    </script>
@endsection
