                @extends('layouts.admin')

                @section('content')


                @php $x = 0 @endphp
                @php $i = 0 @endphp

                <style>
                    td {
                        text-align: center;
                    }
                </style>

                <div class="app-heading-container app-heading-bordered bottom">

                    <ul class="breadcrumb">

                        <li><a href="/backoffice">Dashboard</a></li>
                        <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>
                        <li class="active"></li>
                    </ul>

                </div>
                <div class="container">
                    <div class="row">

                        <div class="col-md-12 ">

                            <div class="tile-basic tile-basic-icon-top">

                                <div class="tile-icon">

                                    <span class="fa fa-university"></span>

                                </div>

                                <div class="tile-content text-center padding-5">

                                    <h3 class="tile-title"></h3>

                                    <div class="col-md-2" style="text-align: left">
                                    </div>
                                    <div class="col-md-4" style="float:right">
                                        <select class="bs-select group-decision" id="group_id" data-live-search="true" data-dependent="student_id" name="student_id">
                                            <option style="display: none">Yilni tanlang</option>
                                            @foreach($groups as $group)
                                            <option value="{{ $groups[$x] }}" <?php if ($groups[$x] == $year) : ?> selected <?php endif ?> data-href=" {{ action('Admin\TestController@moststudentrespost',[$groups[$x]]) }}" name="year">{{$groups[$x] }}

                                            </option>
                                            <?php $x++; ?>
                                            @endforeach
                                        </select>
                                    </div>


                                </div>

                            </div>

                        </div>

                    </div>
                    <div class="block block-condensed">

                        <div class="app-heading app-heading-small">

                            <div class="title">

                                <h2>Viloyatlar</h2>

                            </div>
                            <input type="button" onclick="tableToExcel('testTable', 'W3C Example Table')" class="btn btn-danger btn-lg pull-right" value="Excelga export qilish  ">

                        </div>
                        <div class="block-content">
                              <table id="DataTables_Table_0" class="table table-striped table-bordered datatable-extended">
                                <thead>
                                    <tr>
                                        <th>№</th>
                                        <th>O`quvchi FISH</th>
                                        @if(!empty( \Auth::user()->role == 7))
                                        <th>Viloyat nomi</th>
                                        @endif
                                        @if(!empty( \Auth::user()->role == 6))
                                        <th>Filial nomi</th>
                                        @endif
                                        @if(!empty( \Auth::user()->role == 5))
                                        <th>Filial nomi</th>
                                        @endif
                                        <th>Umumiy ball (shablon)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($data as $item)
                                    <tr class="clickable-row" data-href="/backoffice/payments/resultstudent/{{$item->user_id}}" style="cursor: pointer">
                                        <td>{{++$i}}</td>
                                        <td>
                                            <?php

                                            $student = Test\Model\Student::where('user_id', '=', $item->user_id)
                                                ->first();
                                            ?>
                                            {{$student->last_name}} {{$student->first_name}} {{$student->middle_name}}
                                        </td>
                                        <?php
                                        $a = Test\Model\ShablonResult::where('user_id', '=', $item->user_id)
                                            ->first();
                                        $region = Test\Model\Region::where('id', '=', $a->region_id)
                                            ->first();
                                        $branch = Test\Model\Branch::where('id', '=', $a->branch_id)
                                            ->first();
                                        ?>
                                        @if(!empty( \Auth::user()->role == 7))
                                        <td> {{$region->name_uz}}</td>
                                        @endif
                                     
                                        @if(!empty( \Auth::user()->role == 6))
                                        <td> {{$branch->name_uz}}</td>
                                        @endif
                                        @if(!empty( \Auth::user()->role == 5))
                                        <td> {{$branch->name_uz}}</td>
                                        @endif
                                        <td> {{$item->all_sum}}</td>

                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            <div class="row">

                            </div>

                        </div>

                    </div>
                </div>
                @endsection