@extends('layouts.admin_alisher')

@section('content')
                    <div class="title-link">
                        <div>
                            <h1>Filial rahbarlari</h1>
                            <p><span class="head-link-href" data-href="/backoffice">Bosh sahifa </span>/Filial rahbarlari</p>
                        </div>
                        
                    </div>
                    <div class="table-toifa-CE">
                    <div class="h1-button">
                        <h1> Filial rahbarlari</h1>
                        <button id="href_button" data-href="{{ route('branchadmin.create') }}" class="add-fan">
                            <p> Qo'shish</p>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7 1.16667V12.8333" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M1.16602 7H12.8327" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>    
                        </button>
                    </div>
                    <div class="table-content">


                    <table class="">

                        <thead>

                        <tr>

                            <th><p>Direktor FIO </p></th>

                            <th><p>Filial nomi </p></th>

                            <th><p>Tuman </p></th>

                            <th><p>Login </p></th>
                            <th><p>Kirgan vaqti </p></th>

                            <th  width="5%"><p> </p></th>

                            @if(\Illuminate\Support\Facades\Auth::user()->role == 7)

                            <th  width="5%"><p> </p></th>

                            <th  width="5%"><p> </p></th>
                                @endif

                        </tr>

                        </thead>

                        <tbody>

                        @foreach($data as $item)

                            <tr>

                                <td><p>{{$item->full_name}} </p></td>

                                <td><p>{{$item->branch->name_uz}} </p></td>

                                <td><p>{{$item->branch->area->name}} </p></td>

                                <td><p>{{$item->user->username}} </p></td>

                                <td><p>{{$item->last_seen}} </p></td>


                                <td><p>

                                    <a href="{{ route('branchadmin.show', ['id' => $item->id]) }}" class="btn btn-default btn-icon">

                                        <i class="fa fa-eye"></i>

                                    </a> </p>

                                </td>

                                @if(\Illuminate\Support\Facades\Auth::user()->role == 7)

                                <td><p>

                                    <a href="{{ route('branchadmin.edit', ['id' => $item->id]) }}" class="btn btn-default btn-icon">

                                        <i class="fa fa-edit"></i>

                                    </a> </p>

                                </td>

                                <td><p>

                                    <form action="{{ route('branchadmin.destroy', ['id' => $item->id]) }}" method="post">

                                        {{ csrf_field() }}

                                        {{ method_field('delete') }}

                                        <button class="btn btn-default btn-icon deleteData"><i class="fa fa-trash"></i></button>

                                    </form> </p>

                                </td>
                                    @endif

                            </tr>

                        @endforeach

                        </tbody>

                    </table>



                </div>



            </div>

@endsection