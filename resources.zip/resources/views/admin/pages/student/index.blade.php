@extends('layouts.admin_alisher')
@section('content')
@php $i =1 @endphp


                <div class="title-link">
                    <div>
                        <h1>Studentlar</h1>
                        <p><span>Darsliklar</span>/Studentlar</p>                        
                    </div>
                    <div>
                        <a href="">Ortga</a>
                    </div>
                </div>
                <div class="table-toifa-CE">
                    <div class="h1-button">
                        <h1>Studentlar ro’yxati</h1>
                        <button data-href="{{ route('student.create') }}" class="add-fan add-student">
                            <p>Student Qo'shish</p>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7 1.16667V12.8333" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M1.16602 7H12.8327" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>    
                        </button>
                    </div>
                    <div class="table-content">


                    <table class="">
                            <tr>
                                <th><p># </p> </th>
                                <th><p>FIO </p></th>
                                <th><p>Pasport info </p></th>
                               
                                <th><p>Telefon </p></th>
                                <th><p>Kirgan vaqti(STUDY) </p></th>
                                <th  width="5%"><p>ko`rish </p></th>
                                <th  width="5%"><p>o`zgartirish </p></th>
                                <th  width="5%"><p>o`chirish </p></th>
                            </tr>

                            @foreach($data as $item)
                                <tr>
                                    <td><p>{{ $i}} </p></td>
                                    <td><p>{{ $item->last_name." ".$item->first_name." ".$item->middle_name}}</p></td>
                                    <td><p>{{$item->passport_serial.$item->passport_number}}</p></td>

                                    <!-- <td>{{$item->getCourseName()}}</td> -->
                                    <td><p>{{$item->phone1}}</p></td>
                                    <td><p>{{$item->last_seen_shablon}}</p></td>
                                    <td><p>
                                        <a href="{{ route('student.show', ['id' => $item->id]) }}" class="btn btn-default btn-icon">
                                            <i class="fa fa-eye"></i>
                                        </a></p>
                                    </td>
                                    <td><p>
                                        <a href="{{ route('student.edit', ['id' => $item->id]) }}" class="btn btn-default btn-icon">
                                            <i class="fa fa-edit"></i>
                                        </a></p>
                                    </td>
                                    <td><p>
                                        <form action="{{ route('student.destroy', ['id' => $item->id]) }}" method="post">
                                            {{ csrf_field() }}
                                            {{ method_field('delete') }}
                                            <button class="btn btn-default btn-icon deleteData"><i class="fa fa-trash"></i></button>
                                        </form></p>
                                    </td>
                                </tr>
                                @php $i++ @endphp
                            @endforeach
                                                        

                        </table>
                      
                    </div>

                </div>


@endsection

@section('js')
<script type="text/javascript">
    $('.add-student').click(function(){
        location.href = $(this).attr('data-href');
    });
</script>
@endsection