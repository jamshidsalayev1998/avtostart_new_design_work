@extends('layouts.admin_alisher')

@section('content')
<style type="text/css">
    .paygroup-a{
        color: #333333 !important;
    }
    .paygroup-a:hover{
        color: #45D99E !important;
    }
</style>
    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
            <div class="title-link">
                    <div>
                        <h1>Filiallar</h1>
                        <p><span>Bosh sahifa</span>/Filiallar</p>
                    </div>
                    
                </div>
                <div class="table-toifa">
                    <h1>Filialni tanlang</h1>
                    <div class="table-content">
                        <table class=" table-hover">
                            <tr>
                                 <th style="width: 2%"><p># </p></th>
                                <th ><p>Filial nomi </p></th>
                                <th ><p>{{empty($branch) ? '2018-yil' : 'Filial nomi'}} </p></th>
                                <th ><p>{{empty($branch) ? '2019-yil' : 'Filial nomi'}} </p></th>
                            </tr>
                            @foreach($count as $item)
                                <tr>
                                    <td><p>{{++$i}} </p></td>
                                    <td><p><a class="paygroup-a" href="{{empty($data2) ? '../groupstudent' : '/groupstudents'}}/{{ $item->id }}">{{$item->name_uz}}</a></a> </p></td>
                                    <td><p>{{$item->sum1}} </p></td>
                                                                           
                                    <td><p>{{$item->sum2}} </p></td>
                                   
                                </tr>
                            @endforeach
                            
                        </table>
                        {{-- <div class="row">
                            <div class="col-sm-5">
                                Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries
                            </div>
                            <div class="col-sm-7">
                        
                            </div>
                        </div> --}}
                    </div>
                </div>

            
@endsection