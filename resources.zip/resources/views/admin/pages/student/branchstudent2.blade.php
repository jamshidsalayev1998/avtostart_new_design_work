@extends('layouts.admin')

@section('content')
    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
    <div class="container">
        <div class="row">


            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                    
                        </h3>
                    </div>
                    <div class="panel-body">
                        @if(session('message'))
                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-checkmark-circle"></span>
                                </div>
                                {{ session('message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        @endif
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                 <th style="width: 2%">#</th>
                                <th style="text-align: center">Filial nomi</th>
                                <th style="text-align: center">{{empty($branch) ? '2018-yil' : 'Filial nomi'}}</th>
                                <th style="text-align: center">{{empty($branch) ? '2019-yil' : 'Filial nomi'}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($count as $item)
                                <tr>
                                    <td>{{++$i}}</td>
                                    <td><a href="{{'../backoffice/groupstudent' }}/{{ $item->id }}">{{$item->name_uz}}</a></a></td>
                                    <td>{{$item->sum1}}</td>
                                                                           
                                    <td>{{$item->sum2}}</td>
                                   
                                </tr>
                            @endforeach
                            
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col-sm-5">
                                Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}} entries
                            </div>
                            <div class="col-sm-7">
                        
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection