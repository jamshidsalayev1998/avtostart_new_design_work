<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style media="all" type="text/css">
    body {
        font-family: DejaVu Sans;
        font-size: 14px;
    }
</style>
<table width="100%">
    <tr>
        <td width="150px">
            @if(file_exists(public_path($data->image)) && $data->image !== null)
                <img style="width: 100%" src="{{ asset($data->image) }}" style="width: 120px;height: auto;max-height:135px;background: white" class="studentimage">
            @endif
            @if($data->image === null && $data->gender == 0)
                <img style="width: 100%" src="{{ asset('/extra/avatarmale.png') }}" style="width: 120px;height: auto;background: white" class="studentimage">
            @endif
            @if($data->image === null && $data->gender == 1)
                <img style="width: 100%" src="{{ asset('/extra/avatarfemale.png') }}" style="width: 120px;height: auto;background: white" class="studentimage">
            @endif
        </td>
        <td>
            <table width="100%">
                <tr>
                    <td colspan="2" style="border-bottom: 1px solid #aaaaaa;vertical-align: top;height: 20px">
                        <b class="fa fa-user"></b> <b>SHAXSIY MA'LUMOTLARI</b>
                    </td>
                </tr>
                <tr>
                    <td style="vertical-align: top">
                        Ismi: <b>{{ $data->first_name }}</b><br>
                        Familyasi: <b>{{ $data->last_name }}</b><br>
                        Otasining ismi: <b>{{ $data->middle_name }}</b><br>
                        Jinsi: <b>{{ $data->getGender() }}</b>
                    </td>
                    <td style="vertical-align: top">
                        Tug'ilgan sanasi: <b>{{ $data->birth_date }}</b><br>
                        Millati: <b>{{ $data->getNationality() }}</b><br>
                        Fuqaroligi: <b>{{ $data->getCitizenship() }}</b><br>
                        Yashash mamlakati: <b>{{ $data->getCitizenship() }}</b>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<br>
<table width="100%">
    <tr>
        <td colspan="2" style="border-bottom: 1px solid #aaaaaa;">
            <b><i class="fa fa-vcard"></i> PASSPORT VA MANZIL MA'LUMOTLARI</b>
        </td>
    </tr>
    <tr>
        <td style="width: 50%;vertical-align: top;">
            Passport seriyasi: <b>{{ $data->passport_serial }}</b><br>
            Passport raqami: <b>{{ $data->passport_number }}</b><br>
            Kim tomonidan berilgan: <b>{{ $data->passport_issued_by }}</b>
        </td>
        <td style="width: 50%">
            Passport berilgan sana: <b>{{ $data->passport_issued_date }}</b><br>
            Passport amal qilish muddati: <b>{{ $data->passport_expiration_date }}</b><br>
            Doimiy manzil: <b>{{ $data->home_address }}</b>
        </td>
    </tr>
</table>
<br>
<table width="100%">
    <tr>
        <td colspan="2" style="border-bottom: 1px solid #aaaaaa;">
            <b><i class="fa fa-list"></i> TA'LIM HAQIDA MA'LUMOT</b>
        </td>
    </tr>
    <tr>
        <td style="width: 50%;vertical-align: top;">
            Ta'lim turi: <b>{{ $data->getCourse()->name }}</b><br>
            Boshlanish sanasi: <b>{{ $data->edu_starting_date }}</b><br>
            Yakunlanish sanasi: <b>{{ $data->edu_ending_date }}</b>
        </td>
        <td style="width: 50%;vertical-align: top;">
            Qabul hujjat raqami: <b>{{ $data->application_number }}</b><br>
            Student ID: <b>{{ $data->student_number }}</b><br>
            Hoziri holati: <b>{{ $data->getStatus() }}</b>
        </td>
    </tr>
</table>
<br>
<table width="100%">
    <tr>
        <td colspan="2" style="border-bottom: 1px solid #aaaaaa;">
            <b><i class="fa fa-plus-square"></i> QO'SHIMCHA MA'LUMOTLAR</b>
        </td>
    </tr>
    <tr>
        <td style="width: 50%;vertical-align: top;">
            Telefon: {{ $data->phone1 }}
            @if(!empty($data->phone2))
                Qo'shimcha telefon: {{ $data->phone2 }}
            @endif
            @if(!empty($data->phone3))
                Qo'shimcha telefon: {{ $data->phone3 }}
            @endif
        </td>
        <td style="width: 50%;vertical-align: top;">
            @if(!empty($data->military_doc_number))
                Xarbiy guvohnoma raqami: {{ $data->military_doc_number }}
            @endif
        </td>
    </tr>
</table>