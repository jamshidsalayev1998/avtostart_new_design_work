@extends('layouts.admin_alisher')

@section('content')
<style type="text/css">
    .paygroup-a{
        color: #333333 !important;
    }
    .paygroup-a:hover{
        color: #45D99E !important;
    }
</style>
    @php $i = ($data->currentPage() - 1) * $data->perPage() @endphp
                <div class="title-link">
                    <div>
                        <h1>Viloyatlar</h1>
                        <p><span class="head-link-href" data-href="/backoffice">Bosh sahifa</span>/Viloyatlar</p>
                    </div>
                    
                </div>
                <div class="table-toifa">
                    <h1>Villoyatni  tanlang</h1>
                    <div class="table-content">
                        
                        <table class=" table-hover">
                            <tr>
                                 <th style="width: 2%"><p># </p></th>
                                <th ><p>{{empty($branch) ? 'Viloyat nomi' : 'Filial nomi'}} </p></th>
                                <th ><p>{{empty($branch) ? '2018-yil' : 'Filial nomi'}} </p></th>
                                <th ><p>{{empty($branch) ? '2019-yil' : 'Filial nomi'}} </p></th>
                            </tr>
                            @foreach($count as $item)
                                <tr>
                                    <td><p>{{++$i}} </p></td>
                                    <td><p><a class="paygroup-a" href="{{empty($data2) ? 'branchstudent' : '../paybranch'}}/{{ $item->id }}">{{$item->name_uz}}</a></a> </p></td>
                                    <td><p>{{$item->sum1}} </p></td>
                                                                           
                                    <td><p>{{$item->sum2}} </p></td>
                                   
                                </tr>
                            @endforeach
                            
                        </table>
                        <div class="row">
                            
                        </div>
                    </div>
                </div>

         
@endsection