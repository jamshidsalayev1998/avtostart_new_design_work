@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                       Ta'lim turini tanlang
                    </div>
                    @if(session('message'))
                        <div class="panel-body">
                            <div class="col-md-10">
                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        </div>
                    @endif
                    <div class="block">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="width: 2%">#</th>
                                <th style="width: 50%">Ta'lim turi</th>
                                <th style="text-align: center">Jami soatlar</th>
                                <th style="text-align: center">Nazariy</th>
                                <th style="text-align: center">Amaliy</th>
                            </tr>
                            </thead>
                            <tbody>
                            @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp
                            @foreach($data as $item)
                                <tr class="clickable-row" data-href="{{ route('lesson.show',['id'=>$item->id]) }}" style="cursor: pointer">
                                    <td>{{ ++$count }}</td>
                                    <td>{{ $item->name }}</td>
                                    <td style="text-align: center">{{ $item->getHours() }}</td>
                                    <td style="text-align: center">{{ $item->getTheroricslHours() }}</td>
                                    <td style="text-align: center">{{ $item->getPracticaLHours() }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {!! $data->links() !!}

                    </div>
                </div>
            </div>


        </div>
    </div>
@endsection