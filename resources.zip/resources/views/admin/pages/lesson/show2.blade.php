@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('lesson.index') }}">Fanlar</a></li>
            <li class="active">{{ $course->name }}</li>
            <li class="active"> Mavzular </li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading"><h4 style="color: darkblue;font-weight: bold">{{ $course->name }} toifa > <span style="color:black;font-weight: 500">Fanlar va Mavzular</span></h4></div>
            <div class="panel-body">
                <div class="col-md-2">
                    @if(\Auth::user()->role == 7)<button data-toggle="modal" data-target="#modal-create" class="btn btn-default"><i class="icon-plus-circle">&nbsp;</i>Fan qo'shish</button>@endif
                </div>

                @if(session('message'))
                    <div class="col-md-10">
                        <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                            <div class="alert-icon">
                                <span class="icon-checkmark-circle"></span>
                            </div>
                            {{ session('message') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                        </div>
                    </div>
                @endif
                @if(session('error'))
                    <div class="col-md-10">
                        <div class="alert alert-danger alert-icon-block alert-dismissible" role="alert">
                            <div class="alert-icon">
                                <span class="icon-checkmark-circle"></span>
                            </div>
                            {{ session('error') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                        </div>
                    </div>
                @endif
            </div>
        </div>
        <div class="block block-condensed">
            <div class="block-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="dd" id="nestable">
                            <ol class="dd-list">
                                @foreach($lessons as $lesson)
                                    <li class="dd-item dd-nodrag dd-collapsed" data-id="2" >
                                        <div class="dd-handle"><span style="font-weight: bolder">{{ $lesson->name_uz }}</span><span class="label label-success label-bordered label-ghost">+{{ ($lesson->topics->sum('hours')) }}</span>
                                            @if(\Auth::user()->role == 7||\Auth::user()->role == 0)
                                            <div class="dropdown pull-right margin-right-10">
                                                <button type="button" class="btn btn-success pull-right btn-sm margin-left-5" style="margin-top:0px;" data-toggle="dropdown"><span class="fa fa-ellipsis-v "></span></button>
                                                <ul class="dropdown-menu dropdown-left">
                                                    <li><button class="btn btn-default lessonshower form-control" data-idec="{{ $lesson->id }}" style="border:none;text-align: left" data-toggle="modal" data-target="#modal-edit"><span class="fa fa-edit"></span>O'zgartirish</button></li>
                                                    <li><button class="btn btn-default addtopic form-control" data-name="{{ $lesson->name_uz }}" data-idec="{{ $lesson->id }}" style="border:none;text-align: left" data-toggle="modal" data-target="#modal-add-topic"><span class="fa fa-plus-square-o"></span>Mavzu qo'shish</button></li>
                                                    <li><button class="btn btn-default clickable-row form-control" data-href="{{ route('view',['id'=>$lesson->id]) }}" style="border:none;text-align: left" ><span class="fa fa-info-circle"></span>Batafsil</button></li>
                                                </ul>
                                            </div>
                                            @endif
                                        </div>
                                        <ol class="dd-list">
                                            @foreach($lesson->topics as $topic)
                                                <li class="dd-item dd-collapsed" data-id="5">
                                                    <div class="dd-handle">{{ $topic->name_uz }}
                                                        <span class="label label-default label-bordered label-ghost">+{{ $topic->hours }}</span>
                                                        <span class="label label-default label-bordered label-ghost">{{ $topic->getType() }}</span>
                                                        @if(\Auth::user()->role == 7||\Auth::user()->role == 0)
                                                        <div class="dropdown pull-right margin-right-10">
                                                            <button type="button" class="btn btn-default pull-right btn-sm margin-left-5" style="margin-top:0px;" data-toggle="dropdown"><span class="fa fa-ellipsis-h "></span></button>
                                                            <ul class="dropdown-menu dropdown-left">
                                                                <li><a href="{{ route('addcontent',['id'=>$topic->id]) }}">&nbsp;<span class="fa fa-plus"></span>Mavzuga ma'lumot qo'shish</a></li>
                                                                <li><a href="{{ route('topics.show',['id'=>$topic->id]) }}"><span class="fa fa-info"></span> Batafsil</a></li>
                                                                <button class="btn btn-default topicshower form-control" data-idec="{{ $topic->id }}" style="border:none;text-align: left" data-toggle="modal" data-target="#modal-edit-topic"><span class="fa fa-edit">&nbsp;&nbsp;&nbsp;</span>O'zgartirish</button>
                                                                <li><a href="{{ route('goup',['id'=>$topic->id]) }}"><span class="icon-arrow-up-circle"></span>Tepaga ko'tarish</a></li>
                                                                <li><a href="{{ route('godown',['id'=>$topic->id]) }}"><span class="icon-arrow-down-circle"></span>Pastga tushirish</a></li>
                                                            </ul>
                                                        </div>
                                                        @endif
                                                    </div>
                                                </li>
                                            @endforeach
                                        </ol>
                                    </li>
                                @endforeach
                            </ol>
                        </div>
                    </div>
                    <div class="col-md-2">

                    </div>
                </div>

            </div>
        </div>
        <!-- END NESTABLE LIST -->
    </div>
    <div class="modal fade" id="modal-create" tabindex="-1" role="dialog" aria-labelledby="modal-default-header">
        <div class="modal-dialog" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modal-default-header">Yangi fan qo'shish</h4>
                </div>
                <form action="{{ route('lesson.store') }}" method="post">
                    {{ csrf_field() }}
                    <input type="hidden" value="{{ $course->id }}" name="edu_type">
                    <div class="modal-body">
                        <div class="form-group" style="margin-bottom: -30px;">
                            <div class="app-content-tabs">
                                <ul>
                                    <li><a href="#uz" class="active"><span class="fa fa-globe"></span>O'zbek tili</a></li>
                                    <li><a href="#ru"><span class="fa fa-globe"></span> Rus tili</a></li>
                                </ul>
                            </div>

                            <div class="container app-content-tab active" id="uz">
                                <div class="block">
                                    <label for="name_uz">Darslikning nomlanishi
                                        @if($errors->has('name_uz'))
                                            <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                                        @endif
                                    </label>
                                    <input type="text" name="name_uz" id="name_uz" value="{{ old('name_uz') }}" class="form-control" >
                                </div>
                            </div>

                            <div class="container app-content-tab" id="ru">
                                <div class="block">
                                    <label for="name_ru">Названия Учебника
                                        @if($errors->has('name_ru'))
                                            <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                                        @endif
                                    </label>
                                    <input type="text" name="name_ru" id="name_ru" value="{{ old('name_ru') }}" class="form-control" >
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-12">
                                <label> Tanlangan fandan keyinga joylashadi
                                    @if($errors->has('l_order'))
                                        <span class="text-danger"> | {{ $errors->first('l_order') }}</span>
                                    @endif
                                </label>
                                <select class="bs-select dynamic"  id="l_order" data-live-search="true" data-dependent="l_order" name="l_order">
                                    <option value="0" style="color:blue" selected>Eng boshida</option>
                                    @foreach($lessons as $lesson)
                                        <option selected value="{{ $lesson->l_order }}">{{ $lesson->name_uz }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-link" data-dismiss="modal">Bekor qilish</button>
                        <button type="submit" class="btn btn-default">Qo'shish</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-edit" tabindex="-1" role="dialog" aria-labelledby="modal-default-header">
        <div class="modal-dialog" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modal-success-header">Fanni o'zgartirish</h4>
                </div>
                <form action="" method="post" id="edit-lesson-form">
                    {{ csrf_field() }}
                    {{ method_field('put') }}
                    <input type="hidden" value="{{ $course->id }}" name="edu_type">
                    <div class="modal-body">
                        <div class="form-group" style="margin-bottom: 0px;">
                            <div class="app-content-tabs">
                                <ul>
                                    <li><a href="#edituz" class="active"><span class="fa fa-globe"></span>O'zbek tili</a></li>
                                    <li><a href="#editru"><span class="fa fa-globe"></span> Rus tili</a></li>
                                </ul>
                            </div>

                            <div class="container app-content-tab active" id="edituz">
                                <div class="block">
                                    <label for="name_uz">Darslikning nomlanishi
                                        @if($errors->has('name_uz'))
                                            <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                                        @endif
                                    </label>
                                    <input type="text" name="name_uz" id="name_uz_edit" value="{{ old('name_uz') }}" class="form-control" >
                                </div>
                            </div>

                            <div class="container app-content-tab" id="editru">
                                <div class="block">
                                    <label for="name_ru">Названия Учебника
                                        @if($errors->has('name_ru'))
                                            <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                                        @endif
                                    </label>
                                    <input type="text" name="name_ru" id="name_ru_edit" value="{{ old('name_ru') }}" class="form-control" >
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-link" data-dismiss="modal">Bekor qilish</button>
                        <button type="submit" class="btn btn-default">Saqlash</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-add-topic" tabindex="-1" role="dialog" aria-labelledby="modal-success-header">
        <div class="modal-dialog modal-success" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <form method="post" action="{{ route('topics.store') }}">
                    {{ csrf_field() }}
                <div class="modal-header" style="border-radius: 0px">
                    <h4 class="modal-title" id="modal-success-header">Mavzu qo'shish</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name_uz">Joriy fan nomi
                        </label>
                        <select class="form-control" name="lesson_id">
                            <option selected id="current-topic"></option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name_uz">Mavzuning nomlanishi
                            @if($errors->has('name_uz'))
                                <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                            @endif
                        </label>
                        <input type="text" name="name_uz" id="name_uz" value="{{ old('name_uz') }}" class="form-control" >
                    </div>
                    <div class="form-group">
                        <label for="name_uz">Названия тема
                            @if($errors->has('name_ru'))
                                <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                            @endif
                        </label>
                        <input type="text" name="name_ru" id="name_ru" value="{{ old('name_ru') }}" class="form-control" >
                    </div>
                    <div class="col-md-6" style="margin: 0px;padding-left: 0px;">
                        <label for="name_uz">Soatlar soni(butun son)
                            @if($errors->has('hours'))
                                <span class="text-danger"> | {{ $errors->first('hours') }}</span>
                            @endif
                        </label>
                        <input type="text" name="hours" id="hours" value="{{ old('hours') }}" class="form-control" >
                    </div>
                    <div class="col-md-6" style="margin: 0px;padding-right: 0px;">
                        <label for="name_uz">Tanlangan mavzudan keyin joylashadi
                            @if($errors->has('t_order'))
                                <span class="text-danger"> | {{ $errors->first('t_order') }}</span>
                            @endif
                        </label>
                        <select class="form-control" name="t_order" id="t_order">
                            <option value="0" style="color: blue">Eng boshida</option>
                        </select>
                    </div>
                    <div class="col-md-6" style="margin-top: 20px;padding-left: 0px;">
                        <label>Mashg'ulot turi
                            @if($errors->has('type'))
                                <span class="text-danger"> | {{ $errors->first('type') }}</span>
                            @endif
                        </label>
                        <br>
                        <div class="app-radio danger inline">
                            <label><input type="radio" name="type" id="type" value="2" checked=""> Amaliy<span></span></label>
                        </div>
                        <div class="app-radio success inline">
                            <label><input type="radio" name="type" id="type" value="1" @if(old('gender')==0) checked @endif> Nazariy<span></span></label>
                        </div>
                    </div>
                    <div class="col-md-6" style="margin-top: 20px;padding-right: 0px;">
                        <label for="name_uz">Status
                            @if($errors->has('t_order'))
                                <span class="text-danger"> | {{ $errors->first('t_order') }}</span>
                            @endif
                        </label>
                        <select class="form-control" name="status" id="status">
                            <option value="1" >Aktiv</option>
                            <option value="0" >Passiv</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link" data-dismiss="modal">Bekor qilish</button>
                    <button type="submit" class="btn btn-success">Qo'shish</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-edit-topic" tabindex="-1" role="dialog" aria-labelledby="modal-success-header">
        <div class="modal-dialog modal-success" role="document">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>

            <div class="modal-content">
                <form method="post" action="{{ route('topics.store') }}" id="edit-topic-form">
                    {{ csrf_field() }}
                    {{ method_field('put') }}
                <div class="modal-header" style="border-radius: 0px">
                    <h4 class="modal-title" id="modal-success-header">Mavzu qo'shish</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name_uz">Joriy fan nomi
                        </label>
                        <select class="form-control" name="lesson_id" id="lesson_edit">
                            <option selected id="current-topic"></option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name_uz">Mavzuning nomlanishi
                            @if($errors->has('name_uz'))
                                <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                            @endif
                        </label>
                        <input type="text" name="name_uz" value="{{ old('name_uz') }}" id="name_uz_edit" class="form-control" >
                    </div>
                    <div class="form-group">
                        <label for="name_uz">Названия тема
                            @if($errors->has('name_ru'))
                                <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                            @endif
                        </label>
                        <input type="text" name="name_ru" value="{{ old('name_ru') }}" id="name_ru_edit" class="form-control" >
                    </div>
                    <div class="col-md-6" style="margin: 0px;padding-left: 0px;">
                        <label for="name_uz">Soatlar soni(butun son)
                            @if($errors->has('hours'))
                                <span class="text-danger"> | {{ $errors->first('hours') }}</span>
                            @endif
                        </label>
                        <input type="text" name="hours" id="hours_edit" value="{{ old('hours') }}" class="form-control" >
                    </div>
                    <div class="col-md-6" style="padding-left: 0px;">
                        <label>Mashg'ulot turi
                            @if($errors->has('type'))
                                <span class="text-danger"> | {{ $errors->first('type') }}</span>
                            @endif
                        </label>
                        <br>
                        <div class="app-radio danger inline">
                            <label><input type="radio" name="type" id="topic-type-edit2" value="2" checked=""> Amaliy<span></span></label>
                        </div>
                        <div class="app-radio success inline">
                            <label><input type="radio" name="type" id="topic-type-edit1" value="1" @if(old('type')==0) checked @endif> Nazariy<span></span></label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link" data-dismiss="modal">Bekor qilish</button>
                    <button type="submit" class="btn btn-success">Saqlash</button>
                </div>
                </form>
            </div>
        </div>
    </div>
@endsection