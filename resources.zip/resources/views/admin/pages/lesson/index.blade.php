@extends('layouts.admin_alisher')

@section('content')
                <div class="title-link">
                    <div>
                        <h1>Toifalar</h1>
                        <p><span>Darsliklar</span>/Toifalar</p>
                    </div>
                    
                </div>
                <div class="table-toifa">
                    <h1>Ta’lim turini tanlang</h1>
                    <div class="table-content">
                        <table>
                            <tr>
                                <th><p>#</p></th>
                                <th><p>Ta’lim turi</p></th>
                                <th><p>Jami soatlar</p></th>
                                <th><p>Nazariy</p></th>
                                <th><p>Amaliy</p></th>
                            </tr>
                            @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp
                            @foreach($data as $item)
                            <tr class="clickable-row" data-href="{{ route('lesson.show',['id'=>$item->id]) }}" style="cursor: pointer;">
                                <td><p>{{ ++$count }}</p></td>
                                <td><p>{{ $item->name }}</p></td>
                                <td><p>{{ $item->getHours() }}</p></td>
                                <td><p>{{ $item->getTheroricslHours() }}</p></td>
                                <td><p>{{ $item->getPracticaLHours() }}</p></td>
                            </tr>
                            @endforeach
                            
                        </table>
                    </div>
                </div>



@endsection