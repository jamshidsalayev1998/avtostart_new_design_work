@extends('layouts.admin_alisher')
@section('content')

                <div class="title-link">
                    <div>
                    	<?php $course = 'Test\Model\Course'::find($data->edu_type); ?>
                        <h1>Yo'l harakati sohasidagi qonunchilik asoslari</h1>
                        <p><span>Darsliklar / Toifalar /{{ $course->name }}	/</span> {{ $data->name_uz }}</p>                        
                    </div>
                    <div>
                        <a href="{{ route('lesson.show' , ['id' => $course->id])  }}">Ortga</a>
                    </div>
                </div>
                <div class="table-toifa-batafsil">
                    <div class="boshlash-batafsil">
                        <div>
                            <h1>{{ $data->name_uz }}</h1>
                            <p class="batafsil-ru-sarlavha">({{ $data->name_ru }})</p>
                            <div class="batafsil-p-i"><img width="14px" src="{{ asset('admin/style/images/icons/soat.svg') }}" alt=""><p>{{ date('d.m.Y H:i',strtotime($data->updated_at)) }}</p></div>
                        </div>
                        <div class="mavzular-batafsil-button">
                            <button href="#" class="batafsil-mav-qosh mavzuga-m-add">
                                <p>Mavzu qo’shish</p>
                                <img width="16px" src="{{ asset('admin/style/images/icons/addMavzuWhite.svg') }}" alt="AAA">
                            </button>
                            <button class="batafsil-mav-uzgar">
                                <img width="16px" src="{{ asset('admin/style/images/icons/uzgartirBlue.svg') }}" alt="AAA">
                                <p>O’zgartirish</p>
                            </button>
                           
	                            <button class="batafsil-mav-uchir">
	                                <img width="16px" src="{{ asset('admin/style/images/icons/deleteRed.svg') }}" alt="AAA">
	                                <p>O'chirish</p>
	                            </button>
                        </div>
                    </div>
                    <div class="mavzu-linkes">
                        <div class="mavzu-batafsil-title">
                            <h1>Mavzular</h1>
                        </div>
                        <table>
                        	@foreach($data->topics as $topic)
                        	<tr>
                                <td><a href="{{ route('topics.show',['id'=>$topic->id]) }}">{{ $topic->name_uz }}</a></td>
                            </tr>
                        	@endforeach
                            
                        </table>
                    </div>
                </div>


                <div class="change-mavzu">
                            <form class="change-form" action="{{ route('lesson.update' , ['id' => $data->id]) }}" method="POST">
                                {{ csrf_field() }}
                                {{ method_field('put') }}
                                <div class="change-text">
                                    <h1>Fanni o’zgartirish</h1>
                                    <button class="change-mavzu-close" type="button"><img src="{{ asset('admin/style/images/icons/closex.svg') }}" alt="AAA"></button>
                                </div>
                                <div class="change-item">
                                    <p>Darslikning nomlanishi - O’zbek tilida</p>
                                    <input type="text" class="name_uz_change" placeholder="Darslik nomini kiriting" name="name_uz" value="{{ $data->name_uz }}" >
                                </div>
                                <div class="change-item">
                                    <p>Darslikning nomlanishi - Rus tilida</p>
                                    <input type="text" class="name_ru_change" placeholder="Дорожные знаки" name="name_ru" value="{{ $data->name_ru }}">
                                </div>
                                <div class="submit-changes">
                                    <button class="change-mavzu-bekor" type="button"><p>Bekor qilish</p></button>
                                    <button class="submit_mavzu_b" type="button"><p>Saqlash</p></button>
                                </div>

                            </form>
                            <div class="change-close-div"></div>
                        </div>

                            <div class="delete-mavzu">
						        <div class="delete-close"></div>
						        <form  id="delete_fan" action="{{ route('lesson.destroy', ['id' => $data->id]) }}" method="post" class="delete-form">
						            <div class="delete-close-div"><button type="button" class="delete-close-button"><img src="{{ asset('admin/style/images/icons/closex.svg') }}" alt="AAA"></button></div>
						            <div class="delete-image"><img width="80px" src="{{ asset('admin/style/images/glavni/delete.svg') }}" alt="AAA"></div>
						            <div class="delete-text">
						                <h1>Ma’lumotni o’chirmoqchimisiz?</h1>
						                <p>Ma’lumot o’chirilgandan so’ng qayta tiklab bo’lmaydi!</p>
						            </div>
						            <div class="delete-buttons">
						                <button type="button" class="delete-bekor">Bekor qilish</button>
				                            {{ csrf_field() }}  
				                            {{ method_field('delete') }}
						                	<button type="submit" class="delete-submit">Tasdiqlash</button>
									        

						            </div>
						        </form>
						    </div>
<div class="m-m-qush">
                            <div class="m-m-qush-close"></div>
                            <form  method="post" action="{{ route('topics.store') }}" class="m-m-qush-form">
                                 {{ csrf_field() }}
                                 {{ method_field('post') }}
                                <div class="m-m-qush-sarlavha">
                                    <h1 id="sarlavha_modal">Yangi mavzu qo’shish</h1>
                                    <button type="button" class="m-m-qush-close-button"><img src="{{ asset('admin/style/images/icons/closex.svg') }}" alt="AAA"></button>
                                </div>
                                <div class="m-m-qush-text">
                                    <p class="m-m-sarlavha-p">Joriy fan nomi</p>
                                    <div class="m-m-qush-down joriy-fan">
                                        <p class="joriy-fan-nomi">{{ $data->name_uz }}</p>
                                        <img src="{{ asset('admin/style/images/icons/dropdown.svg') }}" alt="AAA">
                                        <input type="text" name="lesson_id" value="{{ $data->id }}" class="j_fan_id"  style="display: none;">
                                    </div>
                                    <div class="m-m-qush-down-items joriy-fan-items">
                                        <div>
                                          {{--   @foreach($lessons as $lesson)
                                           
                                            <button type="button" onclick="but_j_fan({{ $lesson->id }})" id="{{ $lesson->id }}">{{ $lesson->name_uz }}</button>
                                            
                                            @endforeach --}}
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="m-m-qush-text">
                                    <p class="m-m-sarlavha-p">Mavzuning nomlanishi - O’zbek tilida</p>
                                    <input name="name_uz" class="mavzu-nomi-uz"  type="text" placeholder="Mavzu nomini kiriting">
                                    <span>To'ldirish shart</span>
                                </div>
                                <div class="m-m-qush-text">
                                    <p class="m-m-sarlavha-p">Mavzuning nomlanishi - Rus tilida</p>
                                    <input type="text" class="mavzu-nomi-ru" name="name_ru" placeholder="Дорожные знаки">
                                    <span>To'ldirish shart</span>
                                </div>
                                <div class="m-m-qush-text">
                                    <p class="m-m-sarlavha-p">Tanlangan mavzudan keyinga joylashadi</p>
                                    <div class="m-m-qush-down shundan-keyin">
                                        <p class="shundan-keyin-text">Eng boshida</p>
                                        <img src="{{ asset('admin/style/images/icons/dropdown.svg') }}" alt="AAA">
                                        <input type="text" name="t_order" id="l_order_f" value="0"  style="display: none;">
                                    </div>
                                    <div class="m-m-qush-down-items shundan-keyin-items">
                                        <div class="mavzudan_keyin">
                                        </div>
                                    </div>
                                </div>
                                <div class="m-m-qush-choose">
                                    <div class="m-m-choose-items">
                                        <div><p class="m-m-sarlavha-p">Mashg’ulot turi</p></div>
                                        <div class="m-m-choose-item">
                                            <div class="mr-2 st-ch" >
                                                <div class="radio-m">
                                                    <input id="nazariy-mavzu" type="radio" value="1" name="type">
                                                    <label for="nazariy-mavzu"></label>
                                                </div>
                                                <p>Nazariy</p>
                                            </div>
                                            <div class="st-ch">
                                                <div class="radio-m">
                                                    <input id="amaliy-mavzu" type="radio" value="2" name="type">
                                                    <label for="amaliy-mavzu"></label>
                                                </div>
                                                <p>Amaliy</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="m-m-choose-items">
                                        <div><p class="m-m-sarlavha-p">Soatlar soni (butun son)</p></div>
                                        <div class="m-m-choose-item">
                                            <div class="st-ch"><input name="hours" class="soatlar-soni" type="text"></div>
                                        </div>
                                    </div>
                                    <div class="m-m-choose-items">
                                        <div><p class="m-m-sarlavha-p">Status</p></div>
                                        <div class="m-m-choose-item">
                                            <div class="Status-down st-ch"> 
                                                <button type="button"><p class="status-text">Aktive</p><img src="{{ asset('admin/style/images/icons/dropdown.svg') }}" alt="AAA"></button>
                                                <input type="text" name="status" value="1" style="display: none;">
                                            </div>
                                            <div class="status-down-items">
                                                <div class="status-down-item-button">
                                                    <button id="1" type="button"><p>Active 1</p></button>
                                                    <button id="2" type="button"><p>Passiv</p></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="submit-mavzu-add">
                                    <button type="button" class="bekor-mavzu-add-button"><p class="m-m-sarlavha-p">Bekor qilish</p></button>
                                    <button type="button" name="submit-add-mavzu" class="submit-mavzu-add-button"><p id="saqlash_but" class="m-m-sarlavha-p">Qo’shish</p></button>
                                </div>
                            </form>
                        </div>

@endsection