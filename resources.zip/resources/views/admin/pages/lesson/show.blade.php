@extends('layouts.admin_alisher')
@section('content')
                <div class="title-link">
                    <div>
                        <h1>Toifalar</h1>
                        <p><span>Darsliklar</span>/Toifalar</p>                        
                    </div>
                    <div>
                        <a href="{{ url()->previous() }}">Ortga</a>
                    </div>
                </div>
                <div class="table-toifa-CE">
                    <div class="h1-button">
                        <h1>Mavzular ro’yxati</h1>
                        <button class="add-fan">
                            <p>Fan Qo'shish</p>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7 1.16667V12.8333" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M1.16602 7H12.8327" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>    
                        </button>
                    </div>
                    <ul class="down-menus">
                        <!-- down 1 -->
                                @foreach($lessons as $lesson)
                                <li class="down-menus-li">
                                    <div class="ce-dropdown">
                                        <!-- drop down -->
                                        <div class="down-menu">
                                            <div class="menu-button">
                                                <button class="menu-text">
                                                    <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 1L6 6L11 1"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </svg>
                                                    <p>{{ $lesson->name_uz }}</p>
                                                    <p><span>+3</span></p>
                                                </button>
                                                <div class="hover-button-items">
                                                    <ul>
                                                        <li>
                                                            <button class="change_mavzu_b" onclick="getlesson({{ $lesson->id }})" data-url="{{ route('lesson.update' , ['id' => $lesson->id]) }}" id="but{{ $lesson->id }}">
                                                                <img width="14px" src="{{ asset('admin/style/images/icons/uzgartir.svg') }}" alt="AAA">
                                                                <p>O’zgartirish</p>
                                                            </button>
                                                        </li>
                                                        
                                                        <li>
                                                            <a  class="mavzuga-m-add" onclick="add_topic({{ $lesson->id }})">
                                                                <img width="14px" src="{{ asset('admin/style/images/icons/faylqosh.svg') }}" alt="AAA">
                                                                <p>Mavzu qo’shish</p>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="{{ route('view',['id'=>$lesson->id]) }}"><img width="14px" src="{{ asset('admin/style/images/icons/batafsil.svg') }}" alt="AAA">
                                                                <p>Batafsil</p>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <button class="hover-button">
                                                    <svg width="18" height="4" viewBox="0 0 18 4" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M10 2C10 1.44772 9.55228 1 9 1C8.44772 1 8 1.44772 8 2C8 2.55228 8.44772 3 9 3C9.55228 3 10 2.55228 10 2Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                        <path d="M3 2C3 1.44772 2.55228 1 2 1C1.44772 1 1 1.44772 1 2C1 2.55228 1.44772 3 2 3C2.55228 3 3 2.55228 3 2Z"  stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                        <path d="M17 2C17 1.44772 16.5523 1 16 1C15.4477 1 15 1.44772 15 2C15 2.55228 15.4477 3 16 3C16.5523 3 17 2.55228 17 2Z"  stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </svg>    
                                                </button>
                                                </div>
                                        </div>
                                            <!-- ddd- items -->
                                            <div class="down-items">
                                                <!-- dd item -->
                                                @foreach($lesson->topics as $topic)
                                                <div class="down-item">
                                                    <div class="down-item-text">
                                                        <p>{{ $topic->name_uz }}</p>
                                                        <p><span>+{{ $topic->hours }}</span></p>
                                                        <p><span>{{ $topic->getType() }}</span></p>
                                                    </div>
                                                    <div>
                                                        <button class="down-item-button">
                                                            <svg width="18" height="4" viewBox="0 0 18 4" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M10 2C10 1.44772 9.55228 1 9 1C8.44772 1 8 1.44772 8 2C8 2.55228 8.44772 3 9 3C9.55228 3 10 2.55228 10 2Z"  stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                                <path d="M3 2C3 1.44772 2.55228 1 2 1C1.44772 1 1 1.44772 1 2C1 2.55228 1.44772 3 2 3C2.55228 3 3 2.55228 3 2Z"  stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                                <path d="M17 2C17 1.44772 16.5523 1 16 1C15.4477 1 15 1.44772 15 2C15 2.55228 15.4477 3 16 3C16.5523 3 17 2.55228 17 2Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                            </svg>    
                                                        </button>
                                                    </div>
                                                    @if(\Auth::user()->role == 7||\Auth::user()->role == 0)
                                                    <div class="down-item-hover">
                                                        <ul class="down-item-ul">
                                                            <li>
                                                                <a href="{{ route('addcontent',['id'=>$topic->id]) }}" >
                                                                    <img width="14px" src="{{ asset('admin/style/images/icons/faylqosh.svg') }}" alt="">
                                                                    <p>Mavzuga ma’lumot qo’shish</p>
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <button class="mavzuga-m-change" id="but_edit_topic{{ $topic->id }}" data-url="{{ route('topics.update' , ['id' => $topic->id]) }}" onclick="edit_topic({{ $topic->id }})" >
                                                                    <img width="14px" src="{{ asset('admin/style/images/icons/uzgartir.svg') }}" alt="">
                                                                    <p>O’zgartirish</p>
                                                                </button>
                                                            </li>
                                                            <li>
                                                                <a href="{{ route('topics.show',['id'=>$topic->id]) }}"  class="mavzuga-m-batafsil">
                                                                    <img width="14px" src="{{ asset('admin/style/images/icons/batafsil.svg') }}" alt="">
                                                                    <p>Batafsil</p>
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a href="{{ route('goup',['id'=>$topic->id]) }}" class="mavzuga-m-batafsil">
                                                                    <img width="14px" src="{{ asset('admin/style/images/icons/tepaga.svg') }}" alt="">
                                                                    <p>Tepaga ko’tarish</p>
                                                                </a>
                                                            </li>
                                                            <li><a href="{{ route('godown',['id'=>$topic->id]) }}" class="mavzuga-m-batafsil"><img width="14px" src="{{ asset('admin/style/images/icons/pastga.svg') }}" alt=""><p>Pastga tushirish</p></a></li>
                                                        </ul>
                                                    </div>
                                                    @endif
                                                </div>
                                                @endforeach
                                                
                                                <!-- end dd item -->
                                               
                                            </div>
                                            <!-- end dd items -->
                                    </div>
                                </li>
                                @endforeach

                     
                       
                        <!-- END drop down -->
                    </ul>
                        <!-- END drop down -->
                    </div>
                    <!-- end -->
                </div>

                <div class="add-element">
                            <!-- add mavzu or add fan -->
                            <form class="add-mavzu" action="{{ route('lesson.store') }}" method="post">
                                {{ csrf_field() }}
                                 <input type="hidden" value="{{ $course->id }}" name="edu_type">

                                <div>
                                    <h1>Yangi fan qo’shish</h1>
                                    <button class="close-mavzu" type="button"><img src="{{ asset('admin/style/images/icons/closex.svg') }}" alt="AA"></button>
                                </div>
                                <div>
                                    <p>Darslikning nomlanishi - O’zbek tilida</p>
                                    <input class="fan-nomi-uz" name="name_uz" type="text">
                                </div>
                                <div>
                                    <p>Darslikning nomlanishi - Rus tilida</p>
                                    <input class="fan-nomi-ru"  name="name_ru"  type="text">
                                </div>
                                <div class="f-item">
                                    <p>Tanlangan fandan keyinga joylashadi</p>
                                    <select class="form-control" name="l_order" style="padding-bottom: 5px; border-radius: 10px;">
                                        <option value="0"  selected>Eng boshida</option>
                                        @foreach($lessons as $lesson)
                                            <option  value="{{ $lesson->l_order }}">{{ $lesson->name_uz }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="submit-file">
                                    <button class="bekor-mavzu"  type="button" class="close-fayl"><p>Bekor qilish</p></button>
                                    <button name="fan-qoshildi" type="button" class="yuklash-file"><p>Qo’shish</p></button>
                                </div>
                            </form>
                            <div class="close-file-add-mavzu"></div>
                 </div>
                        <!-- ChanGE MAVZU  or fan-->
                        <div class="change-mavzu">
                            <form class="change-form"  method="POST">
                                {{ csrf_field() }}
                                {{ method_field('put') }}
                                <div class="change-text">
                                    <h1>Fanni o’zgartirish</h1>
                                    <button class="change-mavzu-close" type="button"><img src="{{ asset('admin/style/images/icons/closex.svg') }}" alt="AAA"></button>
                                </div>
                                <div class="change-item">
                                    <p>Darslikning nomlanishi - O’zbek tilida</p>
                                    <input type="text" class="name_uz_change" placeholder="Darslik nomini kiriting" name="name_uz" >
                                </div>
                                <div class="change-item">
                                    <p>Darslikning nomlanishi - Rus tilida</p>
                                    <input type="text" class="name_ru_change" placeholder="Дорожные знаки" name="name_ru">
                                </div>
                                <div class="submit-changes">
                                    <button class="change-mavzu-bekor" type="button"><p>Bekor qilish</p></button>
                                    <button class="submit_mavzu_b" type="button"><p>Saqlash</p></button>
                                </div>

                            </form>
                            <div class="change-close-div"></div>
                        </div>
                        <!-- END CHANGE MAVZU -->
                        <!-- Mavzuga ma'luumot qo'shish -->
                        
                        
                        <div class="m-m-qush">
                            <div class="m-m-qush-close"></div>
                            <form  method="post" action="{{ route('topics.store') }}" class="m-m-qush-form">
                                 {{ csrf_field() }}
                                 {{ method_field('post') }}
                                <div class="m-m-qush-sarlavha">
                                    <h1 id="sarlavha_modal">Yangi mavzu qo’shish</h1>
                                    <button type="button" class="m-m-qush-close-button"><img src="{{ asset('admin/style/images/icons/closex.svg') }}" alt="AAA"></button>
                                </div>
                                <div class="m-m-qush-text">
                                    <p class="m-m-sarlavha-p">Joriy fan nomi</p>
                                    <div class="m-m-qush-down joriy-fan">
                                        <p class="joriy-fan-nomi"></p>
                                        <img src="{{ asset('admin/style/images/icons/dropdown.svg') }}" alt="AAA">
                                        <input type="text" name="lesson_id" class="j_fan_id"  style="display: none;">
                                    </div>
                                    <div class="m-m-qush-down-items joriy-fan-items">
                                        <div>
                                            @foreach($lessons as $lesson)
                                           
                                            <button type="button" onclick="but_j_fan({{ $lesson->id }})" id="{{ $lesson->id }}">{{ $lesson->name_uz }}</button>
                                            
                                            @endforeach
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="m-m-qush-text">
                                    <p class="m-m-sarlavha-p">Mavzuning nomlanishi - O’zbek tilida</p>
                                    <input name="name_uz" class="mavzu-nomi-uz"  type="text" placeholder="Mavzu nomini kiriting">
                                    <span>To'ldirish shart</span>
                                </div>
                                <div class="m-m-qush-text">
                                    <p class="m-m-sarlavha-p">Mavzuning nomlanishi - Rus tilida</p>
                                    <input type="text" class="mavzu-nomi-ru" name="name_ru" placeholder="Дорожные знаки">
                                    <span>To'ldirish shart</span>
                                </div>
                                <div class="m-m-qush-text">
                                    <p class="m-m-sarlavha-p">Tanlangan mavzudan keyinga joylashadi</p>
                                    <div class="m-m-qush-down shundan-keyin">
                                        <p class="shundan-keyin-text">Eng boshida</p>
                                        <img src="{{ asset('admin/style/images/icons/dropdown.svg') }}" alt="AAA">
                                        <input type="text" name="t_order" id="l_order_f" value="0"  style="display: none;">
                                    </div>
                                    <div class="m-m-qush-down-items shundan-keyin-items">
                                        <div class="mavzudan_keyin">
                                        </div>
                                    </div>
                                </div>
                                <div class="m-m-qush-choose">
                                    <div class="m-m-choose-items">
                                        <div><p class="m-m-sarlavha-p">Mashg’ulot turi</p></div>
                                        <div class="m-m-choose-item">
                                            <div class="mr-2 st-ch" >
                                                <div class="radio-m">
                                                    <input id="nazariy-mavzu" type="radio" value="1" name="type">
                                                    <label for="nazariy-mavzu"></label>
                                                </div>
                                                <p>Nazariy</p>
                                            </div>
                                            <div class="st-ch">
                                                <div class="radio-m">
                                                    <input id="amaliy-mavzu" type="radio" value="2" name="type">
                                                    <label for="amaliy-mavzu"></label>
                                                </div>
                                                <p>Amaliy</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="m-m-choose-items">
                                        <div><p class="m-m-sarlavha-p">Soatlar soni (butun son)</p></div>
                                        <div class="m-m-choose-item">
                                            <div class="st-ch"><input name="hours" class="soatlar-soni" type="text"></div>
                                        </div>
                                    </div>
                                    <div class="m-m-choose-items">
                                        <div><p class="m-m-sarlavha-p">Status</p></div>
                                        <div class="m-m-choose-item">
                                            <div class="Status-down st-ch"> 
                                                <button type="button"><p class="status-text">Aktive</p><img src="{{ asset('admin/style/images/icons/dropdown.svg') }}" alt="AAA"></button>
                                                <input type="text" name="status" value="1" style="display: none;">
                                            </div>
                                            <div class="status-down-items">
                                                <div class="status-down-item-button">
                                                    <button id="1" type="button"><p>Active 1</p></button>
                                                    <button id="2" type="button"><p>Passiv</p></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="submit-mavzu-add">
                                    <button type="button" class="bekor-mavzu-add-button"><p class="m-m-sarlavha-p">Bekor qilish</p></button>
                                    <button type="button" name="submit-add-mavzu" class="submit-mavzu-add-button"><p id="saqlash_but" class="m-m-sarlavha-p">Qo’shish</p></button>
                                </div>
                            </form>
                        </div>

            @endsection


            @section('js')
            <script type="text/javascript">
                    function edit_topic(id){
                        var topic_id = id;
                        $.ajax({
                            url: '/backoffice/get_topic_for_edit/'+topic_id,
                            type: 'GET',
                            data: {},
                            success:function(result){
                                var topic = JSON.parse(result);
                                $('input[name="_method"]').val("put");
                                var action = $('#but_edit_topic'+id+'').attr('data-url');
                                $('.m-m-qush-form').attr('action' , action);
                                $('.mavzu-nomi-uz').val(topic.name_uz);
                                $('.mavzu-nomi-ru').val(topic.name_ru);
                                $('#l_order_f').val(topic.tp_order);
                                $('.soatlar-soni').val(topic.hours);
                                $('#sarlavha_modal').html("Mavzuni o`zgartirish");
                                $('#saqlash_but').html("Saqlash");
                                if (topic.type == 1) {
                                    $('#amaliy-mavzu').removeAttr('checked');
                                    $('#nazariy-mavzu').attr('checked' , '');
                                }
                                else{
                                    $('#nazariy-mavzu').removeAttr('checked');
                                    $('#amaliy-mavzu').attr('checked' , '');

                                }
                                console.log(topic);

                                $('#'+topic.lesson_id+'').click();
                            }
                        });
                        
                    }
            </script>
                                                        <script type="text/javascript">
                                                            function getlesson(id){
                                                                console.log(id);
                                                                var _token = $('input[name="_token"]').val();
                                                                var lesson_id = id;
                                                                var url = '/backoffice/get_lesson_for_edit/'+lesson_id;
                                                                $.ajax({
                                                                    url: url,
                                                                    type: 'GET',
                                                                    data: {_token: 'value1'},
                                                                    success: function (result){
                                                                        var lesson = JSON.parse(result);
                                                                        $('.change-mavzu .name_uz_change').val(lesson.name_uz);
                                                                        $('.change-mavzu .name_ru_change').val(lesson.name_ru);
                                                                        var url2 = $('#but'+lesson.id+'').attr('data-url');

                                                                        $('.change-mavzu .change-form').attr('action' , url2);                                                                    }
                                                                });
                                                                
                                                                
                                                            }
                                                        </script>
                                                        <script type="text/javascript">


                                                            function add_topic(id){
                                                                var lesson_id = id;
                                                                $.ajax({
                                                                    url: '/backoffice/get_topic_for_add/'+lesson_id,
                                                                    type: 'GET',
                                                                    data: {},
                                                                    success:function(result){
                                                                        var topics  = JSON.parse(result);
                                                                        var html = '<button type="button" onclick="l_order(0)">Eng boshida</button>';
                                                                         $.each(topics, function(key, value) {
                                                                            html = html + '<button type="button" onclick="l_order('+value['tp_order']+')">'+value['name_uz']+'</button>';
                                                                        });
                                                                         $('#sarlavha_modal').html("Yangi mavzu qo’shish");
                                                                            $('#saqlash_but').html("Qo’shish");
                                                                         $('.mavzudan_keyin').html(html);
                                                                    }
                                                                });
                                                                
                                                                
                                                                $('#'+id+'').click();  
                                                                
                                                            }


                                                            function but_j_fan(id){
                                                                $('.j_fan_id').val(id);
                                                            }
                                                            function l_order(id_o){
                                                                $('#l_order_f').val(id_o);

                                                            }
                                                        </script>
                                                        
            @endsection