@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Menyular ro'yxati</h3>
                        <a href="{{route('menu.create')}}" class="btn btn-success pull-right"><i class="icon-plus-circle">&nbsp;</i>Yangi qo'shish</a>
                    </div>
                    <div class="panel-body">
                        @if(session('message'))
                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-checkmark-circle"></span>
                                </div>
                                {{ session('message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        @endif
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th style="width: 2%">#</th>
                                <th>Nomi (UZ)</th>
                                <th>Nomi (RU)</th>
                                <th>Turi</th>
                                <th>Parent</th>
                                <th colspan="3" width="5%"></th>
                            </tr>
                            </thead>
                            <tbody>

                            @php $count = $data->perPage() * ($data->currentPage() - 1) @endphp
                            @foreach($data as $univer)
                                <tr>
                                    <td>{{ ++$count }}</td>
                                    <td>{{ $univer->name_uz }}</td>
                                    <td>{{ $univer->name_ru }}</td>
                                    <td>{{ $univer->getType() }}</td>
                                    <td>{{ $univer->getParent() }}</td>

                                    <td>
                                        <a href="{{ route('menu.show', ['id' => $univer->id]) }}" class="btn btn-default btn-icon">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <a href="{{ route('menu.edit', ['id' => $univer->id]) }}" class="btn btn-default btn-icon">
                                            <i class="icon-pencil"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <form action="{{ route('menu.destroy', ['id' => $univer->id]) }}" method="post">
                                            {{ csrf_field() }}
                                            {{ method_field('delete') }}
                                            <button class="btn btn-default btn-icon deleteData"><i class="icon-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {!! $data->links() !!}

                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection