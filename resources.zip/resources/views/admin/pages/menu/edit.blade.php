@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <form action="{{ route('menu.update',['id'=>$data->id]) }}" method="post">
                {{ csrf_field() }}
                {{ method_field('put') }}

                <div class="col-md-6">
                    <div class="block">
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-success btn-block">O'zgarishlarni saqlash</button>
                        </div>
                        <div class="col-md-6">
                            <a href="{{ url()->previous() }}" class="btn btn-default btn-block">Bekor qilish</a>
                        </div>


                        <label for="parent_id" class="margin-top-20 control-label">
                            Bosh Menyular
                            @if($errors->has('parent_id'))
                                <span class="text-danger"> | {{ $errors->first('parent_id') }}</span>
                            @endif
                        </label>
                        <select name="parent_id" id="parent_id" class="form-control" required>
                            <option value="0"></option>
                            @foreach($parents as $parent)
                                <option @if($parent->id == $data->parent_id) selected @endif value="{{ $parent->id }}">{{ $parent->name_uz }}</option>
                            @endforeach
                        </select>

                        <label for="menu_order" class="margin-top-20">Tartib raqami</label>
                        <input type="tel" name="menu_order" id="menu_order" value="{{$data->menu_order}}" class="form-control">

                        <label for="status" class="margin-top-20">
                            Status
                            @if($errors->has('dormitory'))
                                <span class="text-danger"> | {{ $errors->first('status') }}</span>
                            @endif
                        </label>
                        <br>
                        <div class="app-radio success inline">
                            <label><input type="radio" name="status" value="1" @if($data->status == 1) checked @endif> Aktiv<span></span></label>
                        </div>
                        <div class="app-radio warning inline">
                            <label><input type="radio" name="status" value="0" @if($data->status == 0) checked @endif> Passiv<span></span></label>
                        </div>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="app-content-tabs">
                        <ul>
                            <li><a href="#uz" class="active"><span class="fa fa-globe"></span>O'zbek tili</a></li>
                            <li><a href="#ru"><span class="fa fa-globe"></span> Rus tili</a></li>
                        </ul>
                    </div>

                    <div class="container app-content-tab active" id="uz">
                        <div class="block">
                            <label for="name_uz">Menyuni nomlanishi
                                @if($errors->has('name_uz'))
                                    <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_uz" id="name_uz" value="{{ $data->name_uz }}" class="form-control" required>
                        </div>
                    </div>

                    <div class="container app-content-tab" id="ru">
                        <div class="block">
                            <label for="name_ru">Название меню
                                @if($errors->has('name_ru'))
                                    <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_ru" id="name_ru" class="form-control" value="{{ $data->name_ru }}" required>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="app-heading app-heading-small app-heading-condensed">
                        <div class="title" style="padding:5px">
                            <h2>Administrator uchun eslatma!</h2>
                            <p>Yaratilayotgan menyuni faollashtirish uchun unga tog'ridan to'gri link bering yoki sahifa bilan biriktiring. Bir vaqtda ham link ham sahifa bilan biriktirmang.</p>
                        </div>
                    </div>
                    <div class="app-content-tabs">
                        <ul>
                            <li><a href="#link" class="active"><span class="fa fa-search"></span>Link&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
                            <li><a href="#page"><span class="fa fa-paperclip"></span> Sahifa</a></li>
                        </ul>
                    </div>

                    <div class="container app-content-tab active" id="link">
                        <div class="block">
                            <label for="name_uz">Direct Link
                                @if($errors->has('link'))
                                    <span class="text-danger"> | {{ $errors->first('link') }}</span>
                                @endif
                            </label>
                            <input type="text" name="link" id="link" class="form-control" value="{{$data->link}}" required>
                        </div>
                    </div>

                    <div class="container app-content-tab" id="page">
                        <div class="block">
                            <label for="name_ru">Sahifani ko'rsating
                                @if($errors->has('page_id'))
                                    <span class="text-danger"> | {{ $errors->first('page_id') }}</span>
                                @endif
                            </label>
                            <input type="text" name="page_id" id="page_id" class="form-control" value="{{$data->page_id}}" required>
                        </div>
                    </div>
                </div>

            </form>
        </div>
    </div>
@endsection