@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="row">
            <form action="{{ route('menu.store') }}" method="post">
                {{ csrf_field() }}

                <div class="col-md-6">
                    <div class="block">
                        <button class="btn btn-success btn-block" type="submit">Saqlash</button>

                        <label for="menu_order" class="margin-top-20">Tartib raqami</label>
                        <input type="tel" name="menu_order" id="menu_order" value="{{ old('menu_order') }}" class="form-control">

                        <label for="status" class="margin-top-20">
                                Status
                            @if($errors->has('dormitory'))
                                <span class="text-danger"> | {{ $errors->first('status') }}</span>
                            @endif
                        </label>
                        <br>
                        <div class="app-radio success inline">
                            <label><input type="radio" name="status" value="1" checked=""> Aktiv<span></span></label>
                        </div>
                        <div class="app-radio warning inline">
                            <label><input type="radio" name="status" value="0"> Passiv<span></span></label>
                        </div>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="app-content-tabs">
                        <ul>
                            <li><a href="#uz" class="active"><span class="fa fa-globe"></span>O'zbek tili</a></li>
                            <li><a href="#ru"><span class="fa fa-globe"></span> Rus tili</a></li>
                        </ul>
                    </div>

                    <div class="container app-content-tab active" id="uz">
                        <div class="block">
                            <label for="name_uz">Menyuni nomlanishi
                                @if($errors->has('name_uz'))
                                    <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_uz" id="name_uz" class="form-control" required>
                        </div>
                    </div>

                    <div class="container app-content-tab" id="ru">
                        <div class="block">
                            <label for="name_ru">Название меню
                                @if($errors->has('name_ru'))
                                    <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_ru" id="name_ru" class="form-control" required>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="app-content-tabs">
                        <ul>
                            <li><a href="#link" class="active"><span class="fa fa-search"></span>Link&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
                            <li><a href="#page"><span class="fa fa-paperclip"></span> Sahifa</a></li>
                        </ul>
                    </div>

                    <div class="container app-content-tab active" id="link">
                        <div class="block">
                            <label for="name_uz">Direct Link
                                @if($errors->has('link'))
                                    <span class="text-danger"> | {{ $errors->first('link') }}</span>
                                @endif
                            </label>
                            <input type="text" name="link" id="link" class="form-control" required>
                        </div>
                    </div>

                    <div class="container app-content-tab" id="page">
                        <div class="block">
                            <label for="name_ru">Sahifani ko'rsating
                                @if($errors->has('page_id'))
                                    <span class="text-danger"> | {{ $errors->first('page_id') }}</span>
                                @endif
                            </label>
                            <input type="text" name="page_id" id="page_id" class="form-control" required>
                        </div>
                    </div>
                </div>

            </form>
        </div>
    </div>
@endsection