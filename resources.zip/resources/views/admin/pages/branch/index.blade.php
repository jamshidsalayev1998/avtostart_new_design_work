@extends('layouts.admin_alisher')
@section('content')
    <div class="title-link">
                    <div>
                        <h1>@if(isset($region)){{ $region }}@endif barcha avtomobil o`qitishga mo`ljallangan maktablari</h1>
                        <p><span>Bosh sahifa /</span> Filiallar</p>
                    </div>
                    
                </div>
                <div class="table-toifa-CE">
                    <div class="h1-button">
                        <h1>Mavzular ro’yxati</h1>
                        <button data-href="{{route('branch.create')}}" class="add-fan add-branch">
                            <p>Filial Qo'shish</p>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7 1.16667V12.8333" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M1.16602 7H12.8327" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>    
                        </button>
                    </div>
                    <div class="table-content">

                    <table class="">
                        <thead>
                        <tr>
                            {{-- <th><p>#</p></th> --}}
                            <th><p>Filial nomi </p></th>
                            <th><p>Tuman </p></th>
                            <th><p>Telefon </p></th>
                            <th><p>Reestr raqami </p></th>
                            <th><p>Litsenziya raqami </p></th>
                            <th ><p>Litseniya sanasi </p></th>
                            <th><p>Ta`lim turlari </p></th>
                            <th><p></p></th>
                            <th><p></p></th>
                            <th><p></p></th>
                        </tr>
                        </thead>
                        <tbody>
                            @php $i = 1; @endphp
                        @foreach($data as $item)
                            <tr>
                                {{-- <td><p>{{ $i }} @php $i++; @endphp</p></td> --}}
                                <td><p>{{$item->name_uz}} </p></td>
                                <td><p>{{$item->area->name}} </p></td>
                                <td><p>{{$item->phone}}</td>
                                <td><p>{{$item->reestr_number}} </p></td>
                                <td><p>{{$item->license_number}} </p></td>
                                <td><p>{{$item->license_date}} </p></td>
                                <td><p>
                                    <?php
                                        $t = 0;
                                        $edutypes = explode("," , $item->edutype_id);
                                        for ($i = 0; $i < count($edutypes) ; $i++){
                                            foreach ($edutype as $etype){
                                                if ($etype->id == $edutypes[$i]){
                                                    if ($etype->status == 1){
                                                        echo $etype->name;
                                                        echo '<br>';
                                                    }
                                                }
                                            }
                                        }
                                    ?> </p>

                                </td>
                                
                                <td><p>
                                    <a href="{{ route('branch.show', ['id' => $item->id]) }}" class="btn btn-default btn-icon">
                                        <i class="fa fa-eye"></i>
                                    </a> </p>
                                </td>
                                <td><p>
                                    <a href="{{ route('branch.edit', ['id' => $item->id]) }}" class="btn btn-default btn-icon">
                                        <i class="fa fa-edit"></i>
                                    </a> </p>
                                </td>
                                <td><p>
                                    <form action="{{ route('branch.destroy', ['id' => $item->id]) }}" method="post">
                                        {{ csrf_field() }}
                                        {{ method_field('delete') }}
                                        <button class="btn btn-default btn-icon deleteData"><i class="fa fa-trash"></i></button>
                                    </form> </p>
                                </td>
                            </tr>
                            
                        @endforeach
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>
@endsection

@section('js')
<script type="text/javascript">
    $('.add-branch').click(function(){
        location.href = $(this).attr('data-href');
    });
</script>
@endsection