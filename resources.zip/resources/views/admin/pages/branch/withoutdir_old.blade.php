@extends('layouts.admin')
@section('content')
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="col-md-12">
                        <div class="col-md-6">
                            <h3 style="float: left">@if(isset($region)) {{$region}} @endif Rahbar tayinlanmagan filiallar ro`yxati</h3>
                        </div>
                        <div class="col-lg-6">
                           
                        </div>
                    </div>

                    @if(session('message'))
                        <div class="col-md-10">
                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-checkmark-circle"></span>
                                </div>
                                {{ session('message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
            <div class="block block-condensed">
                <br>
                <div class="block-content">

                    <table class="table table-striped table-bordered datatable-extended">
                        <thead>
                        <tr>
                            <th>Filial nomi</th>
                            <th>Tumani</th>
                            <th>Telefon</th>
                            <th>Reestr raqami</th>
                            <th>Litsenziya</th>
                            <th >Litsenziya date</th>
                            <th>Edutype</th>
                            <th>Direktor tayinlash</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $item)
                            <tr>
                                <td>{{$item->name_uz}}</td>
                                <td>{{$item->area->name}}</td>
                                <td>{{$item->phone}}</td>
                                <td>{{$item->reestr_number}}</td>
                                <td>{{$item->license_number}}</td>
                                <td>{{$item->license_date}}</td>
                                <td>
                                    <?php
                                    $t = 0;
                                    $edutypes = explode("," , $item->edutype_id);
                                    for ($i = 0; $i < count($edutypes) ; $i++){
                                        foreach ($edutype as $etype){
                                            if ($etype->id == $edutypes[$i]){
                                                if ($etype->status == 1){
                                                    echo $etype->name;
                                                    echo '<br>';
                                                }
                                            }
                                        }
                                    }
                                    ?>

                                </td>

                                <td>
                                    <a href="{{ route('director' , ['id' => $item->id]) }}" class="btn btn-default btn-icon">
                                        <i class="fa fa-user-plus"></i>
                                    </a>
                                </td>
                               
                            </tr>

                        @endforeach
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>
@endsection