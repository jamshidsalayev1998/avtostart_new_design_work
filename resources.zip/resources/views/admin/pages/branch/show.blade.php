@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('branch.index') }}">Filiallar</a></li>
            <li class="active">Filialni ko'rish  > {{$data->name_uz}}</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <!-- SEARCH FORM -->
        <div class="block padding-top-20">
            <div class="row">
                <div class="col-md-9">
                    <div class="form-group">
                        <div class="input-group">
                            <a class="btn btn-default btn-icon">
                                <i class="fa fa-search"></i>
                            </a>&nbsp;&nbsp;&nbsp;<span style="font-size: 18px;">{{$data->name_uz}}</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 text-right">
                    <div class='pull-right'>
                        <a href="{{route('branch.index')}}" class="btn btn-default btn-icon-fixed "><span class="icon-list"></span> Ro'yxat</a>
                    </div>
                    <div class="dropdown pull-right margin-right-10">
                        <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>
                        <ul class="dropdown-menu dropdown-left">
                            @if(\Auth::user()->role == 7)
                                <li>
                                    <form action="{{ route('branch.destroy', ['id' => $data->id]) }}" method="post">
                                        {{ csrf_field() }}
                                        {{ method_field('delete') }}
                                        <button class="btn form-control btn-icon-fixed deleteData text-danger"><span class="icon-trash text-danger"></span><p style="margin-left: -35px;margin-top: 0px;">Filialni O'chirish</p></button>
                                    </form>
                                 </li>
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- END SEARCH FORM -->
    </div>
    <div class="app-content-tabs">
        <ul>
            <li><a href="#tab-1" class="active"><span class="icon-map-marker"></span>Filial haqida</a></li>
            <li><a href="#tab-2"><span class="icon-car"></span> Filialdagi guruhlar</a></li>
            <li><a href="#tab-3"><span class="icon-briefcase"></span> Filial xodimlari</a></li>
            <li><a href="#tab-4"><span class="icon-plus-circle"></span> Qo'shimcha</a></li>
        </ul>
    </div>
    <!-- END CONTENT TABS -->
      <div class="container app-content-tab active" id="tab-1">

            <!-- BLOCK -->
            <div class="block">
                <!-- START HEADING -->
                <div class="app-heading app-heading-small">
                    <div class="icon">
                        <span class="icon-cube"></span>
                    </div>
                    <div class="title" style="width:100%;">
                        <div class="col-md-2">
                          <h2>Filial haqida</h2>
                        </div>
                        @if(session('message'))
                            <div class="col-md-10">
                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
                <!-- END START HEADING -->

                <div class="row">
                    <div class="container">

                        <div class="invoice">
                            <div class="invoice-container">
                                <div class="row">
                                    <div class="col-lg-8 col-lg-offset-2">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="invoice-company">
                                                    <h2>{{ $data->name_uz }}</h2>
                                                    <p style="margin: 0">Filial nomi</p>
                                                    <p style="margin: 0"><span class="fa fa-calendar">&nbsp;</span>{{ date('Y-m-d H:i',strtotime($data->created_at)) }}</p>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="invoice-number text-right">
                                                    <h3></h3>
                                                    <p style="margin: 0"><span class="fa fa-phone">&nbsp;</span>+998 {{ $data->phone }}</p>
                                                    <p style="margin: 0"><span class="fa fa-map-marker">&nbsp;</span>{{ $data->address }}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="invoice-container">
                                <div class="row">
                                    <div class="col-lg-8 col-lg-offset-2">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="invoice-company">
                                                    <p>
                                                        Ta`lim turi:
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="invoice-number text-right">
                                                    <?php
                                                    $t = 0;
                                                    $edutypes = explode("," , $data->edutype_id);
                                                    for ($i = 0; $i < count($edutypes) ; $i++){
                                                        foreach ($edutype as $etype){
                                                            if ($etype->id == $edutypes[$i]){
                                                                echo '<p>';
                                                                echo $etype->name;
                                                                echo '</p>';
                                                                
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="invoice-container invoice-container-highlight">
                                <div class="row">
                                    <div class="col-lg-8 col-lg-offset-2">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="invoice-address">
                                                    <h5>Filial rahbari:</h5>
                                                    <p>
{{--                                                        {{ $data->getManager()->full_name }}<br>--}}
{{--                                                        <span class="fa fa-phone"></span>+998 {{ $data->getManager()->phone }}<br>--}}
                                                        <form method="post" action="{{ route('support.index') }}">
                                                            {{ csrf_field() }}
{{--                                                            <input type="hidden" value="{{ $data->getManager()->user_id }}" name="receiver_id">--}}
                                                            <button type="submit" class="btn btn-default btn-sm"><span class="fa fa-envelope">&nbsp;</span>Xabar yozish</button><br>
                                                        </form>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="invoice-address text-right">
                                                    <h5>Rekvizitlar:</h5>
                                                    <p>
                                                        INN:&nbsp;<span>@if(isset($data->requisite->inn)) {{ $data->requisite->inn }} @endif</span><br>
                                                        OKONH:&nbsp;<span>@if(isset($data->requisite->okonh)){{ $data->requisite->okonh }}@endif</span><br>
                                                        Bank:&nbsp;<span>@if(isset($data->requisite->bank_info)){{ $data->requisite->bank_info }}@endif</span> <br>
                                                        BMM:&nbsp;<span>@if(isset($data->requisite->bmm)){{ $data->requisite->bmm }}@endif</span><br>
                                                        Telefon:&nbsp;@if(isset($data->requisite->phone)){{ $data->requisite->phone }}@endif
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="invoice-container">
                                <div class="row">
                                    <div class="col-lg-8 col-lg-offset-2">
                                        <p>Filialdagi ta'lim narxlari</p>
                                        <table class="table table-bordered">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Toifa</th>
                                                <th>Soatlar soni</th>
                                                <th width="150">To'lov miqdori</th>
                                            </tr>
                                            </thead>
                                            <tbody class="text-thin">
                                            @php $i=1; @endphp
                                            @foreach($data->getPrices() as $course)
                                                <tr>
                                                    <td width="40" class="text-center">{{ $i }}</td>
                                                    <td class="text-bold">{{ $course->getCourse() }}</td>
                                                    <td>{{ $course->getCourseHours($course->course_id) }}</td>
                                                    <td class="text-bold">{{ $course->price }}</td>
                                                </tr>
                                            @php $i++ @endphp
                                            @endforeach
                                            </tbody>
                                        </table>

                                        <div class="invoice-thanks">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <p>Filialni yaratatuvchi</p>
                                                </div>
                                                <div class="col-md-6 text-right">
                                                    <div class="title">{{ $data->getCreator() }}</div>
                                                    <p class="text-italic">Viloyat rahbari</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- END BLOCK -->

        </div>
        <!-- END CONTAINER -->

        <!-- START CONTAINER -->
        <div class="container app-content-tab" id="tab-2">

            <!-- BLOCK -->
            <div class="block">
                <!-- START HEADING -->
                <div class="app-heading app-heading-small">
                    <div class="title">
                        <h2>Filialdagi barcha guruhlar</h2>
                    </div>
                </div>
                <!-- END START HEADING -->

                <div class="row">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th style="width: 2%">#</th>
                            <th style="width: 10%;text-align: center">Holati</th>
                            <th style="text-align: center">Raqami</th>
                            <th style="text-align: center">Toifa</th>
                            <th style="text-align: center">Ta'limning boshlanish sanasi</th>
                            <th style="text-align: center">Ta'limning tugash sanasi</th>
                            <th style="width: 8%">Ko`rish</th>
                        </tr>
                        </thead>
                        <tbody>
                        @php $i=1; @endphp

                        @foreach($data->groups as $item)
                            <tr>
                                <td>{{ $i }}</td>
                                <td align="center"><span class="fa fa-circle @if($item->status == 2) @endif @if($item->status == 1) text-success @endif @if($item->status == 3) text-danger @endif text-lg"></span></td>
                                <td align="center">{{ $item->name_uz }}</td>
                                <td align="center">{{ $item->getCourse()->name }}</td>
                                <td align="center">{{ $item->edu_starting_date }}</td>
                                <td align="center">{{ $item->edu_ending_date }}</td>
                                <td>
                                    <a href="{{ route('group.show', ['id' => $item->id]) }}" class="btn btn-sm btn-default btn-icon">
                                        <span class="fa fa-eye"></span>
                                    </a>
                                </td>
                            </tr>
                             @php $i++ @endphp
                        @endforeach
                        </tbody>
                    </table>
                </div>

            </div>
            <!-- END BLOCK -->

        </div>
        <!-- END CONTAINER -->

        <!-- START CONTAINER -->
        <div class="container app-content-tab" id="tab-3">

            <!-- BLOCK -->
            <div class="block">
                <!-- START HEADING -->
                <div class="app-heading app-heading-small">
                    <div class="icon">
                        <span class="icon-cloud-rain"></span>
                    </div>
                    <div class="title">
                        <h2>Filial xodimlari</h2>
                    </div>
                </div>
                <!-- END START HEADING -->

                <div class="row">
                    <div class="block block-condensed padding-top-20">
                        <div class="block-content">
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>O'qituvchilar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($data->teachers as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="{{ route('teacher.show',['id'=>$teacher->id]) }}">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>Moderatorlar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($data->moderators as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="{{ route('moderator.show',['id'=>$teacher->id]) }}">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="app-heading app-heading-small heading-transparent">
                                    <div class="title">
                                        <p>Hisobchilar</p>
                                    </div>
                                </div>
                                <div class="row" style="border-bottom: 1px solid lightblue">
                                    @foreach($data->accountants as $teacher)
                                        <div class="col-md-3 col-xs-6 col-sm-4">
                                            <div class="contact contact-single contact-bordered contact-rounded status-online" style="min-height: 140px;;">
                                                <img @if($teacher->user->image  === null) src="/admin/img/user/no-image.png" @endif @if($teacher->user->image != null) src="{{ asset($teacher->user->image) }}" @endif>
                                                <div class="contact-container">
                                                    <a href="{{ route('accountant.show',['id'=>$teacher->id]) }}">{{ $teacher->full_name }}</a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END BLOCK -->

        </div>
        <!-- END PAGE HEADING -->


        <!-- START CONTAINER -->
        <div class="container app-content-tab" id="tab-4">

            <!-- BLOCK -->
            <div class="block">
                <!-- START HEADING -->
                <div class="app-heading app-heading-small">
                    <div class="icon">
                        <span class="icon-cloud-rain"></span>
                    </div>
                    <div class="title">
                        <h2>Qo'shimcha ma'lumotlar</h2>
                    </div>
                </div>
                <!-- END START HEADING -->

                <div class="row">

                </div>
            </div>
            <!-- END BLOCK -->

        </div>
        <!-- END PAGE HEADING -->
@endsection
