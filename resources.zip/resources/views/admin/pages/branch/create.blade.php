@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="app-heading-container app-heading-bordered bottom">
            <ul class="breadcrumb">
                <li><a href="/backoffice">Dashboard</a></li>
                <li><a href="{{ route('branch.index') }}">Filiallar</a></li>
                <li class="active">Filial yaratish</li>
            </ul>
        </div>
        <div class="row">
            <form action="{{ route('branch.store') }}" method="post">
                {{ csrf_field() }}

                <div class="col-md-6">
                    <div class="block">
                        <button class="btn btn-success btn-block" type="submit">Saqlash</button>
                        @if(Auth::user()->role == 7)
                            <div class="form-group margin-top-30">
                                <label>Viloyatni tanlang
                                    @if($errors->has('region_id'))
                                        <span class="text-danger"> | {{ $errors->first('region_id') }}</span>
                                    @endif
                                </label>
                                <select class="bs-select"  id="regions2_id" data-dependent="area" data-live-search="true" name="region_id">
                                    <option selected></option>
                                    @foreach($regions as $region)
                                        <option value="{{$region->id}}" >{{$region->name_uz}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group margin-top-30">
                                <label>Tumanni tanlang

                                </label>
                                <select class="form-control"  id="areas2_id" data-live-search="true"  name="area_id">



                                </select>
                            </div>
                            @else
                             @if(Auth::user()->role == 6)
                                <div class="form-group margin-top-30">
                                    <label>Tumanni tanlang
                                        @if($errors->has('area_id'))
                                            <span class="text-danger"> | {{ $errors->first('area_id') }}</span>
                                        @endif
                                    </label>
                                    <select class="bs-select"  id="area" data-live-search="true"  name="area_id">
                                        <option selected></option>
                                        @foreach($areas as $area)
                                            <option value="{{$area->id}}" @if(old('area_id')==$area->id) selected @endif>{{$area->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif
                        @endif


                        <div class="form-group">
                            <label>Manzil
                                @if($errors->has('address'))
                                    <span class="text-danger"> | {{ $errors->first('address') }}</span>
                                @endif
                            </label>
                            <input class="form-control" placeholder="Manzilni kiriting"  name="address" value="{{old('address')}}" id="address">
                        </div>
                        <div class="form-group margin-top-10">
                            <label>Telefon raqam
                                @if($errors->has('phone'))
                                    <span class="text-danger"> | {{ $errors->first('phone') }}</span>
                                @endif
                            </label>
                            <input type="text" class="mask_tin form-control" value="{{old('phone')}}"  name="phone" id="phone">
                            <span class="help-block">Masalan: 90-1234567</span>
                        </div>
                        <div class="form-group margin-top-10">
                            <label>Email
                                @if($errors->has('email'))
                                    <span class="text-danger"> | {{ $errors->first('email') }}</span>
                                @endif
                            </label>
                            <input type="text" class=" form-control" value="{{old('email')}}"  name="email" >

                        </div>
                        <label for="status" class="margin-top-20">
                            Status
                            @if($errors->has('dormitory'))
                                <span class="text-danger"> | {{ $errors->first('status') }}</span>
                            @endif
                        </label>
                        <br>
                        <div class="app-radio success inline">
                            <label><input type="radio" name="status" value="1" checked=""> Aktiv<span></span></label>
                        </div>
                        <div class="app-radio warning inline">
                            <label><input type="radio" name="status" value="0"> Passiv<span></span></label>
                        </div>
                        <br>

                    </div>
                </div>
                <div class="col-md-6 " >
                    <div class="block">

                    <div class="app-content-tabs">
                        <ul>
                            <li><a href="#uz" class="active"><span class="fa fa-globe"></span>Nomlanishi</a></li>
                            <li><a href="#ru"><span class="fa fa-globe"></span> Наименование</a></li>
                        </ul>
                    </div>

                    <div class="container app-content-tab active" id="uz">
                        <div class="block">
                            <label for="name_uz">Filial nomi
                                @if($errors->has('name_uz'))
                                    <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_uz" id="name_uz" value="{{old('name_uz')}}" class="form-control">
                        </div>
                    </div>

                    <div class="container app-content-tab" id="ru">
                        <div class="block">
                            <label for="name_ru">Название Филиал
                                @if($errors->has('name_ru'))
                                    <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_ru" id="name_ru" value="{{old('name_ru')}}" class="form-control">
                        </div>

                    </div>


                    <div class="form-group margin-top-10">
                        <label>
                            Reestr raqam
                        </label>
                        @if($errors->has('reestr_number'))
                            <span class="text-danger"> | {{ $errors->first('reestr_number') }}</span>
                        @endif
                        <input type="text" class="form-control" name="reestr_number" value="{{old('reestr_number')}}">
                    </div>
                    <div class="form-group margin-top-10">
                        <label>
                            Litsenziya raqam
                        </label>
                        @if($errors->has('license_number'))
                            <span class="text-danger"> | {{ $errors->first('license_number') }}</span>
                        @endif
                        <input type="text" class="form-control" name="license_number" value="{{old('license_number')}}">
                    </div>
                    <div class="form-group margin-top-10">
                        <label >
                            Lintsenziya olingan vaqt
                        </label>
                        @if($errors->has('license_date'))
                            <span class="text-danger"> | {{ $errors->first('license_date') }}</span>
                        @endif
                        <div class="input-group bs-datepicker">

                            <input type="text" class="form-control"  name="license_date" id="birth_date"  >

                            <span class="input-group-addon">
                                    <span class="icon-calendar-full"></span>

                                </span>

                        </div>
                    </div>
                    <div class="form-group margin-top-10">
                        <label>
                            Ta`lim turi
                        </label>
                        @if($errors->has('edutype'))
                            <span class="text-danger"> | {{ $errors->first('edutype') }}</span>
                        @endif <br>
                        @foreach($edutype as $etype)
                            @if($etype->status == 1)
                                <input type="checkbox" style="padding: 3px; margin: 3px;" name="edutype{{$etype->id}}" value="{{$etype->id}}">{{$etype->name}}<br>
                            @endif
                        @endforeach
                    </div>
                    </div>

                    </div>
            </form>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script >
        $('#regions2_id').change(function() {
            if ($(this).val() != '') {
                var _token = $('input[name="_token"]').val();
                var region_id = $(this).val();
                var url = '/backoffice/areas/' + region_id;
                $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        _token: _token,
                    },
                    success: function(result) {
                        var areas = JSON.parse(result);
                        var html = '';
                        $.each(areas, function(key, value) {
                            html = html + '<option value="' + value["id"] + '">' + value['name'] + '</option>';
                        });
                        $('#areas2_id').html(html);
                    }
                });
            }
        });
    </script>

@endsection