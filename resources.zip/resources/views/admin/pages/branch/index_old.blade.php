@extends('layouts.admin')
@section('content')
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="col-md-12">
                        <div class="col-md-8">
                            <h3 style="float: left">@if(isset($region)) {{$region}} @endif barcha avtomobil o`qitishga mo`ljallangan maktablari </h3>
                        </div>
                        <div class="col-lg-4">
                            <a href="{{route('branch.create')}}" class="btn btn-success pull-right"><span class="fa fa-plus text-sm">&nbsp;</span>Yangi qo'shish</a>
                        </div>
                    </div>

                    @if(session('message'))
                        <div class="col-md-10">
                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-checkmark-circle"></span>
                                </div>
                                {{ session('message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
            <div class="block block-condensed">
                <br>
                <div class="block-content">

                    <table class="table table-striped table-bordered datatable-extended">
                        <thead>
                        <tr>
                            <th>Filial nomi</th>
                            <th>Tuman</th>
                            <th>Telefon</th>
                            <th>Reestr raqami</th>
                            <th>Litsenziya raqami</th>
                            <th >Litseniya sanasi</th>
                            <th>Ta`lim turlari</th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $item)
                            <tr>
                                <td>{{$item->name_uz}}</td>
                                <td>{{$item->area->name}}</td>
                                <td>{{$item->phone}}</td>
                                <td>{{$item->reestr_number}}</td>
                                <td>{{$item->license_number}}</td>
                                <td>{{$item->license_date}}</td>
                                <td>
                                    <?php
                                        $t = 0;
                                        $edutypes = explode("," , $item->edutype_id);
                                        for ($i = 0; $i < count($edutypes) ; $i++){
                                            foreach ($edutype as $etype){
                                                if ($etype->id == $edutypes[$i]){
                                                    if ($etype->status == 1){
                                                        echo $etype->name;
                                                        echo '<br>';
                                                    }
                                                }
                                            }
                                        }
                                    ?>

                                </td>
                                
                                <td>
                                    <a href="{{ route('branch.show', ['id' => $item->id]) }}" class="btn btn-default btn-icon">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                </td>
                                <td>
                                    <a href="{{ route('branch.edit', ['id' => $item->id]) }}" class="btn btn-default btn-icon">
                                        <i class="icon-pencil"></i>
                                    </a>
                                </td>
                                <td>
                                    <form action="{{ route('branch.destroy', ['id' => $item->id]) }}" method="post">
                                        {{ csrf_field() }}
                                        {{ method_field('delete') }}
                                        <button class="btn btn-default btn-icon deleteData"><i class="icon-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            
                        @endforeach
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>
@endsection