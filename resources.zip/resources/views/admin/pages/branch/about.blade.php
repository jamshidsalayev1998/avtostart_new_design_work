@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="app-heading-container app-heading-bordered bottom">
            <ul class="breadcrumb">
                <li><a href="/backoffice">Dashboard</a></li>
                <li><a href="{{ route('branch.index') }}">Filiallar</a></li>
                <li class="active">Filial ma`lumotlari</li>
            </ul>
        </div>
        <div class="row"  style="margin-right: 12px;margin-left: 12px; margin-top: 12px;">

            <div class="block block-condensed">
                <br>
                <div class="block-content">
                   <div class="row">
                        <div class="col-md-10">
                            <div class="app-content-tabs col-md-10">
                                <ul>
                                    <li><a href="#t1" class="active"><span class="fa fa-building"></span>Filial haqida</a></li>
                                    <li><a href="#t2"><span class="fa fa-user"></span> Filial rahbari</a></li>
                                    <li><a href="#t3"><span class="fa fa-calculator"></span> Hisob kitob ma`lumotlari</a></li>

                                </ul>

                            </div>
                               </div>
                            <div class="col-md-2">
                                @if($branch->checking == 0)
                                    <a class="btn " style="background-color: red; color: white;" href="{{route('check_branch')}}"><span style="color: white;" class="fa fa-pencil"></span> O`zgartirish</a>
                                @endif
                            </div>


                        <div class="app-content-tab active " id="t1">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">
                                    <div class="form-group" style="width: 100%; margin-top:  10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex; ">
                                        <label style="width: 50%; font-size: 14px;" for="">Filial nomi (UZ)
                                            </label>

                                        <b  style="font-size: 16px;">{{$branch->name_uz}}</b>
                                    </div>
                                </div>
                                 <div class="col-md-12">
                                    <div class="form-group" style="width: 100%; margin-top: 10px; padding-bottom: 10px;  border-bottom: 1px solid #999999; display: flex; ">
                                        <label style="width: 50%; font-size: 14px;"  for="">Filial nomi (RU)
                                           </label>

                                        <b style="font-size: 16px;">{{$branch->name_ru}}</b>
                                    </div>
                                </div>

                                <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex; ">
                                    <div class="form-group">
                                        <label style="width: 50%; font-size: 14px;" for="">Viloyat
                                          </label>

                                        <b   style="font-size: 16px;">{{$branch->region->name_uz}}</b >
                                    </div>
                                </div>
                                <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex; ">
                                    <div class="form-group">
                                        <label  style="width: 50%; font-size: 14px;" for="">Tuman
                                            </label>
                                            <b  style="font-size: 16px;">{{$branch->area->name}}</b >
                                    </div>
                                </div>
                                 <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex; ">
                                    <div class="form-group">
                                        <label  style="width: 50%; font-size: 14px;" for="">Adress
                                         </label>
                                        <b  style="font-size: 16px;">{{$branch->address}}"</b >
                                    </div>
                                </div>
                                 <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex; ">
                                    <div class="form-group ">
                                        <label  style="width: 50%; font-size: 14px;">Telefon raqam

                                        </label>

                                        <b  style="font-size: 16px;">{{$branch->phone}}</b>

                                    </div>
                                </div>
                                 <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex; ">
                                    <div class="form-group">
                                        <label  style="width: 50%; font-size: 14px;" for="">Reestr raqam
                                          </label>
                                        <b  style="font-size: 16px;">{{$branch->reestr_number}}</b>
                                    </div>
                                </div>
                                <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex; ">
                                    <div class="form-group">
                                        <label  style="width: 50%; font-size: 14px;" for="">Litsenziya raqam
                                           </label>
                                           <b  style="font-size: 16px;">{{$branch->license_number}}</b>
                                    </div>
                                </div>
                                 <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex; ">
                                    <div class="form-group">
                                        <label  style="width: 50%; font-size: 14px;" for="">Litsenziya sanasi
                                          </label>
                                        <?php $datee = date('Y-m-d', strtotime($branch->license_date));?>
                                        <b  style="font-size: 16px;">{{$datee}}</b>
                                    </div>
                                </div>
                                <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex; ">
                                    <div class="form-group">
                                        <label  style="width: 50%; font-size: 14px;" for="">Email</label>
                                        <b  style="font-size: 16px;">{{$branch->branch_email}}</b>
                                    </div>
                                </div>

                                </div>
                            </div>



                                <div class="col-md-6" style="margin-top: 10px;">

                                        <label for="">Ta`lim turlari
                                          </label>
                                        <br>
                                        @foreach($edutype as $item)
                                        <div class="form-group">
                                            <p>{{$item->name}}</p>
                                        </div>
                                            <br>
                                        @endforeach

                                </div>


                        </div>
                        <div class="app-content-tab  " id="t2" style="padding-left: 130px; padding-right: 130px;">
                            <div class=" text-center col-md-12" style="margin-top: 10px; margin-bottom: 10px;">
                                <img src="{{asset('admin/img/user/no-image.png')}}" alt="">
                            </div>
                            <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">
                                <label style="width: 30%; font-size: 14px;">F.I.O</label>
                                <b  style="font-size: 16px;">{{$branchadmin->full_name}}</b>
                            </div>
                            <div class="col-md-12" style="width: 100%; margin-top: 10px;  padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">

                                <label style="width: 30%; font-size: 14px;">Jinsi</label>
                                <b  style="font-size: 16px;">
                                    @if($branchadmin->gender == 0)
                                    Erkak
                                    @else
                                    Ayol
                                    @endif
                                </b>
                            </div>
                            <div class="col-md-12" style="width: 100%; margin-top: 10px;  padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">
                                <?php $datee2 = date('Y-m-d', strtotime($branchadmin->birthdate));?>
                                <label style="width: 30%; font-size: 14px;">Tug`ilgan sana</label>
                                <b  style="font-size: 16px;">{{$datee2}}</b>
                            </div>
                            <div class="col-md-12" style="width: 100%; margin-top: 10px;  padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">
                                <label style="width: 30%; font-size: 14px;">Adress</label>
                                <b  style="font-size: 16px;">{{$branchadmin->address}}</b>
                            </div>
                            <div class="col-md-12" style="width: 100%; margin-top: 10px;  padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">
                                <label style="width: 30%; font-size: 14px;">Passport info</label>
                                <b  style="font-size: 16px;">{{$branchadmin->passport_info}}</b>
                            </div>
                            <div class="col-md-12" style="width: 100%; margin-top: 10px;  padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">
                                <label style="width: 30%; font-size: 14px;">Telefon raqam</label>
                                <b  style="font-size: 16px;">{{$branchadmin->phone}}</b>
                            </div>
                        </div>




                         <div class="app-content-tab  " id="t3" style="padding-left: 130px; padding-right: 130px;">
                            <div class="col-md-12" style="width: 100%; margin-top: 30px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">
                                <label style="width: 30%; font-size: 14px;">Shartnoma raqam</label>
                                <b  style="font-size: 16px;">{{$requisites->shartnoma_number}} </b>
                            </div>
                            <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">
                                <label style="width: 30%; font-size: 14px;">INN</label>
                                <b  style="font-size: 16px;">{{$requisites->inn}}</b>
                            </div>
                            <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">
                                <label style="width: 30%; font-size: 14px;">Hisob raqam</label>
                                <b  style="font-size: 16px;">{{$requisites->hr}}</b>
                            </div>
                            <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">
                                <label style="width: 30%; font-size: 14px;">Faoliyat yo`nalishi</label>
                                <b  style="font-size: 16px;">{{$requisites->okonh}}</b>
                            </div>
                            <div class="col-md-12" style="width: 100%; margin-top: 10px; padding-bottom: 10px; border-bottom: 1px solid #999999; display: flex;">
                                <label style="width: 30%; font-size: 14px;">Bank</label>
                                <b  style="font-size: 16px;">{{$bank->bank_name}}</b>
                            </div>
                         </div>









                   </div>
                </div>
            </div>
        </div>
    </div>


@endsection