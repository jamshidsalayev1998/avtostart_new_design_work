@extends('layouts.admin')

@section('content')

    <div class="container" style="margin: 0px 15px !important">
        <form action="{{route('checking_branch')}}" method="post">
            {{csrf_field()}}
            {{ method_field('put') }}

        <div class="row" style="margin-right: 12px;margin-left: 12px;">

            <div class="panel panel-default" style="margin-bottom: 0px !important">

                <div class="panel-heading">

                    <div class="col-md-12">

                        <h3 class="panel-title">Bu yerda filial haqida barcha ma`lumotlar chiqariladi.  Xatolik bo`lsa tuzatishingizni yoki to`ldirilmagan bo`lsa to`ldirishingizni so`raymiz!
                         <strong style="color: red; display: block; line-height: 10px !important; ">Etiborli bo`ling bu imkoniyat bir marta beriladi saqlash tugmasi bosilgandan keyin orqaga qaytishning iloji yo`q</strong>
                        </h3>

                        <button href="" class="btn btn-success pull-right">
                       Saqlash</button>

                    </div>
                    @if(session('message'))

                        <div class="col-md-12">

                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">

                                <div class="alert-icon">

                                    <span class="icon-checkmark-circle"></span>

                                </div>

                                {{ session('message') }}

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>

                            </div>

                        </div>

                    @endif

                </div>

            </div>

            <div class="block block-condensed">

                <br>

                <div class="block-content">

                    <div class="row">
                        <div class="col-md-12">
                            <div class="app-content-tabs">
                                <ul>
                                    <li><a href="#t1" class="active"><span class="fa fa-globe"></span>Filial haqida</a></li>
                                    <li><a href="#t2"><span class="fa fa-globe"></span> Filial rahbari</a></li>
                                    <li><a href="#t3"><span class="fa fa-globe"></span> Hisob kitob ma`lumotlari</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="app-content-tab active " id="t1">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">Filial nomi (UZ)
                                            @if($errors->has('name_uz'))
                                        <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                                    @endif</label>

                                        <input type="text" class="form-control" value="{{$branch->name_uz}}" required name="name_uz">
                                    </div>
                                </div>
                                 <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">Filial nomi (RU)
                                            @if($errors->has('name_ru'))
                                        <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                                    @endif</label>

                                        <input type="text" class="form-control"  value="{{$branch->name_ru}}" required name="name_ru">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Viloyat
                                            @if($errors->has('regions_id'))
                                        <span class="text-danger"> | {{ $errors->first('regions_id') }}</span>
                                    @endif</label>

                                        <select class="form-control bs-select" data-live-search="true"  required name="region_id" id="regions_id">
                                            @foreach($regions as $region)
                                            @if($branch->region_id == $region->id)
                                                <option selected value="{{$region->id}}">{{$region->name_uz}}</option>
                                                @else
                                                <option  value="{{$region->id}}">{{$region->name_uz}}</option>
                                            @endif

                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Tuman
                                            @if($errors->has('areas_id'))
                                        <span class="text-danger"> | {{ $errors->first('areas_id') }}</span>
                                    @endif</label>

                                        <select class="form-control " data-live-search="true" required  name="area_id" id="areas_id">
                                            <option value="{{$branch->area_id}}"><?php $areaa = 'Test\Model\Area'::where('id', $branch->area_id)->first();
echo $areaa->name;?></option>

                                        </select>
                                    </div>
                                </div>
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Adress
                                         @if($errors->has('adress'))
                                        <span class="text-danger"> | {{ $errors->first('adress') }}</span>
                                    @endif </label>

                                        <input type="text" class="form-control"  value="{{$branch->address}}" required name="adress">
                                    </div>
                                </div>
                                 <div class="col-md-6">
                                    <div class="form-group ">
                                        <label>Telefon raqam
                                            @if($errors->has('phone'))
                                                <span class="text-danger"> | {{ $errors->first('phone') }}</span>
                                            @endif
                                        </label>
                                        <input type="text" class="mask_tin form-control" required value="{{$branch->phone}}"  name="phone" id="phone">
                                        <span class="help-block">Masalan: 90-1234567</span>
                                    </div>
                                </div>
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Reestr raqam
                                            @if($errors->has('reestr_number'))
                                        <span class="text-danger"> | {{ $errors->first('reestr_number') }}</span>
                                    @endif</label>

                                        <input type="text" class="form-control" required value="{{$branch->reestr_number}}" name="reestr_number">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Litsenziya raqam
                                            @if($errors->has('license_number'))
                                        <span class="text-danger"> | {{ $errors->first('license_number') }}</span>
                                    @endif</label>
                                        <input type="text" class="form-control" required value="{{$branch->license_number}}" name="license_number">
                                    </div>
                                </div>
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Litsenziya sanasi
                                            @if($errors->has('license_date'))
                                        <span class="text-danger"> | {{ $errors->first('license_date') }}</span>
                                    @endif</label>
                                        <?php $datee = date('Y-m-d', strtotime($branch->license_date));?>
                                        <input type="date" class="form-control" required value="{{$datee}}" name="license_date">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Email</label>
                                        <input type="email" class="form-control" value="{{$branch->branch_email}}" name="branch_email">
                                    </div>
                                </div>

                                </div>
                            </div>



                                <div class="col-md-6">

                                        <label for="">Ta`lim turlari
                                          </label>
                                        <br>
                                        @foreach($edutype as $item)
                                        <div class="form-group">
                                            <?php $array = explode(',', $branch->edutype_id);
$tt = 0;
for ($i = 0; $i <= count($array); $i++) {
	if (isset($array[$i])) {
		if ($array[$i] == $item->id) {
			$tt = 1;
		}
	}
}
?>

                                            @if($tt == 1)
                                            <input type="checkbox" checked class="" name="edutype[{{$item->id}}]" value="{{$item->id}}"> {{$item->name}}
                                            @else
                                            <input type="checkbox"  class="" name="edutype[{{$item->id}}]" value="{{$item->id}}"> {{$item->name}}
                                            @endif

                                        </div>
                                            <br>
                                        @endforeach

                                </div>


                        </div>
                        <div class="container app-content-tab" id="t2">
                            <div class="col-md-12">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">F.I.O
                                            @if($errors->has('full_name_branchadmin'))
                                        <span class="text-danger"> | {{ $errors->first('full_name_branchadmin') }}</span>
                                    @endif</label>
                                        <input type="text" class="form-control" value="{{$branchadmin->full_name}}" name="full_name_branchadmin">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Tug`ilgan sana
                                            @if($errors->has('birth_date_branchadmin'))
                                        <span class="text-danger"> | {{ $errors->first('birth_date_branchadmin') }}</span>
                                    @endif</label>

                                    <?php $datee2 = date('Y-m-d', strtotime($branchadmin->birthdate));?>

                                        <input type="date" class="form-control" value="{{$datee2}}" name="birth_date_branchadmin">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Jinsi
                                            @if($errors->has('gender_branchadmin'))
                                        <span class="text-danger"> | {{ $errors->first('gender_branchadmin') }}</span>
                                    @endif</label> <br>
                                            <div class="app-radio danger inline">

                                                <label><input type="radio" name="gender_branchadmin" id="gender" value="1" @if($branchadmin->gender == 1)checked @else @endif> Ayol<span></span></label>
                                            </div>
                                            <div class="app-radio success inline">
                                                <label><input type="radio" name="gender_branchadmin" id="gender" value="0" @if($branchadmin->gender == 0)checked @else @endif> Erkak<span></span></label>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Adress
                                            @if($errors->has('adress_branchadmin'))
                                        <span class="text-danger"> | {{ $errors->first('adress_branchadmin') }}</span>
                                    @endif</label>
                                        <input type="text" class="form-control" value="{{$branchadmin->address}}" name="adress_branchadmin">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="" >Passport info
                                            @if($errors->has('passport_info'))
                                        <span class="text-danger"> | {{ $errors->first('passport_info') }}</span>
                                    @endif</label>
                                        <input class="form-control" value="{{$branchadmin->passport_info}}"  name="passport_info_branchadmin" id="passport_info">
                                        <span class="help-block">Masalan: AA 1234567</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Telefon raqam
                                                @if($errors->has('phone'))
                                                    <span class="text-danger"> | {{ $errors->first('phone') }}</span>
                                                @endif
                                            </label>
                                            <input type="text" value="{{$branchadmin->phone}}" class="mask_tin form-control"   name="phone_branchadmin" id="phone_branchadmin">
                                            <span class="help-block">Masalan: 90-1234567</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="container app-content-tab" id="t3">
                            <div class="col-md-12">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Shartnoma raqam
                                            @if($errors->has('shartnoma_number'))
                                        <span class="text-danger"> | {{ $errors->first('shartnoma_number') }}</span>
                                    @endif</label>
                                        <input type="text" value="{{$requisites->shartnoma_number}}" class="form-control" name="shartnoma_number">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">INN
                                            @if($errors->has('inn'))
                                        <span class="text-danger"> | {{ $errors->first('inn') }}</span>
                                    @endif</label>
                                        <input type="number" value="{{$requisites->inn}}" class="form-control" name="inn">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Hisob raqam
                                            @if($errors->has('hr'))
                                        <span class="text-danger"> | {{ $errors->first('hr') }}</span>
                                    @endif</label>
                                        <input type="text" value="{{$requisites->hr}}" class="form-control" name="hr">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Faoliyat yo`nalishi
                                            @if($errors->has('okonh'))
                                        <span class="text-danger"> | {{ $errors->first('okonh') }}</span>
                                    @endif</label>
                                        <input type="number" value="{{$requisites->okonh}}" class="form-control" name="okonh">
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-12">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">MFO</label>
                                         @if($errors->has('mfo'))
                                        <span class="text-danger"> | {{ $errors->first('mfo') }}</span>
                                    @endif
                                        <input type="number" class="form-control" id="mfo_bank" value="{{$requisites->mfo}}">
                                    </div>
                                </div>
                                <div class="col-md-9">
                                    <div class="form-group">
                                        <label for="">Bank</label>

                                        <p id="bank_name_mfo"></p>
                                        <input type="text" hidden id="mfo" name="mfo" >
                                    </div>
                                </div>
                                {{-- <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="">Bank
                                            @if($errors->has('mfo'))
                                        <span class="text-danger"> | {{ $errors->first('mfo') }}</span>
                                    @endif</label>
                                        <select name="mfo" id="" class="form-control bs-select" data-live-search="true" >
                                            @foreach($banks as $item)
                                            @if($requisites->mfo == $item->mfo)
                                                <option selected value="{{$item->mfo}}">{{$item->bank_name}}</option>
                                                @else
                                                <option  value="{{$item->mfo}}">{{$item->bank_name}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>
                                </div> --}}

                            </div>
                        </div>
                    </div>


                </div>



            </div>

        </div>
    </form>

    </div>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script >
        $('#regions_id').change(function() {
            if ($(this).val() != '') {
                var _token = $('input[name="_token"]').val();
                var region_id = $(this).val();
                var url = '/backoffice/get_area_branch/' + region_id;
                $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        _token: _token,
                    },
                    success: function(result) {
                        var areas = JSON.parse(result);
                        var html = '';
                        $.each(areas, function(key, value) {
                            html = html + '<option value="' + value["id"] + '">' + value['name'] + '</option>';
                        });
                        $('#areas_id').html(html);
                    }
                });
            }
        });
    </script>

    <script>
        $("#mfo_bank").keyup(function(){
            if ($(this).val() != '') {
                var _token = $('input[name="_token"]').val();
                var mfo = $(this).val();
                var url = '/backoffice/get_bank_mfo/'+mfo;
                 $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        _token: _token,
                    },
                    success: function(result) {
                        var bank = JSON.parse(result);
                        if (bank == null) {
                            var tt = "Bank topilmadi";
                            $( "#bank_name_mfo" ).text( tt );

                        }
                        else{
                            $( "#bank_name_mfo" ).text( bank.bank_name );
                            $("#mfo").val( bank.mfo );
                        }
                    }
                });
            }
        });
        $(document).ready(function(){
            if ($("#mfo_bank").val() != '') {
                var _token = $('input[name="_token"]').val();
                var mfo = $("#mfo_bank").val();
                var url = '/backoffice/get_bank_mfo/'+mfo;
                 $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        _token: _token,
                    },
                    success: function(result) {
                        var bank = JSON.parse(result);
                        if (bank == null) {
                            var tt = "Bank topilmadi";
                            $( "#bank_name_mfo" ).text( tt );

                        }
                        else{
                            $( "#bank_name_mfo" ).text( bank.bank_name );
                            $("#mfo").val( bank.mfo );
                        }
                    }
                });
            }
        });
    </script>



@endsection