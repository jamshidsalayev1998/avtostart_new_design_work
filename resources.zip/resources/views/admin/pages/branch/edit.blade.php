@extends('layouts.admin')

@section('content')

    <div class="container">
        <div class="app-heading-container app-heading-bordered bottom">
            <ul class="breadcrumb">
                <li><a href="/backoffice">Dashboard</a></li>
                <li><a href="{{ route('branch.index') }}">Filiallar</a></li>
                <li class="active">O'zgartirish</li>
            </ul>
        </div>
        <div class="row">
            <form action="{{ route('branch.update',['id'=>$data->id] )}}" method="post">
                {{ csrf_field() }}
                {{ method_field('put') }}

                <div class="col-md-6">
                    <div class="block">
                        <button class="btn btn-success btn-block" type="submit">Saqlash</button>

                        <div class="form-group margin-top-30">
                            <label>Tumanni tanlang
                                @if($errors->has('area_id'))
                                    <span class="text-danger"> | {{ $errors->first('area_id') }}</span>
                                @endif
                            </label>
                            <select class="bs-select"  id="area" data-live-search="true" data-dependent="area" name="area_id">
                                <option selected></option>
                                @foreach($areas as $area)
                                    <option value="{{$area->id}}" @if($data->area_id==$area->id) selected @endif>{{$area->name}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Manzil
                                @if($errors->has('address'))
                                    <span class="text-danger"> | {{ $errors->first('address') }}</span>
                                @endif
                            </label>
                            <input class="form-control" placeholder="Manzilni kiriting"  name="address" value="<?php if(old('address')=="") echo $data->address; else echo old('address')?>" id="address">
                        </div>
                        <div class="form-group margin-top-10">
                            <label>Telefon raqam
                                @if($errors->has('phone'))
                                    <span class="text-danger"> | {{ $errors->first('phone') }}</span>
                                @endif
                            </label>
                            <input type="text" class="mask_tin form-control" value="<?php if(old('phone')=="") echo $data->phone; else echo old('phone')?>"  name="phone" id="phone">
                            <span class="help-block">Masalan: 90-1234567</span>
                        </div>
                        <label for="status" class="margin-top-20">
                            Status
                            @if($errors->has('dormitory'))
                                <span class="text-danger"> | {{ $errors->first('status') }}</span>
                            @endif
                        </label>
                        <br>
                        <div class="app-radio success inline">
                            <label><input type="radio" name="status" value="1" 
                                @if(($data->status)==1) 
                                    
                                checked=""
                               @endif
                                > 
                                
                                Aktiv<span></span></label>
                        </div>
                        <div class="app-radio warning inline">
                            <label><input type="radio" name="status" value="0"
                                 @if(($data->status)==0) 
                                    
                                checked=""
                               @endif
                               
                                
                                > Passiv<span></span></label>
                        </div>



                    </div>
                </div>
                <div class="col-md-6">

                    <div class="block">

                    <div class="app-content-tabs">
                        <ul>
                            <li><a href="#uz" class="active"><span class="fa fa-globe"></span>Nomlanishi</a></li>
                            <li><a href="#ru"><span class="fa fa-globe"></span> Наименование</a></li>
                        </ul>
                    </div>

                    <div class="container app-content-tab active" id="uz">
                        <div class="block">
                            <label for="name_uz">Filial nomi
                                @if($errors->has('name_uz'))
                                    <span class="text-danger"> | {{ $errors->first('name_uz') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_uz" id="name_uz" value="<?php if(old('name_uz')=="") echo $data->name_uz; else echo old('name_uz')?>" class="form-control">
                        </div>
                    </div>

                    <div class="container app-content-tab" id="ru">
                        <div class="block">
                            <label for="name_ru">Название Филиал
                                @if($errors->has('name_ru'))
                                    <span class="text-danger"> | {{ $errors->first('name_ru') }}</span>
                                @endif
                            </label>
                            <input type="text" name="name_ru" id="name_ru" value="<?php if(old('name_ru')=="") echo $data->name_ru; else echo old('name_ru')?>" class="form-control">
                        </div>
                    </div>

                        <div class="form-group margin-top-10">
                            <label>
                                Reestr raqam
                            </label>
                            @if($errors->has('reestr_number'))
                                <span class="text-danger"> | {{ $errors->first('reestr_number') }}</span>
                            @endif
                            <input type="text" class="form-control" name="reestr_number" value="<?php if(old('reestr_number')=="") echo $data->reestr_number; else echo old('reestr_number')?>">
                        </div>
                        <div class="form-group margin-top-10">
                            <label>
                                Litsenziya raqam
                            </label>
                            @if($errors->has('license_number'))
                                <span class="text-danger"> | {{ $errors->first('license_number') }}</span>
                            @endif
                            <input type="text" class="form-control" name="license_number" value="<?php if(old('license_number')=="") echo $data->license_number; else echo old('license_number')?>">
                        </div>

                        <div class="form-group margin-top-10">
                            <label >
                                Lintsenziya olingan vaqt
                            </label>
                            @if($errors->has('license_date'))
                                <span class="text-danger"> | {{ $errors->first('license_date') }}</span>
                            @endif
                            <div class="input-group bs-datepicker">

                                <input type="text" class="form-control"  name="license_date" id="birth_date" value="{{$data->license_date}}" >

                                <span class="input-group-addon">
                                    <span class="icon-calendar-full"></span>

                                </span>

                            </div>
                        </div>

                        <div class="form-group margin-top-10">
                            <label>
                                Ta`lim turi
                            </label>
                            @if($errors->has('edutype'))
                                <span class="text-danger"> | {{ $errors->first('edutype') }}</span>
                            @endif <br>
                            <?php
                            $edutypes = explode("," , $data->edutype_id);
                            ?>
                            @foreach($edutype as $etype)
                                @if($etype->status == 1)
                                    <?php
                                    $t = 0;
                                    for ($i = 0; $i < count($edutypes) ; $i++){
                                        if ($etype->id == $edutypes[$i]){
                                            echo ' <input type="checkbox" style="padding: 3px; margin: 3px;" checked name="edutype'.$etype->id.'" value="'.$etype->id.'">'.$etype->name.'<br>';
                                            $t = 1;
                                        }
                                    }
                                    if ($t != 1){
                                        echo ' <input type="checkbox" style="padding: 3px; margin: 3px;" name="edutype'.$etype->id.'" value="'.$etype->id.'">'.$etype->name.'<br>';
                                    }
                                    ?>
                                @endif
                            @endforeach
                        </div>

                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection