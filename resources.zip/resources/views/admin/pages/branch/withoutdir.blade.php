@extends('layouts.admin_alisher')
@section('content')
                <div class="title-link">
                    <div>
                        <h1>Rahbar tayinlanmagan filiallar</h1>
                        <p><span>Darsliklar</span>/Rahbarsiz filiallar</p>
                    </div>
                    
                </div>
                <div class="table-toifa">
                    <h1>Rahbar tayinlanmagan filiallar</h1>
                    <div class="table-content">

                    <table >
                        <tr>
                            <th><p>Filial nomi </p></th>
                            <th><p>Tumani </p></th>
                            <th><p>Telefon </p></th>
                            <th><p>Reestr raqami </p></th>
                            <th><p>Litsenziya </p></th>
                            <th ><p>Litsenziya date </p></th>
                            <th><p>Edutype </p></th>
                            <th><p>Direktor tayinlash </p></th>
                        </tr>
                        @foreach($data as $item)
                            <tr>
                                <td><p>{{$item->name_uz}} </p></td>
                                <td><p>{{$item->area->name}} </p></td>
                                <td><p>{{$item->phone}} </p></td>
                                <td><p>{{$item->reestr_number}} </p></td>
                                <td><p>{{$item->license_number}} </p></td>
                                <td><p>{{$item->license_date}} </p></td>
                                <td><p>
                                    <?php
                                    $t = 0;
                                    $edutypes = explode("," , $item->edutype_id);
                                    for ($i = 0; $i < count($edutypes) ; $i++){
                                        foreach ($edutype as $etype){
                                            if ($etype->id == $edutypes[$i]){
                                                if ($etype->status == 1){
                                                    echo $etype->name;
                                                    echo '<br>';
                                                }
                                            }
                                        }
                                    }
                                    ?> </p>

                                </td>

                                <td><p>
                                    <a href="{{ route('director' , ['id' => $item->id]) }}" class="btn btn-default btn-icon">
                                        <i class="fa fa-user-plus"></i>
                                    </a> </p>
                                </td>
                               
                            </tr>

                        @endforeach
                    </table>

                </div>

            </div>
       
@endsection