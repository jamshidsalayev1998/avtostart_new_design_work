@extends('layouts.admin')
@section('content')
    @php $i = ($data->currentPage() - 1) * $data->perPage() + 1 @endphp
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="block block-condensed">
                <br>
                <div class="block-content" style="width: 100%; overflow: auto;">
                    <table class="table table-striped table-bordered" id="data-table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Guruh nomi</th>
                            <th>Filial</th>
                            <th>Dars boshlangan vaqt</th>
                            <th>Dars tugagan vaqt</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $item)
                            <tr>
                                <td>{{$i}}</td>
                                <td><a href="ball/reg/{{ $item->id }}">{{ $item->name_uz }}</a></td>
                                <td>{{ $item->branch_name }}</td>
                                <td>{{ $item->edu_starting_date }}</td>
                                <td>{{ $item->edu_ending_date }}</td>
                            </tr>
                            @php $i ++ @endphp
                        @endforeach
                        </tbody>
                    </table>
                    <div class="row">
                        <div class="col-sm-5">
                            Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i - 1}} of {{$data->total()}} entries
                        </div>
                        <div class="col-sm-7">
                            {{ $data->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection