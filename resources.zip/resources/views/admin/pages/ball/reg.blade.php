@extends('layouts.admin')
@section('content')
    @php $i = 1;$j = 0 @endphp
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="block block-condensed">
                <br>
                <div id="group" class="text-center" data-id="<?=$group->edu_type?>">
                        <h3 class="tile-title" style="color: blue">{{ $group->name_uz." (".$group->getCourseName().")" }}</h3>
                        @if($group->assistant_id != null)
                            <h5>#{{ $group->teacher->full_name }} / {{ "@".$group->assistant->full_name }}</h5>
                        @endif
                        {{ $group->edu_starting_date }} <span class="fa fa-long-arrow-right"></span> {{ $group->edu_ending_date }}<br>
                        <div class="col-md-12       ">
                            <p class="text-left margin-0">Guruhning Hozirgi holati: <strong>{{ $group->getStatus() }}</strong></p>
                            @if($group->status == 0)<p class="text-left margin-0"><span class="fa fa-info" style="color: blue;text-align: justify">&nbsp;</span>Eslatma: <span style="opacity: 0.8">Guruhni 15-25 ta o'quvchilar bilan to'ldirsangiz guruh avtomatik ravishda <strong>Aktiv</strong> holatga o'tadi!</span></p>@endif
                        </div>
                </div>
                <br>
                <div class="block-content" style="width: 100%; overflow: auto;">
                    <form action="..\..\ball\owing" method="get">
                        <input hidden name="group" value="{{ $group->id }}">
                        <table class="table table-striped table-bordered" id="data-table">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>F.I.O.</th>
                                <th>baho 1</th>
                                <th>baho 2</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($data as $item)
                                <tr>
                                    <td>{{ $i }}</td>
                                    <td>{{ $item->last_name }} {{ $item->first_name }} {{ $item->middle_name }}</td>
                                    <td><input type="number" max="5" min="2" class="form-control" name="a{{ $item->id }}" value="<?=!empty($lists[$item->id]) ? $lists[$item->id]['a'] : ''?>"></td>
                                    <td><input type="number" max="5" min="2" class="form-control" name="b{{ $item->id }}" value="<?=!empty($lists[$item->id]) ? $lists[$item->id]['b'] : ''?>"></td>
                                </tr>
                                @php $i ++ @endphp
                            @endforeach
                            </tbody>
                        </table>
                        <div class="text-right">
                            <input type="submit" class="btn btn-success" value="Saqlash">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        var le = <?=--$i?>
    </script>
@endsection