@extends('layouts.admin')
@section('content')
    @php $i = 1 @endphp
    <div class="container">
        <div class="row" style="margin-right: 12px;margin-left: 12px;">
            <div class="block block-condensed">
                <br>
                <div class="block-content" style="width: 100%; overflow: auto;">
                    <table class="table table-striped table-bordered" id="data-table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>F.I.O.</th>
                            <th>Login</th>
                            <th>Parol</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $item)
                            <tr>
                                <td>{{$i}}</td>
                                <td>{{ $item->last_name }} {{ $item->first_name }} {{ $item->middle_name }}</td>
                                <td>{{ $item->passport_serial }}{{ $item->passport_number }}</td>
                                <td>{{ $item->group_id }}</td>
                            </tr>
                            @php $i ++ @endphp
                        @endforeach
                        </tbody>
                    </table>
                    <div class="row">
                        <div class="col-sm-5">
                            Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i - 1}} of {{$data->total()}} entries
                        </div>
                        <div class="col-sm-7">
                            {{ $data->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection