@extends('layouts.admin')
@section('content')
@php $i = ($data->currentPage() - 1) * $data->perPage() @endphp

<div class="app-heading-container app-heading-bordered bottom">
    <ul class="breadcrumb">
        <li><a href="/backoffice">Dashboard</a></li>
        <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>
    </ul>
    <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
</div>
<div class="container">
    <div class="row" style="margin-right: 12px;margin-left: 12px;">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="col-md-12">
                    <div class="col-md-6">
                        <h3 style="float: left"> Barcha qaytarilgan to'lovlar ro'yxati</h3>
                    </div>
                    <div class="col-lg-6">
                        <a href="../monitor/againcreate" class="btn btn-success pull-right"><span
                                class="fa fa-plus text-sm">&nbsp;</span>To'lov qaytarish</a>
                    </div>
                </div>

                @if(session('message'))
                <div class="col-md-10">
                    <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                        <div class="alert-icon">
                            <span class="icon-checkmark-circle"></span>
                        </div>
                        {{ session('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                class="fa fa-times"></span></button>
                    </div>
                </div>
                @endif
            </div>
        </div>
        <div class="block block-condensed">
            <div style="padding: 10px;">
                <strong style="padding: 20px;font-size:16px;">Ja'mi qaytarilgan to'lovlar:
                    &nbsp;</strong>
            </div>
            <div class="block-content">

                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>To'lovchi FIO</th>
                            <th>Qaytarilgan summa</th>
                            <th>Yaratilgan sana</th>
                           
                            <th>O`zgartirish</th> 
                            <th>o`chirish</th>
                            <th>O`quvchi</th>
                        </tr>
                    </thead>
                    <tbody>
                           
                        @foreach($data as $item)

                        <tr style="@if(0) background: lightsalmon @endif">
                            <td>{{++$i}}</td>
                            <td>{{$item->student->fio()}}</td>
                            <td>{{ $item->hours }}</td>
                            
                            <td>{{date("d/m/Y H:i",strtotime($item->created_at))}}</td>
                              <td>       
                                <a class="justify-content-center" href="{{'../monitor/againupdate'}}/{{ $item->id }}">
                                    <span class="icon-pencil"></span>
                                </a> 
                        
                                </td>
                                  <td>
                                  <a class="justify-content-center" href="{{'../monitor/againdelete'}}/{{ $item->id }}">
                                    <span class="icon-trash"></span>
                                </a> 
                                  </td>
                                <td>
                                        <a class="justify-content-center" href="{{ route('student.show',['id'=>$item->student_id]) }}">
                                            <span class="icon-eye"></span>
                                        </a>
                                </td>
                            </tr>
            @endforeach
            </tbody>
            </table>
            <div class="row">
                <div class="col-sm-5">
                    Showing {{($data->currentPage() - 1) * $data->perPage() + 1}} to {{$i}} of {{$data->total()}}
                    entries
                </div>
                <div class="col-sm-7">
               
                </div>     {{ $data->links() }}
            </div>
        </div>

    </div>
</div>
</div>
@endsection