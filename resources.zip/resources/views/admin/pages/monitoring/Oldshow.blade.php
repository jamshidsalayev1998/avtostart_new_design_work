@extends('layouts.admin')
@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li><a href="{{ route('group.index') }}">Monitoring</a></li>
            <li class="active">{{ $data->name_uz }}</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="app-heading app-heading-bordered app-heading-page">
        <div class="icon icon-lg">
            <span class="icon-clipboard-text"></span>
        </div>
        <div class="heading-elements col-md-12">
            <div class="col-md-5">
                <select class="bs-select group-decision"  id="group_id" data-live-search="true" data-dependent="student_id" name="student_id">
                    <option style="display: none">Guruhni tanlang</option>
                    @foreach($groups as $group)
                        <option value="{{ $group->id }}" data-href="{{ route('monitoring.show',['id'=>$group->id]) }}"
                                @if($group->id == $data->id) selected @endif
                        >{{ $group->name_uz }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-4">
                <button onclick="$('#decisions-form').submit()"  class="rendering btn btn-success form-control"><span class="fa fa-save">&nbsp;</span>Saqlash</button>
            </div>
            <div class="col-md-1">
                <div class="dropdown pull-right">
                    <button type="button" class="btn btn-default btn-icon pull-right" data-toggle="dropdown"><span class="fa fa-ellipsis-v " style="font-size: 17px;"></span></button>
                    <ul class="dropdown-menu dropdown-left">
                        <li><a href="{{ route('timetables.index') }}" ><span class="fa fa-print">&nbsp;&nbsp;</span> Guvohnoma chiqarish</a></li>
                        <li><a href="{{ route('timetables.index') }}" ><span class="fa fa-file-pdf-o text-danger">&nbsp;&nbsp;</span> PDF Export</a></li>
                        <li><a href="{{ route('export.monitoringtoexcel',['id'=>$data->id]) }}" ><span class="fa fa-file-excel-o text-success">&nbsp;&nbsp;</span> Excel Export</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="invoice">
            <div class="invoice-container">
                <div class="row">
    <input type="checkbox"  class="styled" id="all_checked2" style="
                       margin-left: 740px;
                    width: 78px;
                    height: 32px;">
                    <span style="    margin-left: -18px;
                    margin-top: 10px;
                    position: absolute;
                    font-size: 20px;">
                    Hammasini belgilash</span>
                    <div class="col-lg-12">
                        @if(session('message'))
                            <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                <div class="alert-icon">
                                    <span class="icon-checkmark-circle"></span>
                                </div>
                                {{ session('message') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                            </div>
                        @endif
                        <form method="post" action="{{ route('monitoring.store') }}" id="decisions-form">
                            {{ csrf_field() }}
                            <input type="hidden" value="{{ $data->id }}" name="group_id" class="input_check">
                            <div class="col-md-4">
                                <table class="table table-bordered" id="decisions-form">
                                    <thead>
                                    <tr>
                                        <th style="width: 2%">#</th>
                                        <th style="width: 38%;text-align: center">FIO</th>
                                    </tr>
                                    </thead>
                                    <tbody class="text-thin" id="students">
                                    @php $i=1; @endphp
                                    @foreach($array2 as $student)
                                                  

                                  
                                        @php $student = $student->student @endphp
                                       
                                        <tr>
                                            <td style="padding-top: 20px;padding-bottom: 20px;">{{ $i }}</td>
                                     <td>
                       
                                     <!--    <span style="font-weight: bolder">{{ $student->id }}</span>
                    -->
                              
                                        <span style="font-weight: bolder">{{ $student->fio() }}</span>
                        
                                     </td>
                                            @php $i++; @endphp
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-8" style="overflow-x: scroll">
                                <table class="table table-bordered" id="decisions-form">
                                    <thead>
                                    <tr>
                                        @foreach($data->classDate as $class)
                                            <th style="width: 10%;text-align: center">{{ date('m/d',strtotime($class->start_time)) }}</th>
                                        @endforeach
                                    </tr>
                                    </thead>
                                    <tbody class="text-thin" id="students">
                                    @foreach($array2 as $student)

                                        @php $student = $student->student @endphp
                                        <tr>
                                            @foreach($data->classDate as $class)
                                                <?php
                                                    $check_time = date('Y.m.d',time()) == date('Y.m.d',strtotime($class->start_time));
                                                    $check_ch = $data->checkPermission($class->start_time);
                                                ?>
<td class="text-center @if(date('Y.m.d',time()) == date('Y.m.d',strtotime($class->start_time))) all_check @endif" 
style="@if(date('Y.m.d',time()) == date('Y.m.d',strtotime($class->start_time))) background: lightgreen @endif
 @if($data->checkPermission($class->start_time)) background: antiquewhite @endif">

                         @if(time()>strtotime($class->start_time))
                                                        <button type="button" class="btn btn-default btn-icon<?=$check_time || $check_ch ? ' monitoring' : ''?>" @if($check_time || $check_ch)
                                                        data-student_id = "{{ $student->id }}" data-class_id="{{ $class->id }}" @endif
                                                                @if(date('Y.m.d',time()) != date('Y.m.d',strtotime($class->start_time)) && !$check_ch) disabled @endif>
                                                            @if($class->getAttendance($student->id) == 1) <span class="fa fa-check-circle text-success"></span>@endif
                                                            @if($class->getAttendance($student->id) == 0) <span class="fa fa-times text-danger"></span>@endif
                                                        </button>
                                                        @if($check_time || $check_ch)
                                                        <div class="hidden" id="{{ $student->id }}d{{ $class->id }}"></div>
                                                        @endif
                                                    @endif()
                                                </td>
                                            @endforeach
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection