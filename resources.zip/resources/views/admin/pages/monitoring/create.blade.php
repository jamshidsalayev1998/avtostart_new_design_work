@extends('layouts.admin')
@section('content')
    <div class="container">
        <div class="app-heading-container app-heading-bordered bottom">
            <ul class="breadcrumb">
                <li><a href="/backoffice">Dashboard</a></li>
                <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>
                <li class="active">To'lovni qaytarish</li>
            </ul>
        </div>
        <div class="block block-condensed">
            <div class="app-heading app-heading-small">
                <div class=" col-md-6 title">
                    <h2 style="color: red;">To'lovni qaytarish</h2>
                   
                </div>
                <div class="col-md-6"> 
                <button type="button" class="btn btn-success form-control" data-toggle="modal" data-target="#myModal">Saqlash</button>

                </div>
            </div>
        
            <div class="block-content">

                <form action="../monitor/againstores" id="payment-form" method="post" class="form-horizontal" enctype="multipart/form-data" name="student-form" id="student-form">
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-6 ">

                            <div class="form-group ">
                                <label class="col-md-12 control-label">
                                    @if($errors->has('student_id'))
                                        <span class="text-danger"> | {{ $errors->first('student_id') }}</span>
                                    @endif
                                </label>
                               
                                <div class="col-md-6" >
                                <select class="form-control "  id="groups"  name="groups_id">
                                           
                                           </select>
                                </div>
                                <div class="col-md-6">
                                <select class="form-control students_monitored"  id="students2" data-live-search="true" data-dependent="area" name="student_id">
                                           
                                           </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-12 control-label"> Qaytariladigan to'lov miqdori
                                    @if($errors->has('amount'))
                                        <span class="text-danger"> | {{ $errors->first('amount') }}</span>
                                    @endif
                                </label>
                                <div class="col-md-12">
                                    <input type="text" class="form-control" name="amount" id="amount" value="{{ old('amount') }}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-12 control-label">Status</label>
                                <div class="col-md-12">
                                    <select name="status" id="status" class="form-control">
                                        <option value="1">Aktiv</option>
                                        <option value="0">Passiv</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-12 control-label margin-bottom-0">Qaytarilgan to'lov sanasi
                                    @if($errors->has('payment_date'))
                                        <span class="text-danger"> | {{ $errors->first('payment_date') }}</span>
                                    @endif
                                </label>
                                <div class="col-md-12 input-group bs-datepicker control-label margin-left-20 margin-right-10">
                                    <input type="text" class="form-control"  name="payment_date" id="payment_date" value="{{ old('payment_date') }}">
                                    <span class="input-group-addon">
                                          <span class="icon-calendar-full"></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="block block-condensed" id="student_info">
                                <p style="padding: 30px;">O'quvchi haqida ma'lumot shu  yerda ko'rinadi</p>
                            </div>
                            <div> 
                            <span  style="font-size:24px;">To`langan Summa: </span><span style="font-size:20px;color:red" id="monitored"></span> <span  style="font-size:20px;"> so`m</span>
                             <br>   <span  style="font-size:24px;">To`langan Summa1: </span><span style="font-size:20px;color:red" id="monitored1"></span> <span  style="font-size:20px;"> so`m</span>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
    

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">To`lov qaytarish</h4>
      </div>
      <div class="modal-body">
        <p>Saqlash tugmasini bosganingizda o`quvchi guruhdan va monitoring, baholash bo`limidan o`chib ketadi.Shuni e`tiborga olgan holda tugmani bosishingizni so`rab qolamiz.</p>
      </div>
      <div class="modal-footer">
      <button type="submit"  onclick="$('#payment-form').submit()" class="btn btn-success form-control">Saqlash</button>
      </div>
    </div>

  </div>
</div>
@endsection