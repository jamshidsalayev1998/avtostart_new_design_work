@extends('layouts.admin')

@section('content')
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="/backoffice">Dashboard</a></li>
            <li class="active">>Monitoring</li>
        </ul>
        <a href="{{ url()->previous() }}" class="pull-right">Orqaga</a>
    </div>
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="panel panel-default">
                    <div class="panel-heading">Davomat o'tkazish uchun guruhni tanlang</div>
                    <div class="panel-body">
                        @if(session('message'))
                            <div class="col-md-10">
                                <div class="alert alert-success alert-icon-block alert-dismissible" role="alert">
                                    <div class="alert-icon">
                                        <span class="icon-checkmark-circle"></span>
                                    </div>
                                    {{ session('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="fa fa-times"></span></button>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>

                <div class="block">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th style="width: 2%">#</th>
                            <th>Guruh raqami</th>
                            <th>Ma'sul o'qituvchi</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        @php $count = $data->perPage() * ($data->currentpage() - 1) @endphp
                        @foreach($data as $item)
                            <tr class="clickable-row" @if($item->has_timetable == 1) data-href="{{ route('monitoring.show',['id'=>$item->id]) }}" @endif style="cursor: pointer">
                                <td>{{ ++$count }}</td>
                                <td>{{ $item->name_uz }}</td>
                                <td>{{ $item->teacher->full_name }}</td>
                                <td>
                                    <span class="fa fa-check"></span>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>

                    {!! $data->links() !!}

                </div>

            </div>


        </div>
    </div>
@endsection