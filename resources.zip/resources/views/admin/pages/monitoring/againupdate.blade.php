@extends('layouts.admin')
@section('content')
    <div class="container">
        <div class="app-heading-container app-heading-bordered bottom">
            <ul class="breadcrumb">
                <li><a href="/backoffice">Dashboard</a></li>
                <li><a href="{{ route('payment.index') }}">To'lovlar</a></li>
                <li class="active">Yangi to'lovni kiritish</li>
            </ul>
        </div>
      
        <div class="block block-condensed">
            <div class="app-heading app-heading-small">
                <div class=" col-md-6 title">
                    <h2>To'lovni kiritish</h2>
                    <p>Barcha maydonlar to'ldirilishi shartew</p>
                </div>
                <div class="col-md-6">
                    <button type="submit" onclick="$('#payment-form').submit()" class="btn btn-success form-control">Saqlash</button>
                </div>
            </div>
            <div class="block-content">
                       {!!Form::open(['url'=>'backoffice/monitor/againedit/','method'=>'post',
                        'id'=>'payment-form',
                         'class'=>"form-horizontal" ,
                          'enctype'=>'multipart/form-data',
                          'role'=>'form',
                       'name'=>'student-form'])!!}
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-6">  
                            <div class="form-group">
                                <label class="col-md-12 control-label">O'quvchini tanlang
                                    @if($errors->has('student_id'))
                                        <span class="text-danger"> | {{ $errors->first('student_id') }}</span>
                                    @endif
                                </label>
                                <div class="col-md-12">
                                    <select class="bs-select student_id"  id="student_id" data-live-search="true" data-dependent="student_id" name="student_id">
                                        @foreach($students as $student)
                                            <option value="{{ $student->id }}" @if(old('student_id')==$student->id) selected @endif>{{ $student->first_name}} {{ $student->middle_name}} {{ $student->last_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-12 control-label">To'lov miqdori
                                    @if($errors->has('hours'))
                                        <span class="text-danger"> | {{ $errors->first('hours') }}</span>
                                    @endif
                                </label>
                                <div class="col-md-12">
                                    <input type="text" class="form-control" name="amount" id="amount" value="{{ $student->hours }}">
                                    <input type="hidden" class="form-control" name="payment_id" id="payment_id" value="{{$payment_id }}">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-12 control-label">Status</label>
                                <div class="col-md-12">
                                    <select name="status" id="status" class="form-control">
                                        <option value="1">Aktiv</option>
                                        <option value="0">Passiv</option>
                                    </select>
                                </div>
                            </div>
                            
                        </div>
                        <div class="col-md-6">
                            <div class="block block-condensed" id="student_info">
                                <p style="padding: 30px;">O'quvchi haqida ma'lumot shu  yerda ko'rinadi</p>
                            </div>
                        </div>
                    </div>
               {!!Form::close()!!}

            </div>
        </div>
    </div>
@endsection