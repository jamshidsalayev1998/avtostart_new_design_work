@extends('layouts.admin')
@section('content')
    <!-- START PAGE HEADING -->
    <div class="app-heading app-heading-bordered app-heading-page">
        <div class="title">
            <h1>Calendar</h1>
            <p>Display your events or task on a full-sized calendar</p>
        </div>
        <!--<div class="heading-elements">
            <a href="#" class="btn btn-danger" id="page-like"><span class="app-spinner loading"></span> loading...</a>
            <a href="https://themeforest.net/item/boooya-revolution-admin-template/17227946?ref=aqvatarius&license=regular&open_purchase_for_item_id=17227946" class="btn btn-success btn-icon-fixed"><span class="icon-text">$24</span> Purchase</a>
        </div>-->
    </div>
    <div class="app-heading-container app-heading-bordered bottom">
        <ul class="breadcrumb">
            <li><a href="#">Application</a></li>
            <li><a href="#">Pages</a></li>
            <li class="active">Calendar</li>
        </ul>
    </div>
    <!-- END PAGE HEADING -->


    <!-- START PAGE SEPARATED CONTAINER -->
    <div class="app-content-separate app-content-separated-left">

        <div class="app-content-separate-left" data-separate-control-height="true">
            <div class="app-content-separate-panel padding-20 visible-mobile">
                <div class="pull-left">
                    <h4 class="text-sm text-uppercase text-bolder margin-bottom-0">Visible On Mobile</h4>
                    <p class="subheader">Use this panel to control this sidebar</p>
                </div>
                <button class="btn btn-default btn-icon pull-right" data-separate-toggle-panel=".app-content-separate-left"><span class="icon-menu"></span></button>
            </div>
            <div class="app-content-separate-content padding-20">
                <div class="app-heading app-heading-small heading-transparent app-heading-condensed">
                    <div class="title">
                        <h2>Add Event</h2>
                        <p>It's easy to add new events</p>
                    </div>
                </div>
                <div class="form-group margin-bottom-30">
                    <form action="#" method="post" id="new-event-form">
                        <div class="input-group">
                            <input type="text" class="form-control" id="new-event-text" placeholder="Event text...">
                            <div class="input-group-btn">
                                <button class="btn btn-default" id="new-event" type="submit">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="app-heading app-heading-small heading-transparent app-heading-condensed">
                    <div class="title">
                        <h2>Events</h2>
                        <p>Drag & Drop this events</p>
                    </div>
                    <div class="heading-elements">
                        <label class="switch" data-toggle="tooltip" data-placement="top" data-original-title="Remove after dropped">
                            <input type="checkbox" name="drop-remove" value="0" id="drop-remove" checked="">
                        </label>
                    </div>
                </div>
                <div class="list-group" id="external-events">
                    <a href="#" class="list-group-item external-event">Lorem ipsum dolor</a>
                    <a href="#" class="list-group-item external-event">Nam a nisi et nisi</a>
                    <a href="#" class="list-group-item external-event">Donec tristique eu</a>
                    <a href="#" class="list-group-item external-event">Vestibulum cursus</a>
                    <a href="#" class="list-group-item external-event">Etiam euismod</a>
                    <a href="#" class="list-group-item external-event">Sed pharetra dolor</a>
                </div>

            </div>
        </div>
        <div class="app-content-separate-content">
            <!-- CONTENT CONTAINER -->
            <div class="container">

                <div class="block block-condensed padding-top-20">

                    <div class="block-content">
                        <div id="calendar"></div>
                    </div>

                </div>

            </div>
            <!-- CONTENT CONTAINER -->
        </div>

    </div>
    <!-- END PAGE SEPARATED CONTAINER -->
@endsection