                     <li class="active-li">
                        <a href="{{ route('admin') }}">
                            <svg width="20" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.5 7.5L9 1.66666L16.5 7.5V16.6667C16.5 17.1087 16.3244 17.5326 16.0118 17.8452C15.6993 18.1577 15.2754 18.3333 14.8333 18.3333H3.16667C2.72464 18.3333 2.30072 18.1577 1.98816 17.8452C1.67559 17.5326 1.5 17.1087 1.5 16.6667V7.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M6.5 18.3333V10H11.5V18.3333"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>    
                            <p>Bosh sahifa</p>
                        </a>
                    </li>
                        
                    <!-- ********** -->
                     @if(Auth::user()->role == 2020)
                    <li>
                        <a href="{{ route('cov.index') }}">
                            <p>Bemorlar</p>
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('cov.index_1') }}">
                                
                           <p> 1-darajali aloqada bo`lganlar</p>
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('cov.index_2') }}">
                          
                            <p>2-darajali aloqada bo`lganlar</p>
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('cov.hisobot') }}">
                           
                           <p> Hisobot</p>
                        </a>
                    </li>
                    @endif
                     @if(Auth::user()->role==7777)
                    <li>
                        <a href="{{ route('hisobot.index') }}">
                           <svg width="20" height="20" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.66699 1.5H6.66699C7.55105 1.5 8.39889 1.85119 9.02401 2.47631C9.64914 3.10143 10.0003 3.94928 10.0003 4.83333V16.5C10.0003 15.837 9.73693 15.2011 9.26809 14.7322C8.79925 14.2634 8.16337 14 7.50033 14H1.66699V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M18.3333 1.5H13.3333C12.4493 1.5 11.6014 1.85119 10.9763 2.47631C10.3512 3.10143 10 3.94928 10 4.83333V16.5C10 15.837 10.2634 15.2011 10.7322 14.7322C11.2011 14.2634 11.837 14 12.5 14H18.3333V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>    
                            <p>Oxirgi chorak hisobotlari</p>
                            
                        </a>
                    </li>
                    <li>
                        <a href="{{ route('hisobot.sort') }}">
                             <svg width="20" height="20" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.66699 1.5H6.66699C7.55105 1.5 8.39889 1.85119 9.02401 2.47631C9.64914 3.10143 10.0003 3.94928 10.0003 4.83333V16.5C10.0003 15.837 9.73693 15.2011 9.26809 14.7322C8.79925 14.2634 8.16337 14 7.50033 14H1.66699V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M18.3333 1.5H13.3333C12.4493 1.5 11.6014 1.85119 10.9763 2.47631C10.3512 3.10143 10 3.94928 10 4.83333V16.5C10 15.837 10.2634 15.2011 10.7322 14.7322C11.2011 14.2634 11.837 14 12.5 14H18.3333V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>    
                            <p>Hisobotlar chorak va yil bo`yicha</p>
                            
                        </a>
                    </li>
                    @endif
                    @if(Auth::user()->role == 7)
                   
                    <!-- *********** -->
                <li>
                    <a href="{{ route('paygroup.index') }}">
                        <svg width="20" height="20" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M18 4.17241C18 4.04598 17.9854 3.91667 17.9561 3.78448C17.9268 3.6523 17.8711 3.49713 17.7891 3.31897C17.707 3.1408 17.5664 2.97701 17.3672 2.82759C17.168 2.67816 16.9219 2.56322 16.6289 2.48276L3.91992 0C3.61523 0 3.33398 0.0747126 3.07617 0.224138C2.81836 0.373563 2.61328 0.574713 2.46094 0.827586C2.30859 1.08046 2.23242 1.35632 2.23242 1.65517V3.86207H1.66992C1.21289 3.87356 0.820312 4.04023 0.492188 4.36207C0.164063 4.68391 0 5.06897 0 5.51724V14.3448C0 14.8046 0.164063 15.1954 0.492188 15.5172C0.820312 15.8391 1.21875 16 1.6875 16H16.3125C16.7812 16 17.1797 15.8391 17.5078 15.5172C17.8359 15.1954 18 14.8046 18 14.3448V4.17241ZM3.35742 1.65517C3.35742 1.50575 3.40723 1.37931 3.50684 1.27586C3.60645 1.17241 3.73242 1.11494 3.88477 1.10345L16.2949 3.56897L16.251 3.64655L16.0752 3.80172L15.75 3.86207H3.35742V1.65517ZM16.875 14.3448C16.875 14.4943 16.8193 14.6236 16.708 14.7328C16.5967 14.842 16.4648 14.8966 16.3125 14.8966H1.6875C1.53516 14.8966 1.40332 14.842 1.29199 14.7328C1.18066 14.6236 1.125 14.4943 1.125 14.3448V5.51724C1.125 5.36782 1.18066 5.23851 1.29199 5.12931C1.40332 5.02011 1.53516 4.96552 1.6875 4.96552H15.75C16.0547 4.96552 16.3184 4.91667 16.541 4.81897C16.7637 4.72126 16.875 4.58621 16.875 4.41379V14.3448ZM3.36621 8.82759C3.05566 8.82759 2.79199 8.93678 2.5752 9.15517C2.3584 9.37356 2.25 9.63506 2.25 9.93966C2.25 10.2443 2.3584 10.5029 2.5752 10.7155C2.79199 10.9282 3.05566 11.0345 3.36621 11.0345C3.67676 11.0345 3.94336 10.9282 4.16602 10.7155C4.38867 10.5029 4.5 10.2443 4.5 9.93966C4.5 9.63506 4.38867 9.37356 4.16602 9.15517C3.94336 8.93678 3.67676 8.82759 3.36621 8.82759Z" fill="#5C6467"/>
                                </svg>  
                            <p>Ais to`lov</p>
                        
                    </a>
                 </li>
            {{--      <li>
                    <a href="{{route('nochecks')}}">
                        <span class="nav-icon-hexa text-bloody-100"><i class="fa fa-check"></i></span>
                        Tasdiqlanmagan to`lovlar
                    </a>
                 </li> --}}
                    
                    <!-- ****************** -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Darsliklar</p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a href="{{ route('lesson.index') }}"><p>Toifalar</p></a>
                        </div>
                    </li>
                    <!-- ******************** -->
                                    <!-- ****************** -->
                    <li>
                        <a href="{{ route('courses.index') }}">
                            <svg width="20" height="20" viewBox="0 0 13 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.33334H7.66667C8.55072 1.33334 9.39857 1.68453 10.0237 2.30965C10.6488 2.93478 11 3.78262 11 4.66668C11 5.55073 10.6488 6.39858 10.0237 7.0237C9.39857 7.64882 8.55072 8.00001 7.66667 8.00001H1V1.33334Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M1 8H8.5C9.38406 8 10.2319 8.35119 10.857 8.97631C11.4821 9.60143 11.8333 10.4493 11.8333 11.3333C11.8333 12.2174 11.4821 13.0652 10.857 13.6904C10.2319 14.3155 9.38406 14.6667 8.5 14.6667H1V8Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>    
                            <p>Ta’lim turlari</p>
                        </a>
                    </li>
                    <!-- ******************** -->
                                    <!-- ****************** -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M16.667 4.83334H3.33366C2.41318 4.83334 1.66699 5.57954 1.66699 6.50001V14.8333C1.66699 15.7538 2.41318 16.5 3.33366 16.5H16.667C17.5875 16.5 18.3337 15.7538 18.3337 14.8333V6.50001C18.3337 5.57954 17.5875 4.83334 16.667 4.83334Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M13.3337 16.5V3.16667C13.3337 2.72464 13.1581 2.30072 12.8455 1.98816C12.5329 1.67559 12.109 1.5 11.667 1.5H8.33366C7.89163 1.5 7.46771 1.67559 7.15515 1.98816C6.84259 2.30072 6.66699 2.72464 6.66699 3.16667V16.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Hisobotlar</p>
                            </div>
                            
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{ action('Admin\PaymentController@hisobotviloyat',[]) }}" ><p>Umumiy hisobot</p></a>
                            <a href="{{ action('Admin\PaymentController@hisobotresguruh',[]) }}"><p>Yillik guruh hisoboti</p></a>
                            <a href="{{ action('Admin\PaymentController@hisobotresstudent',[]) }}"><p>Yillik o’quvchilar hisoboti</p></a>
                            <a href="{{ action('Admin\PaymentController@pay',[]) }}"><p>Guruhlar vaqt oralig’ida</p></a>
                            <a href="{{ action('Admin\PaymentController@regionpay',[]) }}"><p>Guruhlar bo’yicha to’lovlar</p></a>
                            <a href="{{ action('Admin\AttendanceController@student',[]) }}"><p>Barcha dars qoldirganlar</p></a>
                            <a href="{{ action('Admin\AttendanceController@region',[]) }}"><p>Viloyat kesimida ro’yxati</p></a>
                        </div>
                    </li>
                    <!-- ******************** -->
                                    <!-- ****************** -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M16.5 8.33334C16.5 14.1667 9 19.1667 9 19.1667C9 19.1667 1.5 14.1667 1.5 8.33334C1.5 6.34422 2.29018 4.43656 3.6967 3.03004C5.10322 1.62352 7.01088 0.833344 9 0.833344C10.9891 0.833344 12.8968 1.62352 14.3033 3.03004C15.7098 4.43656 16.5 6.34422 16.5 8.33334Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M9 10.8333C10.3807 10.8333 11.5 9.71406 11.5 8.33334C11.5 6.95263 10.3807 5.83334 9 5.83334C7.61929 5.83334 6.5 6.95263 6.5 8.33334C6.5 9.71406 7.61929 10.8333 9 10.8333Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>     
                                <p>Hududlar</p>
                            </div>
                            
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a href="{{ route('region.index') }}"><p>Viloyatlar</p></a>
                            <a href="{{ route('branch.index') }}"><p>Filiallar</p></a>
                            <a href="{{route('withoutdir')}}"><p>Rahbarsiz filiallar</p></a>
                            <a href="{{ route('group.index') }}"><p>Barcha guruhlar</p></a>
                        </div>
                    </li>
                    <!-- ******************** -->
                                    <!-- ****************** -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 20 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9.78438 0L9.58875 0.0593749L1.77625 2.67687L0 3.2625L1.03437 3.59375V10.175C0.66125 10.3919 0.409375 10.7875 0.409375 11.25C0.409375 11.5815 0.541071 11.8995 0.775492 12.1339C1.00991 12.3683 1.32785 12.5 1.65937 12.5C1.9909 12.5 2.30884 12.3683 2.54326 12.1339C2.77768 11.8995 2.90938 11.5815 2.90938 11.25C2.90938 10.7875 2.6575 10.3919 2.28437 10.175V4.025L3.53438 4.43437V8.75C3.53438 9.2625 3.84687 9.6875 4.21812 9.98125C4.58938 10.2731 5.05062 10.4794 5.60437 10.6644C6.71312 11.0331 8.17438 11.25 9.78438 11.25C11.3944 11.25 12.8556 11.0337 13.9644 10.6637C14.5181 10.4794 14.9794 10.2731 15.3506 9.98063C15.7219 9.6875 16.0344 9.2625 16.0344 8.75V4.43437L17.7925 3.84812L19.5688 3.2625L17.7919 2.67625L9.97937 0.0593749L9.78438 0ZM9.78438 1.30937L15.6438 3.2625L9.78438 5.21562L3.925 3.2625L9.78438 1.30937ZM4.78438 4.86437L9.58937 6.46562L9.78438 6.52437L9.98 6.465L14.7844 4.86375V8.75C14.7844 8.75625 14.7869 8.82875 14.5888 8.98438C14.3913 9.14062 14.0369 9.3375 13.5731 9.4925C12.6469 9.80062 11.2812 10 9.78438 10C8.2875 10 6.92188 9.80125 5.995 9.49187C5.5325 9.3375 5.1775 9.14 4.98 8.98438C4.78125 8.82812 4.78438 8.75625 4.78438 8.75V4.86437Z" fill="#5C6467" />
                                </svg>      
                                <p>O’quvchilar</p>
                            </div>
                            
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a href="{{ route('student.index') }}"><p>Barcha o`quvchilar ro`yhati</p></a>
                            <a href="{{action('Admin\StudentController@regionstudent',[])}}"><p>Arxivlangan o`quvchilar ro`yhati</p></a>
                        </div>
                    </li>
                    <!-- ******************** -->
                                    <!-- ****************** -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M14.6663 16.5V14.8333C14.6663 13.9493 14.3151 13.1014 13.69 12.4763C13.0649 11.8512 12.2171 11.5 11.333 11.5H4.66634C3.78229 11.5 2.93444 11.8512 2.30932 12.4763C1.6842 13.1014 1.33301 13.9493 1.33301 14.8333V16.5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M7.99935 8.16667C9.8403 8.16667 11.3327 6.67428 11.3327 4.83333C11.3327 2.99238 9.8403 1.5 7.99935 1.5C6.1584 1.5 4.66602 2.99238 4.66602 4.83333C4.66602 6.67428 6.1584 8.16667 7.99935 8.16667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>      
                                <p>Foydalanuvchilar</p>
                            </div>
                            
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div  class="li-link">
                            <a href="{{ route('regionadmin.index') }}"><p>Viloyat Rahbarlari</p></a>
                            <a  href="{{ route('branchadmin.index') }}"><p>Filial rahbarlari</p></a>
                            <a href="{{ action('Admin\RegionAdminController@managerindex',[])}}"><p>Content Manager</p></a>
                            <a href="{{ route('moderator.index') }}"><p>Moderatorlar</p></a>
                            <a href="{{ route('teacher.index') }}"><p>O'qituvchilar</p></a>
                            <a  href="{{ route('accountant.index') }}"><p>Hisobchilar</p></a>
                        </div>
                    </li>
                    <!-- ******************** -->
                                    <!-- ****************** -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M18 4.17241C18 4.04598 17.9854 3.91667 17.9561 3.78448C17.9268 3.6523 17.8711 3.49713 17.7891 3.31897C17.707 3.1408 17.5664 2.97701 17.3672 2.82759C17.168 2.67816 16.9219 2.56322 16.6289 2.48276L3.91992 0C3.61523 0 3.33398 0.0747126 3.07617 0.224138C2.81836 0.373563 2.61328 0.574713 2.46094 0.827586C2.30859 1.08046 2.23242 1.35632 2.23242 1.65517V3.86207H1.66992C1.21289 3.87356 0.820312 4.04023 0.492188 4.36207C0.164063 4.68391 0 5.06897 0 5.51724V14.3448C0 14.8046 0.164063 15.1954 0.492188 15.5172C0.820312 15.8391 1.21875 16 1.6875 16H16.3125C16.7812 16 17.1797 15.8391 17.5078 15.5172C17.8359 15.1954 18 14.8046 18 14.3448V4.17241ZM3.35742 1.65517C3.35742 1.50575 3.40723 1.37931 3.50684 1.27586C3.60645 1.17241 3.73242 1.11494 3.88477 1.10345L16.2949 3.56897L16.251 3.64655L16.0752 3.80172L15.75 3.86207H3.35742V1.65517ZM16.875 14.3448C16.875 14.4943 16.8193 14.6236 16.708 14.7328C16.5967 14.842 16.4648 14.8966 16.3125 14.8966H1.6875C1.53516 14.8966 1.40332 14.842 1.29199 14.7328C1.18066 14.6236 1.125 14.4943 1.125 14.3448V5.51724C1.125 5.36782 1.18066 5.23851 1.29199 5.12931C1.40332 5.02011 1.53516 4.96552 1.6875 4.96552H15.75C16.0547 4.96552 16.3184 4.91667 16.541 4.81897C16.7637 4.72126 16.875 4.58621 16.875 4.41379V14.3448ZM3.36621 8.82759C3.05566 8.82759 2.79199 8.93678 2.5752 9.15517C2.3584 9.37356 2.25 9.63506 2.25 9.93966C2.25 10.2443 2.3584 10.5029 2.5752 10.7155C2.79199 10.9282 3.05566 11.0345 3.36621 11.0345C3.67676 11.0345 3.94336 10.9282 4.16602 10.7155C4.38867 10.5029 4.5 10.2443 4.5 9.93966C4.5 9.63506 4.38867 9.37356 4.16602 9.15517C3.94336 8.93678 3.67676 8.82759 3.36621 8.82759Z" fill="#5C6467"/>
                                </svg>       
                                <p>To’lovlar</p>
                            </div>
                            
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a href="{{ route('payment.index') }}"><p>Hududlar</p></a>
                            <a href="{{ action('Admin\PaymentController@regionpay2',[]) }}"><p>Qarzdorlar</p></a>
                            <a href="{{action('Admin\PaymentController@list',[])}}"><p>To'lov  tarixi</p></a>
                        </div>
                    </li>
                    <!-- ******************** -->
                    <!-- *********** -->
                    <li>
                        <a href="{{ route('permissions.index') }}">
                            <svg width="20" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M14.8333 3.33331H3.16667C2.24619 3.33331 1.5 4.07951 1.5 4.99998V16.6666C1.5 17.5871 2.24619 18.3333 3.16667 18.3333H14.8333C15.7538 18.3333 16.5 17.5871 16.5 16.6666V4.99998C16.5 4.07951 15.7538 3.33331 14.8333 3.33331Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M12.333 1.66666V4.99999" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M5.66699 1.66666V4.99999"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M1.5 8.33331H16.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>      
                            <p>Ruxsat berishlar</p>
                        </a>
                    </li>
                    <!-- ****************** -->
                                    <!-- ****************** -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M2.5 2.5H8.33333V8.33333H2.5V2.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M11.667 11.6667H17.5003V17.5H11.667V11.6667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M2.5 11.6667H8.33333V17.5H2.5V11.6667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M17.5003 3.33331L13.4899 7.34373L11.667 5.52081"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Yakuniy  TEST</p>
                            </div>
                            
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{ route('test.index') }}"><p>Yakuniy testga ruxsat berish</p></a>
                            <a href="{{ action('Admin\TestController@res',[]) }}"><p>Yakuniy test statistika</p></a>
                        </div>
                    </li>
                    <!-- ******************** -->
                                    <!-- ****************** -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M14.8333 1.5H3.16667C2.24619 1.5 1.5 2.24619 1.5 3.16667V14.8333C1.5 15.7538 2.24619 16.5 3.16667 16.5H14.8333C15.7538 16.5 16.5 15.7538 16.5 14.8333V3.16667C16.5 2.24619 15.7538 1.5 14.8333 1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M4.83301 4.83331H7.33301V12.3333H4.83301V4.83331Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M10.667 4.83331H13.167V8.99998H10.667V4.83331Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>     
                                <p>Shablon hisobotlar</p>
                            </div>
                            
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a href="{{action('Admin\TestController@hisobotresshablon',[])}}"><p>Viloyatlar boyicha</p></a>
                            <a href="{{ action('Admin\TestController@moststudentres',[]) }}"><p>Eng yaxshi talabalar</p></a>
                            <a href="{{ action('Admin\TestController@mostteacherres',[]) }}"><p>Eng yaxshi o`qituvchilar</p></a>
                        </div>
                    </li>
                    <!-- ******************** -->
                                    <!-- ****************** -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10 12.5C11.3807 12.5 12.5 11.3807 12.5 10C12.5 8.61929 11.3807 7.5 10 7.5C8.61929 7.5 7.5 8.61929 7.5 10C7.5 11.3807 8.61929 12.5 10 12.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M16.1663 12.5C16.0554 12.7513 16.0223 13.0301 16.0713 13.3005C16.1204 13.5708 16.2492 13.8202 16.4413 14.0166L16.4913 14.0666C16.6463 14.2214 16.7692 14.4052 16.8531 14.6076C16.937 14.8099 16.9802 15.0268 16.9802 15.2458C16.9802 15.4648 16.937 15.6817 16.8531 15.884C16.7692 16.0864 16.6463 16.2702 16.4913 16.425C16.3366 16.5799 16.1527 16.7029 15.9504 16.7867C15.7481 16.8706 15.5312 16.9138 15.3122 16.9138C15.0931 16.9138 14.8763 16.8706 14.6739 16.7867C14.4716 16.7029 14.2878 16.5799 14.133 16.425L14.083 16.375C13.8866 16.1829 13.6372 16.054 13.3668 16.005C13.0965 15.956 12.8177 15.989 12.5663 16.1C12.3199 16.2056 12.1097 16.381 11.9616 16.6046C11.8135 16.8282 11.7341 17.0902 11.733 17.3583V17.5C11.733 17.942 11.5574 18.3659 11.2449 18.6785C10.9323 18.991 10.5084 19.1666 10.0663 19.1666C9.62431 19.1666 9.20039 18.991 8.88783 18.6785C8.57527 18.3659 8.39967 17.942 8.39967 17.5V17.425C8.39322 17.1491 8.30394 16.8816 8.14343 16.6572C7.98293 16.4328 7.75862 16.2619 7.49967 16.1666C7.24833 16.0557 6.96951 16.0226 6.69918 16.0716C6.42885 16.1207 6.17941 16.2495 5.98301 16.4416L5.93301 16.4916C5.77822 16.6466 5.5944 16.7695 5.39207 16.8534C5.18974 16.9373 4.97287 16.9805 4.75384 16.9805C4.53481 16.9805 4.31794 16.9373 4.11561 16.8534C3.91328 16.7695 3.72946 16.6466 3.57467 16.4916C3.41971 16.3369 3.29678 16.153 3.21291 15.9507C3.12903 15.7484 3.08586 15.5315 3.08586 15.3125C3.08586 15.0935 3.12903 14.8766 3.21291 14.6742C3.29678 14.4719 3.41971 14.2881 3.57467 14.1333L3.62467 14.0833C3.81679 13.8869 3.94566 13.6375 3.99468 13.3671C4.04369 13.0968 4.0106 12.818 3.89967 12.5666C3.79404 12.3202 3.61864 12.11 3.39506 11.9619C3.17149 11.8138 2.9095 11.7344 2.64134 11.7333H2.49967C2.05765 11.7333 1.63372 11.5577 1.32116 11.2452C1.0086 10.9326 0.833008 10.5087 0.833008 10.0666C0.833008 9.62462 1.0086 9.2007 1.32116 8.88813C1.63372 8.57557 2.05765 8.39998 2.49967 8.39998H2.57467C2.8505 8.39353 3.11801 8.30424 3.34242 8.14374C3.56684 7.98323 3.73777 7.75893 3.83301 7.49998C3.94394 7.24863 3.97703 6.96982 3.92801 6.69949C3.879 6.42916 3.75012 6.17971 3.55801 5.98331L3.50801 5.93331C3.35305 5.77852 3.23012 5.59471 3.14624 5.39238C3.06237 5.19005 3.0192 4.97317 3.0192 4.75415C3.0192 4.53512 3.06237 4.31824 3.14624 4.11591C3.23012 3.91358 3.35305 3.72977 3.50801 3.57498C3.6628 3.42002 3.84661 3.29709 4.04894 3.21321C4.25127 3.12934 4.46815 3.08617 4.68717 3.08617C4.9062 3.08617 5.12308 3.12934 5.32541 3.21321C5.52774 3.29709 5.71155 3.42002 5.86634 3.57498L5.91634 3.62498C6.11274 3.81709 6.36219 3.94597 6.63252 3.99498C6.90285 4.044 7.18166 4.01091 7.43301 3.89998H7.49967C7.74615 3.79434 7.95635 3.61894 8.10442 3.39537C8.25248 3.17179 8.33194 2.9098 8.33301 2.64165V2.49998C8.33301 2.05795 8.5086 1.63403 8.82116 1.32147C9.13372 1.00891 9.55765 0.833313 9.99967 0.833313C10.4417 0.833313 10.8656 1.00891 11.1782 1.32147C11.4907 1.63403 11.6663 2.05795 11.6663 2.49998V2.57498C11.6674 2.84313 11.7469 3.10513 11.8949 3.3287C12.043 3.55228 12.2532 3.72768 12.4997 3.83331C12.751 3.94424 13.0298 3.97733 13.3002 3.92832C13.5705 3.8793 13.8199 3.75043 14.0163 3.55831L14.0663 3.50831C14.2211 3.35335 14.4049 3.23042 14.6073 3.14655C14.8096 3.06267 15.0265 3.0195 15.2455 3.0195C15.4645 3.0195 15.6814 3.06267 15.8837 3.14655C16.0861 3.23042 16.2699 3.35335 16.4247 3.50831C16.5796 3.6631 16.7026 3.84692 16.7864 4.04925C16.8703 4.25158 16.9135 4.46845 16.9135 4.68748C16.9135 4.90651 16.8703 5.12338 16.7864 5.32571C16.7026 5.52804 16.5796 5.71186 16.4247 5.86665L16.3747 5.91665C16.1826 6.11305 16.0537 6.36249 16.0047 6.63282C15.9557 6.90315 15.9887 7.18197 16.0997 7.43331V7.49998C16.2053 7.74645 16.3807 7.95666 16.6043 8.10472C16.8279 8.25279 17.0899 8.33224 17.358 8.33331H17.4997C17.9417 8.33331 18.3656 8.50891 18.6782 8.82147C18.9907 9.13403 19.1663 9.55795 19.1663 9.99998C19.1663 10.442 18.9907 10.8659 18.6782 11.1785C18.3656 11.4911 17.9417 11.6666 17.4997 11.6666H17.4247C17.1565 11.6677 16.8945 11.7472 16.671 11.8952C16.4474 12.0433 16.272 12.2535 16.1663 12.5V12.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>       
                                <p>Sozlamalar</p>
                            </div>
                            
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a href="{{ route('languages.index') }}"><p>Til</p></a>
                            <a href="{{ route('exceptions.index') }}"><p>Bayram kunlari</p></a>
                            <a href="{{ route('menu.index') }}" ><p>Menu</p></a>
                            <a href="{{ route('keys.index') }}"><p>Keys</p></a>
                            <a href="{{ route('developing.index') }}"><p> Developing Mode</p></a>
                        </div>
                    </li>
                    <!-- ******************** -->
                                                    <!-- ****************** -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M16.667 1H3.33366C2.41318 1 1.66699 1.74619 1.66699 2.66667V11.8333C1.66699 12.7538 2.41318 13.5 3.33366 13.5H16.667C17.5875 13.5 18.3337 12.7538 18.3337 11.8333V2.66667C18.3337 1.74619 17.5875 1 16.667 1Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M17.5 1.66669L10.0007 7.33335L2.5 1.66669"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>     
                                <p>Xabarlar</p>
                            </div>
                            
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a href="{{ route('chat.index') }}"><p>Kelgan xabarlar</p></a>
                            <a href="{{action('Admin\ChatController@send',[])}}"><p>Jo'natilgan xabarlar</p></a>
                        </div>
                    </li>
                    @endif
                    @if(\Auth::user()->role==6)
                     <li>
                         <a href="{{route('hisobot.index')}}">
                            <svg width="20" height="20" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.66699 1.5H6.66699C7.55105 1.5 8.39889 1.85119 9.02401 2.47631C9.64914 3.10143 10.0003 3.94928 10.0003 4.83333V16.5C10.0003 15.837 9.73693 15.2011 9.26809 14.7322C8.79925 14.2634 8.16337 14 7.50033 14H1.66699V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M18.3333 1.5H13.3333C12.4493 1.5 11.6014 1.85119 10.9763 2.47631C10.3512 3.10143 10 3.94928 10 4.83333V16.5C10 15.837 10.2634 15.2011 10.7322 14.7322C11.2011 14.2634 11.837 14 12.5 14H18.3333V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>    
                                    <p>Hisobotlar</p>
                             
                         </a>
                     </li>
                     {{-- <li>
                        <a href="{{ route('paygroup.index') }}">
                            <span class="nav-icon-hexa text-bloody-100">A</span>
                            Ais to`lov
                        </a>
                     </li> --}}
                <!--
                    <li>
                        <a href="#"><span class="nav-icon-hexa text-orange-100"><i
                                    class="fa fa-graduation-cap"></i></span>O'quvchilar</a>
                        <ul>
                            <li>
                                <a href="{{ route('group.index') }}"><span class="nav-icon-hexa">G</span>Guruhlar</a></li>
                            <li>
                            <li>
                                <a href="{{ route('student.index') }}"><span class="nav-icon-hexa">BS</span>Barcha O'quvchilar</a></li>
                            <li>
                            <li>
                                <a href="{{action('Admin\StudentController@branchstudent2',[])}}"><span class="nav-icon-hexa">A</span>O'quvchilar Arxivi</a></li>
                            <li>
                            </li>
                        </ul>
                    </li>
                 -->    
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Testlar tahlili</p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a href="{{ action('Admin\TestController@res',[]) }}">
                                <p>
                                    Avto maktablar kesimida test statistikasi
                                </p>
                            </a>
                        </div>
                    </li>
                   <!--  {{-- <li>
                        <a href="{{ route('permissions.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                                    class="fa fa-calendar"></i></span>Ruxsat berishlar</a>
                    </li> --}} -->
                    <!-- <li>
                                <a href="{{ route('teacher.index') }}"><span class="nav-icon-hexa">FD</span>Avto maktablarda faoliyat yurituvci o'qituvchilar</a></li>
                            <li>
                     -->
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Avto maktablar</p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{ route('branch.index') }}">
                                <p>
                                    Avto maktablar haqida
                                </p>
                            </a>
                            <a  href="{{ route('branchadmin.index') }}">
                                <p>
                                    Avto maktab direktorlari
                                </p>
                            </a>
                        </div>
                    </li>
                    {{-- <li>
                        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-calculator"></i></span>Hisobotlar</a> --}}
                        <!-- <ul>
                            <li>
                                <a href="{{ route('payment.index') }}"><span class="nav-icon-hexa">F</span>Barcha To'lovlar</a></li>
                            <li>
                            <li>

                                <a href="{{action('Admin\PaymentController@payregs',[])}}"><span class="nav-icon-hexa">F</span>Guruhlar Viloyat</a>
                                </li>
                            <li><a href="{{ action('Admin\PaymentController@hisobotfilialadmin',[]) }}"><span class="nav-icon-hexa">H</span>Umumiy hisobot</a></li>

                                <li>

                                    <a href="{{action('Admin\PaymentController@branchpays',[])}}"><span class="nav-icon-hexa">F</span>Yillik Tushum Hisobot</a>
                                    </li>

                            <li>
                                <a href="{{action('Admin\PaymentController@branchpays',[])}}"><span class="nav-icon-hexa">Q</span>Qarzdorlar </a></li>
                            <li>
                                <a href="{{action('Admin\PaymentController@list',[])}}"><span class="nav-icon-hexa">TT</span>To'lov tarix</a>
                            </li> -->

                    {{-- </li> --}}
                    <!-- <li><a href="{{ action('Admin\PaymentController@hisobotfilialstudentadmin',[]) }}"><span class="nav-icon-hexa">H</span>Umumiy  o`quvchilar hisoboti</a></li>
                            <li><a href="{{ action('Admin\PaymentController@hisobotfilialguruhadmin',[]) }}"><span class="nav-icon-hexa">H</span>Umumiy guruh  hisobot</a></li>
                    <li>
                        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Dars
                            qoldirganlar</a>
                        <ul>
                            <li>
                                <a href="{{action('Admin\AttendanceController@student',[])}}"><span
                                        class="nav-icon-hexa">BR</span>Eng ko`p qoldirganlar </a></li>
                            <li>
                                <a href="{{action('Admin\AttendanceController@index',[])}}"><span
                                        class="nav-icon-hexa">TR</span>Filiallar kesimida</a></li>
                            <li>
                        </ul>
                    </li>
                    {{-- <li>
                        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Guvohnoma berish
                            </a>
                        <ul>

                       <li>
                                <a href="{{ action('Admin\GuvohnomaController@returnindex',[]) }}"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-calendar-check-o"></i></span>
                                Guvohnoma berish</a>
                            </li>

                        </ul>
                    </li> --}} -->
                   
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Xabarlar</p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{ route('chat.index') }}">
                                <p>
                                    Kelgan xabarlar
                                </p>
                            </a>
                            <a  href="{{action('Admin\ChatController@send',[])}}">
                                <p>
                                    Jo'natilgan xabarlar
                                </p>
                            </a>
                        </div>
                    </li>
                     <!-- <li>
                        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-desktop"></i></span> Shablon Hisobotlar </a>
                        <ul>
                            <li>
                                <a href="{{action('Admin\TestController@hisobotfilialshablonadmin',[])}}"><span class="nav-icon-hexa text-orange-100"><i
                                            class="fa fa-calendar-check-o"></i></span>Filiallar bo`yicha</a>
                            </li>
                           <li>
                                <a href="{{ action('Admin\TestController@moststudentres',[]) }}"><span class="nav-icon-hexa text-orange-100">
                                    <i
                                            class="fa fa-calendar-check-o"></i></span>Eng yaxshi talabalar</a>
                            </li>
                             <li>
                                <a href="{{ action('Admin\TestController@mostteacherres',[]) }}"><span class="nav-icon-hexa text-orange-100"><i
                                            class="fa fa-calendar-check-o"></i></span>Eng yaxshi o`qituvchilar</a>
                            </li> -->
                        </ul>
                    </li>
                    {{-- @if(0)
                    <li>
                        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-pencil"></i></span>Nazorat testlari</a>
                        <ul>
                            <li>
                                <a href="{{ route('branch.index') }}"><span class="nav-icon-hexa">F</span>Nazorat testni yaratish</a>
                            </li>
                            <li>
                            <li>
                                <a href="{{ route('branchadmin.index') }}"><span class="nav-icon-hexa">Q</span>Test natijalari</a></li>
                            <li>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-envelope-o"></i></span>Xabarlar</a>
                        <ul>
                            <li>
                                <a href="{{ route('chat.index') }}"><span class="nav-icon-hexa">T</span>Kelgan xabarlar</a></li>
                            <li>
                            <li>
                                <a href="{{action('Admin\ChatController@send',[])}}"><span class="nav-icon-hexa">T</span>Jo'natilgan
                                    xabarlar</a></li>
                            <li>
                        </ul>
                    </li>

                    @endif --}}
                    @endif
                     @if(\Auth::user()->role==5)
                     <li>
                        <a href="{{ route('paygroup.index') }}">
                           <svg width="20" height="20" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M18 4.17241C18 4.04598 17.9854 3.91667 17.9561 3.78448C17.9268 3.6523 17.8711 3.49713 17.7891 3.31897C17.707 3.1408 17.5664 2.97701 17.3672 2.82759C17.168 2.67816 16.9219 2.56322 16.6289 2.48276L3.91992 0C3.61523 0 3.33398 0.0747126 3.07617 0.224138C2.81836 0.373563 2.61328 0.574713 2.46094 0.827586C2.30859 1.08046 2.23242 1.35632 2.23242 1.65517V3.86207H1.66992C1.21289 3.87356 0.820312 4.04023 0.492188 4.36207C0.164063 4.68391 0 5.06897 0 5.51724V14.3448C0 14.8046 0.164063 15.1954 0.492188 15.5172C0.820312 15.8391 1.21875 16 1.6875 16H16.3125C16.7812 16 17.1797 15.8391 17.5078 15.5172C17.8359 15.1954 18 14.8046 18 14.3448V4.17241ZM3.35742 1.65517C3.35742 1.50575 3.40723 1.37931 3.50684 1.27586C3.60645 1.17241 3.73242 1.11494 3.88477 1.10345L16.2949 3.56897L16.251 3.64655L16.0752 3.80172L15.75 3.86207H3.35742V1.65517ZM16.875 14.3448C16.875 14.4943 16.8193 14.6236 16.708 14.7328C16.5967 14.842 16.4648 14.8966 16.3125 14.8966H1.6875C1.53516 14.8966 1.40332 14.842 1.29199 14.7328C1.18066 14.6236 1.125 14.4943 1.125 14.3448V5.51724C1.125 5.36782 1.18066 5.23851 1.29199 5.12931C1.40332 5.02011 1.53516 4.96552 1.6875 4.96552H15.75C16.0547 4.96552 16.3184 4.91667 16.541 4.81897C16.7637 4.72126 16.875 4.58621 16.875 4.41379V14.3448ZM3.36621 8.82759C3.05566 8.82759 2.79199 8.93678 2.5752 9.15517C2.3584 9.37356 2.25 9.63506 2.25 9.93966C2.25 10.2443 2.3584 10.5029 2.5752 10.7155C2.79199 10.9282 3.05566 11.0345 3.36621 11.0345C3.67676 11.0345 3.94336 10.9282 4.16602 10.7155C4.38867 10.5029 4.5 10.2443 4.5 9.93966C4.5 9.63506 4.38867 9.37356 4.16602 9.15517C3.94336 8.93678 3.67676 8.82759 3.36621 8.82759Z" fill="#5C6467"/>
                                </svg>
                                    <p> Ais to`lov</p>
                           
                        </a>
                     </li>
                     <?php $branchadmin = 'Test\Model\BranchAdmin'::where('user_id', Auth::user()->id)->first();
                            $branch = 'Test\Model\Branch'::where('id', $branchadmin->branch_id)->first();?>
                     @if($branch->checking != 1)
                     <li>
                        <a href="{{route('check_branch')}}">
                             <svg width="20" height="20" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.66699 1.5H6.66699C7.55105 1.5 8.39889 1.85119 9.02401 2.47631C9.64914 3.10143 10.0003 3.94928 10.0003 4.83333V16.5C10.0003 15.837 9.73693 15.2011 9.26809 14.7322C8.79925 14.2634 8.16337 14 7.50033 14H1.66699V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M18.3333 1.5H13.3333C12.4493 1.5 11.6014 1.85119 10.9763 2.47631C10.3512 3.10143 10 3.94928 10 4.83333V16.5C10 15.837 10.2634 15.2011 10.7322 14.7322C11.2011 14.2634 11.837 14 12.5 14H18.3333V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>    
                                    <p> Filial ma`lumotlarini tekshirish</p>
                            
                        </a>
                     </li>
                     @endif
                     <li>
                        <a href="{{ route('branch_about') }}">
                            <svg width="20" height="20" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.66699 1.5H6.66699C7.55105 1.5 8.39889 1.85119 9.02401 2.47631C9.64914 3.10143 10.0003 3.94928 10.0003 4.83333V16.5C10.0003 15.837 9.73693 15.2011 9.26809 14.7322C8.79925 14.2634 8.16337 14 7.50033 14H1.66699V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M18.3333 1.5H13.3333C12.4493 1.5 11.6014 1.85119 10.9763 2.47631C10.3512 3.10143 10 3.94928 10 4.83333V16.5C10 15.837 10.2634 15.2011 10.7322 14.7322C11.2011 14.2634 11.837 14 12.5 14H18.3333V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>    
                                    <p> Filial ma`lumotlari</p>
                            
                        </a>
                     </li>
                     <li>
                        <a href="{{ route('hisobot.index') }}">
                           <svg width="20" height="20" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.66699 1.5H6.66699C7.55105 1.5 8.39889 1.85119 9.02401 2.47631C9.64914 3.10143 10.0003 3.94928 10.0003 4.83333V16.5C10.0003 15.837 9.73693 15.2011 9.26809 14.7322C8.79925 14.2634 8.16337 14 7.50033 14H1.66699V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M18.3333 1.5H13.3333C12.4493 1.5 11.6014 1.85119 10.9763 2.47631C10.3512 3.10143 10 3.94928 10 4.83333V16.5C10 15.837 10.2634 15.2011 10.7322 14.7322C11.2011 14.2634 11.837 14 12.5 14H18.3333V1.5Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>    
                                    <p> Hisobotlar</p>
                            
                        </a>
                     </li>

                            <li>
                                    
                             <button>
                                <div>
                                    <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>    
                                    <p>Ta`lim</p>
                                </div>
                                <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                            <div class="li-link">
                                <a  href="{{ route('timetables.index') }}">
                                    <p>
                                        Dars jadvali
                                    </p>
                                </a>
                                <a  href="{{ route('monitoring.index') }}">
                                    <p>
                                        Monitoring
                                    </p>
                                </a>
                                <a  href="{{ route('mark.index') }}">
                                    <p>
                                        Baholash
                                    </p>
                                </a>
                                <a  href="{{ action('Admin\AttendanceController@student',[]) }}">
                                    <p>
                                        Barcha dars qoldirganlar ro'yxati
                                    </p>
                                </a>
                                <a  href="{{action('Admin\AttendanceController@index',[]) }}">
                                    <p>
                                        Guruhlar kesimida ro'yxati
                                    </p>
                                </a>
                                <a  href="{{action('Admin\StudentController@groupstudent2',[]) }}">
                                    <p>
                                        O'quvchilar Arxivi
                                    </p>
                                </a>
                            </div>
                        </li>
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Yakuniy test</p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{ route('test.index') }}">
                                <p>
                                   Yakuniy testga ruxsat berish
                                </p>
                            </a>
                            <a  href="{{ action('Admin\TestController@res',[]) }}">
                                <p>
                                    Yakuniy test statistikasi
                                </p>
                            </a>
                        </div>
                        
                    </li>

                    <li>
                            <button>
                                <div>
                                    <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>    
                                    <p>Hisoblar-kitob</p>
                                </div>
                                <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                            <div class="li-link">
                                <a  href="{{ route('payment.index') }}">
                                    <p>
                                        Barcha To'lovlar
                                    </p>
                                </a>
                                <a  href="{{ action('Admin\PaymentController@hisobotguruhadmin',[]) }}">
                                    <p>
                                        Umumiy hisobot
                                    </p>
                                </a>
                                <a  href="{{action('Admin\PaymentController@reggroup',[])}}">
                                    <p>
                                        Guruhlar kesimida hisoboti
                                    </p>
                                </a>
                                <a  href="{{ action('Admin\PaymentController@paygroup',[]) }}">
                                    <p>
                                        Guruxlar 3.1 Hisoboti
                                    </p>
                                </a>
                                <a  href="{{ action('Admin\PaymentController@owing',[]) }}">
                                    <p>
                                        Guruhlar kesimida qarzdorlar
                                    </p>
                                </a>
                                <a  href="{{ route('price.index') }}">
                                    <p>
                                        Ta'lim narxlari
                                    </p>
                                </a>
                            </div>
                        
                    </li>



                    @if(0)
                    <li>
                        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-pencil"></i></span>Nazorat testlari</a>
                        <ul>
                            <li>
                                <a href="{{ route('branch.index') }}"><span class="nav-icon-hexa">F</span>Nazorat testni yaratish</a>
                            </li>
                            <li>
                            <li>
                                <a href="{{ route('branchadmin.index') }}"><span class="nav-icon-hexa">Q</span>Test natijalari</a></li>
                            <li>
                            </li>
                        </ul>
                    </li>
                    @endif
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Chop qilish</p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{ action('Admin\PrintController@harakatindex',[]) }}">
                                <p>
                                   Hujjatlar
                                </p>
                            </a>
                            <a  href="{{ route('begin') }}">
                                <p>
                                   Buyruq boshlanishi
                                </p>
                            </a>
                        </div>
                        
                    </li>
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Guvohnomalar</p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{ route('decisions.index') }}">
                                <p>
                                   Guvohnoma chiqarish
                                </p>
                            </a>
                            <a  href="{{ route('licence.index') }}">
                                <p>
                                   Chiqarilgan guvohnomlar
                                </p>
                            </a>
                        </div>
                        
                       
                    </li>

                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Qo'shimcha</p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{ route('room.index') }}">
                                <p>
                                   Auditoriyalar
                                </p>
                            </a>
                            <a  href="{{ route('price.index') }}">
                                <p>
                                   Ta'lim narxlari
                                </p>
                            </a>
                            <a  href="{{ route('requisites.index') }}">
                                <p>
                                   Rekvizitlar
                                </p>
                            </a>
                        </div>
                        
                    </li>
                      <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Shablon Hisobotlar </p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{action('Admin\TestController@hisobotguruhshablonadmin',[])}}">
                                <p>
                                   Guruhlar bo`yicha
                                </p>
                            </a>
                            <a  href="{{ action('Admin\TestController@moststudentres',[]) }}">
                                <p>
                                   Eng yaxshi talabalar
                                </p>
                            </a>
                            <a  href="{{ action('Admin\TestController@mostteacherres',[]) }}">
                                <p>
                                   Eng yaxshi o`qituvchilar
                                </p>
                            </a>
                        </div>
                        
                    </li>
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Foydalanuvchilar </p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{ route('moderator.index') }}">
                                <p>
                                   Moderatorlar
                                </p>
                            </a>
                            <a  href="{{ route('teacher.index') }}">
                                <p>
                                   O'qituvchilar
                                </p>
                            </a>
                            <a  href="{{ route('accountant.index') }}">
                                <p>
                                  Hisobchilar
                                </p>
                            </a>
                            <a  href="{{ route('master.index') }}">
                                <p>
                                  Texnik Ustalar
                                </p>
                            </a>
                        </div>
                      
                    </li>
                    <li>
                        <button>
                            <div>
                                <svg width="20" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.33301 16.25C1.33301 15.6975 1.5525 15.1676 1.9432 14.7769C2.3339 14.3862 2.86381 14.1667 3.41634 14.1667H14.6663"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M3.41634 1.66667H14.6663V18.3333H3.41634C2.86381 18.3333 2.3339 18.1138 1.9432 17.7231C1.5525 17.3324 1.33301 16.8025 1.33301 16.25V3.75001C1.33301 3.19747 1.5525 2.66757 1.9432 2.27687C2.3339 1.88617 2.86381 1.66667 3.41634 1.66667V1.66667Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>    
                                <p>Xabarlar</p>
                            </div>
                            <svg class="nav-svg" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L6 6.5L11 1.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <div class="li-link">
                            <a  href="{{ route('chat.index') }}">
                                <p>
                                    Kelgan xabarlar
                                </p>
                            </a>
                            <a  href="{{action('Admin\ChatController@send',[])}}">
                                <p>
                                    Jo'natilgan xabarlar
                                </p>
                            </a>
                        </div>
                    </li>

                    @endif
                    <!-- ******************** -->
                                    <!-- ********** -->
                    <li class="mb-5">
                        <a href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M6.5 16.5H3.16667C2.72464 16.5 2.30072 16.3244 1.98816 16.0118C1.67559 15.6993 1.5 15.2754 1.5 14.8333V3.16667C1.5 2.72464 1.67559 2.30072 1.98816 1.98816C2.30072 1.67559 2.72464 1.5 3.16667 1.5H6.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M12.333 13.1666L16.4997 8.99998L12.333 4.83331"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M16.5 9H6.5"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <p>Tizimdan chiqish</p>
                            
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">

                                    {{ csrf_field() }}

                                </form>
                        </a>
                    </li>
                    <!-- *********** -->