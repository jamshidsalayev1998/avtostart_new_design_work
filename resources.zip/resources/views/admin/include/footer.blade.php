@if(0)
<div class="app-footer app-footer-default" id="footer" style="position: fixed; bottom: 0; z-index: 999;">

    <div class="app-footer-line darken">
        <div class="copyright wide text-center">&copy; @php echo date('Y') > 2018 ? 2018  . ' - ' . date('Y') : date('Y') @endphp
            <span style="text-transform: uppercase">{{ env('APP_NAME') }}</span>.
            All right reserved in the Uzbekistan and other countries.</div>
    </div>
</div>
@endif