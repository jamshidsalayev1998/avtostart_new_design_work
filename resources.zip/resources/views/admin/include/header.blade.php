<div class="app-header">

    
    <ul class="app-header-buttons">

        <li class="visible-mobile"><a href="#" class="btn btn-link btn-icon" data-sidebar-toggle=".app-sidebar.dir-left"><span class="icon-menu"></span></a></li>

        <li class="hidden-mobile"><a href="#" class="btn btn-link btn-icon" data-sidebar-minimize=".app-sidebar.dir-left"><span class="icon-menu"></span></a></li>

            <div class="siteheader__item siteheader__btn">
                @if(Auth::user()->role != 2020)
            <li style="list-style-type: none;" class="dropdown">

                <a style="font-size: 20px;" href="{{ action('Admin\ChatController@index',[]) }}">

                    <i class="fa fa-envelope-o"></i>
                    @php
                        $user = \Illuminate\Support\Facades\Auth::user();
                        $messages = \Test\Model\Chat::select(['test_sys_users.name', 'test_sys_chat.*'])
                        ->where('test_sys_chat.to_id', $user->id)->where('test_sys_chat.status', 0)
                        ->join('test_sys_users', 'test_sys_users.id', 'test_sys_chat.from_id')->get();

                        $message_cout = count($messages);
                    @endphp

                    @if($message_cout != 0)

                        <span class="badge bg-theme" style="background-color: red; margin-top: -11px; margin-left: -7px;">{{ $message_cout }}</span>

                    @endif

                </a>
            </li>
            @endif

        </div>

    </ul>

   <!--  <form class="app-header-search" action="" method="post">

        <input type="text" name="keyword" placeholder="Search">

    </form> -->





    <ul class="app-header-buttons pull-right">

        <li>

            <div class="contact contact-rounded contact-bordered contact-lg contact-ps-controls">

                <img 
                @if(\Auth::user()->image  === null) 
                src="/admin/img/user/no-image.png" @endif

                 @if(\Auth::user()->image != null) 
                src="{{ asset(\Auth::user()->image) }}" @endif

                 alt="{{ \Auth::user()->name }}">

                <div class="contact-container">

                    <a href="#">{{\Auth::user()->name}}</a>

                    <span>{{\Auth::user()->getRole()}}</span>

                </div>

                <div class="contact-controls">

                    <div class="dropdown">

                        <button type="button" class="btn btn-default btn-icon" data-toggle="dropdown"><span class="icon-cog"></span></button>

                        <ul class="dropdown-menu dropdown-left">
                            @if(Auth::user()->role != 2020)
                            <li><a href="{{ route('settings') }}"><span class="icon-cog"></span> Sozlamalar</a></li>

                            <li class="divider"></li>

                            <li>

                                @php $d =count(\Test\Model\Chat::where(['status' => 0, 'to_id' => \Auth::user()->id])->get()) @endphp

                                <form id="new-messages" action="{{ route('support.index') }}" method="post">

                                    {{ csrf_field() }}

                                    <input type="hidden" name="receiver_id" id="receiver_id" value="{{ Test\User::where('role','7')->first()->id }}">

                                    <a class="btn btn-default form-control" href="{{action('Admin\ChatController@index',[])}}" style="border: none;text-align: left">

                                        <span class="icon-envelope"></span><span style="margin-top: 7px"> Xabarlar</span>

                                        @if ($d > 0)

                                        <span class="label label-danger pull-right" style="margin-top: 7px;">+{{$d}}</span>

                                        @endif

                                    </a>

                                </form>

                            </li>
                            @endif

                            <li>

                                <a href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();">

                                    <span class="fa fa-power-off"></span> Chiqish

                                </a>



                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">

                                    {{ csrf_field() }}

                                </form>

                            </li>

                        </ul>

                    </div>

                </div>

            </div>

        </li>

    </ul>

</div>