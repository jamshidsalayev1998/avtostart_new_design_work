<ul>
    <li class="title">Asosiy</li>
    <li><a href="{{ route('admin') }}"><span class="nav-icon-hexa text-bloody-100"><i class="fa fa-home"></i></span>
            Bosh sahifa</a></li>
            @if(Auth::user()->role != 2020)
                <li><a href="{{ route('help') }}"><span class="nav-icon-hexa text-bloody-100"><i class="fa fa-question"></i></span>
            Yordam</a></li>
            @endif
    @if(Auth::user()->role == 2020)
    <li>
        <a href="{{ route('cov.index') }}">
            <span class="nav-icon-hexa text-bloody-100">
                <i class="fa fa-plus"></i>
            </span>
            Bemorlar
        </a>
    </li>
    <li>
        <a href="{{ route('cov.index_1') }}">
            <span class="nav-icon-hexa text-bloody-100">
                1
            </span>
            1-darajali aloqada bo`lganlar
        </a>
    </li>
    <li>
        <a href="{{ route('cov.index_2') }}">
           <span class="nav-icon-hexa text-bloody-100">
                2
            </span>
            2-darajali aloqada bo`lganlar
        </a>
    </li>
    <li>
        <a href="{{ route('cov.hisobot') }}">
           <span class="nav-icon-hexa text-bloody-100">
                H
            </span>
            Hisobot
        </a>
    </li>
    @endif
    @if(\Auth::user()->role==7)
    <li>
        <a href="#">
            <span class="nav-icon-hexa text-bloody-100">
                <i class="fa fa-question"></i>
            </span>
            Yordam
        </a>
    </li>
    @endif
    @if(Auth::user()->role==7777)
    <li>
    	<a href="{{ route('hisobot.index') }}">
            <span class="nav-icon-hexa text-bloody-100">H</span>
            Oxirgi chorak hisobotlari
        </a>
    </li>
    <li>
        <a href="{{ route('hisobot.sort') }}">
            <span class="nav-icon-hexa text-bloody-100">HKY</span>
            Hisobotlar chorak va yil bo`yicha
        </a>
    </li>
    @endif
    @if(\Auth::user()->role==7&&\Auth::user()->auth_key==NULL)

    <li>
        <a href="{{ route('paygroup.index') }}">
            <span class="nav-icon-hexa text-bloody-100">A</span>
            Ais to`lov
        </a>
     </li>
{{--      <li>
        <a href="{{route('nochecks')}}">
            <span class="nav-icon-hexa text-bloody-100"><i class="fa fa-check"></i></span>
            Tasdiqlanmagan to`lovlar
        </a>
     </li> --}}

    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-book"></i></span>Darsliklar</a>
        <ul>
            <li>
                <a href="{{ route('lesson.index') }}"><span class="nav-icon-hexa">T</span>Toifalar</a></li>
            <li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-car"></i></span>Ta'lim turlari</a>
        <ul>
            <li>
                <a href="{{ route('courses.index') }}"><span class="nav-icon-hexa">TT</span>Ta'lim turlari</a></li>
            <li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-suitcase"></i></span> Hisobotlar </a>
        <ul>
            <li><a href="{{ action('Admin\PaymentController@hisobotviloyat',[]) }}"><span class="nav-icon-hexa">H</span>Umumiy hisobot</a></li>
            <li><a href="{{ action('Admin\PaymentController@hisobotresguruh',[]) }}"><span class="nav-icon-hexa">H</span>Yillik guruh hisoboti</a></li>
            <li><a href="{{ action('Admin\PaymentController@hisobotresstudent',[]) }}"><span class="nav-icon-hexa">H</span>Yillik o`quvchilar hisobot</a></li>

            <li><a href="{{ action('Admin\PaymentController@pay',[]) }}"><span class="nav-icon-hexa">H</span>Guruhlar vaqt oraligida</a></li>

                    <li><a href="{{ action('Admin\PaymentController@regionpay',[]) }}"><span class="nav-icon-hexa">H</span>Guruhlar bo'yicha to`lovlar</a></li>
            <li><a href="{{ action('Admin\AttendanceController@student',[]) }}"><span
                        class="nav-icon-hexa">BR</span>Barcha dars qoldirganlar ro'yxati</a></li>
            <li><a href="{{ action('Admin\AttendanceController@region',[]) }}"><span
                        class="nav-icon-hexa">VR</span>Viloyat kesimida ro'yxati</a></li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-map-marker"></i></span> Hududlar </a>
        <ul>
            <li><a href="{{ route('region.index') }}"><span class="nav-icon-hexa">V</span> Viloyatlar</a></li>
            <li><a href="{{ route('branch.index') }}"><span class="nav-icon-hexa">F</span> Filiallar</a></li>
            <li><a href="{{route('withoutdir')}}"><span class="nav-icon-hexa">F</span>Rahbarsiz filiallar</a></li>
            <li><a href="{{ route('group.index') }}"><span class="nav-icon-hexa">G</span> Barcha guruhlar</a></li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-graduation-cap"></i></span>O'quvchilar</a>
        <ul>
            <li>
                <a href="{{ route('student.index') }}"><span class="nav-icon-hexa">BR</span>Barcha o'quvchilar
                    ro'yxati</a></li>
            <li>
            <li>
                <a href="{{action('Admin\StudentController@regionstudent',[])}}"><span class="nav-icon-hexa">AR</span>Arxivlangan o'quvchilar
                    ro'yxati</a></li>
            <li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-user"></i></span>Foydalanuvchilar</a>
        <ul>
            <li>
                <a href="{{ route('regionadmin.index') }}"><span class="nav-icon-hexa">VA</span> Viloyat Rahbarlari</a>
            </li>
            <li>
            <li>
                <a href="{{ route('branchadmin.index') }}"><span class="nav-icon-hexa">O'</span>Filial rahbarlari</a>
            </li>
            <li>
                    <a href="{{ action('Admin\RegionAdminController@managerindex',[])}}"><span class="nav-icon-hexa">M</span>Content Manager</a></li>
            <li>

            <li>
                <a href="{{ route('moderator.index') }}"><span class="nav-icon-hexa">O'</span> Moderatorlar</a></li>
            <li>
            <li>
                <a href="{{ route('teacher.index') }}"><span class="nav-icon-hexa">M</span> O'qituvchilar</a></li>
            <li>
            <li>
                <a href="{{ route('accountant.index') }}"><span class="nav-icon-hexa">M</span> Hisobchilar</a></li>
            <li>

        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-calculator"></i></span>To'lovlar</a>
        <ul>
            <li>
                <a href="{{ route('payment.index') }}"><span class="nav-icon-hexa">F</span>Hududlar</a></li>

                <li><a href="{{ action('Admin\PaymentController@regionpay2',[]) }}"><span class="nav-icon-hexa">H</span>
                  Qarzdorlar</a></li>
            <li>
                <a href="{{action('Admin\PaymentController@list',[])}}"><span class="nav-icon-hexa">TT</span>To'lov
                    tarixi</a>
            </li>

            <li>
            </li>
        </ul>
    </li>

    <li>
        <a href="{{ route('permissions.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-calendar"></i></span>Ruxsat berishlar</a>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-calendar-check-o"></i></span> Yakuniy test </a>
        <ul>
            <li>
                <a href="{{ route('test.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                            class="fa fa-calendar-check-o"></i></span>Yakuniy testga ruxsat berish</a>
            </li>
            <li>
                <a href="{{ action('Admin\TestController@res',[]) }}"><span class="nav-icon-hexa text-orange-100"><i
                            class="fa fa-calendar-check-o"></i></span>Yakuniy test statistika</a>
            </li>
        </ul>
    </li>
     <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-desktop"></i></span> Shablon Hisobotlar </a>
        <ul>
            <li>
                <a href="{{action('Admin\TestController@hisobotresshablon',[])}}"><span class="nav-icon-hexa text-orange-100"><i
                            class="fa fa-calendar-check-o"></i></span>Viloyatlar boyicha</a>
            </li>
            <li>
                <a href="{{ action('Admin\TestController@moststudentres',[]) }}"><span class="nav-icon-hexa text-orange-100">
                    <i
                            class="fa fa-calendar-check-o"></i></span>Eng yaxshi talabalar</a>
            </li>
             <li>
                <a href="{{ action('Admin\TestController@mostteacherres',[]) }}"><span class="nav-icon-hexa text-orange-100"><i
                            class="fa fa-calendar-check-o"></i></span>Eng yaxshi o`qituvchilar</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-cog"></i></span> Sozlamalar </a>
        <ul>
            <li>
                <a href="{{ route('languages.index') }}"><span class="nav-icon-hexa">T</span> Til</a>
            <li>
            <li>
                <a href="{{ route('exceptions.index') }}"><span class="nav-icon-hexa">D</span> Bayram kunlari</a>
            <li>
            <li>
                <a href="{{ route('menu.index') }}"><span class="nav-icon-hexa">M</span> Menu</a></li>
            <li>
            <li>
                <a href="{{ route('keys.index') }}"><span class="nav-icon-hexa">K</span> Keys</a></li>
            <li>
            <li>
                <a href="{{ route('developing.index') }}"><span class="nav-icon-hexa">DM</span> Developing Mode</a></li>
            <li>
        </ul>
    </li>

    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-envelope-o"></i></span>Xabarlar</a>
        <ul>
            <li>
                <a href="{{ route('chat.index') }}"><span class="nav-icon-hexa">T</span>Kelgan xabarlar</a></li>
            <li>
            <li>
                <a href="{{action('Admin\ChatController@send',[])}}"><span class="nav-icon-hexa">T</span>Jo'natilgan
                    xabarlar</a></li>
            <li>
        </ul>
    </li>
    @endif
        @if(\Auth::user()->role==7&&\Auth::user()->auth_key==-7)
          <li>
     <li><a href="{{ action('Admin\PaymentController@hisobotviloyat',[]) }}"><span class="nav-icon-hexa">H</span>Umumiy 3.1 hisobot</a></li>

            <li><a href="{{ action('Admin\PaymentController@pay',[]) }}"><span class="nav-icon-hexa">H</span>Guruhlar
                    bo'yicha hisobot</a></li>
                    <li><a href="{{ action('Admin\PaymentController@regionpay',[]) }}"><span class="nav-icon-hexa">H</span>Guruhlar
                    bo'yicha pul hisobot</a></li>


    </li>
                 <li><a href="{{ action('Admin\PaymentController@hisobotresguruh',[]) }}"><span class="nav-icon-hexa">H</span>Yillik guruh hisoboti</a></li>
            <li><a href="{{ action('Admin\PaymentController@hisobotresstudent',[]) }}"><span class="nav-icon-hexa">H</span>Yillik o`quvchilar hisobot</a></li>

            <li>
                <a href="{{ route('payment.index') }}"><span class="nav-icon-hexa">F</span>Hududlar</a></li>

                <li><a href="{{ action('Admin\PaymentController@regionpay2',[]) }}"><span class="nav-icon-hexa">H</span>
                  Qarzdorlar</a></li>




            @endif
    @if(\Auth::user()->role==6)
     <li>
         <a href="{{route('hisobot.index')}}">
            <span class="nav-icon-hexa text-bloody-100">H</span>
             Hisobotlar
         </a>
     </li>
     {{-- <li>
        <a href="{{ route('paygroup.index') }}">
            <span class="nav-icon-hexa text-bloody-100">A</span>
            Ais to`lov
        </a>
     </li> --}}
<!--
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-graduation-cap"></i></span>O'quvchilar</a>
        <ul>
            <li>
                <a href="{{ route('group.index') }}"><span class="nav-icon-hexa">G</span>Guruhlar</a></li>
            <li>
            <li>
                <a href="{{ route('student.index') }}"><span class="nav-icon-hexa">BS</span>Barcha O'quvchilar</a></li>
            <li>
            <li>
                <a href="{{action('Admin\StudentController@branchstudent2',[])}}"><span class="nav-icon-hexa">A</span>O'quvchilar Arxivi</a></li>
            <li>
            </li>
        </ul>
    </li>
 -->    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Testlar tahlili</a>
        <ul>

            <li>
                <a href="{{ action('Admin\TestController@res',[]) }}"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-calendar-check-o"></i></span>
                    Avto maktablar kesimida test statistikasi</a>
            </li>

        </ul>
    </li>
   <!--  {{-- <li>
        <a href="{{ route('permissions.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-calendar"></i></span>Ruxsat berishlar</a>
    </li> --}} -->
    <!-- <li>
                <a href="{{ route('teacher.index') }}"><span class="nav-icon-hexa">FD</span>Avto maktablarda faoliyat yurituvci o'qituvchilar</a></li>
            <li>
     --><li>

        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-user"></i></span>Avto maktablar</a>
        <ul>
            <li>
                <a href="{{ route('branch.index') }}"><span class="nav-icon-hexa">F</span>Avto maktablar haqida</a></li>
            <li>
            <li>
                <a href="{{ route('branchadmin.index') }}"><span class="nav-icon-hexa">FD</span>Avto maktab direktorlari</a>
            </li>
            <li>

            </li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-calculator"></i></span>Hisobotlar</a>
        <!-- <ul>
            <li>
                <a href="{{ route('payment.index') }}"><span class="nav-icon-hexa">F</span>Barcha To'lovlar</a></li>
            <li>
            <li>

                <a href="{{action('Admin\PaymentController@payregs',[])}}"><span class="nav-icon-hexa">F</span>Guruhlar Viloyat</a>
                </li>
            <li><a href="{{ action('Admin\PaymentController@hisobotfilialadmin',[]) }}"><span class="nav-icon-hexa">H</span>Umumiy hisobot</a></li>

                <li>

                    <a href="{{action('Admin\PaymentController@branchpays',[])}}"><span class="nav-icon-hexa">F</span>Yillik Tushum Hisobot</a>
                    </li>

            <li>
                <a href="{{action('Admin\PaymentController@branchpays',[])}}"><span class="nav-icon-hexa">Q</span>Qarzdorlar </a></li>
            <li>
                <a href="{{action('Admin\PaymentController@list',[])}}"><span class="nav-icon-hexa">TT</span>To'lov tarix</a>
            </li> -->

    </li>
    <!-- <li><a href="{{ action('Admin\PaymentController@hisobotfilialstudentadmin',[]) }}"><span class="nav-icon-hexa">H</span>Umumiy  o`quvchilar hisoboti</a></li>
            <li><a href="{{ action('Admin\PaymentController@hisobotfilialguruhadmin',[]) }}"><span class="nav-icon-hexa">H</span>Umumiy guruh  hisobot</a></li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Dars
            qoldirganlar</a>
        <ul>
            <li>
                <a href="{{action('Admin\AttendanceController@student',[])}}"><span
                        class="nav-icon-hexa">BR</span>Eng ko`p qoldirganlar </a></li>
            <li>
                <a href="{{action('Admin\AttendanceController@index',[])}}"><span
                        class="nav-icon-hexa">TR</span>Filiallar kesimida</a></li>
            <li>
        </ul>
    </li>
    {{-- <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Guvohnoma berish
            </a>
        <ul>

       <li>
                <a href="{{ action('Admin\GuvohnomaController@returnindex',[]) }}"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-calendar-check-o"></i></span>
                Guvohnoma berish</a>
            </li>

        </ul>
    </li> --}} -->
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-envelope-o"></i></span>Xabarlar</a>
        <ul>
            <li>
                <a href="{{ route('chat.index') }}"><span class="nav-icon-hexa">T</span>Kelgan xabarlar</a></li>
            <li>
            <li>
                <a href="{{action('Admin\ChatController@send',[])}}"><span class="nav-icon-hexa">T</span>Jo'natilgan
                    xabarlar</a></li>
            <li>
        </ul>
    </li>
     <!-- <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-desktop"></i></span> Shablon Hisobotlar </a>
        <ul>
            <li>
                <a href="{{action('Admin\TestController@hisobotfilialshablonadmin',[])}}"><span class="nav-icon-hexa text-orange-100"><i
                            class="fa fa-calendar-check-o"></i></span>Filiallar bo`yicha</a>
            </li>
           <li>
                <a href="{{ action('Admin\TestController@moststudentres',[]) }}"><span class="nav-icon-hexa text-orange-100">
                    <i
                            class="fa fa-calendar-check-o"></i></span>Eng yaxshi talabalar</a>
            </li>
             <li>
                <a href="{{ action('Admin\TestController@mostteacherres',[]) }}"><span class="nav-icon-hexa text-orange-100"><i
                            class="fa fa-calendar-check-o"></i></span>Eng yaxshi o`qituvchilar</a>
            </li> -->
        </ul>
    </li>
    @if(0)
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-pencil"></i></span>Nazorat testlari</a>
        <ul>
            <li>
                <a href="{{ route('branch.index') }}"><span class="nav-icon-hexa">F</span>Nazorat testni yaratish</a>
            </li>
            <li>
            <li>
                <a href="{{ route('branchadmin.index') }}"><span class="nav-icon-hexa">Q</span>Test natijalari</a></li>
            <li>
            </li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-envelope-o"></i></span>Xabarlar</a>
        <ul>
            <li>
                <a href="{{ route('chat.index') }}"><span class="nav-icon-hexa">T</span>Kelgan xabarlar</a></li>
            <li>
            <li>
                <a href="{{action('Admin\ChatController@send',[])}}"><span class="nav-icon-hexa">T</span>Jo'natilgan
                    xabarlar</a></li>
            <li>
        </ul>
    </li>

    @endif
    @endif
    @if(\Auth::user()->role==5)
     <li>
        <a href="{{ route('paygroup.index') }}">
            <span class="nav-icon-hexa text-bloody-100">A</span>
            Ais to`lov
        </a>
     </li>
     <?php $branchadmin = 'Test\Model\BranchAdmin'::where('user_id', Auth::user()->id)->first();
$branch = 'Test\Model\Branch'::where('id', $branchadmin->branch_id)->first();?>
     @if($branch->checking != 1)
     <li>
        <a href="{{route('check_branch')}}">
            <span class="nav-icon-hexa text-bloody-100">Ch</span>
            Filial ma`lumotlarini tekshirish
        </a>
     </li>
     @endif
     <li>
        <a href="{{ route('branch_about') }}">
            <span class="nav-icon-hexa text-bloody-100">H</span>
            Filial ma`lumotlari
        </a>
     </li>
     <li>
        <a href="{{ route('hisobot.index') }}">
            <span class="nav-icon-hexa text-bloody-100">H</span>
            Hisobotlar
        </a>
     </li>

            <li>
                <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Ta`lim</a>
        <ul>

            <li>
                <a href="{{ route('student.index') }}"><span class="nav-icon-hexa">BS</span>O'quvchilar
                    ro'yxati</a></li>
            <li>
            <li>
                <a href="{{ route('group.index') }}"><span class="nav-icon-hexa">G</span>Guruhlar</a></li>
                 <li>
        <a href="{{ route('timetables.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-th"></i></span>Dars jadvali</a>
    </li>
    <li>
        <a href="{{ route('monitoring.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-times"></i></span>Monitoring</a>
    </li>

    <li>
        <a href="{{ route('mark.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-check"></i></span>Baholash</a>
    </li>
            <li>
                <a href="{{action('Admin\AttendanceController@student',[])}}"><span
                        class="nav-icon-hexa">BR</span>Barcha dars qoldirganlar ro'yxati</a></li>
            <li>
                <a href="{{action('Admin\AttendanceController@index',[])}}"><span
                        class="nav-icon-hexa">GR</span>Guruhlar kesimida ro'yxati</a></li>
            <li>
           <!--  <li>
                <a href="{{action('Admin\StudentController@groupstudent2',[])}} "><span class="nav-icon-hexa">A</span>O'quvchilar Arxivi</a></li>
            <li> -->
            </li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Yakuniy test
            </a>
        <ul>
       <li>
        <a href="{{ route('test.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-th"></i></span>Yakuniy testga ruxsat berish</a>
    </li>
    <li>
        <a href="{{ action('Admin\TestController@res',[]) }}"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-calendar-check-o"></i></span>Yakuniy test statistikasi</a>
    </li>

        </ul>
    </li>

    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-calculator"></i></span>Hisoblar-kitob</a>
        <ul>
            <li>
                <a href="{{ route('payment.index') }}"><span class="nav-icon-hexa">F</span>Barcha To'lovlar</a></li>
                   <li><a href="{{ action('Admin\PaymentController@hisobotguruhadmin',[]) }}"><span class="nav-icon-hexa">H</span>Umumiy hisobot</a></li>
        <li>
            <a href="{{action('Admin\PaymentController@reggroup',[])}}"><span class="nav-icon-hexa">F</span>Guruhlar kesimida hisoboti</a>
                               </li>
                          <li>
                                <a href="{{ action('Admin\PaymentController@paygroup',[]) }}"><span
                                        class="nav-icon-hexa">Q</span>Guruxlar 3.1 Hisoboti</a></li>
            <li>
                <a href="{{ action('Admin\PaymentController@owing',[]) }}"><span
                        class="nav-icon-hexa">Q</span> Guruhlar kesimida qarzdorlar</a></li>

            <li>
            <li>
                <a href="{{ route('price.index') }}"><span class="nav-icon-hexa">Q</span>Ta'lim narxlari</a></li>
            <li>
            <li>
            </li>
        </ul>
    </li>



    @if(0)
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-pencil"></i></span>Nazorat testlari</a>
        <ul>
            <li>
                <a href="{{ route('branch.index') }}"><span class="nav-icon-hexa">F</span>Nazorat testni yaratish</a>
            </li>
            <li>
            <li>
                <a href="{{ route('branchadmin.index') }}"><span class="nav-icon-hexa">Q</span>Test natijalari</a></li>
            <li>
            </li>
        </ul>
    </li>
    @endif
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-file-pdf-o"></i></span>Chop qilish</a>
        <ul>
        	            <li>
                <a  href="{{ action('Admin\PrintController@harakatindex',[]) }}"><span class="nav-icon-hexa">G</span>Hujjatlar</a></li>
            <li>
                <a href="{{ route('begin') }}"><span class="nav-icon-hexa">BB</span>Buyruq boshlanishi</a></li>
            <li>

            </li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="icon-license"></i></span>Guvohnomalar</a>
        <ul>
            <li>
                <a href="{{ route('decisions.index') }}"><span class="nav-icon-hexa">G</span>Guvohnoma chiqarish</a>
            </li>
            <li>
            <li>
                <a href="{{ route('licence.index') }}"><span class="nav-icon-hexa">G</span>Chiqarilgan guvohnomlar</a>
            </li>
            <li>
            </li>
        </ul>
    </li>

    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="icon-plus-circle"></i></span>Qo'shimcha</a>
        <ul>
            <li>
                <a href="{{ route('room.index') }}"><span class="nav-icon-hexa">A</span>Auditoriyalar</a></li>
            <li>
            <li>
                <a href="{{ route('price.index') }}"><span class="nav-icon-hexa">T</span>Ta'lim narxlari</a></li>
            <li>
            <li>
                <a href="{{ route('requisites.index') }}"><span class="nav-icon-hexa">R</span>Rekvizitlar</a></li>
            <li>
            </li>
        </ul>
    </li>
      <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-desktop"></i></span> Shablon Hisobotlar </a>
        <ul>
            <li>
                <a href="{{action('Admin\TestController@hisobotguruhshablonadmin',[])}}"><span class="nav-icon-hexa text-orange-100"><i
                            class="fa fa-calendar-check-o"></i></span>Guruhlar bo`yicha</a>
            </li>
            <li>
                <a href="{{ action('Admin\TestController@moststudentres',[]) }}"><span class="nav-icon-hexa text-orange-100">
                    <i
                            class="fa fa-calendar-check-o"></i></span>Eng yaxshi talabalar</a>
            </li>
             <li>
                <a href="{{ action('Admin\TestController@mostteacherres',[]) }}"><span class="nav-icon-hexa text-orange-100"><i
                            class="fa fa-calendar-check-o"></i></span>Eng yaxshi o`qituvchilar</a>
            </li>
        </ul>
    </li>
        <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-user"></i></span>Foydalanuvchilar</a>
        <ul>
            <li>
                <a href="{{ route('moderator.index') }}"><span class="nav-icon-hexa">F</span>Moderatorlar</a></li>
            <li>
            <li>
                <a href="{{ route('teacher.index') }}"><span class="nav-icon-hexa">FD</span>O'qituvchilar</a></li>
            <li>
            <li>
                <a href="{{ route('accountant.index') }}"><span class="nav-icon-hexa">FD</span>Hisobchilar</a></li>
                <li>
                <a href="{{ route('master.index') }}"><span class="nav-icon-hexa">FD</span>Texnik Ustalar</a></li>
            <li>
            </li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-envelope-o"></i></span>Xabarlar</a>
        <ul>
            <li>
                <a href="{{ route('chat.index') }}"><span class="nav-icon-hexa">T</span>Kelgan xabarlar</a></li>
            <li>
            <li>
                <a href="{{action('Admin\ChatController@send',[])}}"><span class="nav-icon-hexa">T</span>Jo'natilgan
                    xabarlar</a></li>
            <li>
        </ul>
    </li>

    @endif

    @if(\Auth::user()->role==4)


       <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-envelope-o"></i></span>Ta`lim</a>
        <ul>
             <li>
                <a href="{{ route('student.index') }}"><span class="nav-icon-hexa">BO</span>Barcha O'quvchilar</a>
            </li>
			<li>
                <a href="{{ route('group.index') }}"><span class="nav-icon-hexa">G</span>Guruhlar</a>
            </li>
                 <li>
        <a href="{{ route('timetables.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-th"></i></span>Dars jadvali</a>
    		</li>
             <li>
        <a href="{{ route('monitoring.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-times"></i></span>Monitoring</a>
   			 </li>
   			    <li>
                <a href="{{action('Admin\AttendanceController@student',[])}}"><span
                        class="nav-icon-hexa">BR</span>Barcha dars qoldirganlar ro'yxati</a></li>
            <li>
                <a href="{{action('Admin\AttendanceController@index',[])}}"><span
                        class="nav-icon-hexa">GR</span>Guruhlar kesimida ro'yxati</a></li>
        </ul>
    </li>
    	   <li>
    	<a href="#"><span class="nav-icon-hexa text-orange-100"><i
    		class="fa fa-calculator"></i></span>Hisoblar-kitob</a>
    		<ul>
                   <li>
            <a href="{{action('Admin\PaymentController@reggroup',[])}}"><span class="nav-icon-hexa">F</span>Guruhlar Hisoboti</a>
      </li>
    			<li>
    				<a href="{{ action('Admin\PaymentController@owing',[]) }}"><span
    					class="nav-icon-hexa">Q</span>Qarzdorlar</a></li>
    					<li>
    						<a href="{{ action('Admin\PaymentController@paygroup',[]) }}"><span
    							class="nav-icon-hexa">Q</span>Guruxlar 3.1 Hisoboti</a></li>
    							<li>
    								<li>
    							<a href="{{ route('price.index') }}"><span class="nav-icon-hexa">Q</span>Ta'lim narxlari</a></li>

    								</ul>
    					</li>
    		    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Test
            </a>
        <ul>
       <li>
        <a href="{{ route('test.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-th"></i></span>Testga ruxsat berish</a>
    </li>
    <li>
        <a href="{{ action('Admin\TestController@res',[]) }}"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-calendar-check-o"></i></span>Guruhlar kesimida test statistika</a>
    </li>

        </ul>
    </li>


    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-file-pdf-o"></i></span>Chop qilish</a>
        <ul>
        	            <li>
                <a href="{{ route('group.index') }}"><span class="nav-icon-hexa">G</span>Hujjatlar</a></li>
            <li>
                <a href="{{ route('begin') }}"><span class="nav-icon-hexa">BB</span>Buyruq boshlanishi</a></li>
            <li>
            <li>
                <a href="{{ route('end') }}"><span class="nav-icon-hexa">BT</span>Buyruq yakunlanishi</a></li>
            <li>
            </li>
        </ul>
    </li>

    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-pencil"></i></span>Foydalanuvchilar</a>
        <ul>
            <li>
                <a href="{{ route('teacher.index') }}"><span class="nav-icon-hexa">BS</span>O'qituvchilar</a></li>
            <li>
            <li>
                <a href="{{ route('accountant.index') }}"><span class="nav-icon-hexa">BS</span>Hisobchilar</a></li>
            <li>
            <li>
                <a href="{{ route('student.index') }}"><span class="nav-icon-hexa">BS</span>O'quvchilar</a></li>
            <li>
        </ul>
    </li>


    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="icon-plus-circle"></i></span>Qo'shimcha</a>
        <ul>
            <li>
                <a href="{{ route('room.index') }}"><span class="nav-icon-hexa">A</span>Auditoriyalar</a></li>
            <li>


            <li>
                <a href="{{ route('requisites.index') }}"><span class="nav-icon-hexa">R</span>Rekvizitlar</a>
            </li>
            <li>
            </li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-envelope-o"></i></span>Xabarlar</a>
        <ul>
            <li>
                <a href="{{ route('chat.index') }}"><span class="nav-icon-hexa">T</span>Kelgan xabarlar</a></li>
            <li>
            <li>
                <a href="{{action('Admin\ChatController@send',[])}}"><span class="nav-icon-hexa">T</span>Jo'natilgan
                    xabarlar</a></li>
            <li>
        </ul>
    </li>
    @endif
    @if(\Auth::user()->role==3)
   <li>
        <a href="{{ url('http://study.vatanparvar.uz')  }}"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Elektron o`quv qo`llanmaga o`tish</a>

    </li>
    <li>
        <a href="{{ route('group.index') }}"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Guruhlar</a>

    </li>
  <li>
        <a href="{{ action('Admin\PaymentController@owing',[]) }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-calculator"></i></span>Qarzdorlar</a>

    </li>
    <li>
        <a href="{{ route('monitoring.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-times"></i></span>Monitoring</a>
    </li>

    <li>
        <a href="{{ route('mark.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-check"></i></span>Baholash</a>
    </li>
    <li>
        <a href="{{ route('timetables.index') }}"><span class="nav-icon-hexa text-orange-100"><i
                    class="fa fa-th"></i></span>Dars jadvali</a>
    </li>
        <li>
        <a href="{{ action('Admin\TestController@res',[]) }}"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-calendar-check-o"></i></span>Guruhlar kesimida test statistika</a>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-envelope-o"></i></span>Xabarlar</a>
        <ul>
            <li>
                <a href="{{ route('chat.index') }}"><span class="nav-icon-hexa">T</span>Kelgan xabarlar</a></li>
            <li>
            <li>
                <a href="{{action('Admin\ChatController@send',[])}}"><span class="nav-icon-hexa">T</span>Jo'natilgan
                    xabarlar</a></li>
            <li>
        </ul>
    </li>
    @endif
    @if(\Auth::user()->role==2)
     <li>
        <a href="{{ route('paygroup.index') }}">
            <span class="nav-icon-hexa text-bloody-100">A</span>
            Ais to`lov
        </a>
     </li>

         <li>
     <a href="{{ route('payment.index') }}"><span class="nav-icon-hexa" style="color: white;">BT</span>Barcha to'lovlar</a>
        </li>
         <li>
       <a href="{{ route('price.index') }}"><span class="nav-icon-hexa">Q</span>Ta'lim narxlari</a>
   </li>
    <li>
                       <a href="{{ action('Admin\PaymentController@reggroup',[]) }}"><span
                                        class="nav-icon-hexa" style="color: white;">GH</span>Guruxlar Hisoboti</a></li>
        <li>
                       <a href="{{ action('Admin\PaymentController@paygroup',[]) }}"><span
                                        class="nav-icon-hexa" style="color: white;">GPH</span>Guruxlar 3.1 Hisoboti</a></li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Qo'shimcha</a>
        <ul>
               <li>
     <a href="{{route('sreturn.index')}}"><span
                        class="nav-icon-hexa">Q</span>Pul qaytarish (Chetlashtirish)</a>
        </li>

            <li>
            <li>
                <a href="{{ route('group.index') }}"><span class="nav-icon-hexa">G</span>Guruhlar</a></li>
            <li>

            <li>
                <a href="{{ action('Admin\PaymentController@owing',[]) }}"><span class="nav-icon-hexa">A</span>Qarzdorlar</a></li>
            <li>
                <a href="{{ route('price.index') }}"><span class="nav-icon-hexa">T</span>Ta'lim narxlari</a>
            </li>

            <li>
                <a href="{{ route('requisites.index') }}"><span class="nav-icon-hexa">R</span>Rekvizitlar</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="#"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-envelope-o"></i></span>Xabarlar</a>
        <ul>
            <li>
                <a href="{{ route('chat.index') }}"><span class="nav-icon-hexa">T</span>Kelgan xabarlar</a></li>
            <li>
                <li>
                    <a href="{{action('Admin\ChatController@send',[])}}"><span class="nav-icon-hexa">T</span>Jo'natilgan
                        xabarlar</a>
                </li>
            <li>
        </ul>
    </li>
     		<li>
                <a href="#"><span class="nav-icon-hexa" style="color: white;">T</span>Yordam</a>
            </li>

    @endif

    @if(\Auth::user()->role==0)
    <li>
        <a href={{action('Admin\LessonController@index',[])}}><span class="nav-icon-hexa text-orange-100">
            <i class="fa fa-graduation-cap"></i></span>Mavzular</a>

    </li>


    @endif

</ul>