<div class="left-nav">
                <div class="app-nav">
                    <button>
                        <svg width="20" height="14" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 7H19"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M10 1L19 1"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M1 13H10"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                    <a href="home.html">
                        <img src="{{ asset('admin/style/images/glavni/iconstart.svg') }}" alt="#">
                    </a>
                </div>
                <div class="search">
                    <form action="home.html" class="search-content">
                        <div>
                            <button type="button">
                                <svg width="14" height="14" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9 17C13.4183 17 17 13.4183 17 9C17 4.58172 13.4183 1 9 1C4.58172 1 1 4.58172 1 9C1 13.4183 4.58172 17 9 17Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M19.0004 19L14.6504 14.65"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                        </div>
                        <div>
                            <input class="search-text" placeholder="Izlash" type="text"> 
                        </div>
                    </form>
                    <button class="app-search-close">
                        <svg width="12" height="12" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M13 1L1 13" stroke="#333333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M1 1L13 13" stroke="#333333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                </div>
                <!-- USER LANG BELLL -->
                <div class="user-lang">
                                    <!-- Bell -->
                    <div class="search-opener">
                        <button>
                            <svg width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9 17C13.4183 17 17 13.4183 17 9C17 4.58172 13.4183 1 9 1C4.58172 1 1 4.58172 1 9C1 13.4183 4.58172 17 9 17Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M19.0004 19L14.6504 14.65"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </div>
                    <div class="bell">
                        <button>
                            <svg width="16" height="16" viewBox="0 0 20 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M16 7C16 5.4087 15.3679 3.88258 14.2426 2.75736C13.1174 1.63214 11.5913 1 10 1C8.4087 1 6.88258 1.63214 5.75736 2.75736C4.63214 3.88258 4 5.4087 4 7C4 14 1 16 1 16H19C19 16 16 14 16 7Z" stroke="#333333" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M11.7295 20C11.5537 20.3031 11.3014 20.5547 10.9978 20.7295C10.6941 20.9044 10.3499 20.9965 9.99953 20.9965C9.64915 20.9965 9.30492 20.9044 9.0013 20.7295C8.69769 20.5547 8.44534 20.3031 8.26953 20" stroke="#333333" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                        </button>
                    </div>
                    <!-- Lang -->
                    <div class="lang">
                        <p>O'zbekcha</p> <img src="{{ asset('admin/style/images/icons/dropdown.svg') }}" alt="AA">
      
                          <div class="lang-link">
                              <a href="#"><p>Руский</p></a>
                              <a href="#"><p>English</p></a>
                          </div>
                    </div>
                    <!-- User -->
                    <div class="user">
                        <button>
                            <div class="user-img">
                                <img class="img img-fluid" src="{{ asset('admin/style/images/users/user1.jpg') }}" alt="USER">
                            </div>
                            <p>Parpiyev Alisher</p>
                            <div class="user-icon">
                                <img src="{{ asset('admin/style/images/icons/dropdown.svg') }}" alt="dropdown">
                            </div>
                        </but>
                    </div>
                </div>
                <!-- END USER LANG BELL -->
            </div>