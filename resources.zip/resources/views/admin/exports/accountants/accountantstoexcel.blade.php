<table class="table table-bordered table-hover">
    <thead>
    <tr>
        <th style="width: 2%">#</th>
        <th>FIO</th>
        <th>Tug'ilgan sana</th>
        <th>Viloyat</th>
        <th>Tuman</th>
        <th>Filial</th>
        <th>Pasport</th>
        <th>Jinsi</th>
        <th>Telefon</th>
        <th>Manzil</th>
        <th>Tizimga qo'shdi</th>
        <th>Login</th>
        <th>Yaratilgan sana</th>
    </tr>
    </thead>
    <tbody>
    @php $i = 0; @endphp
    @foreach($data as $person)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $person->full_name }}</td>
            <td>{{ $person->birthdate }}</td>
            <td>{{ $person->branch->region->name_uz }}</td>
            <td>{{ $person->branch->area->name_uz }}</td>
            <td>{{ $person->branch->name_uz }}</td>
            <td>{{ $person->passport_info }}</td>
            <td>{{ $person->getGender() }}</td>
            <td>{{ $person->phone }}</td>
            <td>{{ $person->address }}</td>
            <td>{{ $person->getCreator() }}</td>
            <td>{{ $person->user->username }}</td>
            <td>{{ $person->created_at }}</td>
        </tr>
    @endforeach
    </tbody>
</table>