<table class="table table-bordered table-striped margin-bottom-10">
    <thead>
    <tr>
        <th style="width: 3%">#</th>
        <th>Ismi</th>
        <th>Familyasi</th>
        <th>Sharifi</th>
        <th>Tug'ilgan sana</th>
        <th>Jinsi</th>
        <th>Fuqaroligi</th>
        <th>Pasport seriya</th>
        <th>Pasport nomeri</th>
        <th>Kim tomonidan berigan</th>
        <th>Pasport berilgan sana</th>
        <th>Pasport amal qilish muddati</th>
        <th>Manzil</th>
        <th>Ta'liim turi</th>
        <th>Student ID</th>
        <th>Telefon1</th>
        <th>Telefon2</th>
        <th>Telefon3</th>
        <th>Xarbiy hujjat raqami</th>
        <th>Holati</th>
        <th>Filial nomi</th>
    </tr>
    </thead>
    <tbody>@php $i=0; @endphp
    @foreach($data->students as $student)
        @php $student = $student->student; @endphp
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $student->first_name }}</td>
            <td>{{ $student->last_name }}</td>
            <td>{{ $student->middle_name }}</td>
            <td>{{ $student->birth_date }}</td>
            <td>{{ $student->getGender() }}</td>
            <td>{{ $student->getCitizenship() }}</td>
            <td>{{ $student->passport_serial }}</td>
            <td>{{ $student->passport_number }}</td>
            <td>{{ $student->passport_issued_by }}</td>
            <td>{{ $student->passport_issued_date }}</td>
            <td>{{ $student->passport_expiration_date }}</td>
            <td>{{ $student->home_address }}</td>
            <td>{{ $student->getCourse()->name }}</td>
            <td>{{ $student->student_number }}</td>
            <td>{{ $student->phone1 }}</td>
            <td>{{ $student->phone2 }}</td>
            <td>{{ $student->phone3 }}</td>
            <td>{{ $student->military_doc_number }}</td>
            <td>{{ $student->getStatus() }}</td>
            <td>{{ $student->branch->name_uz }}</td>
        </tr>
    @endforeach
    </tbody>
</table>
