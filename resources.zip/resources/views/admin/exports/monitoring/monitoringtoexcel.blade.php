<table class="table table-bordered" id="decisions-form">
    <thead>
    <tr>
        <th style="width: 2%">#</th>
        <th style="width: 38%;text-align: center">FIO</th>
        @foreach($data->classDate as $lesson)
            <th class="clickable-row" title="Ushbu sana bo'yicha" style="cursor: pointer;text-align: center;font-size:10px;padding: 0" data-href="{{ route('schedule.show',['id'=>$lesson->id]) }}">
                <div style="background: blueviolet;color:white;border-radius: 50%;margin:5px;padding: 0">
                    {{ date("d",strtotime($lesson->start_time)) }}
                </div>
                {{ date("m/Y",strtotime($lesson->start_time)) }}
            </th>
        @endforeach
    </tr>
    </thead>
    <tbody class="text-thin" id="students">
    @php $i=1; @endphp
    @foreach($data->students as $student)
        @php $student = $student->student @endphp
        <tr>
            <td>{{ $i }}</td>
            <td>{{ $student->fio() }}</td>
            @foreach($data->classDate as $lesson)
                <td>
                    {{ $lesson->getAttendance($student->id) }}
                </td>
            @endforeach
            @php $i++; @endphp
        </tr>
    @endforeach
    </tbody>
</table>
