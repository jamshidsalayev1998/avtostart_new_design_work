@extends('layouts.admin')
@section('content')
<div class="container">
    <h3>Tizimga xush kelibsiz.</h3>
    <h4><span class="icon-bullhorn"></span>Tizim doimiy yangiliklar qo`shib takomillashtirib borilmoqda. takliflaringizni @ost_administrator telegramm manzili orqali jo`natishingiz mumkin</h4>
    <div class="row">
        @if(\Auth::user()->role==7)
        <div class="col-md-6">
            <div class="block">

                <div class="app-heading app-heading-small">
                    <div class="icon icon-lg">
                        <span class="icon-chart-bars"></span>
                    </div>
                    <div class="title">
                        <h2>RESPUBLIKA</h2>
                        <p>Viloyat rahbari filiallar va ularning rahbarlarini yaratadi.</p>
                    </div>
                </div>

                <div class="app-faq">

                    <div class="app-faq-item">
                        <div class="app-faq-item-title">Dastlab siz viloyat rahbarlarini yarating.</div>
                        <div class="app-faq-item-content">

                        </div>
                    </div>

                    <div class="app-faq-item">
                        <div class="app-faq-item-title">Viloyat rahbarlariga login va parol bering.</div>
                        <div class="app-faq-item-content">

                        </div>
                   </div>

                    <div class="app-faq-item">
                        <div class="app-faq-item-title">Ta'lim bilan bog'liq masalalar va kontentni shakllantiring</div>
                        <div class="app-faq-item-content">
                            <p></p>
                        </div>
                    </div>

                    <div class="app-faq-item">
                        <div class="app-faq-item-title">Filiallar va guruhlar ustida nazoratni amalga oshiring</div>
                        <div class="app-faq-item-content">
                            <p></p>
                        </div>
                    </div>

                    <div class="app-faq-item">
                        <div class="app-faq-item-title">Darsga qatnashish statistikalari bilan tanishining</div>
                        <div class="app-faq-item-content">
                            <p></p>
                        </div>
                        <div class="app-faq-item">
                            <div class="app-faq-item-title">Yillik choraklik oylik hisobotlarni elektron olishingiz mumkin</div>
                            <div class="app-faq-item-content">
                                <p></p>
                            </div>
                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Tizimlardan foydalanish ko`rsatkichi bilan tanishing </div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>

                        </div>
                        </div>
                        </div>

                    </div>
                </div>
                @endif
                @if(\Auth::user()->role>=6)
                <div class="col-md-6">
                    <div class="block">

                        <div class="app-heading app-heading-small">
                            <div class="icon icon-lg">
                                <span class="fa fa-building"></span>
                            </div>
                            <div class="title">
                                <h2 style="text-transform: uppercase">Viloyat rahbari</h2>
                                <p>Viloyatingizdagi filiallarni yarating va ularga rahbarlarni biriktiring.</p>
                            </div>
                        </div>

                        <div class="app-faq">

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Dastlab, filiallarni yarating.</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                    <p></p>
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Filial uchun rahbarni kiriting va tegishli filialga biriktiring.</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                    <p></p>
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Yaratilgan filiallar ustida nazoratni o'rnating</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Davomatlarni tekshirib boring</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>
                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Hisobotlar(to`lovlar, guruhlar soni va tizimlardan foydalanish ko`rsatkichi bilan tanishing</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>
                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Viloyat bo`yicha Filiallar kesimida test ko`rsatkichlari bilan tanishing </div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>

                        </div>
                        </div>


            </div>
            </div>
            @endif
            @if(\Auth::user()->role>=5)
            <div class="col-md-6">
                <div class="block">
                    <div class="app-heading app-heading-small">
                        <div class="icon icon-lg">
                            <span class="icon-car"></span>
                        </div>
                        <div class="title">
                            <h2 style="text-transform: uppercase">Filial rahbari</h2>
                            <p>Filial rahbari filialda mavjud xonalar, o`qituvchilar, amaliy boshqaruv ustalari, hisobchilar va o`zizga yordamchi bo`lgan moderatorlarni kiriting.</p>
                        </div>
                    </div>
                    <div class="app-faq">
                        <div class="app-faq-item">
                            <div class="app-faq-item-title">O`quvchilarni kiritish ularni o`zgartirish yoki o`quvchilarni o`chirish(agar guruhga biriktirilmagan bo`lsa) guruhga biriktirish shartnoma va arizalar chiqarishingiz mumkin</div>
                            <div class="app-faq-item-content">
                                <p></p>
                                <p></p>
                            </div>
                        </div>

                        <div class="app-faq">

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Guruhlar shakllantirish ularni o`zgartirish o`quvchilarni biriktirish imkoniyatiga egasiz</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                    <p></p>
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Guruhlar bo`yicha to`lovlar va yakuniy test tahlili bilan tanishishingiz mumkin</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                    <p></p>
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Guruhlarni shakllantirish va buyruq chiqarish</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Guruh yakunlanganida buyruqni chiqarish</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>

                        </div>
                        </div>

                    </div>
                </div>

                @endif
                @if(\Auth::user()->role >= 4)
                <div class="col-md-6">
                    <div class="block">

                        <div class="app-heading app-heading-small">
                            <div class="icon icon-lg">
                                <span class="icon-laptop"></span>
                            </div>
                            <div class="title">
                                <h2 style="text-transform: uppercase">Moderator</h2>
                                <p>Quyidagi harakatlarni bajarishingiz mumkin.</p>
                            </div>
                        </div>

                        <div class="app-faq">

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Tizimga o'quvchilarni kiritish</div>
                                <div class="app-faq-item-content">
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Guruhlarni shakllantirish</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Dars jadvallarini shakklantirish</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                    <p></p>
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Nazorat olish</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                    <p></p>
                                </div>
                            </div>

                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Ma'lumotlar oqimini nazorat qilish</div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>
                            <div class="app-faq-item">
                                <div class="app-faq-item-title">Monitoring o`tkazish </div>
                                <div class="app-faq-item-content">
                                    <p></p>
                                </div>
                            </div>



                        </div>


                    </div>
                </div>
                @endif
                @if(\Auth::user()->role >= 3)
                <div class="col-md-6">
                    <div class="block">

                        <div class="app-heading app-heading-small">
                            <div class="icon icon-lg">
                                <span class="icon-briefcase"></span>
                            </div>
                            <div class="title">
                                <h2 style="text-transform: uppercase">O'qituvchi</h2>
                                <p>Quyidagi harakatlarni bajarishingiz mumkin.</p>
                            </div>
                        </div>
                        <div class="app-faq">

                            <div class="app-faq">

                                <div class="app-faq-item">
                                    <div class="app-faq-item-title"> Siz <a href="{{ url('http://study.vatanparvar.uz')  }}"><span class="nav-icon-hexa text-orange-100"><i class="fa fa-graduation-cap"></i></span>Elektron o`quv qo`llanmadan</a> dars jarayonida bemalol foydalanishingiz mumkin.
                                Elektron o`quv qo`llanmada mavzular bo`yicha ma`lumotlar, video va rasmlar mavjud. Bundan tashqari elektron o`quv qo`llanmada mavzular bo`yicha testlar va shavlon testlar joylashtirilgan bo`lib o`z bilimlaringizni oshirishga xizmat qiladi
                                    </div>
                                    <div class="app-faq-item-content">

                                    </div>

                                </div>

                                <div class="app-faq-item">
                                    <div class="app-faq-item-title">Siz guruh uchun ma'sul bo'lasiz.
                                    	Sizga biriktirilgan guruhlarni baholashingiz davomatlarini olib borishinfgiz mumkin.

                                    </div>
                                    <div class="app-faq-item-content">
                                    </div>
                                </div>

                                <div class="app-faq-item">
                                    <div class="app-faq-item-title">Guruh darslarini olib borish. dars davomida elektron o`quv qo`llanmadan foydalaning</div>
                                    <div class="app-faq-item-content">
                                        <p></p>
                                    </div>
                                </div>

                                <div class="app-faq-item">
                                    <div class="app-faq-item-title">O'quvchilarning baholash va davomatini olib borish va doimiy aktiv guruhlarning dars jadvali bilan tanishishingiz mumkin </div>
                                    <div class="app-faq-item-content">
                                        <p></p>
                                        <p></p>
                                    </div>
                                </div>
                            </div>

                        </div>
                        </div>
                    </div>
                    @endif
                    @if(\Auth::user()->role >= 2)
                    <div class="col-md-6">
                        <div class="block">

                            <div class="app-heading app-heading-small">
                                <div class="icon icon-lg">
                                    <span class="fa fa-calculator"></span>
                                </div>
                                <div class="title">
                                    <h2 style="text-transform: uppercase">Hisobchi</h2>
                                    <p>Quyidagi harakatlarni bajarishingiz mumkin.</p>
                                </div>
                            </div>

                            <div class="app-faq">

                                <div class="app-faq-item">
                                    <div class="app-faq-item-title">O'quvchilar to'lovlari bilan ishlash. O`quvchilarni to`lovlarini kiritish. Xato kiritilgan to`lovlarni o`chirish ( kiritilgandan so`ng  24 soat davomida ) va kiritilgan to`lovlarni o`chirish (ma`lumot kiritilganidan so`ng 10 kun davomida). Hisobchidan boshqa hechkim to`lov kiritish huquqiga ega emasligini va to`lovlarini kiritmasangiz o`quvchilar yakuniy test topshirolmasligini yodda tuting</div>
                                    <div class="app-faq-item-content">
                                    </div>
                                </div>

                                <div class="app-faq-item">
                                    <div class="app-faq-item-title">O`qishdan chetlashtirilgan o`quvchilarni to`lovlarni qaytarish(agar ko`p to`lov amalga oshirgan bo`lsalar agar o`quvchi amalga oshirgan to`lovni barcha olib qolinadigan bo`lsa 0 so`m bilan chetlashtirishingiz mumkin) </div>
                                    <div class="app-faq-item-content">
                                        <p></p>
                                    </div>
                                </div>

                                <div class="app-faq-item">
                                    <div class="app-faq-item-title">Qarzdorlar to'grisida hisobotlar ko`rishi</div>
                                    <div class="app-faq-item-content">
                                        <p></p>

                                    </div>

                                    <div class="app-faq-item">
                                    <div class="app-faq-item-title">Guruhlarning to`lov holati haqida ma`lumotlarni bilan tanishishingiz, qarzdorlar to'grisida hisobotlar ko`rishi guruh va o`quvchilar bo`yicha hamda har bir o`quvchining to`lov tarixini ko`rishingiz mumkin </div>
                                    <div class="app-faq-item-content">

                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    @endif
                    <div class="col-md-12">
                        @if(\Auth::user()->role >= 1)
                        <div class="block">

                            <div class="app-heading app-heading-small">
                                <div class="icon icon-lg">
                                    <span class="icon-user"></span>
                                </div>
                                <div class="title">
                                    <h2 style="text-transform: uppercase">O'quvchi</h2>
                                    <p>Quyidagi harakatlarni bajarishingiz mumkin.</p>
                                </div>
                            </div>

                            <div class="app-faq">

                                <div class="app-faq-item">
                                    <div class="app-faq-item-title">Yaratilgan kontentlarni ko'rib chiqish</div>
                                    <div class="app-faq-item-content">
                                    </div>
                                </div>

                                <div class="app-faq-item">
                                    <div class="app-faq-item-title">Nazorat testlarini ishlash</div>
                                    <div class="app-faq-item-content">
                                        <p></p>
                                    </div>
                                </div>

                                <div class="app-faq-item">
                                    <div class="app-faq-item-title">Yakuniy testni topshirish</div>
                                    <div class="app-faq-item-content">
                                        <p></p>
                                        <p></p>
                                    </div>
                                </div>
                            </div>

                        </div>
                        @endif
                    </div>
                </div>

            </div>

            @endsection