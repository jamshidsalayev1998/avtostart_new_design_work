@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Ooops. Tizimga kirish uchun quyidagi linkni bosing!</div>

                    <div class="panel-body">
                        <a href="/login" class="btn btn-success">Tizimga kirish</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
