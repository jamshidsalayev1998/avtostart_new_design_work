@extends('layouts.app')

@section('content')
    <!-- START APP CONTAINER -->
    <div class="app-container" style="background: url({{ asset('extra/bg2.jpg') }}) center center no-repeat fixed;-webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;">
        <div style="text-align: center;padding:30px;">
            <h3 style="font-weight: bold;text-transform: uppercase;">Ўзлаштиришни кўтаришга йўллантирилган, ўқитишни мониторинг<br> килиш ва режалаштириш имконини берувчи<br>
                <span style="font-size: 23px;">автоматлаштирилган ахборот тизим</span></h3>
        </div>
        <div class="app-login-box" style="opacity: 0.9">
            <div class="app-login-box-title padding-top-10">
                <div style="text-align: center"><img src="{{ asset('extra/logoavtostart.png') }}" style="max-width: 100px;height: auto"/></div>
                <div class="title" style="font-weight: bold;color:black">Tizimga kirish</div>
                <div class="subtitle" style="font-weight: bolder;color: black;">Login va parolingizni kiriting</div>
            </div>
            <div class="app-login-box-container margin-top-20">
                <form action="{{ route('login') }}" method="post">
                    {{ csrf_field() }}
                    <div class="form-group {{ $errors->has('username') ? ' has-error' : '' }}">
                        <input type="text" class="form-control" style="border:1px solid blue" name="username" placeholder="Login" value="{{ old('username') }}" required autofocus>
                        @if ($errors->has('username'))
                            <span class="help-block">
                                <strong>{{ $errors->first('username') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="form-group {{ $errors->has('password') ? ' has-error' : '' }}">
                        <input type="password" class="form-control" style="border:1px solid blue" name="password" placeholder="Parol">
                        @if ($errors->has('password'))
                            <span class="help-block">
                                <strong>{{ $errors->first('password') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="form-group">
                        <button class="btn btn-success btn-block" style="color:white;opacity: 1">Tizimga kirish</button>
                    </div>
                </form>
            </div>
            <div class="app-login-box-footer">
                <strong> Boglanish uchun (71) 224-20-30</strong> <br>
                &copy; Barcha huquqlar himoyalangan.<br>{{ date('Y',time()) }}.Orient Software Team 
            </div>
        </div>

    </div>
    <!-- END APP CONTAINER -->
@endsection
