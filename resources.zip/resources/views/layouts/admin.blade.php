@if(Test\Model\Developing::where('status',1)->exists() && !Test\User::checkMyIP())
    @include('admin.include.developing')
    @php die() @endphp
@endif
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
    
    {{-- <link rel="stylesheet" href="{{ asset('admin/dist/css/bootstrap.css') }}"> --}}

    <link rel="stylesheet" href="{{ asset('admin/style/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/style/css/style.css') }}">   
    <link rel="stylesheet" href="{{ asset('admin/style/css/all.css') }}"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    {{-- <link rel="stylesheet" href="{{ asset('admin/js/vendor/dropify/dist/css/dropify.min.css') }}"> --}}
    {{-- <link rel="stylesheet" href="{{ asset('admin/css/styles.css') }}"> --}}
{{--     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css"> --}}
    <!-- EOF CSS INCLUDE -->

    @foreach(Route::getCurrentRoute() as $rout)

@if($rout=="backoffice/decision/decisionsindex")
<link rel="stylesheet" href="{{ asset('admin/dist/css/bootstrap.css') }}">
<link rel="stylesheet" href="{{ asset('admin/dist/css/main.css') }}">
<link rel="stylesheet" href="{{ asset('admin/dist/dist/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('admin/dist/css/bootstrap-theme.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/dist/css/bootstrap-theme.min.css') }}">
 @endif
   @endforeach

      @foreach(Route::getCurrentRoute() as $rout)
@if($rout=="backoffice/decisions")
<link rel="stylesheet" href="{{ asset('admin/dist/css/bootstrap.css') }}">
<link rel="stylesheet" href="{{ asset('admin/dist/css/main.css') }}">
<link rel="stylesheet" href="{{ asset('admin/dist/dist/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('admin/dist/css/bootstrap-theme.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/dist/css/bootstrap-theme.min.css') }}">
 @endif
   @endforeach



</head>
<body>
<div class="all">
        <!-- Nav all div ni ichida joylashadi  -->
        <div class="nav">

            <ul class="nav-icon">
                <li>
                    <button class="nav-opener">
                        <svg width="20" height="14" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 7H19"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M10 1L19 1"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M1 13H10"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                        <a href="#"><img src="{{ asset('admin/style/images/glavni/iconstart.svg') }}" alt="#"></a>
                </li>
            </ul>
            <!-- NAV SCROLL -->
            <div class="nav-scroll">
                <div class="scroll-type">
                <ul class="linkes">
                    @include('admin.include.menu2')
                </ul>
                </div>
            </div>
            <!-- END NAV SCROLL -->
        </div>
        <!-- END NAv -->
        <div class="left">
            <!-- LEFT NAv -->
            @include('admin.include.header2')
            <!-- END LEFT NAV -->
            <!-- LEFT Content -->
            <div class="left-content">
                @yield('content')
            </div>
            <!-- END LEFT CONTENT -->
        </div>
        <!-- END LEFT -->
    </div>
  {{--     <div class="loader show">
          <div class="loader-item">
              <img src="{{ asset('admin/style/images/glavni/loader-img.svg') }}" alt="AAA">
          </div>
      </div> --}}


<!-- page js end-->

    {{-- <script src="{{ asset('admin/style/js/tinymce.min.js') }}"></script> --}}
    <script src="{{ asset('admin/style/js/jquery.js') }}"></script>
    <script src="{{ asset('admin/style/js/main.js') }}"></script>

    @yield('js')


<script type="text/javascript" src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/jquery/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/jquery/jquery-ui.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/bootstrap/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/moment/moment.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/customscrollbar/jquery.mCustomScrollbar.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/bootstrap-datetimepicker/bootstrap-datetimepicker.js') }}"></script>

<script type="text/javascript" src="{{ asset('admin/js/vendor/datatables/jquery.dataTables.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/datatables/dataTables.bootstrap.min.js')}}"></script>

<script type="text/javascript" src="{{ asset('admin/js/app.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/app_plugins.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/app_demo.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/app_demo_dashboard.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/dropify/dist/js/dropify.min.js') }}"></script>

<script type="text/javascript" src="{{ asset('admin/js/vendor/form-validator/jquery.form-validator.min.js') }}"></script>


<script type="text/javascript" src="{{ asset('admin/js/vendor/bootstrap-select/bootstrap-select.js')}}"></script>

<script type="text/javascript" src="{{ asset('admin/js/vendor/bootstrap-daterange/daterangepicker.js')}}"></script>

<script type="text/javascript" src="{{ asset('admin/js/vendor/maskedinput/jquery.maskedinput.min.js')}}"></script>


<script type="text/javascript" src="{{ asset('admin/js/vendor/smartwizard/jquery.smartWizard.js')}}"></script>

<script type="text/javascript" src="{{ asset('admin/js/draganddrop/bala.DualSelectList.jquery.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/highlight/jquery.highlight.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/app_faq.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/sweetalert/sweetalert.min.js') }}"></script>
<!-- Scripts -->
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script> --}}

@if(Route::currentRouteName() == 'schedule.create' || Route::currentRouteName() == 'switch')
    {!! $calendar_details->script() !!}
    <script>
        $('#calendar').fullCalendar({
            timeFormat: 'H(:mm)' // uppercase H for 24-hour clock
        });
    </script>
@endif
@if(Route::currentRouteName() == 'student')
    <script type="text/javascript" src="{{ asset('admin/js/vendor/fullcalendar/fullcalendar.js') }}"></script>
    <script type="text/javascript" src="{{ asset('admin/js/app_demo_calendar.js') }}"></script>
@endif
@if(Route::currentRouteName() == 'lesson.show')
<script type="text/javascript" src="{{ asset('admin/js/vendor/nestable/jquery.nestable.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/noty/jquery.noty.packaged.js') }}"></script>
@endif
<script type="text/javascript" src="{{ asset('admin/js/albatross.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/defender.js') }}"></script>

<script type="text/javascript">
      var tableToExcel = (function() {
  var uri = 'data:application/vnd.ms-excel;base64,'
    , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
    , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
    , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
  return function(table, name) {
    if (!table.nodeType) table = document.getElementById(table)
    var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
    window.location.href = uri + base64(format(template, ctx))
  }
})()
</script>

   @foreach(Route::getCurrentRoute() as $rout)

   @if($rout=="backoffice/statistic")
{{-- <script type="text/javascript" src="{{ asset('admin/js/highcharts.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/exporting.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/export-data.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/printing.js') }}"></script> --}}
    @endif
      @endforeach


<script type="text/javascript" >
    $('#viloyatlar').change(function() {
    if ($(this).val() != '') {
        var _token = $('input[name="_token"]').val();
        var region_id = $(this).val();
        console.log(region_id);
        var url = '/backoffice/branch/gettuman/' + region_id;
        $.ajax({
            url: url,
            method: "GET",
            data: {
                _token: _token,
            },
            success: function(result) {
                var branches = JSON.parse(result);
                var html = '<option style="display:none">Tumanni tanlang</option>';
                $.each(branches, function(key, value) {
                    html = html + '<option value="' + value["name_kiril"] + '">' + value['name_kiril'] + '</option>';
                });

                $('#tumanlar').html(html);
            }
        });
    }
});

</script>

<script type="text/javascript" >
    $('body').click(function() {
        var d = new Date();
var year = d.getFullYear();
var month = d.getMonth();
var day = d.getDate();
var c = new Date(year + 10, month, day);

           var passport_issued_date = $('#passport_issued_date').val();
      if (passport_issued_date) {
        var year=parseInt(passport_issued_date.substring(6, 10));
        var month=parseInt(passport_issued_date.substring(3, 5))-1;
        var day=parseInt(passport_issued_date.substring(0, 2));
        var now=parseInt(passport_issued_date.substring(6, 10))+parseInt(10);
        var now_year=(month+now);

        if(month!="0"&&day=="1"){

              var c = new Date(year + 10, month-1, day-1);

        }
        if(month=="0"&&day=="1"){

            var c = new Date(year + 10, month, day-1);

      }
      else{
        var c = new Date(year + 10, month, day-1);
      }

      var  day1=c.getDate();
      var  month1=c.getMonth()+1;
      var  year1=c.getFullYear();

     if(day1<10){
                day1="0"+c.getDate();
      }
      if(month1<10){
                month1="0"+(c.getMonth()+1);

      }
           var year_all=c.getFullYear();
     var new_date=(day1+"-"+month1+"-"+year_all);



          $('#passport_expiration_date').val(new_date);
      }


});
    function checkTabPress(e)
    { var d = new Date();
var year = d.getFullYear();
var month = d.getMonth();
var day = d.getDate();
var c = new Date(year + 10, month, day);

           var passport_issued_date = $('#passport_issued_date').val();
      if (passport_issued_date) {
        var year=parseInt(passport_issued_date.substring(6, 10));
        var month=parseInt(passport_issued_date.substring(3, 5))-1;
        var day=parseInt(passport_issued_date.substring(0, 2));
        var now=parseInt(passport_issued_date.substring(6, 10))+parseInt(10);
        var now_year=(month+now);

        if(month!="0"&&day=="1"){

              var c = new Date(year + 10, month-1, day-1);

        }
        if(month=="0"&&day=="1"){

       var c = new Date(year + 10, month, day-1);

      }
      else{
        var c = new Date(year + 10, month, day-1);
      }

      var  day1=c.getDate();
      var  month1=c.getMonth()+1;
      var  year1=c.getFullYear();
     if(day1<10){
                day1="0"+c.getDate();
      }
      if(month1<10){
                month1="0"+(c.getMonth()+1);

      }
           var year_all=c.getFullYear();
     var new_date=(day1+"-"+month1+"-"+year_all);



          $('#passport_expiration_date').val(new_date);
      }}
  document.addEventListener('keyup', function (e) {
    checkTabPress(e);
}, false);


</script>


      @foreach(Route::getCurrentRoute() as $rout)

@if($rout=="backoffice/group/create")
<script>

$('#edu_type').change(function() {

    if ($(this).val() != '') {

        var course_id =($(this).val());
        var branch_id =($(this).data('branch_id'));
           var course_id =($('#edu_type').val());
           var group_name =($('#name_uz').val());
           var splits = group_name.split('-', 3);
           var group_count=(splits[0]);
           var year=(splits[2]);

            if(course_id==1){
               var course_type="B(T)";
           }
           if(course_id==2){
               var course_type="A(T)";
           }
            if(course_id==3){
               var course_type="C(T)";
           }
            if(course_id==4){
               var course_type="BC(T)";
           }
            if(course_id==5){
               var course_type="D(KT)";
           }
            if(course_id==6){
               var course_type="CE(KT)";
           }
            if(course_id==7){
               var course_type="BE(KT)";
           }
            if(course_id==8){
               var course_type="C(KT)";
           }
            if(course_id==9){
               var course_type="D(E)";
           }
            if(course_id==10){
               var course_type="MO";
           }

          $('#name_uz').val(group_count+"-"+course_type+"-"+year);



        var branch_id =($('#edu_type').data('branch_id'));
        var url2 = '/backoffice/price/branchprice/'+ course_id;
        $.ajax({
            url: url2,
            method: "GET",

            success: function(result) {
                var branches = JSON.parse(result);
                $.each(branches, function(key, value) {
                    var price=( value["price"]);
                    $('#branch_price').val(price);
                });

            }
        });
    }
});


        var course_id =($('#edu_type').val());
        var branch_id =($('#edu_type').data('branch_id'));
        var url2 = '/backoffice/price/branchprice/'+ course_id;
        $.ajax({
            url: url2,
            method: "GET",

            success: function(result) {
                var branches = JSON.parse(result);
                $.each(branches, function(key, value) {
                    var price=( value["price"]);
                    $('#branch_price').val(price);
                });

            }
        });
</script>
 @endif
   @endforeach

{{-- @if(Route::currentRouteName() == 'addcontent' || Route::currentRouteName() == 'content.edit')
    <script src="{{ asset('admin/js/vendor/tinymce/tinymce.min.js') }}"></script>
    <script src="{{ asset('admin/js/vendor/summernote/summernote.min.js') }}"></script>

    <!-- page javascript begin-->
    @yield('javascript')
    <!-- page js end-->

    <script type="text/javascript">

        tinymce.init({
            selector: '.editor-base',
            height: 400,
            menubar: false,
            toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
            skin_url: "{{ asset('admin/css/vendor/tinymce') }}",
            content_css: "{{ asset('admin/css/vendor/tinymce/content-style.css') }}"
        });

        tinymce.init({
            selector: '.editor-full',
            height: 400,
            plugins: [
                'advlist autolink lists link image charmap print preview hr anchor pagebreak',
                'searchreplace wordcount visualblocks visualchars code fullscreen',
                'insertdatetime media nonbreaking save table contextmenu directionality',
                'emoticons template paste textcolor colorpicker textpattern imagetools'
            ],
            toolbar1: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
            toolbar2: 'print preview media | forecolor backcolor emoticons',
            image_advtab: true,
            skin_url: "{{ asset('admin/css/vendor/tinymce') }}",
            content_css: "{{ asset('admin/css/vendor/tinymce/content-style.css') }}"
        });

        $(document).ready(function(){
            $('.editor-summernote').summernote({
                height: 400,
                toolbar: [
                    // [groupName, [list of button]]
                    ['style', ['bold', 'italic', 'underline', 'clear']],
                    ['font', ['strikethrough', 'superscript', 'subscript']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['insert', ['picture','link','video']]
                ]
            });

            $(window).resize();
        });
    </script>
@endif --}}

<script>
    $('.student_id').change(function(){
        if($(this).val()!='')
        {
            var student_id = $(this).val();
            var _token = $('input[name="_token"]').val();
            $.ajax({
                url: "/backoffice/payment/fetch/"+student_id,
                method: "GET",
                data: {
                    student_id: student_id,
                    _token: _token,
                },
                success: function(result){
                    $('#student_info').html(result);
                }
            })
        }
    });
    $(document).ready(function(){
        $("input.add-member:checkbox").click(function(){
            if ($(this).is(':checked')) {
                $('#counter-add').val(parseInt($('#counter-add').val())+1);
            }
            else {
                $('#counter-add').val(parseInt($('#counter-add').val())-1);
                $('input.add-member:not(:checked)').removeAttr('disabled');
            }
            var count = $('#counter-add').val();
            var members = $('#members').val();

            $('#countstudents').text(count-members);
            if(count>=25) {
                swal('25', 'Ko\'pi bilan 25 ta o\'quvchi qo\'sha olasiz !', 'success');
                $('input.add-member:not(:checked)').attr('disabled', 'disabled');
            }

        });

        $("input.remove-member:checkbox").click(function(){
            if ($(this).is(':checked')) {
                $('#counter-remove').val(parseInt($('#counter-remove').val())-1);
            }
            else {
                $('#counter-remove').val(parseInt($('#counter-remove').val())+1);
                $('input.remove-member:not(:checked)').removeAttr('disabled');
            }
            var count = $('#counter-remove').val();
            var members = $('#members').val();

            $('#countstudents').text(count-members);
            if(count<=15) {
                swal('15', 'Guruhda kamida 15 ta o\'quvchi bo\'lishi kerak!', 'warning');
                $('input.remove-member:not(:checked)').attr('disabled', 'disabled');
            }

        });
        $('#add-button').click(function () {
            $('ul li:not(:first):not(:last)').remove();
            var count = $('#counter').val();
            var members = $('#members').val();
            $('#countstudents').text(count-members);
        });
    });
    $(".clickable-row").on('click',function () {
        window.location = $(this).data("href");
    });
</script>
<script type="text/javascript">
    $(document).ready(function(){
        @if(Route::currentRouteName() == 'lesson.show')
        $("#nestable").nestable({group: 1});
        $("#nestable2").nestable({group: 1});
        $('#div').on('click', 'a', function(){
            return false;
        })

        $(".dd a").on("click", function(event) { // click event
            event.preventDefault();
            window.location = $(this).attr("href");
            return false;
        });
        @endif
  $('#address').change(function(){
            val= $('#manzil_val').val();
           if(val==0){
            $('#manzil_val').val("1");
           }
           if(val==1){
            $('#manzil_val').val("0");
           }
           });
        $('.group-select').change(function(){
            if($(this).val()!='')
            {
                var group_id = $(this).val();
                var _token = $('input[name="_token"]').val();
                var url = '{{ route('groupfetch',['id'=> ':id']) }}';
                var type = $('.group-select option:selected').data('type');
                var room = $('.group-select option:selected').data('room');
                var start_date = $('.group-select option:selected').data('start_date');
                var end_date = $('.group-select option:selected').data('end_date');
                var teacher = $('.group-select option:selected').data('teacher');
                //var assistant = $('.group-select option:selected').data('assistant');
                var count_st = $('.group-select option:selected').data('count_st');

                url = url.replace(':id', group_id);
                room = room['name'];
                if(room == null)
                    room = "";
                $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        group_id: group_id,
                        _token: _token,
                    },
                    success: function(result){
                        $('#students').html(result);
                        document.getElementById('group_name').innerHTML = $('.group-select option:selected').text();
                        document.getElementById('group_type').innerHTML = type;
                        document.getElementById('group_name2').innerHTML = $('.group-select option:selected').text();
                        document.getElementById('number').innerHTML = count_st;
                        document.getElementById('room').innerHTML = room;
                        document.getElementById('start_date').innerHTML = start_date;
                        document.getElementById('end_date').innerHTML = end_date;
                        document.getElementById('teacher').innerHTML = teacher;
                        //document.getElementById('assistant').innerHTML = assistant;
                        document.getElementById('teacher2').innerHTML = teacher;
                        document.getElementById('guruh_id').value = group_id;
                    }
                })
            }
        });
        $('#app-russian').click(function () {
            $('#app-radio-2').attr('disabled',true);
            $('#app-radio-3').attr('disabled',true);
        });
        $('#app-uzbek').click(function () {
            $('#app-radio-2').attr('disabled',false);
            $('#app-radio-3').attr('disabled',false);
        });

        $('.group-select').change(function(){
            if($(this).val()!='')
            {
                var group_id = $(this).val();
                var _token = $('input[name="_token"]').val();
                var url = '{{ route("groupfetch",["id"=> ":id"]) }}';
                var type = $('.group-select option:selected').data('type');
                var room = $('.group-select option:selected').data('room');
                var start_date = $('.group-select option:selected').data('start_date');
                var end_date = $('.group-select option:selected').data('end_date');
                var teacher = $('.group-select option:selected').data('teacher');
                //var assistant = $('.group-select option:selected').data('assistant');
                var count_st = $('.group-select option:selected').data('count_st');

                url = url.replace(':id', group_id);
                room = room['name'];
                if(room == null)
                    room = "";
                $.ajax({
                    url: url,
                    method: "GET",
                    data: {
                        group_id: group_id,
                        _token: _token,
                    },
                    success: function(result){
                        $('#students').html(result);
                        document.getElementById('group_name').innerHTML = $('.group-select option:selected').text();
                        document.getElementById('group_type').innerHTML = type;
                        document.getElementById('group_type2').innerHTML = type;
                        document.getElementById('group_name2').innerHTML = $('.group-select option:selected').text();
                        document.getElementById('room').innerHTML = room;
                        document.getElementById('start_date').innerHTML = start_date;
                        document.getElementById('end_date').innerHTML = end_date;
                        document.getElementById('teacher').innerHTML = teacher;
                        document.getElementById('number').innerHTML = count_st;
                        document.getElementById('teacher2').innerHTML = teacher;
                        document.getElementById('guruh_id').value = group_id;
                    }
                })
            }
        });
    });
</script>

<script>
    $(document).ready(function(){
        $(".status").click(function(){
            var student_id = $(this).data('student');
            var class_id = $(this).data('class');
            var elem = $('#'+student_id+'s'+class_id);
            var val = $('#'+student_id+'s'+class_id).val();
            var val = parseInt(val,10);
            var val2 = (val+1)%2;
            elem.val(val2);
            if(val2 == 0) {
                $('#attendance'+student_id+'s'+class_id).removeClass('fa fa-check').addClass('fa fa-times text-danger');
            }
            if(val2 == 1) {
                $('#attendance'+student_id+'s'+class_id).removeClass('fa fa-times text-danger').addClass('fa fa-check');
            }
        });
        $(".studentjon").mouseover(function () {
            $(this).css('background-color','yellow');
        })
        $(".studentjon").mouseleave(function () {
            $(this).css('background-color','white');
        })
        $(".hoverjon").on('mouseover',function () {
            $(this).css('background-color','skyblue');
        })
        $(".hoverjon").on('mouseleave',function () {
            $(this).css('background-color','white');
        })
        $('.lessonshower').click(function () {
            var lesson_id = $(this).data('idec');
            var _token = $('input[name="_token"]').val();
            url = '{{ route('lesson.edit',['id'=>':id']) }}';
            url = url.replace(':id', lesson_id);
            $.ajax({
                url: url,
                method: "GET",
                data: {
                    lesson_id: lesson_id,
                    _token: _token,
                },
                success: function(result){
                    var jsonObject = JSON.parse(result);
                    var id = jsonObject['id'];
                    var name_uz = jsonObject['name_uz'];
                    var name_ru = jsonObject['name_ru'];
                    var form = $('#edit-lesson-form');
                    var action = '{{ route('lesson.update',['id'=>':id']) }}';
                    action = action.replace(':id', id);
                    form.attr('action',action);
                    $('input[id="name_uz_edit"]').val(name_uz);
                    $('input[id="name_ru_edit"]').val(name_ru);
                }
            })
        });
        $('.topicshower').click(function () {
            var topic_id = $(this).data('idec');
            var _token = $('input[name="_token"]').val();
            url = '{{ route('topics.edit',['id'=>':id']) }}';
            url = url.replace(':id', topic_id);
            $.ajax({
                url: url,
                method: "GET",
                data: {
                    topic_id: topic_id,
                    _token: _token,
                },
                success: function(result){
                    var jsonObject = JSON.parse(result);
                    var id = jsonObject['id'];
                    var name_uz = jsonObject['name_uz'];
                    var name_ru = jsonObject['name_ru'];
                    var hours = jsonObject['hours'];
                    var lesson = jsonObject['lesson']['name_uz'];
                    var lesson_id = jsonObject['lesson']['lesson_id'];
                    var type = jsonObject['type'];
                    var form = $('#edit-topic-form');
                    var action = '{{ route('topics.update',['id'=>':id']) }}';
                    action = action.replace(':id', id);
                    form.attr('action',action);
                    $('input[id="name_uz_edit"]').val(name_uz);
                    $('input[id="name_ru_edit"]').val(name_ru);
                    $('input[id="hours_edit"]').val(hours);
                    html = '<option selected value="'+lesson_id+'">'+lesson+'</option>';
                    $('#lesson_edit').html(html);
                    if(type == 1)
                    {
                            $('#topic-type-edit1').prop('checked',true);
                    }
                    if(type == 2)
                    {
                            $('#topic-type-edit2').prop('checked',true);
                    }
                }
            })
        });
        $('.addtopic').click(function () {
            var lesson_id = $(this).data('idec');
            var _token = $('input[name="_token"]').val();
            var name = $(this).data('name');
            var elem = $('#current-topic');
            elem.text(name);
            elem.val(lesson_id);
            url = '{{ route('gettopics',['id'=>':id']) }}';
            url = url.replace(':id', lesson_id);
            $.ajax({
                url: url,
                method: "GET",
                data: {
                    _token: _token,
                },
                success: function(result){
                    var topics = JSON.parse(result);
                    var html = '<option value="0" style="color:blue">Eng boshida</option>';
                    $.each( topics, function( key, value ) {
                        html = html+'<option selected value="'+value["tp_order"]+'">'+value['name_uz']+'</option>';
                    });
                    $('#t_order').html(html);
                }
            })
        });
        $('#starting_time').datetimepicker({
            format : 'DD/MM/YYYY HH:mm'
        });
        $("#agree1").change(function() {
            if(this.checked) {
                $('#startbutton1').css('display','block');
            }
            else $('#startbutton1').css('display','none');

        });
        $("#show_password").change(function() {
            var old_password = $('#old_password');
            var new_password = $('#new_password');
            var elem3 = $('#repeat');
            elem3.type='text';
            if (old_password.type === "password") {
                old_password.type = "text";
            } else {
                old_password.type = "password";
            }

            if (elem3.type === "password") {
                elem3.type = "text";
            } else {
                elem3.type = "password";
            }
            if (new_password.type === "password") {
                new_password.type = "text";
            } else {
                new_password.type = "password";
            }
        });
    });
</script>
<script>
    $(document).ready(function(){
        @if(Route::currentRouteName() == 'support.index')
            function messages() {
            var receiver_id = $('#message').data('receiver');
            var sender_id = '{{ \Auth::user()->id }}';
            var _token = $('input[name="_token"]').val();
            var url = '{{ route('support.messages') }}';
            $.ajax({
                url: url,
                method: "POST",
                data: {
                    _token: _token,
                    receiver_id: receiver_id,
                },
                success: function (result) {
                    var messages = JSON.parse(result);
                    var html = '';
                    $.each( messages, function( key, value ) {
                        if('{{ \Auth::user()->id }}' == value['sender_id']) {
                            html = html + '<div class="messages-item"> <div class="user">';
                            if ('{{ \Auth::user()->image }}' === null)
                                img = '<img src="/admin/img/user/no-image.png" alt="">';
                            else
                                img = '<img src = "{{ asset(\Auth::user()->image) }}"/>';
                            html = html + img + '</div> <div class="text" style="background:whitesmoke;color:black;border:1px solid whitesmoke">' + value['message'] + '</div> <div class="date">Sunday, July 07, 2016 at 15:45</div> </div>';
                        }
                        if(value['sender_id'] == receiver_id) {
                            html = html + '<div class="messages-item inbox"> <div class="user">';
                            if ('{{ \Auth::user()->image }}' === null)
                                img = '<img src="/admin/img/user/no-image.png" alt="">';
                            else
                                img = '<img src = "/admin/img/user/no-image.png"/>';
                            html = html + img + '</div> <div class="text">' + value['message'] + '</div> <div class="date">Sunday, July 07, 2016 at 15:45</div> </div>';
                        }
                    });
                    $('#messages').html(html);
                }
            });
        }
        setInterval(function(){messages()}, 2000);
        setTimeout(function () {
            scrollToBottom();
        },2300);
        @endif
        $('.send-message').click(function(){
            var receiver_id = $('#message').data('receiver');
                var _token = $('input[name="_token"]').val();
                var message = $('#message').val();
                var url = '{{ route('support.send') }}';
                var check = message;
                check = check.replace(' ','');
                if(check.length>0) {
                    $.ajax({
                        url: url,
                        method: "POST",
                        data: {
                            _token: _token,
                            receiver_id: receiver_id,
                            message: message
                        },
                        success: function (result) {
                            $('#message').val('');
                            messages();
                            setTimeout(function () {
                                scrollToBottom();
                            },1000);
                        }
                    });
                }
        });
        function scrollToBottom() {
            $('#messages-content').scrollTop($('#messages-content')[0].scrollHeight);
        }
    });
    $('input.student-mark').on('input',function(e){
        if($(this).val() == 2 || $(this).val() == 3 || $(this).val() == 4 || $(this).val() == 5) {
            return 1;
        }
        else $(this).val('');
    });
    $(".submitting").on('click',function () {
        var student_id = $(this).data('student_id');
        var input = $('#is_submitted'+student_id);
        if(input.val() == 1) {
            $(this).html('<span class="fa fa-times text-danger"></span>');
            input.val('0');
            return 0;
        }
        if(input.val() == 0) {
            $(this).html('<span class="fa fa-check-circle text-success"></span>');
            input.val('1');
            return 0;
        }
    });

    $(".monitoring").on('click',function () {
        var student_id = $(this).data('student_id');
        var class_id = $(this).data('class_id');
        let input = $(this).children('span').attr('class');
        if(input == 'fa fa-check-circle text-success') {
            $(this).html('<span class="fa fa-times text-danger"></span>');
            $('#'+student_id+'d'+class_id).html('<input name="'+student_id+'s'+class_id+'" value="0">');
            return 0;
        } else {

            $(this).html('<span class="fa fa-check-circle text-success"></span>');
            $('#'+student_id+'d'+class_id).html('<input name="'+student_id+'s'+class_id+'" value="1">');
            return 0;
        }
    });
      $("#all_checked2").on('click',function () {

        $( ".monitoring" ).each(function( index ) {
        var student_id = $(this).data('student_id');
        var class_id = $(this).data('class_id');
        let input = $(this).children('span').attr('class');
        if(input == 'fa fa-check-circle text-success') {
            $(this).html('<span class="fa fa-times text-danger"></span>');
            $('#'+student_id+'d'+class_id).html('<input name="'+student_id+'s'+class_id+'" value="0">');
            return 0;
        } else {

            $(this).html('<span class="fa fa-check-circle text-success"></span>');
            $('#'+student_id+'d'+class_id).html('<input name="'+student_id+'s'+class_id+'" value="1">');
            return 0;
        }
      });

    });




    $('.group-decision').change(function(){
        if($(this).val()!='')
        {
            window.location = $('option:selected',this).data("href");
        }
    });
    $('.specific-date').click(function(){
        var id = $(this).data('idec');
        var _token = $('input[name="_token"]').val();
        var url = '{{ route("timetables.specificdate",["id"=>":id"]) }}';
        url = url.replace(':id', id);
        $.ajax({
            url: url,
            method: "GET",
            data: {
                _token: _token,
                id: id
            },
            success: function (result) {
                if(result != null) {
                    var jsonObject = JSON.parse(result);
                    var id = jsonObject['id'];
                    var day = jsonObject['day'];
                    var start_time = jsonObject['start_time'];
                    var duration = jsonObject['duration'];
                    $('#new_day').val(day);
                    $('#new_time').val(start_time);
                    $('#new_duration').val(duration);
                    var action = '{{ route('timetables.specificupdate',['id'=>':id']) }}';
                    action = action.replace(':id', id);
                    $('#specific-date-form').attr('action',action);
                }
                else alert('Ruxsat berilmadi!');
            }
        });
    });


    $('#pechat').change(function(){
        if($(this).val()!='')
        {
            var url = 'pechat';
            alert(url);
            $.ajax({
                url: url,
                method: "GET",
                data: {
                    _token: _token,
                },
                success: function (result) {
                    console.log(result);
                },
                error: function() {
                    alert('Error');
                }
            });
        }
    });
    $('#testsenddata').click(function(){
        let i = 1;
        var text = '{';
        while ($("#name-"+i).length) {
            if (i == 1)
                text += "\"1\":{\"name\":\""+$("#name-"+i).text()+"\", \"login\":\""+$("#pas-"+i).text()+"\"}";
            i ++;
        }
        text += "}";
        console.log(text);
        console.log($("#group").data('id'));
        var url = 'http://temp.triumf.uz/reg';
        alert(url);
        $.ajax({
            url: url,
            method: "GET",
            data: {
                category: $("#group").data('id'),
                list: text,
            },
            success: function (result) {
                result = JSON.parse(result);
                console.log(result);
                numbers.forEach(function myFunction(item, index) {
                    $("#par-"+index).text(item.password);
                });
                console.log(result);
            },
            error: function(xhr, status, error) {
                var err = eval("(" + xhr.responseText + ")");
                console.log(xhr);
                console.log(status);
                console.log(error);
            }
        });
    });
    $("#btnPrint").on("click", function () {
        var divContents = print;
        var printWindow = window.open('', '', 'height=400,width=800');
        printWindow.document.write('<html><head><title></title>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(divContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    });
    $('.marking-ball').click(function () {
        let student_id = $(this).data('student_id');
        let class_id = $(this).data('class_id');
        $(this).attr('class', '');
        let val = $(this).html().trim();
        if (val.length > 2)
            return;
        console.log(student_id+' '+class_id+' '+val);
        $(this).html('<input class="student-mark" style="width: 20px;height: 20px;" name="'+student_id+'s'+class_id+'" value="'+val+'">');
        // let input = $(this).children('span').attr('class');
        // if(input == 'fa fa-check-circle text-success') {
        //     $(this).html('<span class="fa fa-times text-danger"></span>');
        //     $('#'+student_id+'d'+class_id).html('<input name="'+student_id+'s'+class_id+'" value="0">');
        //     return 0;
        // } else {
        //
        //     $(this).html('<span class="fa fa-check-circle text-success"></span>');
        //     $('#'+student_id+'d'+class_id).html('<input name="'+student_id+'s'+class_id+'" value="1">');
        //     return 0;
        // }
    });
</script>
<script type="text/javascript">
    $('body').click(function() {



    var guvohnoma_count  = document.getElementById('guvohnoma_count').value;
    var count_1  = document.getElementById('count_1').value;

    var sum=parseInt(guvohnoma_count)+parseInt(count_1)-1;
    document.getElementById('count_2').value="";


    if(count_1){
            if(sum.toString().length==1){
            document.getElementById('count_2').value="000000"+sum;
            }
            if(sum.toString().length==2){
                document.getElementById('count_2').value="00000"+sum;
                }
                if(sum.toString().length==3){
                    document.getElementById('count_2').value="0000"+sum;
                    }
                    if(sum.toString().length==4){
                        document.getElementById('count_2').value="000"+sum;
                        }
                        if(sum.toString().length==5){
                            document.getElementById('count_2').value="00"+sum;
                            }
                            if(sum.toString().length==6){
                                document.getElementById('count_2').value="0"+sum;
                                }
                                if(sum.toString().length==7){
                                    document.getElementById('count_2').value=sum;
                                    }


    }



});
</script>
</body>
</html>