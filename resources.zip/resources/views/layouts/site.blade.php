<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" class="no-js">
<head>
    <title>whb home page</title>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- END META SECTION -->
    <!-- CSS INCLUDE -->
    <link rel="stylesheet" href="{{ asset('admin/js/vendor/dropify/dist/css/dropify.min.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/css/styles.css') }}">

</head>
<body>

<!-- APP WRAPPER -->
<div class="app">

    <!-- START APP CONTAINER -->
    <div class="app-container">
        <!-- START APP CONTENT -->
        <div class="app-content">
            @include('site.includes.header')

            <!-- START PAGE CONTAINER -->
            <div class="container container-boxed">
                @yield('content')
            </div>
            <!-- END PAGE CONTAINER -->

        </div>
        <!-- END APP CONTENT -->

    </div>
    <!-- END APP CONTAINER -->
</div>
<!-- END APP WRAPPER -->
<script type="text/javascript" src="{{ asset('admin/js/vendor/jquery/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/jquery/jquery-ui.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/bootstrap/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/moment/moment.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/customscrollbar/jquery.mCustomScrollbar.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/bootstrap-datetimepicker/bootstrap-datetimepicker.js') }}"></script>

<script type="text/javascript" src="{{ asset('admin/js/vendor/jvectormap/jquery-jvectormap.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/jvectormap/jquery-jvectormap-world-mill-en.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/jvectormap/jquery-jvectormap-us-aea-en.js') }}"></script>

<script type="text/javascript" src="{{ asset('admin/js/vendor/rickshaw/d3.v3.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/rickshaw/rickshaw.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/app.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/app_plugins.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/app_demo.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/app_demo_dashboard.js') }}"></script>
<script type="text/javascript" src="{{ asset('admin/js/vendor/dropify/dist/js/dropify.min.js') }}"></script>

<script type="text/javascript" src="{{ asset('admin/js/albatross.js') }}"></script>

</body>
</html>