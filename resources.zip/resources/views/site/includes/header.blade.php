@php
use Test\Model\Menu;
    $main_menu = Menu::where('parent_id','=','0')->where('status','=','1')->get();
    $lang = app()->getLocale();
    $name = "name_".$lang;
@endphp
<div class="app-header" style="margin-left: 100px;margin-right: 100px;">
    <ul class="app-header-buttons visible-mobile">
        <li><a href="#" class="btn btn-link btn-icon" data-header-navigation-toggle="true"><span class="icon-menu"></span></a></li>
    </ul>
    <a href="index.html" class="app-header-logo app-header-logo-light app-header-logo-condensed">Project</a>

    <div class="app-header-navigation" style="width: 90%">
            <div class="col-md-8 col-lg-8" style="border:1px solid red;">
                <nav>
                    <ul>
                        @foreach($main_menu as $menu)
                            <li><a href="{{ $menu->link }}">{{ $menu->$name }}</a></li>
                        @endforeach
                        @if(0)
                            <li class="open">
                                <a href="#">Sublevels</a>
                                <ul>
                                    <li><a href="#">Sublevel item 1</a></li>
                                    <li><a href="#">Sublevel item 2</a></li>
                                    <li><a href="#">Sublevel item 3</a></li>
                                    <li><a href="#">Sublevel item 4</a></li>
                                </ul>
                            </li>
                        @endif
                    </ul>
                </nav>
            </div>
            <div class="col-md-4 col-lg-4" style="border:1px solid red;">
                <ul class="app-header-buttons pull-right">
                    <li>
                        <div class="contact contact-rounded contact-bordered contact-lg contact-ps-controls">
                            <img src="/admin/img/user/no-image.png" alt="John Doe">
                            <div class="contact-container">
                                <a href="#">{{\Auth::user()->name}}</a>
                                <span>Administrator</span>
                            </div>
                            <div class="contact-controls">
                                <div class="dropdown">
                                    <button type="button" class="btn btn-default btn-icon" data-toggle="dropdown"><span class="icon-cog"></span></button>
                                    <ul class="dropdown-menu dropdown-left">
                                        <li><a href="#"><span class="icon-cog"></span> Settings</a></li>
                                        @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                                            <li><a href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}"><img src="/photos/lang/{{$localeCode}}.png" style="max-height: 22px;"> {{Menu::getLocaleName($localeCode)}}</a></li>
                                        @endforeach
                                        <li class="divider"></li>
                                        <li><a href="{{ route('logout') }}"
                                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                <span class="icon-exit-right"></span> Log Out
                                            </a>

                                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                                {{ csrf_field() }}
                                            </form></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
    </div>
</div>
<div class="app-header">
    <div class="container container-boxed">
        <div class="col-md-8" style="border:1px solid blue;">
            <div class="col-md-4">
                <a href="index.html" class="app-header-logo app-header-logo-light app-header-logo-condensed">Project</a>
            </div>
            <div class="col-md-8">
                <nav>
                <ul>
                    @foreach($main_menu as $menu)
                        <li><a href="{{ $menu->link }}">{{ $menu->$name }}</a></li>
                    @endforeach
                    @if(0)
                        <li class="open">
                            <a href="#">Sublevels</a>
                            <ul>
                                <li><a href="#">Sublevel item 1</a></li>
                                <li><a href="#">Sublevel item 2</a></li>
                                <li><a href="#">Sublevel item 3</a></li>
                                <li><a href="#">Sublevel item 4</a></li>
                            </ul>
                        </li>
                    @endif
                </ul>
            </nav>
            </div>
        </div>
        <div class="col-md-4">
            <ul class="app-header-buttons pull-right">
            <li>
                <div class="contact contact-rounded contact-bordered contact-lg contact-ps-controls">
                    <img src="/admin/img/user/no-image.png" alt="John Doe">
                    <div class="contact-container">
                        <a href="#">{{\Auth::user()->name}}</a>
                        <span>{{\Auth::user()->getRole()}}</span>
                    </div>
                    <div class="contact-controls">
                        <div class="dropdown">
                            <button type="button" class="btn btn-default btn-icon" data-toggle="dropdown"><span class="icon-cog"></span></button>
                            <ul class="dropdown-menu dropdown-left">
                                <li><a href="#"><span class="icon-cog"></span> Settings</a></li>
                                @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                                    <li><a href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}"><img src="/photos/lang/{{$localeCode}}.png" style="max-height: 22px;"> {{Menu::getLocaleName($localeCode)}}</a></li>
                                @endforeach
                                <li class="divider"></li>
                                <li><a href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <span class="icon-exit-right"></span> Log Out
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        {{ csrf_field() }}
                                    </form></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        </div>
    </div>
</div>