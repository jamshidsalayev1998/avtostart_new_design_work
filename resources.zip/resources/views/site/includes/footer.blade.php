<div class="app-footer app-footer-default" id="footer">

    <div class="container container-boxed">
        <div class="app-footer-line">
            <div class="copyright wide text-center">&copy; 2018 whb. Barcha huquqlar himoyalangan.</div>
        </div>
    </div>

</div>