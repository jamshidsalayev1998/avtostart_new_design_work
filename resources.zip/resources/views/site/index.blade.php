@extends('layouts.site')

@section('content')
    <div class="app-heading app-heading-bordered margin-top-0 margin-bottom-15">
        <div class="title">
            <h1>Business</h1>
            <p>A business, also known as an enterprise, agency or a firm.</p>
        </div>
        <div class="heading-elements">
            <ul class="breadcrumb">
                <li><a href="#">Home</a></li>
                <li><a href="#">Categories</a></li>
                <li class="active">Business</li>
            </ul>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 hidden-mobile">
            <div class="block block-condensed padding-top-20">
                <div class="block-content">

                    <h4 class="text-uppercase text-bold text-rg heading-line-below heading-line-below-short">Search</h4>
                    <div class="form-group margin-bottom-30">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Keywords...">
                            <div class="input-group-btn">
                                <button class="btn btn-default btn-icon" data-toggle="dropdown" aria-expanded="true"><span class="fa fa-cog"></span></button>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="#"><div class="app-checkbox"><label><input type="checkbox" name="ac-1" checked> Search by tags</label></div></a>
                                    </li>
                                    <li>
                                        <a href="#"><div class="app-checkbox"><label><input type="checkbox" name="ac-2" checked> Search in text</label></div></a>
                                    </li>
                                    <li>
                                        <a href="#"><div class="app-checkbox"><label><input type="checkbox" name="ac-3"> Search in comments</label></div></a>
                                    </li>
                                    <li>
                                        <a href="#"><div class="app-checkbox"><label><input type="checkbox" name="ac-4"> Ignore page name</label></div></a>
                                    </li>
                                </ul>
                                <button class="btn btn-default">Search</button>
                            </div>
                        </div>
                    </div>

                    <h4 class="text-uppercase text-bold text-rg heading-line-below heading-line-below-short">Categories</h4>

                    <div class="list-group list-group-noborder">
                        <a href="#" class="list-group-item active">Phasellus et velit ac lectus</a>
                        <a href="#" class="list-group-item">Vestibulum ante ipsum primis</a>
                        <a href="#" class="list-group-item">Maecenas semper</a>
                        <a href="#" class="list-group-item">Cum sociis natoque penatibus</a>
                        <a href="#" class="list-group-item">Morbi porta metus</a>
                    </div>


                    <div class="pull-left wide margin-bottom-30">
                        <ul class="nav nav-tabs nav-justified">
                            <li class="active"><a href="#tab-business" data-toggle="tab" aria-expanded="true">Business</a></li>
                            <li class=""><a href="#tab-economics" data-toggle="tab" aria-expanded="false">Economics</a></li>
                        </ul>
                        <div class="tab-content tab-content-bordered">
                            <div class="tab-pane active" id="tab-business">

                                <div class="listing margin-bottom-0">
                                    <div class="listing-item margin-bottom-10">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="assets/images/preview/img-2.jpg" class="img-responsive">
                                            </div>
                                            <div class="col-md-7">
                                                <a href="#">Maecenas consequat quis quam non convallis</a>
                                                <p class="text-muted">July 11, 2016 11:38</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="listing-item margin-bottom-10">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="assets/images/preview/img-3.jpg" class="img-responsive">
                                            </div>
                                            <div class="col-md-7">
                                                <a href="#">In placerat velit quis velit tincidunt</a>
                                                <p class="text-muted">July 11, 2016 11:38</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="listing-item margin-bottom-10">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="assets/images/preview/img-4.jpg" class="img-responsive">
                                            </div>
                                            <div class="col-md-7">
                                                <a href="#">Etiam iaculis justo scelerisque tonerpous</a>
                                                <p class="text-muted">July 11, 2016 11:38</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="listing-item margin-bottom-10">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="assets/images/preview/img-5.jpg" class="img-responsive">
                                            </div>
                                            <div class="col-md-7">
                                                <a href="#">Curabitur porta, lectus sit amet dapibus sagittis</a>
                                                <p class="text-muted">July 11, 2016 11:38</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="listing-item">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="assets/images/preview/img-6.jpg" class="img-responsive">
                                            </div>
                                            <div class="col-md-7">
                                                <a href="#">Aenean dignissim erat et urna sollicitudin</a>
                                                <p class="text-muted">July 11, 2016 11:38</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane" id="tab-economics">

                                <div class="listing margin-bottom-0">
                                    <div class="listing-item margin-bottom-10">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="assets/images/preview/img-6.jpg" class="img-responsive">
                                            </div>
                                            <div class="col-md-7">
                                                <a href="#">In placerat velit quis velit tincidunt</a>
                                                <p class="text-muted">July 11, 2016 11:38</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="listing-item margin-bottom-10">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="assets/images/preview/img-7.jpg" class="img-responsive">
                                            </div>
                                            <div class="col-md-7">
                                                <a href="#">Maecenas consequat quis quam non convallis</a>
                                                <p class="text-muted">July 11, 2016 11:38</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="listing-item margin-bottom-10">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="assets/images/preview/img-8.jpg" class="img-responsive">
                                            </div>
                                            <div class="col-md-7">
                                                <a href="#">Curabitur porta, lectus sit amet dapibus sagittis</a>
                                                <p class="text-muted">July 11, 2016 11:38</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="listing-item margin-bottom-10">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="assets/images/preview/img-9.jpg" class="img-responsive">
                                            </div>
                                            <div class="col-md-7">
                                                <a href="#">Aenean dignissim erat et urna sollicitudin</a>
                                                <p class="text-muted">July 11, 2016 11:38</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="listing-item">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <img src="assets/images/preview/img-10.jpg" class="img-responsive">
                                            </div>
                                            <div class="col-md-7">
                                                <a href="#">Etiam iaculis justo scelerisque tonerpous</a>
                                                <p class="text-muted">July 11, 2016 11:38</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="app-blog-banner">
                        <img src="assets/banners/default_300x600.jpg" alt="banner">
                    </div>

                </div>
            </div>

        </div>
        <div class="col-md-8">

            <div class="row app-blog-blocks">
                <div class="col-md-6">
                    <div class="tile-basic">
                        <div class="tile-image">
                            <a href="#"><img src="assets/images/news/business_1.jpg" alt=""></a>
                        </div>
                        <div class="tile-content">
                            <a href="#" class="tile-title">Aliquam tempor ligula</a>
                            <span class="tile-subtitle">22/05/2016 - 08 comments - John Doe</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In placerat velit quis velit tincidunt, ac feugiat lectus mattis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="tile-basic">
                        <div class="tile-image">
                            <a href="#"><img src="assets/images/news/sport_2.jpg" alt=""></a>
                        </div>
                        <div class="tile-content">
                            <a href="#" class="tile-title">Aliquam semper lectus tellus</a>
                            <span class="tile-subtitle">22/05/2016 - 08 comments - John Doe</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In placerat velit quis velit tincidunt, ac feugiat lectus mattis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="tile-basic">
                        <div class="tile-image">
                            <a href="#"><img src="assets/images/news/business_3.jpg" alt=""></a>
                        </div>
                        <div class="tile-content">
                            <a href="#" class="tile-title">Nulla tempus malesuada turpis</a>
                            <span class="tile-subtitle">22/05/2016 - 08 comments - John Doe</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In placerat velit quis velit tincidunt, ac feugiat lectus mattis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="tile-basic">
                        <div class="tile-image">
                            <a href="#"><img src="assets/images/news/sport_1.jpg" alt=""></a>
                        </div>
                        <div class="tile-content">
                            <a href="#" class="tile-title">Etiam iaculis justo scelerisque</a>
                            <span class="tile-subtitle">22/05/2016 - 08 comments - John Doe</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In placerat velit quis velit tincidunt, ac feugiat lectus mattis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="tile-basic">
                        <div class="tile-image">
                            <a href="#"><img src="assets/images/news/city_3.jpg" alt=""></a>
                        </div>
                        <div class="tile-content">
                            <a href="#" class="tile-title">Curabitur tortor nisi</a>
                            <span class="tile-subtitle">22/05/2016 - 08 comments - John Doe</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In placerat velit quis velit tincidunt, ac feugiat lectus mattis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="tile-basic">
                        <div class="tile-image">
                            <a href="#"><img src="assets/images/news/sport_3.jpg" alt=""></a>
                        </div>
                        <div class="tile-content">
                            <a href="#" class="tile-title">Maecenas tristique consectetur</a>
                            <span class="tile-subtitle">22/05/2016 - 08 comments - John Doe</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In placerat velit quis velit tincidunt, ac feugiat lectus mattis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="tile-basic">
                        <div class="tile-image">
                            <a href="#"><img src="assets/images/news/city_1.jpg" alt=""></a>
                        </div>
                        <div class="tile-content">
                            <a href="#" class="tile-title">Suspendisse consectetur</a>
                            <span class="tile-subtitle">22/05/2016 - 08 comments - John Doe</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In placerat velit quis velit tincidunt, ac feugiat lectus mattis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="tile-basic">
                        <div class="tile-image">
                            <a href="#"><img src="assets/images/news/business_2.jpg" alt=""></a>
                        </div>
                        <div class="tile-content">
                            <a href="#" class="tile-title">Pellentesque iaculis varius</a>
                            <span class="tile-subtitle">22/05/2016 - 08 comments - John Doe</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In placerat velit quis velit tincidunt, ac feugiat lectus mattis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="tile-basic">
                        <div class="tile-image">
                            <a href="#"><img src="assets/images/news/city_2.jpg" alt=""></a>
                        </div>
                        <div class="tile-content">
                            <a href="#" class="tile-title">Aliquam auctor lobortis</a>
                            <span class="tile-subtitle">22/05/2016 - 08 comments - John Doe</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In placerat velit quis velit tincidunt, ac feugiat lectus mattis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="tile-basic">
                        <div class="tile-image">
                            <a href="#"><img src="assets/images/preview/img-3.jpg" alt=""></a>
                        </div>
                        <div class="tile-content">
                            <a href="#" class="tile-title">In placerat velit quis velit tincidunt</a>
                            <span class="tile-subtitle">22/05/2016 - 08 comments - John Doe</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In placerat velit quis velit tincidunt, ac feugiat lectus mattis.</p>
                        </div>
                    </div>
                </div>
            </div>

            <nav>
                <ul class="pagination pagination-separated margin-bottom-20 pull-right">
                    <li class="disabled">
                        <a href="#" aria-label="Previous">
                            <span aria-hidden="true">«</span>
                        </a>
                    </li>
                    <li class="active"><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    <li>
                        <a href="#" aria-label="Next">
                            <span aria-hidden="true">»</span>
                        </a>
                    </li>
                </ul>
            </nav>

        </div>
    </div>
@endsection