<?php

return [

    'sign_up' => "Ro'yxatdan o'tish",
    'sign_in' => "Kirish"
];