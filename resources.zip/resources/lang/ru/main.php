<?php

return [

    'sign_up' => "Регистрация",
    'sign_in' => "Войти",

];